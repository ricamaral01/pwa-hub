# Template Base Reutilizavel do ERP

Estrutura extraida e desacoplada da base visual do ERP ConcreTrack para reaproveitamento em outros projetos.

## Estrutura

- `frontend/pages/index.html`: home base com modulos em cards.
- `frontend/pages/login.html`: tela de login pronta para integrar com sua API.
- `frontend/shared/header.html`: topo compartilhado carregado via JavaScript.
- `frontend/shared/footer.html`: rodape compartilhado.
- `static/css/theme.css`: identidade visual base.
- `static/js/template-config.js`: configuracao central do template.
- `static/js/app.js`: injecao de layout, navegacao e hooks opcionais de autenticacao.
- `static/js/login.js`: fluxo base de login.
- `static/js/clock.js`: relogio do header.
- `static/img/` e `static/fonts/`: assets reutilizaveis.

## Como usar

1. Copie a pasta inteira para o novo projeto.
2. Ajuste `static/js/template-config.js` com nome do sistema, links e endpoints.
3. Edite `frontend/shared/header.html` e `frontend/shared/footer.html` se quiser mudar a identidade.
4. Duplique `frontend/pages/index.html` para criar novas telas.
5. Se seu projeto nao tiver autenticacao, mantenha `requireAuth: false`.

## Integracao de autenticacao

O template expõe hooks opcionais:

- `window.erpTemplateConfig.auth.check()`
- `window.erpTemplateConfig.auth.login(payload)`
- `window.erpTemplateConfig.auth.logout()`

Se `requireAuth` estiver como `true`, o template chama `auth.check()` ao abrir paginas protegidas.

## Observacoes

- Os caminhos sao relativos e funcionam sem acoplamento ao prefixo `/concretrack`.
- O tema preserva a direcao visual do ERP original, mas remove dependencias especificas do produto.
- A fonte Gotham foi mantida porque ja existe no ERP original.
