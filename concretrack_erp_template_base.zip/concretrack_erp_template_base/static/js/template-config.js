window.erpTemplateConfig = {
  appName: "ERP Template",
  appSubtitle: "Base reutilizavel para operacoes, dashboards e cadastros",
  footerName: "ERP Template",
  logoPath: "../../static/img/logo-128.png",
  homeHref: "../../frontend/pages/index.html",
  loginPage: "../../frontend/pages/login.html",
  requireAuth: false,
  auth: {
    check: null,
    login: null,
    logout: null,
  },
  modules: [
    {
      title: "Dashboard",
      description: "Indicadores, paines executivos e leitura operacional em tempo real.",
      icon: "DT",
      href: "#",
      tone: "blue",
    },
    {
      title: "Cadastros",
      description: "Catalogos mestres, formularios e manutencao administrativa.",
      icon: "CD",
      href: "#",
      tone: "mag",
    },
    {
      title: "Gerenciador",
      description: "Configuracoes, perfis, rotinas e governanca do sistema.",
      icon: "GR",
      href: "#",
      tone: "cyan",
    },
    {
      title: "Relatorios",
      description: "Consultas operacionais, historico e exportacao de dados.",
      icon: "RL",
      href: "#",
      tone: "green",
    }
  ]
};
