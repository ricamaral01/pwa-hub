-- Espelho FALSO do ERP para testes (colunas conforme o inventário; a etapa 1 confirma as reais)
DROP SCHEMA IF EXISTS erp_espelho CASCADE;
CREATE SCHEMA erp_espelho;
CREATE TABLE erp_espelho.tbl_est_materiais (id int PRIMARY KEY, codigo text, nome text, categoria text, unidade text,
  saldo_inicial numeric, ativo boolean);
INSERT INTO erp_espelho.tbl_est_materiais VALUES
 (1,'ADD-FILL','Filler','adicao','t',0,true),
 (2,'CIM-CP-V','Cimento CP V-ARI','cimento','t',0,true),
 (3,'CIM-CP-II','Cimento CP II','cimento','t',0,true),
 (4,'ARE-MED','Areia média','areia','t',100,true),
 (5,'BRI-1','Brita 1','brita','t',0,true),
 (6,'ADT-PC','Aditivo 1 (PC)','aditivo','kg',0,true);
CREATE TABLE erp_espelho.tbl_est_silos (id int PRIMARY KEY, nome text, capacidade_nominal numeric,
  capacidade_operacional numeric, unidade text, ativo boolean);
INSERT INTO erp_espelho.tbl_est_silos VALUES (1,'Silo 1',60,48,'t',true),(2,'Silo 2',90,72,'t',true),(3,'Silo 3',108,108,'t',true);
CREATE TABLE erp_espelho.tbl_est_config_massada (id int PRIMARY KEY, coluna text, label text, material_id int,
  ativo boolean, ordem int, fator_conversao numeric);
INSERT INTO erp_espelho.tbl_est_config_massada VALUES
 (1,'real_silo1','Silo 1',2,true,1,0.001),(2,'real_silo2','Silo 2',2,true,2,0.001),(3,'real_silo3','Silo 3',3,true,3,0.001),
 (4,'real_agregado1','Areia',4,true,4,0.001),(5,'real_agregado2','Brita 1',5,true,5,0.001),(6,'real_aditivo1','Aditivo',6,true,6,1);
CREATE TABLE erp_espelho.tbl_est_movimentos (id int PRIMARY KEY, material_id int, tipo text, data date, quantidade numeric,
  origem text, referencia_id text, silo_id int, fornecedor text, valor_nota numeric, icms_perc numeric, valor_frete numeric,
  icms_frete numeric, valor_unitario_liquido numeric, observacao text);
INSERT INTO erp_espelho.tbl_est_movimentos VALUES
 (1,1,'entrada','2026-06-01',30,'manual',NULL,1,'Mineradora X',3000,12,0,0,88.0,NULL),
 (2,1,'consumo','2026-06-10',25,'producao_massadas',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
 (3,2,'entrada','2026-07-01',40,'manual',NULL,1,'Votorantim',24480,12,13.6,0,552.16,NULL),
 (4,2,'entrada','2026-10-01',20,'manual','77',1,'Votorantim',12240,12,0,0,538.56,NULL),
 (5,2,'entrada','2026-10-01',20,'manual','77',2,'Votorantim',12240,12,0,0,538.56,NULL),
 (6,2,'consumo','2026-10-02',30,'producao_massadas',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
 (7,2,'acerto','2026-10-03',-11.5,'manual',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,'Medição com trena [Contagem fisica: 45,5]'),
 (8,2,'consumo','2026-10-03',5,'producao_massadas',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
 (9,2,'consumo','2026-10-04',3,'producao_massadas',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
 (10,4,'entrada','2026-10-01',50,'manual',NULL,NULL,'Areal Tietê',5000,12,5.2,0,93.2,NULL),
 (11,4,'consumo','2026-10-02',20,'producao_massadas',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
 (12,4,'entrada','2099-01-01',10,'manual',NULL,NULL,'Areal Tietê',1000,0,0,0,100,NULL);
CREATE TABLE erp_espelho.tbl_massadas (id int PRIMARY KEY, data timestamp, codigo_traco text, volume numeric,
  real_silo1 numeric, real_silo2 numeric, real_silo3 numeric, real_agregado1 numeric, real_agregado2 numeric, real_aditivo1 numeric);
INSERT INTO erp_espelho.tbl_massadas VALUES
 (1,'2026-06-15 08:00','T25',1,300,0,0,0,0,0),
 (2,'2026-10-05 08:00','T25',1,0,390,0,472,750,3.04),
 (3,'2026-10-05 09:00','T25',1,0,390,0,470,752,3.10),
 (4,'2026-10-06 08:00','T25',2,0,760,0,944,1500,6.08);

-- Views que a migração real define sobre o espelho de tbl_massadas
CREATE OR REPLACE VIEW estoque.v_massada_leitura AS
SELECT (SELECT id FROM insumos.unidade WHERE nome = 'Campinas')::smallint AS unidade_id, m.data::date AS data,
       c.coluna, c.valor::numeric AS quantidade
  FROM erp_espelho.tbl_massadas m
  CROSS JOIN LATERAL (VALUES ('real_silo1', m.real_silo1), ('real_silo2', m.real_silo2), ('real_silo3', m.real_silo3),
                             ('real_agregado1', m.real_agregado1), ('real_agregado2', m.real_agregado2),
                             ('real_aditivo1', m.real_aditivo1)) c(coluna, valor)
 WHERE c.valor IS NOT NULL;
CREATE OR REPLACE VIEW estoque.v_massada_produto AS
SELECT (SELECT id FROM insumos.unidade WHERE nome = 'Campinas')::smallint AS unidade_id, m.data::date AS data,
       m.codigo_traco, m.volume::numeric AS volume_m3
  FROM erp_espelho.tbl_massadas m;
