-- =====================================================================
-- Carga Carta Traço: Google Sheets → PostgreSQL (rodada pelo importar_sheets.py, numa transação)
-- Pré-condição: carta_traco_stg.cadastro / custos / alias preenchidas.
-- Modo espelho: apaga cartas e a tabela de preços e recarrega. Catálogos (insumos) são preservados
-- e compartilhados com o Estoque: materiais novos entram, os existentes não são alterados.
-- =====================================================================
SET LOCAL search_path = carta_traco, insumos, public;
SET LOCAL app.sem_auditoria = 'on';

DO $$
BEGIN
  IF (SELECT valor FROM insumos.config WHERE chave = 'carta_fonte_oficial') = 'postgres' THEN
    RAISE EXCEPTION 'Corte já feito (carta_fonte_oficial = postgres). A carga do Sheets está bloqueada.';
  END IF;
END $$;

CREATE OR REPLACE FUNCTION pg_temp.norm(t text) RETURNS text LANGUAGE sql IMMUTABLE AS
$$ SELECT NULLIF(lower(regexp_replace(btrim(coalesce(t, '')), '\s+', ' ', 'g')), '') $$;

CREATE OR REPLACE FUNCTION pg_temp.grupo(t text) RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE
    WHEN t ~ '^(cimento|cp ?[iv])'                              THEN 'cimento'
    WHEN t ~ '(s[ií]lica|metacaulim|esc[oó]ria|f[ií]ler|cinza)' THEN 'adicao'
    WHEN t ~ '^(areia|p[oó] de pedra)'                           THEN 'areia'
    WHEN t ~ '^(brita|pedrisco|pedra|cascalho)'                  THEN 'brita'
    WHEN t ~ '^[aá]gua'                                          THEN 'agua'
    WHEN t ~ '^(aditivo|plastificante|superplast|retardador|acelerador|incorporador)' THEN 'aditivo'
    WHEN t ~ 'fibra'                                             THEN 'fibra'
    ELSE 'outro' END
$$;

TRUNCATE carta_traco.carta_item, carta_traco.carta, insumos.custo RESTART IDENTITY;

-- Unidades ------------------------------------------------------------
INSERT INTO unidade (nome)
SELECT DISTINCT ON (pg_temp.norm(u)) btrim(u)
  FROM (SELECT unidade u FROM carta_traco_stg.cadastro UNION ALL SELECT unidade FROM carta_traco_stg.custos) s
 WHERE pg_temp.norm(u) IS NOT NULL
ON CONFLICT (lower(nome)) DO NOTHING;

-- Fornecedores --------------------------------------------------------
INSERT INTO fornecedor (nome)
SELECT DISTINCT ON (pg_temp.norm(f)) regexp_replace(btrim(f), '\s+', ' ', 'g')
  FROM (SELECT fornecedor f FROM carta_traco_stg.cadastro UNION ALL SELECT fornecedor FROM carta_traco_stg.custos) s
 WHERE pg_temp.norm(f) IS NOT NULL AND btrim(f) NOT IN ('-', '—')
ON CONFLICT (lower(nome)) DO NOTHING;

-- Materiais: 1) nomes canônicos do mapa; 2) produtos das cartas; 3) apelidos; 4) materiais só de custos
INSERT INTO material (nome, grupo)
SELECT DISTINCT ON (pg_temp.norm(material)) btrim(material), coalesce(grupo, pg_temp.grupo(pg_temp.norm(material)))
  FROM carta_traco_stg.alias
ON CONFLICT (lower(nome)) DO NOTHING;

INSERT INTO material (nome, grupo)
SELECT DISTINCT ON (pg_temp.norm(produto)) regexp_replace(btrim(produto), '\s+', ' ', 'g'), pg_temp.grupo(pg_temp.norm(produto))
  FROM carta_traco_stg.cadastro c
 WHERE pg_temp.norm(produto) IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM material_alias a WHERE a.alias = pg_temp.norm(c.produto))
   AND NOT EXISTS (SELECT 1 FROM carta_traco_stg.alias a WHERE pg_temp.norm(a.alias) = pg_temp.norm(c.produto))
ON CONFLICT (lower(nome)) DO NOTHING;

INSERT INTO material_alias (alias, material_id)
SELECT pg_temp.norm(a.alias), m.id
  FROM carta_traco_stg.alias a JOIN material m ON lower(m.nome) = pg_temp.norm(a.material)
ON CONFLICT (alias) DO UPDATE SET material_id = EXCLUDED.material_id;

INSERT INTO material_alias (alias, material_id)
SELECT lower(nome), id FROM material
ON CONFLICT (alias) DO NOTHING;

-- custo de material que não existe em nenhuma carta (texto livre, achado A5): cria e o relatório aponta
INSERT INTO material (nome, grupo)
SELECT DISTINCT ON (pg_temp.norm(material)) regexp_replace(btrim(material), '\s+', ' ', 'g'), pg_temp.grupo(pg_temp.norm(material))
  FROM carta_traco_stg.custos s
 WHERE pg_temp.norm(material) IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM material_alias a WHERE a.alias = pg_temp.norm(s.material))
ON CONFLICT (lower(nome)) DO NOTHING;
INSERT INTO material_alias (alias, material_id)
SELECT lower(nome), id FROM material
ON CONFLICT (alias) DO NOTHING;

-- unidade de estoque padrão para materiais criados pela carga da carta (o Estoque pode corrigir)
UPDATE material SET un_estoque = CASE grupo WHEN 'aditivo' THEN 'kg' WHEN 'agua' THEN 'm3' WHEN 'fibra' THEN 'kg' ELSE 't' END
 WHERE codigo IS NULL AND un_estoque = 't' AND grupo IN ('aditivo','agua','fibra');

-- Cartas --------------------------------------------------------------
CREATE TEMP TABLE carga_carta ON COMMIT DROP AS
WITH grupos AS (
  SELECT legado_id, btrim(nome) AS nome, revisao, pg_temp.norm(unidade) AS un_n,
         max(status) AS status, max(vigencia) AS vigencia, max(cadastro) AS cadastro,
         max(observacao) AS observacao, max(tipo_frete) AS tipo_frete, max(linha) AS ultima_linha
    FROM carta_traco_stg.cadastro
   WHERE pg_temp.norm(nome) IS NOT NULL
   GROUP BY legado_id, btrim(nome), revisao, pg_temp.norm(unidade)
), dedup AS (     -- mesma carta+unidade+revisão gravada mais de uma vez: fica a última
  SELECT g.*, row_number() OVER (PARTITION BY lower(nome), un_n, revisao ORDER BY ultima_linha DESC) AS dup_rank
    FROM grupos g
), ativas AS (    -- mais de uma revisão ativa (achado A1): só a maior continua ativa
  SELECT d.*, CASE WHEN lower(coalesce(status, '')) = 'ativa'
                    AND row_number() OVER (PARTITION BY lower(nome), un_n,
                                           (lower(coalesce(status, '')) = 'ativa')
                                           ORDER BY revisao DESC) = 1
                   THEN 'Ativa' ELSE 'Inativa' END AS status_final
    FROM dedup d WHERE dup_rank = 1
)
SELECT a.*, u.id AS unidade_id FROM ativas a JOIN unidade u ON lower(u.nome) = a.un_n;

INSERT INTO carta (nome, revisao, unidade_id, status, vigencia, observacao, tipo_frete, criado_por, criado_em, legado_id)
SELECT nome, coalesce(revisao, 0), unidade_id, status_final,
       coalesce(vigencia, cadastro, current_date), observacao,
       CASE upper(btrim(tipo_frete)) WHEN 'CIF' THEN 'CIF' WHEN 'FOB' THEN 'FOB' END,
       'carga-sheets', coalesce(cadastro, vigencia, current_date)::timestamptz, legado_id
  FROM carga_carta
 ORDER BY revisao NULLS FIRST, ultima_linha;

INSERT INTO carta_item (carta_id, material_id, fornecedor_id, qtd_kg, massa_especifica, ordem)
SELECT DISTINCT ON (c.id, ma.material_id)
       c.id, ma.material_id, f.id, coalesce(s.quantidade, 0),
       coalesce(nullif(s.massa_especifica, 0), m.massa_especifica, 1), s.linha
  FROM carta_traco_stg.cadastro s
  JOIN carga_carta g ON g.legado_id IS NOT DISTINCT FROM s.legado_id AND g.nome = btrim(s.nome)
                    AND g.revisao IS NOT DISTINCT FROM s.revisao AND g.un_n = pg_temp.norm(s.unidade)
  JOIN carta c ON c.unidade_id = g.unidade_id AND lower(c.nome) = lower(g.nome) AND c.revisao = coalesce(g.revisao, 0)
  JOIN material_alias ma ON ma.alias = pg_temp.norm(s.produto)
  JOIN material m ON m.id = ma.material_id
  LEFT JOIN fornecedor f ON lower(f.nome) = pg_temp.norm(s.fornecedor)
 ORDER BY c.id, ma.material_id, s.linha;

-- massa específica padrão do catálogo = valor mais usado nas cartas
UPDATE material m SET massa_especifica = x.me
  FROM (SELECT material_id, mode() WITHIN GROUP (ORDER BY massa_especifica) AS me
          FROM carta_item GROUP BY material_id) x
 WHERE x.material_id = m.id AND m.massa_especifica IS NULL;

-- Custos --------------------------------------------------------------
INSERT INTO custo (unidade_id, fornecedor_id, material_id, un_medida, valor, icms_pct, frete, tipo_frete,
                   produto_fornecedor, vigente_desde, criado_por, legado_id, legado_valor_liquido)
SELECT u.id, f.id, ma.material_id, s.un_medida, coalesce(s.valor, 0), coalesce(s.icms_pct, 0), coalesce(s.frete, 0),
       CASE upper(btrim(s.tipo_frete)) WHEN 'CIF' THEN 'CIF' WHEN 'FOB' THEN 'FOB' END,
       s.produto_fornecedor, coalesce(s.data, current_date), 'carga-sheets', s.legado_id, s.valor_liquido
  FROM carta_traco_stg.custos s
  JOIN unidade u          ON lower(u.nome) = pg_temp.norm(s.unidade)
  JOIN fornecedor f       ON lower(f.nome) = pg_temp.norm(s.fornecedor)
  JOIN material_alias ma  ON ma.alias = pg_temp.norm(s.material)
 WHERE s.un_medida IS NOT NULL
 ORDER BY s.data NULLS FIRST, s.linha;   -- id crescente = ordem do append no Sheets
