-- =====================================================================
-- Estoque: espelho do ERP antigo → schema estoque (modo paralelo)
--
-- Origem: tabelas do ERP já espelhadas na VPS nova (supervisorio_db.public → schema `erp_espelho`).
-- ATENÇÃO: nomes de colunas abaixo vêm do inventário (CONTROLE-DE-ESTOQUE.md). A etapa 1 do Codex
-- confirma cada um no banco real e ajusta ESTE arquivo antes de rodar.
--
-- Idempotente: upsert por legado_id. IDs gerados na VPS nova não mudam entre execuções.
-- Bloqueada depois do corte (insumos.config estoque_fonte_oficial = 'vps_nova').
-- =====================================================================
CREATE OR REPLACE FUNCTION estoque.sincronizar_legado(p_unidade text DEFAULT 'Campinas')
RETURNS TABLE (etapa text, linhas integer)
LANGUAGE plpgsql AS $$
DECLARE v_u smallint; n int;
BEGIN
  IF (SELECT valor FROM insumos.config WHERE chave = 'estoque_fonte_oficial') = 'vps_nova' THEN
    RAISE EXCEPTION 'Corte do estoque já feito: sincronização com o ERP bloqueada.';
  END IF;
  PERFORM pg_advisory_xact_lock(hashtext('estoque.sincronizar_legado'));
  PERFORM set_config('app.sem_auditoria', 'on', true);

  INSERT INTO insumos.unidade (nome) VALUES (p_unidade) ON CONFLICT (lower(nome)) DO NOTHING;
  SELECT id INTO v_u FROM insumos.unidade WHERE lower(nome) = lower(p_unidade);

  -- Materiais: casa por código; senão pelo nome/apelido (catálogo da Carta Traço); senão cria
  UPDATE insumos.material m SET codigo = e.codigo
    FROM erp_espelho.tbl_est_materiais e
    JOIN insumos.material_alias a ON a.alias = lower(regexp_replace(btrim(e.nome), '\s+', ' ', 'g'))
   WHERE m.id = a.material_id AND m.codigo IS NULL
     AND NOT EXISTS (SELECT 1 FROM insumos.material x WHERE x.codigo = e.codigo);

  INSERT INTO insumos.material (codigo, nome, grupo, un_estoque, usa_silo, ativo)
  SELECT e.codigo, btrim(e.nome),
         CASE lower(e.categoria) WHEN 'cimento' THEN 'cimento' WHEN 'adicao' THEN 'adicao' WHEN 'adição' THEN 'adicao'
              WHEN 'areia' THEN 'areia' WHEN 'brita' THEN 'brita' WHEN 'aditivo' THEN 'aditivo' WHEN 'agua' THEN 'agua'
              ELSE 'outro' END,
         CASE lower(e.unidade) WHEN 't' THEN 't' WHEN 'ton' THEN 't' WHEN 'kg' THEN 'kg' WHEN 'l' THEN 'L'
              WHEN 'litro' THEN 'L' WHEN 'm3' THEN 'm3' WHEN 'm³' THEN 'm3' ELSE 'un' END,
         lower(e.categoria) IN ('cimento','adicao','adição'), coalesce(e.ativo, true)
    FROM erp_espelho.tbl_est_materiais e
   WHERE NOT EXISTS (SELECT 1 FROM insumos.material m WHERE m.codigo = e.codigo)
  ON CONFLICT (lower(nome)) DO UPDATE SET codigo = coalesce(insumos.material.codigo, EXCLUDED.codigo);
  GET DIAGNOSTICS n = ROW_COUNT; etapa := 'materiais novos'; linhas := n; RETURN NEXT;

  UPDATE insumos.material m SET ativo = coalesce(e.ativo, true),
         usa_silo = lower(e.categoria) IN ('cimento','adicao','adição')
    FROM erp_espelho.tbl_est_materiais e WHERE m.codigo = e.codigo;
  INSERT INTO estoque.saldo_inicial (unidade_id, material_id, quantidade)
  SELECT v_u, m.id, coalesce(e.saldo_inicial, 0)
    FROM erp_espelho.tbl_est_materiais e JOIN insumos.material m ON m.codigo = e.codigo
  ON CONFLICT (unidade_id, material_id) DO UPDATE SET quantidade = EXCLUDED.quantidade;
  INSERT INTO insumos.material_alias (alias, material_id)
  SELECT lower(regexp_replace(btrim(e.nome), '\s+', ' ', 'g')), m.id
    FROM erp_espelho.tbl_est_materiais e JOIN insumos.material m ON m.codigo = e.codigo
  ON CONFLICT (alias) DO NOTHING;

  -- Silos (capacidades nominais 60/90/108 t; silos 1 e 2 com alívio de 20%)
  INSERT INTO estoque.silo (unidade_id, numero, nome, capacidade_nominal, alivio_pct, ativo)
  SELECT v_u, s.id, s.nome, s.capacidade_nominal,
         CASE WHEN s.capacidade_operacional IS NOT NULL AND s.capacidade_nominal > 0
              THEN round(100 * (1 - s.capacidade_operacional / s.capacidade_nominal), 2) ELSE 0 END,
         coalesce(s.ativo, true)
    FROM erp_espelho.tbl_est_silos s
  ON CONFLICT (unidade_id, numero) DO UPDATE SET nome = EXCLUDED.nome, capacidade_nominal = EXCLUDED.capacidade_nominal,
         alivio_pct = EXCLUDED.alivio_pct, ativo = EXCLUDED.ativo;

  -- Histórico do silo 1 e regras de silo permitido (do inventário; conferir na etapa 1)
  IF NOT EXISTS (SELECT 1 FROM estoque.silo_material sm JOIN estoque.silo si ON si.id = sm.silo_id WHERE si.unidade_id = v_u) THEN
    INSERT INTO estoque.silo_material (silo_id, material_id, desde, ate)
    SELECT si.id, m.id, d.desde, d.ate
      FROM (VALUES (1, 'ADD-FILL', DATE '2000-01-01', DATE '2026-06-29'),
                   (1, 'CIM-CP-V', DATE '2026-06-30', NULL::date)) d(numero, codigo, desde, ate)
      JOIN estoque.silo si ON si.unidade_id = v_u AND si.numero = d.numero
      JOIN insumos.material m ON m.codigo = d.codigo;
    INSERT INTO estoque.silo_material (silo_id, material_id, desde)       -- silos 2 e 3: material do mapeamento atual
    SELECT DISTINCT ON (si.id) si.id, m.id, DATE '2000-01-01'
      FROM erp_espelho.tbl_est_config_massada c
      JOIN estoque.silo si ON si.unidade_id = v_u AND c.coluna = 'real_silo' || si.numero AND si.numero IN (2, 3)
      JOIN erp_espelho.tbl_est_materiais em ON em.id = c.material_id
      JOIN insumos.material m ON m.codigo = em.codigo
     ORDER BY si.id, c.ativo DESC;
  END IF;
  INSERT INTO estoque.material_silo_permitido (material_id, silo_id)
  SELECT m.id, si.id
    FROM (VALUES ('ADD-FILL', 1), ('CIM-CP-V', 1), ('CIM-CP-V', 2), ('CIM-CP-II', 1), ('CIM-CP-II', 2), ('CIM-CP-II', 3)) r(codigo, numero)
    JOIN insumos.material m ON m.codigo = r.codigo
    JOIN estoque.silo si ON si.unidade_id = v_u AND si.numero = r.numero
  ON CONFLICT DO NOTHING;

  -- Posições do misturador (vigência única desde 2000; mudanças daqui em diante ficam versionadas)
  INSERT INTO estoque.posicao_misturador (unidade_id, coluna, label, material_id, silo_id, fator, ativo, ordem, desde)
  SELECT v_u, c.coluna, c.label,
         CASE WHEN c.coluna LIKE 'real_silo%' THEN NULL ELSE m.id END,
         CASE WHEN c.coluna LIKE 'real_silo%' THEN si.id END,
         coalesce(c.fator_conversao, 1), coalesce(c.ativo, true), coalesce(c.ordem, 0), DATE '2000-01-01'
    FROM erp_espelho.tbl_est_config_massada c
    LEFT JOIN erp_espelho.tbl_est_materiais em ON em.id = c.material_id
    LEFT JOIN insumos.material m ON m.codigo = em.codigo
    LEFT JOIN estoque.silo si ON si.unidade_id = v_u AND c.coluna = 'real_silo' || si.numero
   WHERE NOT EXISTS (SELECT 1 FROM estoque.posicao_misturador p WHERE p.unidade_id = v_u AND p.coluna = c.coluna)
     AND (m.id IS NOT NULL OR si.id IS NOT NULL);

  -- Movimentos (upsert por legado_id). Acerto com "[Contagem fisica: X]" vira contagem estruturada.
  CREATE TEMP TABLE _mov ON COMMIT DROP AS
  SELECT 'erp:' || e.id AS legado_id, v_u AS unidade_id, m.id AS material_id,
         CASE WHEN lower(e.tipo) = 'acerto' AND e.observacao ~* '\[\s*contagem\s+f[ií]sica\s*:\s*[-0-9.,]+\s*\]' THEN 'contagem'
              WHEN lower(e.tipo) IN ('entrada','consumo','acerto') THEN lower(e.tipo) END AS tipo,
         e.data::date AS data,
         CASE WHEN lower(e.tipo) = 'acerto' AND e.observacao ~* '\[\s*contagem\s+f[ií]sica\s*:\s*[-0-9.,]+\s*\]'
              THEN replace(replace(substring(e.observacao from '(?i)contagem\s+f[ií]sica\s*:\s*([-0-9.,]+)'), '.', ''), ',', '.')::numeric
              WHEN lower(e.tipo) IN ('entrada','consumo') THEN abs(e.quantidade)
              ELSE e.quantidade END AS quantidade,
         si.id AS silo_id,
         CASE WHEN e.origem = 'producao_massadas' THEN 'producao_massadas' ELSE 'legado' END AS origem,
         CASE WHEN e.origem = 'producao_massadas' THEN 'legado:' || e.id END AS chave_natural,
         CASE WHEN e.referencia_id IS NOT NULL AND lower(e.tipo) = 'entrada'
              THEN md5('erp-grupo:' || e.referencia_id)::uuid END AS grupo_id,
         f.id AS fornecedor_id, e.referencia_id::text AS referencia, e.valor_nota, e.icms_perc AS icms_pct,
         e.valor_frete AS frete_unit, e.icms_frete AS icms_frete_pct, e.observacao,
         e.valor_unitario_liquido AS legado_custo
    FROM erp_espelho.tbl_est_movimentos e
    JOIN erp_espelho.tbl_est_materiais em ON em.id = e.material_id
    JOIN insumos.material m ON m.codigo = em.codigo
    LEFT JOIN estoque.silo si ON si.unidade_id = v_u AND si.numero = e.silo_id
    LEFT JOIN insumos.fornecedor f ON lower(f.nome) = lower(btrim(e.fornecedor));

  INSERT INTO insumos.fornecedor (nome)
  SELECT DISTINCT btrim(e.fornecedor) FROM erp_espelho.tbl_est_movimentos e
   WHERE btrim(coalesce(e.fornecedor, '')) <> ''
  ON CONFLICT (lower(nome)) DO NOTHING;
  UPDATE _mov SET fornecedor_id = f.id FROM erp_espelho.tbl_est_movimentos e, insumos.fornecedor f
   WHERE _mov.legado_id = 'erp:' || e.id AND lower(f.nome) = lower(btrim(e.fornecedor)) AND _mov.fornecedor_id IS NULL;

  ALTER TABLE estoque.movimento DISABLE TRIGGER movimento_valida;   -- histórico do ERP entra como está; o relatório aponta
  INSERT INTO estoque.movimento (legado_id, unidade_id, material_id, tipo, data, quantidade, silo_id, origem, chave_natural,
                                 grupo_id, fornecedor_id, referencia, valor_nota, icms_pct, frete_unit, icms_frete_pct,
                                 observacao, criado_por)
  SELECT legado_id, unidade_id, material_id, tipo, data, quantidade, silo_id, origem, chave_natural, grupo_id, fornecedor_id,
         referencia, valor_nota, icms_pct, frete_unit, icms_frete_pct, observacao, 'espelho-erp'
    FROM _mov WHERE tipo IS NOT NULL AND (tipo NOT IN ('entrada','consumo') OR quantidade > 0)
  ON CONFLICT (legado_id) WHERE legado_id IS NOT NULL DO UPDATE SET
    material_id = EXCLUDED.material_id, tipo = EXCLUDED.tipo, data = EXCLUDED.data, quantidade = EXCLUDED.quantidade,
    silo_id = EXCLUDED.silo_id, origem = EXCLUDED.origem, chave_natural = EXCLUDED.chave_natural, grupo_id = EXCLUDED.grupo_id,
    fornecedor_id = EXCLUDED.fornecedor_id, referencia = EXCLUDED.referencia, valor_nota = EXCLUDED.valor_nota,
    icms_pct = EXCLUDED.icms_pct, frete_unit = EXCLUDED.frete_unit, icms_frete_pct = EXCLUDED.icms_frete_pct,
    observacao = EXCLUDED.observacao;
  GET DIAGNOSTICS n = ROW_COUNT; etapa := 'movimentos inseridos/alterados'; linhas := n; RETURN NEXT;
  ALTER TABLE estoque.movimento ENABLE TRIGGER movimento_valida;

  -- O ERP apaga e regrava baixas automáticas: some aqui o que sumiu lá
  DELETE FROM estoque.movimento mv
   WHERE mv.legado_id LIKE 'erp:%' AND mv.unidade_id = v_u
     AND NOT EXISTS (SELECT 1 FROM _mov WHERE _mov.legado_id = mv.legado_id);
  GET DIAGNOSTICS n = ROW_COUNT; etapa := 'movimentos removidos no ERP'; linhas := n; RETURN NEXT;

  -- Conferência do custo unitário: o banco calcula; o ERP gravou
  etapa := 'entradas com custo diferente do ERP';
  SELECT count(*) INTO linhas FROM _mov x JOIN estoque.movimento mv ON mv.legado_id = x.legado_id
   WHERE x.tipo = 'entrada' AND x.legado_custo IS NOT NULL AND abs(mv.custo_unit_liquido - x.legado_custo) > 0.0001;
  RETURN NEXT;
END $$;
