-- =====================================================================
-- Rollback / conferência: dados do PostgreSQL no layout das abas do Sheets.
-- Uso (psql):
--   \copy (SELECT * FROM carta_traco.legado_cadastro) TO 'cadastro.csv' CSV HEADER
--   \copy (SELECT * FROM carta_traco.legado_custos)   TO 'custos.csv'   CSV HEADER
-- Os CSVs colam direto nas abas cadastro/custos se for preciso voltar ao Sheets.
-- =====================================================================
CREATE OR REPLACE VIEW carta_traco.legado_cadastro AS
SELECT coalesce(c.legado_id, 'PG-' || c.id) AS "ID", c.nome AS "Nome", c.revisao AS "Revisão",
       u.nome AS "Unidade", c.status AS "Status",
       to_char(c.vigencia, 'DD/MM/YYYY') AS "Vigência", to_char(c.criado_em, 'DD/MM/YYYY') AS "Cadastro",
       coalesce(f.nome, '-') AS "Fornecedor", m.nome AS "Produto", i.qtd_kg AS "Quantidade",
       'kg' AS "Un. Medida", i.massa_especifica AS "M.E.", c.observacao AS "Obs.", c.tipo_frete AS "Tipo Frete"
  FROM carta_traco.carta c
  JOIN insumos.unidade u ON u.id = c.unidade_id
  JOIN carta_traco.carta_item i ON i.carta_id = c.id
  JOIN insumos.material m ON m.id = i.material_id
  LEFT JOIN insumos.fornecedor f ON f.id = i.fornecedor_id
 ORDER BY c.id, i.ordem;

CREATE OR REPLACE VIEW carta_traco.legado_custos AS
SELECT coalesce(c.legado_id, 'PG-' || c.id) AS "ID", to_char(c.vigente_desde, 'DD/MM/YYYY') AS "Data",
       u.nome AS "Unidade", f.nome AS "Fornecedor", m.nome AS "Material",
       CASE c.un_medida WHEN 't' THEN 'ton' WHEN 'L' THEN 'litro' WHEN 'm3' THEN 'm³' ELSE c.un_medida END AS "Un. Medida",
       c.valor AS "Valor", c.icms_pct AS "ICMS %", c.frete AS "Frete", c.valor_liquido AS "Valor Líquido",
       c.produto_fornecedor AS "Produto Fornecedor", c.tipo_frete AS "Tipo Frete"
  FROM insumos.custo c
  JOIN insumos.unidade u ON u.id = c.unidade_id
  JOIN insumos.fornecedor f ON f.id = c.fornecedor_id
  JOIN insumos.material m ON m.id = c.material_id
 WHERE c.ativo
 ORDER BY c.vigente_desde, c.id;
