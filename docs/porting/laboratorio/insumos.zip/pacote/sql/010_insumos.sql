-- =====================================================================
-- Laboratório · Insumos — cadastros compartilhados por Carta Traço e Estoque
-- PostgreSQL 16 · aditiva e idempotente (pode rodar de novo sem efeito)
-- =====================================================================
BEGIN;
CREATE SCHEMA IF NOT EXISTS insumos;

-- ---------------------------------------------------------------- configuração
CREATE TABLE IF NOT EXISTS insumos.config (
  chave     text PRIMARY KEY,
  valor     text NOT NULL,
  descricao text
);
INSERT INTO insumos.config (chave, valor, descricao) VALUES
  ('saco_kg',                 '50',     'Massa do saco de cimento (R$/saco → R$/kg)'),
  ('fechamento_tolerancia_l', '10',     'Tolerância de fechamento de volume da carta (L/m³)'),
  ('fonte_custo_mcc',         'tabela', 'tabela | ultima_entrada | media_ponderada | entrada_senao_tabela'),
  ('media_ponderada_dias',    '90',     'Janela do custo médio ponderado das entradas (dias)'),
  ('carta_fonte_oficial',     'sheets', 'sheets = Postgres é espelho do Google Sheets; postgres = corte feito'),
  ('estoque_fonte_oficial',   'erp',    'erp = ERP antigo grava, VPS nova espelha; vps_nova = corte feito'),
  ('consumo_inicio',          '2026-04-22', 'Produção anterior a esta data não gera baixa automática'),
  ('consumo_gerador',         'erp',    'erp | vps_nova — só um gerador de baixas por vez'),
  ('previsao_lead_time_dias', '3',      'Prazo de entrega de cimento (dias úteis)'),
  ('previsao_seguranca_dias', '2',      'Estoque de segurança mínimo (dias de consumo)'),
  ('previsao_nivel_servico',  '0.95',   'Nível de serviço do estoque de segurança estatístico'),
  ('previsao_carga_t',        '40',     'Carga padrão de cimento (t)'),
  ('nf_tamanho_max_mb',       '12',     'Tamanho máximo do arquivo de NF'),
  ('nf_timeout_s',            '120',    'Tempo máximo de uma leitura de NF por IA')
ON CONFLICT (chave) DO NOTHING;

-- ---------------------------------------------------------------- unidades
CREATE TABLE IF NOT EXISTS insumos.unidade (
  id               smallint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  nome             text NOT NULL,
  unidade_corp_id  bigint,                -- cadastro corporativo, quando existir
  ativo            boolean NOT NULL DEFAULT true
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_unidade_nome ON insumos.unidade (lower(nome));

-- ---------------------------------------------------------------- materiais
-- Um único catálogo: a carta usa kg/m³, o estoque usa a unidade de estoque (t, kg, L).
CREATE TABLE IF NOT EXISTS insumos.material (
  id                integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  codigo            text,                                   -- ex.: CIM-CP-V, ADD-FILL (código do ERP)
  nome              text NOT NULL,
  grupo             text NOT NULL DEFAULT 'outro'
                    CHECK (grupo IN ('cimento','adicao','areia','brita','agua','aditivo','fibra','outro')),
  massa_especifica  numeric(6,3) CHECK (massa_especifica > 0),   -- kg/L (volume absoluto da carta)
  massa_unitaria    numeric(6,3) CHECK (massa_unitaria > 0),     -- t/m³ solto (compra em m³)
  un_estoque        text NOT NULL DEFAULT 't' CHECK (un_estoque IN ('t','kg','L','m3','un')),
  usa_silo          boolean NOT NULL DEFAULT false,
  ordem             smallint NOT NULL DEFAULT 100,
  ativo             boolean NOT NULL DEFAULT true
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_material_nome   ON insumos.material (lower(nome));
CREATE UNIQUE INDEX IF NOT EXISTS ux_material_codigo ON insumos.material (codigo) WHERE codigo IS NOT NULL;

CREATE TABLE IF NOT EXISTS insumos.material_alias (
  alias        text PRIMARY KEY,          -- minúsculo, espaços simples
  material_id  integer NOT NULL REFERENCES insumos.material(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS insumos.fornecedor (
  id     integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  nome   text NOT NULL,
  cnpj   text CHECK (cnpj ~ '^\d{14}$'),
  ativo  boolean NOT NULL DEFAULT true
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_fornecedor_nome ON insumos.fornecedor (lower(nome));
CREATE UNIQUE INDEX IF NOT EXISTS ux_fornecedor_cnpj ON insumos.fornecedor (cnpj) WHERE cnpj IS NOT NULL;

-- ---------------------------------------------------------------- regra única de custo líquido
-- Mesma fórmula para a tabela de preços da Carta Traço e para a entrada de NF do estoque:
--   líquido unitário = valor_unit × (1 − ICMS) + frete_unit × (1 − ICMS do frete)
CREATE OR REPLACE FUNCTION insumos.custo_liquido_unit(valor_unit numeric, icms_pct numeric,
                                                      frete_unit numeric, icms_frete_pct numeric)
RETURNS numeric LANGUAGE sql IMMUTABLE AS $$
  SELECT round(coalesce(valor_unit,0) * (1 - coalesce(icms_pct,0)/100)
             + coalesce(frete_unit,0) * (1 - coalesce(icms_frete_pct,0)/100), 4)
$$;

-- R$ por kg a partir da unidade de compra
--   L  → ÷ massa específica (kg/L)
--   m3 → ÷ (massa unitária, ou massa específica na falta dela) × 1000
CREATE OR REPLACE FUNCTION insumos.custo_por_kg(valor_liquido numeric, un_medida text, massa_esp numeric,
                                                massa_unit numeric DEFAULT NULL, saco_kg numeric DEFAULT 50)
RETURNS numeric LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE un_medida
    WHEN 'kg'   THEN valor_liquido
    WHEN 't'    THEN valor_liquido / 1000
    WHEN 'saco' THEN valor_liquido / NULLIF(saco_kg, 0)
    WHEN 'L'    THEN valor_liquido / NULLIF(massa_esp, 0)
    WHEN 'm3'   THEN valor_liquido / NULLIF(COALESCE(massa_unit, massa_esp) * 1000, 0)
  END
$$;

-- ---------------------------------------------------------------- tabela de preços (Carta Traço)
CREATE TABLE IF NOT EXISTS insumos.custo (
  id                   bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  unidade_id           smallint NOT NULL REFERENCES insumos.unidade(id),
  fornecedor_id        integer  NOT NULL REFERENCES insumos.fornecedor(id),
  material_id          integer  NOT NULL REFERENCES insumos.material(id),
  un_medida            text NOT NULL CHECK (un_medida IN ('kg','t','m3','L','saco')),
  valor                numeric(14,4) NOT NULL CHECK (valor >= 0),
  icms_pct             numeric(5,2)  NOT NULL DEFAULT 0 CHECK (icms_pct BETWEEN 0 AND 100),
  frete                numeric(14,4) NOT NULL DEFAULT 0 CHECK (frete >= 0),
  icms_frete_pct       numeric(5,2)  NOT NULL DEFAULT 0 CHECK (icms_frete_pct BETWEEN 0 AND 100),
  tipo_frete           text CHECK (tipo_frete IN ('CIF','FOB')),
  valor_liquido        numeric(14,4) GENERATED ALWAYS AS
                       (round(valor * (1 - icms_pct/100) + frete * (1 - icms_frete_pct/100), 4)) STORED,
  produto_fornecedor   text,
  vigente_desde        date NOT NULL DEFAULT current_date,
  ativo                boolean NOT NULL DEFAULT true,
  criado_por           text NOT NULL DEFAULT 'sistema',
  criado_em            timestamptz NOT NULL DEFAULT now(),
  legado_id            text,
  legado_valor_liquido numeric(14,4)
);
CREATE INDEX IF NOT EXISTS ix_custo_busca ON insumos.custo
  (unidade_id, material_id, fornecedor_id, vigente_desde DESC, id DESC) WHERE ativo;

-- ---------------------------------------------------------------- auditoria
CREATE TABLE IF NOT EXISTS insumos.auditoria (
  id        bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  esquema   text NOT NULL,
  tabela    text NOT NULL,
  operacao  text NOT NULL,
  registro  jsonb,
  anterior  jsonb,
  usuario   text,
  em        timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_auditoria_tabela ON insumos.auditoria (esquema, tabela, em DESC);

CREATE OR REPLACE FUNCTION insumos.trg_auditoria() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF current_setting('app.sem_auditoria', true) = 'on' THEN RETURN NULL; END IF;
  INSERT INTO insumos.auditoria (esquema, tabela, operacao, registro, anterior, usuario)
  VALUES (TG_TABLE_SCHEMA, TG_TABLE_NAME, TG_OP,
          CASE WHEN TG_OP <> 'DELETE' THEN to_jsonb(NEW) END,
          CASE WHEN TG_OP <> 'INSERT' THEN to_jsonb(OLD) END,
          current_setting('app.usuario', true));
  RETURN NULL;
END $$;

DROP TRIGGER IF EXISTS aud_custo ON insumos.custo;
CREATE TRIGGER aud_custo AFTER INSERT OR UPDATE OR DELETE ON insumos.custo
  FOR EACH ROW EXECUTE FUNCTION insumos.trg_auditoria();
DROP TRIGGER IF EXISTS aud_material ON insumos.material;
CREATE TRIGGER aud_material AFTER INSERT OR UPDATE OR DELETE ON insumos.material
  FOR EACH ROW EXECUTE FUNCTION insumos.trg_auditoria();

COMMIT;
