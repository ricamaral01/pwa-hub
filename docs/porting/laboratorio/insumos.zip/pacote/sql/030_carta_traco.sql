-- =====================================================================
-- Laboratório · Carta Traço (substitui Apps Script + Google Sheets)
-- Depende de 010_insumos.sql e 020_estoque.sql. Aditiva e idempotente.
-- =====================================================================
BEGIN;
CREATE SCHEMA IF NOT EXISTS carta_traco;
CREATE SCHEMA IF NOT EXISTS carta_traco_stg;

CREATE TABLE IF NOT EXISTS carta_traco.carta (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  nome          text NOT NULL CHECK (btrim(nome) <> ''),
  codigo_traco  text,                    -- código do traço na automação da usina (liga carta ↔ massadas)
  revisao       integer NOT NULL CHECK (revisao >= 0),
  unidade_id    smallint NOT NULL REFERENCES insumos.unidade(id),
  status        text NOT NULL DEFAULT 'Ativa' CHECK (status IN ('Ativa','Inativa','Rascunho')),
  vigencia      date NOT NULL,
  observacao    text,
  tipo_frete    text CHECK (tipo_frete IN ('CIF','FOB')),
  criado_por    text NOT NULL DEFAULT 'sistema',
  criado_em     timestamptz NOT NULL DEFAULT now(),
  legado_id     text
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_carta_revisao ON carta_traco.carta (lower(nome), unidade_id, revisao);
CREATE UNIQUE INDEX IF NOT EXISTS ux_carta_ativa   ON carta_traco.carta (lower(nome), unidade_id) WHERE status = 'Ativa';
CREATE INDEX IF NOT EXISTS ix_carta_codigo ON carta_traco.carta (unidade_id, codigo_traco, vigencia) WHERE codigo_traco IS NOT NULL;

CREATE TABLE IF NOT EXISTS carta_traco.carta_item (
  carta_id          bigint  NOT NULL REFERENCES carta_traco.carta(id) ON DELETE CASCADE,
  material_id       integer NOT NULL REFERENCES insumos.material(id),
  fornecedor_id     integer REFERENCES insumos.fornecedor(id),
  qtd_kg            numeric(10,3) NOT NULL CHECK (qtd_kg >= 0),
  massa_especifica  numeric(6,3)  NOT NULL CHECK (massa_especifica > 0),
  ordem             smallint NOT NULL DEFAULT 0,
  PRIMARY KEY (carta_id, material_id)
);

-- Revisão ativa: inativa só revisões menores e recusa se houver revisão maior ativa
CREATE OR REPLACE FUNCTION carta_traco.trg_carta_ativar() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = 'Ativa' THEN
    IF EXISTS (SELECT 1 FROM carta_traco.carta
                WHERE lower(nome) = lower(NEW.nome) AND unidade_id = NEW.unidade_id
                  AND status = 'Ativa' AND revisao > NEW.revisao AND id IS DISTINCT FROM NEW.id) THEN
      RAISE EXCEPTION 'Já existe revisão maior ativa para "%" nesta unidade', NEW.nome USING ERRCODE = 'check_violation';
    END IF;
    UPDATE carta_traco.carta SET status = 'Inativa'
     WHERE lower(nome) = lower(NEW.nome) AND unidade_id = NEW.unidade_id
       AND status = 'Ativa' AND revisao < NEW.revisao AND id IS DISTINCT FROM NEW.id;
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS carta_ativar ON carta_traco.carta;
CREATE TRIGGER carta_ativar BEFORE INSERT OR UPDATE OF status, revisao ON carta_traco.carta
  FOR EACH ROW EXECUTE FUNCTION carta_traco.trg_carta_ativar();

DROP TRIGGER IF EXISTS aud_carta ON carta_traco.carta;
CREATE TRIGGER aud_carta AFTER INSERT OR UPDATE OR DELETE ON carta_traco.carta
  FOR EACH ROW EXECUTE FUNCTION insumos.trg_auditoria();
DROP TRIGGER IF EXISTS aud_carta_item ON carta_traco.carta_item;
CREATE TRIGGER aud_carta_item AFTER INSERT OR UPDATE OR DELETE ON carta_traco.carta_item
  FOR EACH ROW EXECUTE FUNCTION insumos.trg_auditoria();

-- ---------------------------------------------------------------- custos usados no MCC
-- Fonte escolhida em insumos.config 'fonte_custo_mcc':
--   tabela                → tabela de preços (comportamento do legado)
--   ultima_entrada        → custo líquido da última NF lançada no estoque
--   media_ponderada       → média ponderada das entradas na janela (media_ponderada_dias)
--   entrada_senao_tabela  → entrada do estoque; sem entrada, tabela de preços
CREATE OR REPLACE FUNCTION carta_traco.custos_em(p_data date DEFAULT current_date, p_fonte text DEFAULT NULL)
RETURNS TABLE (custo_id bigint, unidade_id smallint, fornecedor_id integer, material_id integer,
               un_medida text, valor_liquido numeric, vigente_desde date, origem text)
LANGUAGE sql STABLE AS $$
  WITH f AS (SELECT coalesce(p_fonte, (SELECT valor FROM insumos.config WHERE chave = 'fonte_custo_mcc'), 'tabela') AS fonte,
                    coalesce((SELECT valor::int FROM insumos.config WHERE chave = 'media_ponderada_dias'), 90) AS dias),
  tab AS (
    SELECT DISTINCT ON (c.unidade_id, c.fornecedor_id, c.material_id)
           c.id, c.unidade_id, c.fornecedor_id, c.material_id, c.un_medida, c.valor_liquido, c.vigente_desde, 'tabela'::text
      FROM insumos.custo c
     WHERE c.ativo AND c.vigente_desde <= p_data
     ORDER BY c.unidade_id, c.fornecedor_id, c.material_id, c.vigente_desde DESC, c.id DESC
  ),
  ent AS (
    SELECT NULL::bigint, e.unidade_id, e.fornecedor_id, e.material_id, mt.un_estoque,
           CASE WHEN f.fonte = 'media_ponderada' THEN coalesce(e.custo_medio, e.ultimo_custo) ELSE e.ultimo_custo END,
           e.ultima_data, CASE WHEN f.fonte = 'media_ponderada' THEN 'media_ponderada' ELSE 'ultima_entrada' END
      FROM f, estoque.custos_entrada_em(p_data, f.dias) e
      JOIN insumos.material mt ON mt.id = e.material_id
     WHERE f.fonte <> 'tabela' AND mt.un_estoque IN ('kg','t','L','m3')
  )
  SELECT * FROM ent
  UNION ALL
  SELECT tab.* FROM tab, f
   WHERE f.fonte = 'tabela'
      OR (f.fonte = 'entrada_senao_tabela'
          AND NOT EXISTS (SELECT 1 FROM ent WHERE ent.unidade_id = tab.unidade_id AND ent.material_id = tab.material_id))
$$;

CREATE OR REPLACE VIEW carta_traco.custo_vigente AS
SELECT * FROM carta_traco.custos_em(current_date, 'tabela');

-- Casamento do item da carta com o custo (uma regra só para tudo)
CREATE OR REPLACE FUNCTION carta_traco._mcc(p_itens jsonb, p_data date, p_fonte text)
RETURNS TABLE (carta_id bigint, material_id integer, material text, grupo text, fornecedor_id integer,
               fornecedor text, qtd_kg numeric, massa_especifica numeric, custo_id bigint, origem_custo text,
               un_medida text, valor_liquido numeric, custo_kg numeric, custo_m3 numeric, sem_custo boolean)
LANGUAGE sql STABLE AS $$
  WITH it AS (
    SELECT * FROM jsonb_to_recordset(p_itens)
      AS x(carta_id bigint, unidade_id smallint, material_id integer, fornecedor_id integer, qtd_kg numeric, massa_especifica numeric)
  ), cv AS (SELECT * FROM carta_traco.custos_em(p_data, p_fonte)),
     saco AS (SELECT valor::numeric AS kg FROM insumos.config WHERE chave = 'saco_kg')
  SELECT it.carta_id, m.id, m.nome, m.grupo, coalesce(it.fornecedor_id, x.fornecedor_id), f.nome,
         it.qtd_kg, coalesce(it.massa_especifica, m.massa_especifica), x.custo_id, x.origem, x.un_medida, x.valor_liquido,
         round(insumos.custo_por_kg(x.valor_liquido, x.un_medida, coalesce(it.massa_especifica, m.massa_especifica),
                                    m.massa_unitaria, (SELECT kg FROM saco)), 6),
         round(it.qtd_kg * coalesce(insumos.custo_por_kg(x.valor_liquido, x.un_medida,
                                    coalesce(it.massa_especifica, m.massa_especifica), m.massa_unitaria, (SELECT kg FROM saco)), 0), 4),
         x.material_id IS NULL
    FROM it
    JOIN insumos.material m ON m.id = it.material_id
    LEFT JOIN LATERAL (
      SELECT * FROM cv
       WHERE cv.unidade_id = it.unidade_id AND cv.material_id = it.material_id
         AND (it.fornecedor_id IS NULL OR cv.fornecedor_id = it.fornecedor_id OR cv.origem <> 'tabela')
       ORDER BY cv.vigente_desde DESC, cv.custo_id DESC NULLS LAST LIMIT 1) x ON true
    LEFT JOIN insumos.fornecedor f ON f.id = coalesce(it.fornecedor_id, x.fornecedor_id)
$$;

CREATE OR REPLACE FUNCTION carta_traco.mcc_itens(p_data date DEFAULT current_date, p_fonte text DEFAULT NULL)
RETURNS TABLE (carta_id bigint, material_id integer, material text, grupo text, fornecedor_id integer,
               fornecedor text, qtd_kg numeric, massa_especifica numeric, custo_id bigint, origem_custo text,
               un_medida text, valor_liquido numeric, custo_kg numeric, custo_m3 numeric, sem_custo boolean)
LANGUAGE sql STABLE AS $$
  SELECT * FROM carta_traco._mcc(
    (SELECT coalesce(jsonb_agg(jsonb_build_object('carta_id', ci.carta_id, 'unidade_id', c.unidade_id,
              'material_id', ci.material_id, 'fornecedor_id', ci.fornecedor_id, 'qtd_kg', ci.qtd_kg,
              'massa_especifica', ci.massa_especifica)), '[]')
       FROM carta_traco.carta_item ci JOIN carta_traco.carta c ON c.id = ci.carta_id),
    p_data, p_fonte)
$$;

CREATE OR REPLACE VIEW carta_traco.mcc_item AS SELECT * FROM carta_traco.mcc_itens(current_date);

CREATE OR REPLACE FUNCTION carta_traco.mcc_cartas(p_data date DEFAULT current_date, p_fonte text DEFAULT NULL)
RETURNS TABLE (carta_id bigint, mcc numeric, itens_sem_custo integer)
LANGUAGE sql STABLE AS $$
  SELECT carta_id, round(sum(custo_m3), 2), count(*) FILTER (WHERE sem_custo)::int
    FROM carta_traco.mcc_itens(p_data, p_fonte) GROUP BY carta_id
$$;

-- Prévia do editor (itens ainda não gravados)
CREATE OR REPLACE FUNCTION carta_traco.calcular_itens(p_unidade_id smallint, p_itens jsonb,
                                                      p_data date DEFAULT current_date, p_fonte text DEFAULT NULL)
RETURNS TABLE (carta_id bigint, material_id integer, material text, grupo text, fornecedor_id integer,
               fornecedor text, qtd_kg numeric, massa_especifica numeric, custo_id bigint, origem_custo text,
               un_medida text, valor_liquido numeric, custo_kg numeric, custo_m3 numeric, sem_custo boolean)
LANGUAGE sql STABLE AS $$
  SELECT * FROM carta_traco._mcc(
    (SELECT coalesce(jsonb_agg(e || jsonb_build_object('unidade_id', p_unidade_id)), '[]') FROM jsonb_array_elements(p_itens) e),
    p_data, p_fonte)
$$;

-- ---------------------------------------------------------------- indicadores
CREATE OR REPLACE FUNCTION carta_traco.indicadores_itens(p_itens jsonb)
RETURNS TABLE (peso_kg numeric, volume_l numeric, fechamento_l numeric, rel_ac numeric, rel_a_agl numeric,
               teor_argamassa_pct numeric, areia_agregados_pct numeric, aditivos_s_cimento_pct numeric,
               aditivos_s_aglomerante_pct numeric)
LANGUAGE sql STABLE AS $$
  WITH it AS (
    SELECT x.qtd_kg, coalesce(x.massa_especifica, m.massa_especifica) AS me, m.grupo
      FROM jsonb_to_recordset(p_itens) AS x(material_id integer, qtd_kg numeric, massa_especifica numeric)
      JOIN insumos.material m ON m.id = x.material_id
  )
  SELECT round(sum(qtd_kg), 2),
         round(sum(qtd_kg / me), 1),
         round(1000 - sum(qtd_kg / me), 1),
         round(sum(qtd_kg) FILTER (WHERE grupo = 'agua') / NULLIF(sum(qtd_kg) FILTER (WHERE grupo = 'cimento'), 0), 3),
         round(sum(qtd_kg) FILTER (WHERE grupo = 'agua') / NULLIF(sum(qtd_kg) FILTER (WHERE grupo IN ('cimento','adicao')), 0), 3),
         round(100 * sum(qtd_kg) FILTER (WHERE grupo IN ('cimento','adicao','areia'))
               / NULLIF(sum(qtd_kg) FILTER (WHERE grupo IN ('cimento','adicao','areia','brita')), 0), 2),
         round(100 * sum(qtd_kg) FILTER (WHERE grupo = 'areia')
               / NULLIF(sum(qtd_kg) FILTER (WHERE grupo IN ('areia','brita')), 0), 2),
         round(100 * sum(qtd_kg) FILTER (WHERE grupo = 'aditivo')
               / NULLIF(sum(qtd_kg) FILTER (WHERE grupo = 'cimento'), 0), 3),
         round(100 * sum(qtd_kg) FILTER (WHERE grupo = 'aditivo')
               / NULLIF(sum(qtd_kg) FILTER (WHERE grupo IN ('cimento','adicao')), 0), 3)
    FROM it
$$;

CREATE OR REPLACE VIEW carta_traco.indicadores_carta AS
SELECT ci.carta_id, i.*
  FROM (SELECT DISTINCT carta_id FROM carta_traco.carta_item) ci
  CROSS JOIN LATERAL carta_traco.indicadores_itens(
    (SELECT jsonb_agg(jsonb_build_object('material_id', material_id, 'qtd_kg', qtd_kg, 'massa_especifica', massa_especifica))
       FROM carta_traco.carta_item WHERE carta_id = ci.carta_id)) i;

CREATE OR REPLACE VIEW carta_traco.resumo AS
SELECT c.id AS carta_id, c.nome, c.codigo_traco, c.revisao, u.nome AS unidade, c.status, c.vigencia,
       mc.mcc, mc.itens_sem_custo, i.peso_kg, i.volume_l, i.fechamento_l, i.rel_ac, i.teor_argamassa_pct
  FROM carta_traco.carta c
  JOIN insumos.unidade u ON u.id = c.unidade_id
  LEFT JOIN carta_traco.mcc_cartas(current_date) mc ON mc.carta_id = c.id
  LEFT JOIN carta_traco.indicadores_carta i ON i.carta_id = c.id;

-- ---------------------------------------------------------------- consumo teórico × real
-- Teórico = volume produzido de cada traço × kg/m³ da revisão vigente na data.
-- Real    = baixas de consumo do estoque (unidade de estoque convertida para kg).
CREATE OR REPLACE FUNCTION carta_traco.consumo_teorico_real(p_de date, p_ate date, p_unidade smallint DEFAULT NULL)
RETURNS TABLE (unidade_id smallint, material_id integer, material text, volume_m3 numeric,
               teorico_kg numeric, real_kg numeric, desvio_kg numeric, desvio_pct numeric, volume_sem_carta_m3 numeric)
LANGUAGE sql STABLE AS $$
  WITH prod AS (
    SELECT p.unidade_id, p.data, p.codigo_traco, sum(p.volume_m3) AS vol
      FROM estoque.v_massada_produto p
     WHERE p.data BETWEEN p_de AND p_ate AND (p_unidade IS NULL OR p.unidade_id = p_unidade)
     GROUP BY 1, 2, 3
  ), carta_dia AS (                                   -- revisão vigente na data da produção
    SELECT pr.*, (SELECT c.id FROM carta_traco.carta c
                   WHERE c.unidade_id = pr.unidade_id AND c.codigo_traco = pr.codigo_traco
                     AND c.status <> 'Rascunho' AND c.vigencia <= pr.data
                   ORDER BY c.vigencia DESC, c.revisao DESC LIMIT 1) AS carta_id
      FROM prod pr
  ), teo AS (
    SELECT cd.unidade_id, ci.material_id, sum(cd.vol * ci.qtd_kg) AS kg
      FROM carta_dia cd JOIN carta_traco.carta_item ci ON ci.carta_id = cd.carta_id
     GROUP BY 1, 2
  ), rea AS (
    SELECT mv.unidade_id, mv.material_id,
           sum(mv.quantidade * CASE mt.un_estoque WHEN 't' THEN 1000 WHEN 'L' THEN coalesce(mt.massa_especifica, 1)
                                                  WHEN 'm3' THEN coalesce(mt.massa_unitaria, mt.massa_especifica) * 1000 ELSE 1 END) AS kg
      FROM estoque.movimento mv JOIN insumos.material mt ON mt.id = mv.material_id
     WHERE mv.tipo = 'consumo' AND NOT mv.anulado AND mv.data BETWEEN p_de AND p_ate
       AND (p_unidade IS NULL OR mv.unidade_id = p_unidade)
     GROUP BY 1, 2
  ), vol AS (
    SELECT unidade_id, sum(vol) AS total, sum(vol) FILTER (WHERE carta_id IS NULL) AS sem_carta FROM carta_dia GROUP BY 1
  )
  SELECT coalesce(t.unidade_id, r.unidade_id)::smallint, coalesce(t.material_id, r.material_id), mt.nome,
         round(v.total, 2), round(t.kg, 1), round(r.kg, 1),
         round(coalesce(r.kg, 0) - coalesce(t.kg, 0), 1),
         round(100 * (coalesce(r.kg, 0) - t.kg) / NULLIF(t.kg, 0), 2),
         round(coalesce(v.sem_carta, 0), 2)
    FROM teo t
    FULL JOIN rea r ON r.unidade_id = t.unidade_id AND r.material_id = t.material_id
    JOIN insumos.material mt ON mt.id = coalesce(t.material_id, r.material_id)
    LEFT JOIN vol v ON v.unidade_id = coalesce(t.unidade_id, r.unidade_id)
$$;

-- ---------------------------------------------------------------- staging da carga do Sheets
CREATE TABLE IF NOT EXISTS carta_traco_stg.cadastro (
  linha integer PRIMARY KEY, legado_id text, nome text, revisao integer, unidade text, status text,
  vigencia date, cadastro date, fornecedor text, produto text, quantidade numeric, un_medida text,
  massa_especifica numeric, observacao text, tipo_frete text
);
CREATE TABLE IF NOT EXISTS carta_traco_stg.custos (
  linha integer PRIMARY KEY, legado_id text, data date, unidade text, fornecedor text, material text,
  un_medida text, valor numeric, icms_pct numeric, frete numeric, valor_liquido numeric,
  produto_fornecedor text, tipo_frete text
);
CREATE TABLE IF NOT EXISTS carta_traco_stg.alias (
  alias text PRIMARY KEY, material text NOT NULL, grupo text
);

COMMIT;
