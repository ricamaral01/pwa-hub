-- =====================================================================
-- Laboratório · Estoque de insumos (substitui o estoque do ERP ConcreTrack)
-- Depende de 010_insumos.sql. Aditiva e idempotente.
-- =====================================================================
BEGIN;
CREATE SCHEMA IF NOT EXISTS estoque;
CREATE EXTENSION IF NOT EXISTS pgcrypto;          -- gen_random_uuid() no PG < 13 / digest()

-- ---------------------------------------------------------------- silos
CREATE TABLE IF NOT EXISTS estoque.silo (
  id                  smallint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  unidade_id          smallint NOT NULL REFERENCES insumos.unidade(id),
  numero              smallint NOT NULL,                       -- 1, 2, 3 = real_silo1..3
  nome                text NOT NULL,
  capacidade_nominal  numeric(10,3) NOT NULL CHECK (capacidade_nominal > 0),   -- t
  alivio_pct          numeric(5,2)  NOT NULL DEFAULT 0 CHECK (alivio_pct BETWEEN 0 AND 100),
  capacidade_operacional numeric(10,3) GENERATED ALWAYS AS (round(capacidade_nominal * (1 - alivio_pct/100), 3)) STORED,
  ativo               boolean NOT NULL DEFAULT true,
  UNIQUE (unidade_id, numero)
);

-- Qual material está em cada silo, com histórico (ex.: silo 1 = Filler até 29/06/2026, CP V-ARI desde 30/06/2026)
CREATE TABLE IF NOT EXISTS estoque.silo_material (
  id           integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  silo_id      smallint NOT NULL REFERENCES estoque.silo(id),
  material_id  integer  NOT NULL REFERENCES insumos.material(id),
  desde        date NOT NULL,
  ate          date,
  CHECK (ate IS NULL OR ate >= desde)
);
CREATE OR REPLACE FUNCTION estoque.trg_silo_material_sem_sobreposicao() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM estoque.silo_material o
              WHERE o.silo_id = NEW.silo_id AND o.id IS DISTINCT FROM NEW.id
                AND daterange(o.desde, o.ate, '[]') && daterange(NEW.desde, NEW.ate, '[]')) THEN
    RAISE EXCEPTION 'Silo % já tem material no período informado', NEW.silo_id USING ERRCODE = 'exclusion_violation';
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS silo_material_periodo ON estoque.silo_material;
CREATE TRIGGER silo_material_periodo BEFORE INSERT OR UPDATE ON estoque.silo_material
  FOR EACH ROW EXECUTE FUNCTION estoque.trg_silo_material_sem_sobreposicao();

-- Em quais silos cada material pode entrar (ADD-FILL: 1; CIM-CP-V: 1,2; CIM-CP-II: 1,2,3)
CREATE TABLE IF NOT EXISTS estoque.material_silo_permitido (
  material_id  integer  NOT NULL REFERENCES insumos.material(id),
  silo_id      smallint NOT NULL REFERENCES estoque.silo(id),
  PRIMARY KEY (material_id, silo_id)
);

CREATE OR REPLACE FUNCTION estoque.material_no_silo(p_silo smallint, p_data date)
RETURNS integer LANGUAGE sql STABLE AS $$
  SELECT material_id FROM estoque.silo_material
   WHERE silo_id = p_silo AND p_data BETWEEN desde AND coalesce(ate, 'infinity'::date)
   ORDER BY desde DESC LIMIT 1
$$;

-- Saldo inicial do livro de cada material (fora de silo) por unidade — 'saldo inicial' do ERP
CREATE TABLE IF NOT EXISTS estoque.saldo_inicial (
  unidade_id   smallint NOT NULL REFERENCES insumos.unidade(id),
  material_id  integer  NOT NULL REFERENCES insumos.material(id),
  quantidade   numeric(14,4) NOT NULL,
  PRIMARY KEY (unidade_id, material_id)
);

-- ---------------------------------------------------------------- nota fiscal e leitura por IA
CREATE TABLE IF NOT EXISTS estoque.nf_leitura (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  unidade_id      smallint NOT NULL REFERENCES insumos.unidade(id),
  status          text NOT NULL DEFAULT 'pendente'
                  CHECK (status IN ('pendente','processando','concluida','erro','confirmada','descartada')),
  provider        text,
  arquivo_sha256  char(64) NOT NULL,
  anexo_caminho   text NOT NULL,                 -- arquivo guardado em disco (storage do Laboratório)
  anexo_mime      text NOT NULL,
  anexo_bytes     integer NOT NULL CHECK (anexo_bytes > 0),
  resultado       jsonb,                         -- campos extraídos pela IA (para conferência)
  erro            text,
  tentativas      smallint NOT NULL DEFAULT 0,
  iniciado_em     timestamptz,
  concluido_em    timestamptz,
  criado_por      text NOT NULL,
  criado_em       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_nf_leitura_status ON estoque.nf_leitura (status, criado_em);
CREATE INDEX IF NOT EXISTS ix_nf_leitura_sha    ON estoque.nf_leitura (arquivo_sha256);

CREATE TABLE IF NOT EXISTS estoque.nota_fiscal (
  id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  unidade_id      smallint NOT NULL REFERENCES insumos.unidade(id),
  chave_acesso    char(44) CHECK (chave_acesso ~ '^\d{44}$'),
  numero          text,
  serie           text,
  emitente_cnpj   text CHECK (emitente_cnpj ~ '^\d{14}$'),
  fornecedor_id   integer REFERENCES insumos.fornecedor(id),
  data_emissao    date,
  valor_total     numeric(14,2),
  leitura_id      uuid REFERENCES estoque.nf_leitura(id),
  anexo_caminho   text,
  criado_por      text NOT NULL,
  criado_em       timestamptz NOT NULL DEFAULT now()
);
-- impede lançar a mesma NF duas vezes
CREATE UNIQUE INDEX IF NOT EXISTS ux_nf_chave  ON estoque.nota_fiscal (chave_acesso) WHERE chave_acesso IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_nf_numero ON estoque.nota_fiscal (emitente_cnpj, numero, coalesce(serie, ''))
  WHERE emitente_cnpj IS NOT NULL AND numero IS NOT NULL;

-- ---------------------------------------------------------------- livro de movimentos
CREATE TABLE IF NOT EXISTS estoque.movimento (
  id                  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  unidade_id          smallint NOT NULL REFERENCES insumos.unidade(id),
  material_id         integer  NOT NULL REFERENCES insumos.material(id),
  tipo                text NOT NULL CHECK (tipo IN ('entrada','consumo','acerto','contagem')),
  data                date NOT NULL,
  -- entrada/consumo: quantidade positiva; acerto: diferença com sinal; contagem: valor contado (≥ 0)
  quantidade          numeric(14,4) NOT NULL,
  silo_id             smallint REFERENCES estoque.silo(id),
  origem              text NOT NULL DEFAULT 'manual'
                      CHECK (origem IN ('manual','nf_ia','producao_massadas','legado')),
  grupo_id            uuid,                         -- rateio de uma NF entre silos
  nota_fiscal_id      bigint REFERENCES estoque.nota_fiscal(id),
  fornecedor_id       integer REFERENCES insumos.fornecedor(id),
  referencia          text,
  valor_nota          numeric(14,2),                -- valor total da linha da NF (sem frete)
  icms_pct            numeric(5,2) CHECK (icms_pct BETWEEN 0 AND 100),
  frete_unit          numeric(14,4) CHECK (frete_unit >= 0),
  icms_frete_pct      numeric(5,2) CHECK (icms_frete_pct BETWEEN 0 AND 100),
  custo_unit_liquido  numeric(14,4) GENERATED ALWAYS AS (
                        CASE WHEN tipo = 'entrada' AND quantidade > 0 AND valor_nota IS NOT NULL
                             THEN insumos.custo_liquido_unit(valor_nota / quantidade, icms_pct, frete_unit, icms_frete_pct)
                        END) STORED,
  chave_natural       text,                         -- baixas automáticas: massadas:<unidade>:<data>:<coluna>
  observacao          text,
  anulado             boolean NOT NULL DEFAULT false,
  anulado_por         text,
  anulado_em          timestamptz,
  motivo_anulacao     text,
  criado_por          text NOT NULL DEFAULT 'sistema',
  criado_em           timestamptz NOT NULL DEFAULT now(),
  legado_id           text,
  CHECK (tipo NOT IN ('entrada','consumo') OR quantidade > 0),
  CHECK (tipo <> 'contagem' OR quantidade >= 0),
  CHECK (NOT anulado OR (anulado_por IS NOT NULL AND motivo_anulacao IS NOT NULL))
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_mov_chave_natural ON estoque.movimento (chave_natural) WHERE chave_natural IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_mov_legado        ON estoque.movimento (legado_id) WHERE legado_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_mov_material_data ON estoque.movimento (unidade_id, material_id, data) WHERE NOT anulado;
CREATE INDEX IF NOT EXISTS ix_mov_silo_data     ON estoque.movimento (silo_id, data) WHERE NOT anulado AND silo_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_mov_grupo         ON estoque.movimento (grupo_id) WHERE grupo_id IS NOT NULL;

-- Regras que cruzam tabelas: silo obrigatório e permitido para material de silo
CREATE OR REPLACE FUNCTION estoque.trg_movimento_valida() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v_usa_silo boolean;
BEGIN
  SELECT usa_silo INTO v_usa_silo FROM insumos.material WHERE id = NEW.material_id;
  IF v_usa_silo AND NEW.silo_id IS NULL AND NEW.tipo IN ('entrada','acerto','contagem') THEN
    RAISE EXCEPTION 'Material de silo exige o silo no lançamento' USING ERRCODE = 'check_violation';
  END IF;
  IF NEW.silo_id IS NOT NULL AND NEW.tipo = 'entrada' AND NOT EXISTS (
       SELECT 1 FROM estoque.material_silo_permitido p WHERE p.material_id = NEW.material_id AND p.silo_id = NEW.silo_id) THEN
    RAISE EXCEPTION 'Este material não pode entrar neste silo' USING ERRCODE = 'check_violation';
  END IF;
  IF NEW.tipo = 'entrada' AND NEW.grupo_id IS NOT NULL AND TG_OP = 'UPDATE' AND NOT NEW.anulado
     AND (NEW.quantidade, NEW.silo_id) IS DISTINCT FROM (OLD.quantidade, OLD.silo_id) THEN
    RAISE EXCEPTION 'Entrada rateada: use a substituição do grupo' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS movimento_valida ON estoque.movimento;
CREATE TRIGGER movimento_valida BEFORE INSERT OR UPDATE ON estoque.movimento
  FOR EACH ROW EXECUTE FUNCTION estoque.trg_movimento_valida();

DROP TRIGGER IF EXISTS aud_movimento ON estoque.movimento;
CREATE TRIGGER aud_movimento AFTER INSERT OR UPDATE OR DELETE ON estoque.movimento
  FOR EACH ROW WHEN (current_setting('app.usuario', true) IS DISTINCT FROM 'gerador-consumo')
  EXECUTE FUNCTION insumos.trg_auditoria();

-- ---------------------------------------------------------------- saldo
-- Regras:
--  * Material fora de silo: base = última contagem (ou saldo inicial) + entradas − consumos ± acertos.
--  * Material de silo: o livro é por SILO; o nível é atribuído ao material que está no silo na data.
--    Déficit de um silo fica no saldo contábil e não reduz o disponível de outro silo.
--  * Contagem física vale como saldo de FIM do dia contado: movimentos da mesma data ou anteriores
--    ficam absorvidos por ela; só contam os de datas posteriores.
--  * Movimentos com data futura ou anulados não entram.
CREATE OR REPLACE FUNCTION estoque.saldo_em(p_data date DEFAULT current_date)
RETURNS TABLE (unidade_id smallint, material_id integer, silo_id smallint,
               base_data date, base_quantidade numeric, movimentado numeric,
               saldo_contabil numeric, saldo_fisico numeric)
LANGUAGE sql STABLE AS $$
  WITH m AS (                                       -- livro: 's<silo>' para material de silo, 'm<material>' para os demais
    SELECT mv.*, CASE WHEN mt.usa_silo THEN 's' || mv.silo_id ELSE 'm' || mv.material_id END AS k
      FROM estoque.movimento mv JOIN insumos.material mt ON mt.id = mv.material_id
     WHERE NOT mv.anulado AND mv.data <= p_data AND mt.usa_silo = (mv.silo_id IS NOT NULL)
  ), chaves AS (
    SELECT DISTINCT m.unidade_id, m.k,
           CASE WHEN m.k LIKE 'm%' THEN m.material_id END AS mat,
           CASE WHEN m.k LIKE 's%' THEN m.silo_id END AS silo
      FROM m
    UNION
    SELECT si.unidade_id, 'm' || si.material_id, si.material_id, NULL::smallint
      FROM estoque.saldo_inicial si JOIN insumos.material mt ON mt.id = si.material_id
     WHERE NOT mt.usa_silo AND si.quantidade <> 0
  ), base AS (                                      -- última contagem física de cada livro
    SELECT DISTINCT ON (m.unidade_id, m.k) m.unidade_id, m.k, m.data, m.quantidade
      FROM m WHERE m.tipo = 'contagem'
     ORDER BY m.unidade_id, m.k, m.data DESC, m.id DESC
  ), mov AS (
    SELECT c.unidade_id, c.k,
           coalesce(sum(CASE x.tipo WHEN 'entrada' THEN x.quantidade WHEN 'consumo' THEN -x.quantidade
                                    WHEN 'acerto' THEN x.quantidade ELSE 0 END), 0) AS mov
      FROM chaves c
      LEFT JOIN base b ON b.unidade_id = c.unidade_id AND b.k = c.k
      LEFT JOIN m x ON x.unidade_id = c.unidade_id AND x.k = c.k AND x.tipo <> 'contagem'
                   AND (b.data IS NULL OR x.data > b.data)
     GROUP BY c.unidade_id, c.k
  ), r AS (
    SELECT c.unidade_id, c.mat, c.silo, b.data AS base_data,
           coalesce(b.quantidade, si.quantidade, 0) AS base_q,
           mv.mov
      FROM chaves c
      JOIN mov mv ON mv.unidade_id = c.unidade_id AND mv.k = c.k
      LEFT JOIN base b ON b.unidade_id = c.unidade_id AND b.k = c.k
      LEFT JOIN estoque.saldo_inicial si ON si.unidade_id = c.unidade_id AND si.material_id = c.mat
  )
  SELECT r.unidade_id::smallint, coalesce(r.mat, estoque.material_no_silo(r.silo, p_data)), r.silo::smallint,
         r.base_data, r.base_q, r.mov, round(r.base_q + r.mov, 4), greatest(round(r.base_q + r.mov, 4), 0)
    FROM r
$$;

CREATE OR REPLACE VIEW estoque.saldo_material AS
SELECT s.unidade_id, s.material_id, mt.nome AS material, mt.un_estoque,
       round(sum(s.saldo_contabil), 4) AS saldo_contabil,
       round(sum(s.saldo_fisico), 4)   AS saldo_disponivel,
       count(s.silo_id)                AS silos
  FROM estoque.saldo_em(current_date) s JOIN insumos.material mt ON mt.id = s.material_id
 GROUP BY s.unidade_id, s.material_id, mt.nome, mt.un_estoque;

CREATE OR REPLACE VIEW estoque.nivel_silo AS
SELECT si.id AS silo_id, si.unidade_id, si.numero, si.nome, si.capacidade_nominal, si.capacidade_operacional,
       s.material_id, mt.nome AS material, coalesce(s.saldo_contabil, 0) AS nivel_contabil,
       coalesce(s.saldo_fisico, 0) AS nivel_fisico,
       round(100 * coalesce(s.saldo_fisico, 0) / si.capacidade_operacional, 1) AS ocupacao_pct,
       greatest(si.capacidade_operacional - coalesce(s.saldo_fisico, 0), 0) AS espaco_livre
  FROM estoque.silo si
  LEFT JOIN estoque.saldo_em(current_date) s ON s.silo_id = si.id
  LEFT JOIN insumos.material mt ON mt.id = coalesce(s.material_id, estoque.material_no_silo(si.id, current_date))
 WHERE si.ativo;

-- ---------------------------------------------------------------- baixa automática pela produção
-- Posição do misturador → material (ou silo), com vigência: mudar o mapeamento não reescreve o passado.
CREATE TABLE IF NOT EXISTS estoque.posicao_misturador (
  id           integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  unidade_id   smallint NOT NULL REFERENCES insumos.unidade(id),
  coluna       text NOT NULL,                       -- real_agregado1, real_silo2, ...
  label        text,
  material_id  integer REFERENCES insumos.material(id),
  silo_id      smallint REFERENCES estoque.silo(id), -- posição de silo: material vem de silo_material
  fator        numeric(12,6) NOT NULL DEFAULT 0.001, -- kg da massada → unidade de estoque (t)
  ativo        boolean NOT NULL DEFAULT true,
  ordem        smallint NOT NULL DEFAULT 0,
  desde        date NOT NULL DEFAULT '2000-01-01',
  ate          date,
  CHECK ((material_id IS NULL) <> (silo_id IS NULL)),
  CHECK (fator > 0)
);
CREATE INDEX IF NOT EXISTS ix_posicao ON estoque.posicao_misturador (unidade_id, coluna, desde);

-- Leituras da produção, uma linha por massada × coluna. A migração do Laboratório substitui esta
-- definição por uma view sobre o espelho de tbl_massadas (mesmas colunas e tipos).
DO $$ BEGIN
  IF to_regclass('estoque.v_massada_leitura') IS NULL THEN
    EXECUTE $v$CREATE VIEW estoque.v_massada_leitura AS
      SELECT NULL::smallint AS unidade_id, NULL::date AS data, NULL::text AS coluna, NULL::numeric AS quantidade WHERE false$v$;
  END IF;
  IF to_regclass('estoque.v_massada_produto') IS NULL THEN
    EXECUTE $v$CREATE VIEW estoque.v_massada_produto AS
      SELECT NULL::smallint AS unidade_id, NULL::date AS data, NULL::text AS codigo_traco, NULL::numeric AS volume_m3 WHERE false$v$;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS estoque.consumo_execucao (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  de            date NOT NULL,
  ate           date NOT NULL,
  simulacao     boolean NOT NULL,
  inseridos     integer, atualizados integer, removidos integer,
  executado_por text NOT NULL,
  executado_em  timestamptz NOT NULL DEFAULT now()
);

-- Consumo calculado (sem gravar): base da paridade com o ERP e da baixa automática
CREATE OR REPLACE FUNCTION estoque.consumo_calculado(p_de date, p_ate date)
RETURNS TABLE (unidade_id smallint, data date, coluna text, material_id integer, silo_id smallint,
               quantidade numeric, chave_natural text)
LANGUAGE sql STABLE AS $$
  SELECT l.unidade_id, l.data, p.coluna,
         coalesce(p.material_id, estoque.material_no_silo(p.silo_id, l.data)), p.silo_id,
         round(sum(l.quantidade) * p.fator, 4),
         format('massadas:%s:%s:%s', l.unidade_id, l.data, p.coluna)
    FROM estoque.v_massada_leitura l
    JOIN estoque.posicao_misturador p
      ON p.unidade_id = l.unidade_id AND p.coluna = l.coluna AND p.ativo
     AND l.data BETWEEN p.desde AND coalesce(p.ate, 'infinity'::date)
   WHERE l.data BETWEEN greatest(p_de, (SELECT valor::date FROM insumos.config WHERE chave = 'consumo_inicio')) AND p_ate
   GROUP BY l.unidade_id, l.data, p.coluna, p.material_id, p.silo_id, p.fator
  HAVING round(sum(l.quantidade) * p.fator, 4) > 0
$$;

-- Baixa automática idempotente: mesma chave = mesmo movimento (o ID não muda ao reprocessar)
CREATE OR REPLACE FUNCTION estoque.gerar_consumo(p_de date, p_ate date, p_por text)
RETURNS TABLE (inseridos integer, atualizados integer, removidos integer)
LANGUAGE plpgsql AS $$
DECLARE v_ins int := 0; v_upd int := 0; v_del int := 0;
BEGIN
  IF (SELECT valor FROM insumos.config WHERE chave = 'consumo_gerador') <> 'vps_nova' THEN
    RAISE EXCEPTION 'O gerador de consumo ainda é o ERP (insumos.config consumo_gerador). Use consumo_calculado para comparar.';
  END IF;
  PERFORM pg_advisory_xact_lock(hashtext('estoque.gerar_consumo'));
  PERFORM set_config('app.usuario', 'gerador-consumo', true);

  CREATE TEMP TABLE _calc ON COMMIT DROP AS SELECT * FROM estoque.consumo_calculado(p_de, p_ate);

  WITH up AS (
    UPDATE estoque.movimento mv SET quantidade = c.quantidade, material_id = c.material_id, silo_id = c.silo_id
      FROM _calc c
     WHERE mv.chave_natural = c.chave_natural AND NOT mv.anulado
       AND (mv.quantidade, mv.material_id, mv.silo_id) IS DISTINCT FROM (c.quantidade, c.material_id, c.silo_id)
    RETURNING 1)
  SELECT count(*) INTO v_upd FROM up;

  WITH ins AS (
    INSERT INTO estoque.movimento (unidade_id, material_id, tipo, data, quantidade, silo_id, origem,
                                   chave_natural, referencia, criado_por)
    SELECT c.unidade_id, c.material_id, 'consumo', c.data, c.quantidade, c.silo_id, 'producao_massadas',
           c.chave_natural, c.coluna, p_por
      FROM _calc c
     WHERE NOT EXISTS (SELECT 1 FROM estoque.movimento mv WHERE mv.chave_natural = c.chave_natural)
    RETURNING 1)
  SELECT count(*) INTO v_ins FROM ins;

  WITH del AS (     -- baixas automáticas do período que deixaram de existir na produção
    DELETE FROM estoque.movimento mv
     WHERE mv.origem = 'producao_massadas' AND mv.data BETWEEN p_de AND p_ate
       AND NOT EXISTS (SELECT 1 FROM _calc c WHERE c.chave_natural = mv.chave_natural)
    RETURNING 1)
  SELECT count(*) INTO v_del FROM del;

  INSERT INTO estoque.consumo_execucao (de, ate, simulacao, inseridos, atualizados, removidos, executado_por)
  VALUES (p_de, p_ate, false, v_ins, v_upd, v_del, p_por);
  RETURN QUERY SELECT v_ins, v_upd, v_del;
END $$;

-- Consumo diário por material (base da previsão)
CREATE OR REPLACE VIEW estoque.consumo_diario AS
SELECT unidade_id, material_id, data, round(sum(quantidade), 4) AS quantidade
  FROM estoque.movimento
 WHERE tipo = 'consumo' AND NOT anulado
 GROUP BY unidade_id, material_id, data;

-- Custo médio ponderado e última entrada (para o MCC usar o custo real do estoque)
CREATE OR REPLACE FUNCTION estoque.custos_entrada_em(p_data date, p_dias integer DEFAULT 90)
RETURNS TABLE (unidade_id smallint, material_id integer, fornecedor_id integer,
               ultima_data date, ultimo_custo numeric, custo_medio numeric, quantidade numeric)
LANGUAGE sql STABLE AS $$
  SELECT e.unidade_id, e.material_id, (array_agg(e.fornecedor_id ORDER BY e.data DESC, e.id DESC))[1],
         max(e.data),
         (array_agg(e.custo_unit_liquido ORDER BY e.data DESC, e.id DESC))[1],
         round(sum(e.custo_unit_liquido * e.quantidade) FILTER (WHERE e.data > p_data - p_dias)
               / NULLIF(sum(e.quantidade) FILTER (WHERE e.data > p_data - p_dias), 0), 4),
         sum(e.quantidade) FILTER (WHERE e.data > p_data - p_dias)
    FROM estoque.movimento e
   WHERE e.tipo = 'entrada' AND NOT e.anulado AND e.custo_unit_liquido IS NOT NULL AND e.data <= p_data
   GROUP BY e.unidade_id, e.material_id
$$;

COMMIT;
