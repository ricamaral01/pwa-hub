const STORAGE_KEY = "pwa_liberacao_inspecao_v1";
const SUBMIT_LOCKS_KEY = "pwa_liberacao_submit_locks_v1";
const CLICKED_FORMS_KEY = "pwa_formas_clicadas_hoje";
const MONTAGEM_POSTES_KEY = "pwa_montagem_postes_v1";
const AUTH_SESSION_KEY = "pwa_mapa_auth_session_v1";
const MANDRIL_MODELOS_PRODUZIDOS_KEY = "pwa_mandril_modelos_produzidos_v1";

const ROLE_PERMISSIONS = {
  CONVIDADO: {label: "Convidado", modes: ["ACMP_CONCRETAGEM", "DASHBOARD_DEFEITOS", "HISTORICO", "INSPECAO", "LIBERACAO", "LIBERACAO_S1", "LIBERACAO_S2", "LIBERACAO_S3", "LIBERACAO_S4", "MANDRIL_CIRCULAR", "MONTAGEM_INDICADORES", "MONTAGEM_POSTES", "PROD_ANALISE", "RELATORIO", "RELATORIO_MANUTENCAO", "SEQUENCIA_S3", "TRATATIVA_DEFEITOS", "USUARIOS"]},
  GERENCIA: {
    label: "Gerência",
    modes: ["DASHBOARD", "PROD_ANALISE", "LIBERACAO", "LIBERACAO_S1", "LIBERACAO_S2", "LIBERACAO_S3", "LIBERACAO_S4", "INSPECAO", "MONTAGEM_POSTES", "MONTAGEM_INDICADORES", "DASHBOARD_DEFEITOS", "RELATORIO", "HISTORICO", "ACMP_CONCRETAGEM", "USUARIOS", "SEQUENCIA_S3", "MANDRIL_CIRCULAR", "RELATORIO_MANUTENCAO", "TRATATIVA_DEFEITOS"]
  },
  GESTOR: {
    label: "Gestor",
    modes: ["DASHBOARD", "PROD_ANALISE", "LIBERACAO", "LIBERACAO_S1", "LIBERACAO_S2", "LIBERACAO_S3", "LIBERACAO_S4", "MONTAGEM_POSTES", "MONTAGEM_INDICADORES", "DASHBOARD_DEFEITOS", "RELATORIO", "HISTORICO", "ACMP_CONCRETAGEM", "SEQUENCIA_S3", "MANDRIL_CIRCULAR", "RELATORIO_MANUTENCAO", "TRATATIVA_DEFEITOS"]
  },
  MONTADOR: {
    label: "Montador",
    modes: ["INSPECAO", "MONTAGEM_POSTES", "SEQUENCIA_S3", "RELATORIO_MANUTENCAO", "TRATATIVA_DEFEITOS"]
  },
  APONTADOR: {
    label: "Apontador",
    modes: ["LIBERACAO_S1", "LIBERACAO_S2", "LIBERACAO_S3", "LIBERACAO_S4", "MANDRIL_CIRCULAR", "RELATORIO_MANUTENCAO", "TRATATIVA_DEFEITOS"]
  }
};

function getInspecaoChecklistSections(modelo = "") {
  return [
    {
      id: "inspecao_visual",
      titulo: "Inspeção Visual",
      itens: [
        { id: "homogeneidade_concreto", texto: "Homogeneidade do Concreto", critico: true, codigoFalha: "O" },
        { id: "falhas_preenchimento", texto: "Falhas de Preenchimento", critico: true, codigoFalha: "A" },
        { id: "concreto_segregado", texto: "Concreto Segregado", critico: true, codigoFalha: "O" },
        { id: "grandes_avarias", texto: "Grandes Avarias", critico: true, codigoFalha: "P" },
        { id: "furacao_obstruida", texto: "Furação Obstruída (pinos)", critico: true, codigoFalha: "E" },
        { id: "armacao_aparente", texto: "Armação aparente", critico: true, codigoFalha: "A" },
        { id: "trincas", texto: "Trincas", critico: true, codigoFalha: "I" },
        { id: "tubulacao_entupida", texto: "Tubulação Entupida", critico: true, codigoFalha: "B" },
        { id: "bolhas_excesso", texto: "Bolhas em excesso", critico: false, codigoFalha: "C" },
        { id: "bolhas_fora_padrao", texto: "Bolhas fora do padrão", critico: false, codigoFalha: "C" },
        { id: "carimbo_identificacao", texto: "Carimbo de Identificação", critico: false, codigoFalha: "F" },
        { id: "fissuras", texto: "Fissuras", critico: false, codigoFalha: "G" },
        { id: "rebarbas", texto: "Rebarbas", critico: false, codigoFalha: "Q" },
        { id: "manchas_excessivas", texto: "Manchas excessivas", critico: false, codigoFalha: "K" },
        { id: "buchas_fixacao", texto: "Buchas de fixação", critico: false, codigoFalha: "L" },
        { id: "acabamento_face_exposta", texto: "Acabamento face exposta", critico: false, codigoFalha: "R" },
        { id: "acabamento_abas", texto: "Acabamento abas", critico: false, codigoFalha: "S" }
      ]
    }
  ];
}

function getMontagemChecklistSections(modelo = "") {
  const isDuploT = /DT|Duplo T|Barreiras/i.test(modelo);

  return [
    {
      id: "checagem_inicial",
      titulo: "Inspeção Visual",
      itens: [
        { id: "homogeneidade_concreto", texto: "Homogeneidade do Concreto", critico: true, codigoFalha: "O" },
        { id: "falhas_preenchimento", texto: "Falhas de Preenchimento", critico: true, codigoFalha: "A" },
        { id: "concreto_segregado", texto: "Concreto Segregado", critico: true, codigoFalha: "O" },
        { id: "grandes_avarias", texto: "Grandes Avarias", critico: true, codigoFalha: "P" },
        { id: "facao_obstruido", texto: "Facão Obstruído", critico: true, codigoFalha: "E" },
        { id: "furacao_obstruida", texto: "Furação Obstruída (pinos)", critico: true, codigoFalha: "E" },
        { id: "armacao_aparente", texto: "Armação aparente", critico: true, codigoFalha: "A" },
        { id: "trincas", texto: "Trincas", critico: true, codigoFalha: "I" },
        { id: "tubulacao_entupida", texto: "Tubulação Entupida", critico: true, codigoFalha: "B" },
        { id: "bolhas_excesso", texto: "Bolhas em excesso", critico: false, codigoFalha: "C" },
        { id: "bolhas_fora_padrao", texto: "Bolhas fora do padrão", critico: false, codigoFalha: "C" },
        { id: "carimbo_identificacao", texto: "Carimbo de Identificação", critico: false, codigoFalha: "F" },
        { id: "fissuras", texto: "Fissuras", critico: false, codigoFalha: "G" },
        { id: "pequenas_avarias", texto: "Pequenas avarias", critico: false, codigoFalha: "J" },
        { id: "rebarbas", texto: "Rebarbas", critico: false, codigoFalha: "Q" },
        { id: "manchas_excessivas", texto: "Manchas excessivas", critico: false, codigoFalha: "K" },
        { id: "buchas_fixacao", texto: "Buchas de fixação", critico: false, codigoFalha: "L" },
        { id: "prisioneiros_lacre_aterramento", texto: "Prisioneiros (lacre / aterramento)", critico: false, codigoFalha: "M" },
        { id: "acabamento_face_exposta", texto: "Acabamento face exposta", critico: false, codigoFalha: "R" },
        { id: "acabamento_abas", texto: "Acabamento abas", critico: false, codigoFalha: "S" }
      ]
    },
    {
      id: "checagem_materiais",
      titulo: "Montagem de Postes",
      itens: [
        { id: "montagem_do_poste", texto: "Montagem do Poste", critico: false }
      ]
    },
    {
      id: "final",
      titulo: "Inspeção Final",
      itens: [
        { id: "rebarbas_final", texto: "Rebarbas", critico: false },
        { id: "liberacao_qualidade", texto: "Liberação Qualidade", critico: false },
        { id: "codificacao_poste", texto: "Codificação Poste", critico: false },
        { id: "aterramento", texto: "Limpeza Aterramento", critico: false },
        { id: "lacre", texto: "Limpeza Lacre", critico: false }
      ]
    }
  ];
}

const CONCRETO_TIPOS = ["Concreto Padrão", "Concreto Seco - Vibrado", "Concreto Segregado", "Concreto Exsudado", "Teste Lab."];

function getConcreteTypeForForma(forma, setor) {
  const dataFabricacao = el.libData?.value || todayYmd();
  const db = readDb();
  const record = findRecordByKey(db, dataFabricacao, setor, normalizeUpper(forma));
  return record?.concretoTipo || null;
}

function getProductionRecordForForma(forma, setor) {
  const dataFabricacao = el.libData?.value || todayYmd();
  const db = readDb();
  return findRecordByKey(db, dataFabricacao, setor, normalizeUpper(forma));
}

function formatFormaConcreteBadge(record) {
  const parts = [];
  if ((record?.setor === "Setor 3" || record?.setor === "Setor 4")
    && record?.modelo && !/^(SC|DTB|DTBM|DTD)$/i.test(String(record.modelo).trim())) {
    parts.push(record.modelo);
  }
  if (record?.concretoTipo) parts.push(record.concretoTipo);
  if (typeof record?.vibrado === "boolean") {
    parts.push(`Vibrado: ${record.vibrado ? "Sim" : "Não"}`);
  }
  return parts.join("\n");
}

function updateProductionCardBadge(card, setor, modelo, concretoTipo, vibrado) {
  card.dataset.modelo = modelo;
  const modelLabel = card.querySelector?.(".lib-btn-model");
  if (modelLabel) modelLabel.textContent = modelo;
  const tipoEl = card.querySelector?.(".fc-tipo");
  if (!tipoEl) return;
  const badgeText = formatFormaConcreteBadge({ setor, modelo, concretoTipo, vibrado });
  tipoEl.textContent = badgeText;
  tipoEl.style.display = badgeText ? "block" : "none";
}

function getClickedFormsToday() {
  const raw = localStorage.getItem(CLICKED_FORMS_KEY);
  if (!raw) return { dia: "", formas: {} };
  try {
    const parsed = JSON.parse(raw);
    const hoje = new Date().toLocaleDateString("pt-BR");
    if (parsed.dia !== hoje) return { dia: hoje, formas: {} };
    return parsed;
  } catch { return { dia: "", formas: {} }; }
}

function markFormaClicked(forma, setor) {
  const data = getClickedFormsToday();
  data.dia = new Date().toLocaleDateString("pt-BR");
  const key = setor + "||" + normalizeUpper(forma);
  data.formas[key] = true;
  localStorage.setItem(CLICKED_FORMS_KEY, JSON.stringify(data));
}

function isFormaClicked(forma, setor) {
  const dataFabricacao = el.libData?.value || todayYmd();

  // Se a data selecionada for hoje, verifica primeiro os cliques rápidos locais
  const hoje = todayYmd();
  if (dataFabricacao === hoje) {
    const clicked = getClickedFormsToday();
    const key = setor + "||" + normalizeUpper(forma);
    if (clicked.formas[key] === true || clicked.formas[key] === "1") return true;
  }

  // Verificação definitiva a partir do banco de dados local (sincronizado dinamicamente do Supabase)
  const db = readDb();
  const record = findRecordByKey(db, dataFabricacao, setor, normalizeUpper(forma));
  return record?.liberacao?.status === "1";
}

function isFormaLiberada(forma, setor) {
  const dataFabricacao = el.libData?.value || todayYmd();

  const hoje = todayYmd();
  if (dataFabricacao === hoje) {
    const clicked = getClickedFormsToday();
    const key = setor + "||" + normalizeUpper(forma);
    if (clicked.formas[key] === "L") return true;
  }

  const db = readDb();
  const record = findRecordByKey(db, dataFabricacao, setor, normalizeUpper(forma));
  return record?.liberacao?.status === "L";
}

function isFormaProgrammed(forma, setor) {
  const dataFabricacao = el.libData?.value || todayYmd();
  const hoje = todayYmd();
  if (dataFabricacao === hoje) {
    const clicked = getClickedFormsToday();
    const key = setor + "||" + normalizeUpper(forma);
    if (clicked.formas[key] === "P") return true;
  }
  const db = readDb();
  const record = findRecordByKey(db, dataFabricacao, setor, normalizeUpper(forma));
  return record?.liberacao?.status === "P";
}
const SUPABASE_CONFIG = {
  URL: location.origin + "/unificado/mapa/api",
  KEY: "unificado-test-only"
};
const PCP_PROGRAMACAO_URL = "https://pcp.concretrack.com.br/api/programacao";
const supabaseClient = window.supabase ? window.supabase.createClient(SUPABASE_CONFIG.URL, SUPABASE_CONFIG.KEY) : null;

function getBackendUrl() {
  const hostname = window.location.hostname;
  if (hostname === "localhost" || hostname === "127.0.0.1") {
    return "http://localhost:5000/api";
  }
  return "https://dautomacao.com/api";
}

const CHECKLIST_INSPECAO_CODIGOS = [
  { codigo: "A", descricao: "Falha na Concretagem" },
  { codigo: "B", descricao: "Cano entupido" },
  { codigo: "C", descricao: "Excesso de Bolhas" },
  { codigo: "D", descricao: "Problema na caixa do Relógio ou Disjuntor" },
  { codigo: "E", descricao: "Furos Obstruídos ou Faltando" },
  { codigo: "F", descricao: "Identificação do poste (Carimbos)" },
  { codigo: "G", descricao: "Presença de Trincas" },
  { codigo: "H", descricao: "Bolha nas caixas" },
  { codigo: "I", descricao: "Trincas em toda a extensão do Poste" },
  { codigo: "J", descricao: "Pequenas Avarias" },
  { codigo: "K", descricao: "Manchas Brancas Superficiais" },
  { codigo: "L", descricao: "Buchas das cxs e/ou Buchas fixação abraç. EDP" },
  { codigo: "M", descricao: "Parafuso Lacre da caixa do Medidor" },
  { codigo: "O", descricao: "Falha no Concreto" },
  { codigo: "P", descricao: "Grandes Avarias" },
  { codigo: "Q", descricao: "Rebarbas" },
  { codigo: "R", descricao: "Rugosidade" },
  { codigo: "S", descricao: "Acabamento quinas" }
];

const INDIVIDUAL_RESPONSAVEIS = ["Alex", "José Carlos", "Osmar", "Philippe", "Ricardo"];

const MATRIZ_DEFEITOS_RESPONSAVEIS = {
  A: { codigo: "A", descricao: "Falha na Concretagem / Armação Aparente", classificacao: "CRÍTICO", status: "Reprova (R)", detalhamento: "Ferragem exposta sem cobrimento mínimo de concreto ou ninhos de abelha no fuste.", acao: "Refugo / Descarte Imediato (Compromete Durabilidade e Estrutura)", responsavel: "Osmar / José Carlos", responsaveisLista: ["Osmar", "José Carlos"] },
  B: { codigo: "B", descricao: "Cano Entupido", classificacao: "CRÍTICO", status: "Reprova (R)", detalhamento: "Eletroduto/tubulação interna de passagem de cabos totalmente obstruída por concreto.", acao: "Refugo / Descarte (Poste Inutilizado para Rede Elétrica)", responsavel: "Osmar / José Carlos", responsaveisLista: ["Osmar", "José Carlos"] },
  C: { codigo: "C", descricao: "Excesso de Bolhas", classificacao: "NÃO CRÍTICO", status: "Retrabalho (RR)", detalhamento: "Presença de bolhas de ar superficiais fora do padrão estético no fuste.", acao: "Encaminhar para Acabamento / Estucagem Superficial", responsavel: "Philippe / Ricardo", responsaveisLista: ["Philippe", "Ricardo"] },
  D: { codigo: "D", descricao: "Problema na Caixa do Relógio ou Disjuntor", classificacao: "NÃO CRÍTICO", status: "Retrabalho (RR)", detalhamento: "Desalinhamento, quebra parcial ou avaria nos nichos das caixas de medição.", acao: "Retrabalho de Ajuste e Reparo na Caixa", responsavel: "Alex", responsaveisLista: ["Alex"] },
  E: { codigo: "E", descricao: "Furos Obstruídos ou Faltando (Facão / Pinos)", classificacao: "CRÍTICO", status: "Reprova (R)", detalhamento: "Furação de fixação de isoladores ou facão do topo obstruídos por concreto.", acao: "Tentativa de Desobstrução / Se Inviável, Reprovação", responsavel: "Osmar / José Carlos", responsaveisLista: ["Osmar", "José Carlos"] },
  F: { codigo: "F", descricao: "Identificação do Poste (Carimbos)", classificacao: "NÃO CRÍTICO", status: "Retrabalho (RR)", detalhamento: "Carimbo de identificação ilegível ou marcação incorreta de esforço/comprimento.", acao: "Re-carimbagem e Correção de Identificação", responsavel: "Osmar / José Carlos", responsaveisLista: ["Osmar", "José Carlos"] },
  G: { codigo: "G", descricao: "Presença de Trincas Superficiais", classificacao: "NÃO CRÍTICO", status: "Retrabalho (RR)", detalhamento: "Fissuras superficiais capilares decorrentes de tensão na desforma.", acao: "Calafetagem Superficial e Monitoramento", responsavel: "Philippe / Ricardo", responsaveisLista: ["Philippe", "Ricardo"] },
  H: { codigo: "H", descricao: "Bolha nas Caixas", classificacao: "NÃO CRÍTICO", status: "Retrabalho (RR)", detalhamento: "Acúmulo de bolhas de ar nos contornos internos/externos dos nichos.", acao: "Estucagem e Acabamento Manuais", responsavel: "Philippe / Ricardo", responsaveisLista: ["Philippe", "Ricardo"] },
  I: { codigo: "I", descricao: "Trincas em Toda a Extensão do Poste", classificacao: "CRÍTICO", status: "Reprova (R)", detalhamento: "Trinca estrutural transversal ou longitudinal contínua ao longo do fuste.", acao: "Refugo Imediato (Perda de Capacidade Mecânica)", responsavel: "Philippe / Ricardo", responsaveisLista: ["Philippe", "Ricardo"] },
  J: { codigo: "J", descricao: "Pequenas Avarias", classificacao: "NÃO CRÍTICO", status: "Retrabalho (RR)", detalhamento: "Lascas superficiais de pequena dimensão ou rebarbas de desforma.", acao: "Acabamento e Reparo com Argamassa Estrutural", responsavel: "Ricardo / Alex", responsaveisLista: ["Ricardo", "Alex"] },
  K: { codigo: "K", descricao: "Manchas Brancas Superficiais", classificacao: "NÃO CRÍTICO", status: "Retrabalho (RR)", detalhamento: "Eflorescência salina ou manchas de nata de cimento na superfície.", acao: "Limpeza Química / Escovação da Superfície", responsavel: "Philippe / Ricardo", responsaveisLista: ["Philippe", "Ricardo"] },
  L: { codigo: "L", descricao: "Buchas das Caixas / Buchas EDP", classificacao: "NÃO CRÍTICO", status: "Retrabalho (RR)", detalhamento: "Buchas de fixação desalinhadas ou obstruídas com nata de concreto.", acao: "Limpeza das Roscas / Re-macho de Rosca", responsavel: "Osmar / José Carlos", responsaveisLista: ["Osmar", "José Carlos"] },
  M: { codigo: "M", descricao: "Parafuso Lacre da Caixa do Medidor", classificacao: "NÃO CRÍTICO", status: "Retrabalho (RR)", detalhamento: "Prisioneiros de lacre ou aterramento cobertos de nata.", acao: "Limpeza dos Prisioneiros e Roscas", responsavel: "Osmar / José Carlos", responsaveisLista: ["Osmar", "José Carlos"] },
  O: { codigo: "O", descricao: "Falha no Concreto (Concreto Segregado)", classificacao: "CRÍTICO", status: "Reprova (R)", detalhamento: "Segregação entre brita e argamassa ou falta de homogeneidade do concreto.", acao: "Refugo Imediato (Falta de Resistência Mecânica)", responsavel: "Ricardo / Alex", responsaveisLista: ["Ricardo", "Alex"] },
  P: { codigo: "P", descricao: "Grandes Avarias", classificacao: "CRÍTICO", status: "Reprova (R)", detalhamento: "Fraturas, quebras de quinas extensas ou avarias de transporte interno.", acao: "Refugo / Sucata (Dano Estrutural Irreversível)", responsavel: "Ricardo / Alex", responsaveisLista: ["Ricardo", "Alex"] }
};

function getDefeitoInfo(codigo) {
  const c = String(codigo || "").trim().toUpperCase();
  return MATRIZ_DEFEITOS_RESPONSAVEIS[c] || {
    codigo: c || "-",
    descricao: "Não especificado",
    classificacao: "NÃO CRÍTICO",
    status: "Retrabalho (RR)",
    detalhamento: "Não conformidade técnica registrada.",
    acao: "Análise técnica de qualidade",
    responsavel: "Equipe de Qualidade",
    responsaveisLista: ["Equipe de Qualidade"]
  };
}

const POSTES_DUPLO_T_CATALOGO = [
  { codigo: "C", descricao: "Padrao Completo 2 cx VR", setor: "Setor 2", codigoProduto: "943", chaves: ["C"] },
  { codigo: "D", descricao: "Padrao Completo 2 cx VL", setor: "Setor 1", codigoProduto: "941", chaves: ["D"] },
  { codigo: "B", descricao: "Padrao Completo 1 cx VL", setor: "Setor 2", codigoProduto: "935", chaves: ["B"] },
  { codigo: "A", descricao: "Padrao Completo 1 cx VR", setor: "Setor 2", codigoProduto: "938", chaves: ["A"] },
  { codigo: "BD", descricao: "Padrao Completo 1 cx VL (EDP)", setor: "Setor 1", codigoProduto: "957", chaves: ["BD"] },
  { codigo: "CE", descricao: "Padrao Completo 2 cx VR Elektro", setor: "Setor 1", codigoProduto: "4032", chaves: ["CE"] },
  { codigo: "DE", descricao: "Padrao Completo 2 cx VL Elektro", setor: "Setor 1", codigoProduto: "4765", chaves: ["DE"] },
  { codigo: "AE", descricao: "Padrao Completo 1 cx VR Elektro", setor: "Setor 1", codigoProduto: "4031", chaves: ["AE"] },
  { codigo: "BE", descricao: "Padrao Completo 1 cx VL Elektro", setor: "Setor 1", codigoProduto: "4764", chaves: ["BE"] },
  { codigo: "IE", descricao: "Padrao Completo 3cxs VL Elektro", setor: "Setor 1", codigoProduto: "4929", chaves: ["IE"] },
  { codigo: "L", descricao: "Padrao Completo 4 cx VR", setor: "Setor 1", codigoProduto: "948", chaves: ["L"] },
  { codigo: "J", descricao: "Padrao Completo 4 cx VL", setor: "Setor 1", codigoProduto: "947", chaves: ["J"] },
  { codigo: "H", descricao: "Padrao Completo 3 cx VR", setor: "Setor 1", codigoProduto: "946", chaves: ["H"] },
  { codigo: "I", descricao: "Padrao Completo 3 cx VL", setor: "Setor 1", codigoProduto: "945", chaves: ["I"] },
  { codigo: "300-VR", descricao: "Poste 2 cx VR (7,5 x 300)", setor: "Setor 1", codigoProduto: "944", chaves: ["300-VR"] },
  { codigo: "300-VL", descricao: "Poste 2 cx VL (7,5 x 300)", setor: "Setor 1", codigoProduto: "942", chaves: ["300-VL"] },
  { codigo: "CM", descricao: "Padrao Cemig 1 cx VL - 7,0 x150", setor: "Setor 1", codigoProduto: "953", chaves: ["CM", "BC"] },
  { codigo: "N", descricao: "Poste 7,5 X 600 VL", setor: "Setor 1", codigoProduto: "936", chaves: ["N"] },
  { codigo: "M", descricao: "Poste 7,5 X 600 VR", setor: "Setor 1", codigoProduto: "939", chaves: ["M"] },
  { codigo: "TCL", descricao: "Poste 7,5 X 600 VL c/", setor: "Setor 2", codigoProduto: "937", chaves: ["TCL"] },
  { codigo: "TCR", descricao: "Poste 7,5 X 600 VR c/", setor: "Setor 2", codigoProduto: "940", chaves: ["TCR"] },
  { codigo: "100", descricao: "Poste Subterraneo 100 A", setor: "Setor 1", codigoProduto: "949", chaves: ["100"] },
  { codigo: "SB-E1", descricao: "Poste Subterraneo 100 A - Elektro", setor: "Setor 1", codigoProduto: "4848", chaves: ["SB-E1"] },
  { codigo: "200", descricao: "Poste Subterraneo 200 A - TC", setor: "Setor 1", codigoProduto: "5017", chaves: ["200"] },
  { codigo: "TOTEM", descricao: "Totem de medicao indireta Elektro", setor: "Setor 2", codigoProduto: "13570", chaves: ["TOTEM", "A-TOTEM", "TMIE"] },
  { codigo: "PL", descricao: "Poste Visor Aereo 1 cx VL (7,5x300)", setor: "Setor 2", codigoProduto: "934", chaves: ["PL"] },
  { codigo: "CEMIG-5X150", descricao: "Padrao Cemig 1CX - 5,0 x 150", setor: "Setor 4", codigoProduto: "952", chaves: ["C-F1"] },
  { codigo: "CEMIG-1VL", descricao: "Padrao Cemig 1 cx VL - 7,0 x150", setor: "Setor 4", codigoProduto: "953", chaves: ["R-G"] },
  { codigo: "CEMIG-2VL", descricao: "Padrao Cemig 2 cx VL - 7,0 x150", setor: "Setor 4", codigoProduto: "954", chaves: [] },
  { codigo: "E", descricao: "Poste Economico 1CX VR", setor: "Setor 1", codigoProduto: "931", chaves: ["E"] },
  { codigo: "F", descricao: "Poste Economico 1CX VL", setor: "Setor 1", codigoProduto: "930", chaves: ["F"] },
  { codigo: "G", descricao: "Poste Economico 2CX VR", setor: "Setor 1", codigoProduto: "932", chaves: ["G"] },
  { codigo: "P", descricao: "Poste Economico 3 CXS VR", setor: "Setor 1", codigoProduto: "933", chaves: ["P"] },
  { codigo: "DTB", descricao: "Poste Duplo T Barreiras", setor: "Setor 4", codigoProduto: "13580", chaves: ["DTB"] },
  { codigo: "DTBM", descricao: "Poste Duplo T Barreiras Médio", setor: "Setor 4", codigoProduto: "13581", chaves: ["DTBM"] },
  { codigo: "DTD", descricao: "Poste Duplo T Especial D", setor: "Setor 4", codigoProduto: "13582", chaves: ["DTD"] }
];

const POSTES_DUPLO_T_BY_CHAVE = new Map();
POSTES_DUPLO_T_CATALOGO.forEach((item) => {
  (item.chaves || []).forEach((chave) => POSTES_DUPLO_T_BY_CHAVE.set(normalizeUpper(chave), item));
});

const SETOR_1_LEFT_FORMS = [
  { forma: "IE-01", modelo: "3 CXS VL" },
  { forma: "BD-01", modelo: "1 CX VL" },
  { forma: "BD-02", modelo: "1 CX VL" },
  { forma: "BD-03", modelo: "1 CX VL" },
  { forma: "BD-04", modelo: "1 CX VL" },
  { forma: "BD-05", modelo: "1 CX VL" },
  { forma: "BD-06", modelo: "1 CX VL" },
  { forma: "BD-07", modelo: "1 CX VL" },
  { forma: "BD-08", modelo: "1 CX VL" },
  { forma: "BD-09", modelo: "1 CX VL" },
  { forma: "BD-10", modelo: "1 CX VL" },
  { forma: "BD-11", modelo: "1 CX VL" },
  { forma: "BD-12", modelo: "1 CX VL" },
  { forma: "BD-13", modelo: "1 CX VL" },
  { forma: "BD-14", modelo: "1 CX VL" },
  { forma: "BD-15", modelo: "1 CX VL" },
  { forma: "AE-27", modelo: "1 CX VR" },
  { forma: "AE-26", modelo: "1 CX VR" },
  { forma: "AE-25", modelo: "1 CX VR" },
  { forma: "AE-24", modelo: "1 CX VR" },
  { forma: "AE-23", modelo: "1 CX VR" },
  { forma: "AE-22", modelo: "1 CX VR" },
  { forma: "AE-21", modelo: "1 CX VR" },
  { forma: "AE-20", modelo: "1 CX VR" },
  { forma: "AE-19", modelo: "1 CX VR" },
  { forma: "AE-18", modelo: "1 CX VR" },
  { forma: "AE-17", modelo: "1 CX VR" },
  { forma: "AE-16", modelo: "1 CX VR" },
  { forma: "AE-15", modelo: "1 CX VR" },
  { forma: "AE-14", modelo: "1 CX VR" },
  { forma: "AE-13", modelo: "1 CX VR" },
  { forma: "AE-12", modelo: "1 CX VR" },
  { forma: "AE-11", modelo: "1 CX VR" },
  { forma: "AE-10", modelo: "1 CX VR" },
  { forma: "AE-09", modelo: "1 CX VR" },
  { forma: "AE-08", modelo: "1 CX VR" },
  { forma: "AE-07", modelo: "1 CX VR" },
  { forma: "AE-06", modelo: "1 CX VR" },
  { forma: "AE-05", modelo: "1 CX VR" },
  { forma: "AE-04", modelo: "1 CX VR" },
  { forma: "AE-03", modelo: "1 CX VR" },
  { forma: "AE-02", modelo: "1 CX VR" },
  { forma: "AE-01", modelo: "1 CX VR" },
  { forma: "100-1", modelo: "SUB. 100-AMP" },
  { forma: "100-2", modelo: "SUB. 100-AMP" },
  { forma: "100-3", modelo: "SUB. 100-AMP" },
  { forma: "F-01", modelo: "Ec. 1 cx VL" }
];

const SETOR_1_RIGHT_FORMS = [
  { forma: "L-01", modelo: "4 CXS VR" },
  { forma: "L-02", modelo: "4 CXS VR" },
  { forma: "J-01", modelo: "4 CXS VL" },
  { forma: "H-01", modelo: "3 CXS VR" },
  { forma: "H-02", modelo: "3 CXS VR" },
  { forma: "I-01", modelo: "3 CXS VL" },
  { forma: "P-01", modelo: "Ec. 3 CXS" },
  { forma: "P-02", modelo: "Ec. 3 CXS" },
  { forma: "I-02", modelo: "3 CXS VL" },
  { forma: "BE-04", modelo: "1 CX VL" },
  { forma: "BE-03", modelo: "1 CX VL" },
  { forma: "BE-02", modelo: "1 CX VL" },
  { forma: "BE-01", modelo: "1 CX VL" },
  { forma: "G-01", modelo: "Ec. 2CXS VR" },
  { forma: "G-02", modelo: "Ec. 2CXS VR" },
  { forma: "G-03", modelo: "Ec. 2CXS VR" },
  { forma: "G-04", modelo: "Ec. 2CXS VR" },
  { forma: "G-05", modelo: "Ec. 2CXS VR" },
  { forma: "BC - 01", modelo: "1 CX VL 7,0 x 150" },
  { forma: "300-VL", modelo: "2 CXS VL" },
  { forma: "300-VR", modelo: "2 CXS VR" },
  { forma: "E-01", modelo: "Ec. 1CX VR" },
  { forma: "E-02", modelo: "Ec. 1CX VR" },
  { forma: "E-03", modelo: "Ec. 1CX VR" },
  { forma: "E-04", modelo: "Ec. 1CX VR" },
  { forma: "E-05", modelo: "Ec. 1CX VR" },
  { forma: "E-06", modelo: "Ec. 1CX VR" },
  { forma: "D-03", modelo: "2 CXS VL" },
  { forma: "D-04", modelo: "2 CXS VL" },
  { forma: "D-05", modelo: "2 CXS VL" },
  { forma: "D-06", modelo: "2 CXS VL" },
  { forma: "D-07", modelo: "2 CXS VL" },
  { forma: "M-01", modelo: "1 CX VR - 600" },
  { forma: "CE-13", modelo: "2 CXS VR" },
  { forma: "CE-12", modelo: "2 CXS VR" },
  { forma: "CE-11", modelo: "2 CXS VR" },
  { forma: "CE-10", modelo: "2 CXS VR" },
  { forma: "CE-09", modelo: "2 CXS VR" },
  { forma: "CE-05", modelo: "2 CXS VR" },
  { forma: "CE-04", modelo: "2 CXS VR" },
  { forma: "CE-03", modelo: "2 CXS VR" },
  { forma: "100 - 4", modelo: "SUB. 100 AMP." },
  { forma: "100 - 5", modelo: "SUB. 100 AMP." },
  { forma: "SBE-1", modelo: "SUB. 100-AMP-E" },
  { forma: "SBE-2", modelo: "SUB. 100-AMP-E" },
  { forma: "200 -1", modelo: "SUB. 200-AMP C/ TC" },
  { forma: "200 -2", modelo: "SUB. 200-AMP C/ TC" },
  { forma: "DE-03", modelo: "2 CXS VL" },
  { forma: "DE-02", modelo: "2 CXS VL" },
  { forma: "DE-01", modelo: "2 CXS VL" },
  { forma: "N-01", modelo: "1 CX VL - 600" }
];

const SETOR_2_LEFT_FORMS = [
  { forma: "TCR-1", modelo: "600-VR" },
  { forma: "PL - 1", modelo: "7,5x300 c/ Lente" },
  { forma: "PL - 2", modelo: "7,5x300 c/ Lente" },
  { forma: "PL - 3", modelo: "7,5x300 c/ Lente" },
  { forma: "PL - 4", modelo: "7,5x300 c/ Lente" },
  { forma: "A-10", modelo: "1 CX VR" },
  { forma: "A-36", modelo: "1 CX VR" },
  { forma: "A-82", modelo: "1 CX VR" },
  { forma: "A-22", modelo: "1 CX VR" },
  { forma: "A-11", modelo: "1 CX VR" },
  { forma: "A-28", modelo: "1 CX VR" },
  { forma: "A-85", modelo: "1 CX VR" },
  { forma: "A-23", modelo: "1 CX VR" },
  { forma: "A-52", modelo: "1 CX VR" },
  { forma: "A-70", modelo: "1 CX VR" },
  { forma: "A-83", modelo: "1 CX VR" },
  { forma: "A-18", modelo: "1 CX VR" },
  { forma: "A-42", modelo: "1 CX VR" },
  { forma: "A-54", modelo: "1 CX VR" },
  { forma: "A-31", modelo: "1 CX VR" },
  { forma: "A-63", modelo: "1 CX VR" },
  { forma: "A-62", modelo: "1 CX VR" },
  { forma: "A-61", modelo: "1 CX VR" },
  { forma: "A-60", modelo: "1 CX VR" },
  { forma: "A-14", modelo: "1 CX VR" },
  { forma: "A-58", modelo: "1 CX VR" },
  { forma: "A-57", modelo: "1 CX VR" },
  { forma: "A-30", modelo: "1 CX VR" },
  { forma: "A-55", modelo: "1 CX VR" },
  { forma: "A-02", modelo: "1 CX VR" },
  { forma: "A-03", modelo: "1 CX VR" },
  { forma: "B-22", modelo: "1 CX VL" },
  { forma: "B-21", modelo: "1 CX VL" },
  { forma: "B-08", modelo: "1 CX VL" },
  { forma: "B-09", modelo: "1 CX VL" },
  { forma: "B-07", modelo: "1 CX VL" },
  { forma: "B-20", modelo: "1 CX VL" },
  { forma: "B-10", modelo: "1 CX VL" },
  { forma: "B-17", modelo: "1 CX VL" },
  { forma: "B-14", modelo: "1 CX VL" },
  { forma: "B-05", modelo: "1 CX VL" },
  { forma: "B-16", modelo: "1 CX VL" },
  { forma: "B-15", modelo: "1 CX VL" },
  { forma: "TMIE-1", label: "TMIE-1", modelo: "Totem Med. Ind. Elecktro" }
];

const SETOR_2_RIGHT_FORMS = [
  { forma: "TCL-1", modelo: "600-VL" },
  { forma: "TCL-2", modelo: "600-VL" },
  { forma: "TCR-4", modelo: "600-VR" },
  { forma: "TCR-3", modelo: "600-VR" },
  { forma: "TCR-2", modelo: "600-VR" },
  { forma: "PL - 5", modelo: "7,5x300 c/ Lente" },
  { forma: "PL - 6", modelo: "7,5x300 c/ Lente" },
  { forma: "A-17", modelo: "1 CX VR" },
  { forma: "A-35", modelo: "1 CX VR" },
  { forma: "A-24", modelo: "1 CX VR" },
  { forma: "A-59", modelo: "1 CX VR" },
  { forma: "A-34", modelo: "1 CX VR" },
  { forma: "A-33", modelo: "1 CX VR" },
  { forma: "A-07", modelo: "1 CX VR" },
  { forma: "A-05", modelo: "1 CX VR" },
  { forma: "A-06", modelo: "1 CX VR" },
  { forma: "A-16", modelo: "1 CX VR" },
  { forma: "A-43", modelo: "1 CX VR" },
  { forma: "A-32", modelo: "1 CX VR" },
  { forma: "A-84", modelo: "1 CX VR" },
  { forma: "A-19", modelo: "1 CX VR" },
  { forma: "A-15", modelo: "1 CX VR" },
  { forma: "A-12", modelo: "1 CX VR" },
  { forma: "A-38", modelo: "1 CX VR" },
  { forma: "A-39", modelo: "1 CX VR" },
  { forma: "A-44", modelo: "1 CX VR" },
  { forma: "A-45", modelo: "1 CX VR" },
  { forma: "A-48", modelo: "1 CX VR" },
  { forma: "C-03", modelo: "2 CXS VR" },
  { forma: "C-14", modelo: "2 CXS VR" },
  { forma: "C-16", modelo: "2 CXS VR" },
  { forma: "C-18", modelo: "2 CXS VR" },
  { forma: "C-11", modelo: "2 CXS VR" },
  { forma: "C-19", modelo: "2 CXS VR" },
  { forma: "C-20", modelo: "2 CXS VR" },
  { forma: "C-21", modelo: "2 CXS VR" },
  { forma: "C-22", modelo: "2 CXS VR" },
  { forma: "C-23", modelo: "2 CXS VR" },
  { forma: "C-12", modelo: "2 CXS VR" },
  { forma: "C-25", modelo: "2 CXS VR" }
];

const SETOR_3_LEFT_FORMS = [
  { forma: "SC01", modelo: "SC" },
  { forma: "SC03", modelo: "SC" },
  { forma: "SC05", modelo: "SC" },
  { forma: "SC07", modelo: "SC" },
  { forma: "SC09", modelo: "SC" },
  { forma: "SC11", modelo: "SC" },
  { forma: "SC13", modelo: "SC" },
  { forma: "SC15", modelo: "SC" },
  { forma: "SC17", modelo: "SC" },
  { forma: "SC19", modelo: "SC" },
  { forma: "SC21", modelo: "SC" },
  { forma: "SC23", modelo: "SC" },
  { forma: "SC25", modelo: "SC" },
  { forma: "SC27", modelo: "SC" },
  { forma: "SC29", modelo: "SC" },
  { forma: "SC31", modelo: "SC" },
  { forma: "SC33", modelo: "SC" },
  { forma: "SC35", modelo: "SC" },
  { forma: "SC37", modelo: "SC" },
  { forma: "SC39", modelo: "SC" },
  { forma: "SC41", modelo: "SC" },
  { forma: "SC43", modelo: "SC" },
  { forma: "SC45", modelo: "SC" },
  { forma: "SC47", modelo: "SC" },
  { forma: "SC49", modelo: "SC" },
  { forma: "SC51", modelo: "SC" }
];

const SETOR_3_RIGHT_FORMS = [
  { forma: "SC02", modelo: "SC" },
  { forma: "SC04", modelo: "SC" },
  { forma: "SC06", modelo: "SC" },
  { forma: "SC08", modelo: "SC" },
  { forma: "SC10", modelo: "SC" },
  { forma: "SC12", modelo: "SC" },
  { forma: "SC14", modelo: "SC" },
  { forma: "SC16", modelo: "SC" },
  { forma: "SC18", modelo: "SC" },
  { forma: "SC20", modelo: "SC" },
  { forma: "SC22", modelo: "SC" },
  { forma: "SC24", modelo: "SC" },
  { forma: "SC26", modelo: "SC" },
  { forma: "SC28", modelo: "SC" },
  { forma: "SC30", modelo: "SC" },
  { forma: "SC32", modelo: "SC" },
  { forma: "SC34", modelo: "SC" },
  { forma: "SC36", modelo: "SC" },
  { forma: "SC38", modelo: "SC" },
  { forma: "SC40", modelo: "SC" },
  { forma: "SC42", modelo: "SC" },
  { forma: "SC44", modelo: "SC" },
  { forma: "SC46", modelo: "SC" },
  { forma: "SC48", modelo: "SC" },
  { forma: "SC50", modelo: "SC" },
  { forma: "SC52", modelo: "SC" },
  { forma: "DTBM-25", label: "DTBM-25", modelo: "DTBM-25" }
];

const SETOR_4_COL1_FORMS = [
  { forma: "DTB 01",   label: "DTB 01",  modelo: "DTB 01" },
  { forma: "DTB 02",   label: "DTB 02",  modelo: "DTB 02" },
  { forma: "DTB 03",   label: "DTB 03",  modelo: "DTB 03" },
  { forma: "DTB 04",   label: "DTB 04",  modelo: "DTB 04" },
  { forma: "DTB 05",   label: "DTB 05",  modelo: "DTB 05" },
  { forma: "DTB 06",   label: "DTB 06",  modelo: "DTB 06" },
  { forma: "DTB 07",   label: "DTB 07",  modelo: "DTB 07" },
  { forma: "DTB 08",   label: "DTB 08",  modelo: "DTB 08" },
  { forma: "DTB 09",   label: "DTB 09",  modelo: "DTB 09" },
  { forma: "DTB 10",   label: "DTB 10",  modelo: "DTB 10" },
  { forma: "DTBM 01",  label: "DTBM 01", modelo: "DTBM 01" },
  { forma: "DTBM 02",  label: "DTBM 02", modelo: "DTBM 02" },
  { forma: "DTD 01",   label: "DTD 01",  modelo: "DTD 01" },
  { forma: "DTD 02",   label: "DTD 02",  modelo: "DTD 02" },
  { forma: "DTD 03",   label: "DTD 03",  modelo: "DTD 03" }
];

const SETOR_4_COL2_FORMS = [
  {"forma": "C-F1-1", "label": "1", "modelo": "6,0 x 90"},
  {"forma": "C-F1-2", "label": "2", "modelo": "6,0 x 90"},
  {"forma": "C-F3-15", "label": "15", "modelo": "7,5 x 90"},
  {"forma": "C-F2-5", "label": "5", "modelo": "7,5 x 200"},
  {"forma": "C-F2-8", "label": "8", "modelo": "7,5 x 200"},
  {"forma": "C-F2-7", "label": "7", "modelo": "7,5 x 200"},
  {"forma": "C-F2-6", "label": "6", "modelo": "7,5 x 200"},
  {"forma": "C-F2-9", "label": "9", "modelo": "7,5 x 200"},
  {"forma": "C-F3-14", "label": "14", "modelo": "7,5 x 90"},
  {"forma": "C-F3-13", "label": "13", "modelo": "7,5 x 90"},
  {"forma": "C-F3-12", "label": "12", "modelo": "7,5 x 90"},
  {"forma": "C-F3-11", "label": "11", "modelo": "7,5 x 90"},
  {"forma": "C-F3-10", "label": "10", "modelo": "7,5 x 90"},
  {"forma": "C-F3-9", "label": "9", "modelo": "7,5 x 90"},
  {"forma": "C-F3-8", "label": "8", "modelo": "7,5 x 90"},
  {"forma": "C-F3-7", "label": "7", "modelo": "7,5 x 90"},
  {"forma": "C-F3-6", "label": "6", "modelo": "7,5 x 90"},
  {"forma": "C-F3-5", "label": "5", "modelo": "7,5 x 90"},
  {"forma": "C-F3-4", "label": "4", "modelo": "7,5 x 90"},
  {"forma": "C-F3-3", "label": "3", "modelo": "7,5 x 90"},
  {"forma": "C-F3-2", "label": "2", "modelo": "7,5 x 90"},
  {"forma": "C-F3-1", "label": "1", "modelo": "7,5 x 90"},
  {"forma": "C-F3-16", "label": "16", "modelo": "7,5 x 90"}
];

const SETOR_4_COL3_FORMS = [
  {"forma": "R-F1-3", "label": "3", "modelo": "6,0 x 90"},
  {"forma": "R-F2-9", "label": "9", "modelo": "7,5 x 300 / 400 / 600 / 700 / 800", "modelos": ["7,5 x 300", "7,5 x 400", "7,5 x 600", "7,5 x 700", "7,5 x 800"], "multimodelo": true},
  {"forma": "R-F2-8", "label": "8", "modelo": "7,5 x 300 / 400 / 600 / 700 / 800", "modelos": ["7,5 x 300", "7,5 x 400", "7,5 x 600", "7,5 x 700", "7,5 x 800"], "multimodelo": true},
  {"forma": "R-F2-7", "label": "7", "modelo": "7,5 x 300 / 400 / 600 / 700 / 800", "modelos": ["7,5 x 300", "7,5 x 400", "7,5 x 600", "7,5 x 700", "7,5 x 800"], "multimodelo": true},
  {"forma": "R-F2-6", "label": "6", "modelo": "7,5 x 300 / 400 / 600 / 700 / 800", "modelos": ["7,5 x 300", "7,5 x 400", "7,5 x 600", "7,5 x 700", "7,5 x 800"], "multimodelo": true},
  {"forma": "R-F2-5", "label": "5", "modelo": "7,5 x 300 / 400 / 600 / 700 / 800", "modelos": ["7,5 x 300", "7,5 x 400", "7,5 x 600", "7,5 x 700", "7,5 x 800"], "multimodelo": true},
  {"forma": "R-F3-4", "label": "4", "modelo": "7,5 x 300 / 400 / 600 / 700 / 800", "modelos": ["7,5 x 300", "7,5 x 400", "7,5 x 600", "7,5 x 700", "7,5 x 800"], "multimodelo": true},
  {"forma": "R-F3-3", "label": "3", "modelo": "7,5 x 300 / 400 / 600 / 700 / 800", "modelos": ["7,5 x 300", "7,5 x 400", "7,5 x 600", "7,5 x 700", "7,5 x 800"], "multimodelo": true},
  {"forma": "R-F3-2", "label": "2", "modelo": "7,5 x 300 / 400 / 600 / 700 / 800", "modelos": ["7,5 x 300", "7,5 x 400", "7,5 x 600", "7,5 x 700", "7,5 x 800"], "multimodelo": true},
  {"forma": "R-E18", "label": "18", "modelo": "7,5 x 90", "inicioEstoque": true},
  {"forma": "R-E19", "label": "19", "modelo": "7,5 x 90"},
  {"forma": "R-E17", "label": "17", "modelo": "7,5 x 90"},
  {"forma": "R-E22", "label": "22", "modelo": "7,5 x 90"},
  {"forma": "R-E21", "label": "21", "modelo": "7,5 x 90"},
  {"forma": "R-E23", "label": "23", "modelo": "7,5 x 90"},
  {"forma": "R-E24", "label": "24", "modelo": "7,5 x 90"},
  {"forma": "R-E20", "label": "20", "modelo": "7,5 x 90"},
  {"forma": "R-G6", "label": "6", "modelo": "7,0 x 150"},
  {"forma": "R-G5", "label": "5", "modelo": "7,0 x 150"},
  {"forma": "R-G3", "label": "3", "modelo": "7,0 x 150"},
  {"forma": "R-G4", "label": "4", "modelo": "7,0 x 150"},
  {"forma": "R-G2", "label": "2", "modelo": "7,0 x 150"},
  {"forma": "R-G1", "label": "1", "modelo": "7,0 x 150"}
];

const SECTOR_FORMS = {
  "Setor 1": { left: SETOR_1_LEFT_FORMS, right: SETOR_1_RIGHT_FORMS },
  "Setor 2": { left: SETOR_2_LEFT_FORMS, right: SETOR_2_RIGHT_FORMS },
  "Setor 3": { left: SETOR_3_LEFT_FORMS, right: SETOR_3_RIGHT_FORMS },
  "Setor 4": { col1: SETOR_4_COL1_FORMS, col2: SETOR_4_COL2_FORMS, col3: SETOR_4_COL3_FORMS }
};

function getProductionModelOptions(forma, setor, fallbackModel = "") {
  const forms = SECTOR_FORMS[setor] || {};
  const item = Object.values(forms).flat().find((entry) => normalizeUpper(entry.forma) === normalizeUpper(forma));
  const official = window.PRODUCTION_MODELS_BY_FORMA?.[setor]?.[normalizeUpper(forma)];
  const requiresMatrix = (setor === "Setor 3" && /^SC\d{2}$/.test(normalizeUpper(forma)))
    || (setor === "Setor 4" && /^DTB(?:M)?\s?\d{2}$|^DTD\s?\d{2}$/.test(normalizeUpper(forma)));
  const configured = Array.isArray(official) ? official
    : (requiresMatrix ? [] : (Array.isArray(item?.modelos) ? item.modelos : [item?.modelo || fallbackModel]));
  const seen = new Set();
  return configured.map((value) => String(value || "").trim()).filter((value) => {
    const key = normalizeProductionModelKey(value);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function normalizeProductionModelKey(value) {
  return normalizeUpper(value).replace(/\s+/g, "").replace(/,/g, ".");
}

function getProductionProgrammedModel(forma, setor) {
  if (!["Setor 3", "Setor 4"].includes(setor)) return "";
  return String(state.programmedProductsByForma?.get(normalizeUpper(forma)) || "").trim();
}

function getSectorForms(setor) {
  const forms = SECTOR_FORMS[setor] || SECTOR_FORMS["Setor 2"];
  if (forms.left || forms.right) {
    return {
      left: (forms.left || []).map((item) => withPosteData(item, setor)),
      right: (forms.right || []).map((item) => withPosteData(item, setor))
    };
  }
  return {
    col1: (forms.col1 || []).map((item) => withPosteData(item, setor)),
    col2: (forms.col2 || []).map((item) => withPosteData(item, setor)),
    col3: (forms.col3 || []).map((item) => withPosteData(item, setor))
  };
}

const MANUTENCAO_FORMAS_KEY = "mapa_formas_manutencao_v1";
const MANUTENCAO_FORMAS_TABLE = "formas_manutencao";

function isManutencaoAuthorizedUser() {
  if (!state.authUser || !state.authUser.name) return false;
  const name = String(state.authUser.name).trim().toLowerCase();
  const role = String(state.authUser.role || "").trim().toUpperCase();
  if (role === "GESTOR" || role === "GERENCIA" || role === "ADMIN") return true;
  return name.includes("ricardo") || name.includes("philippe") || name.includes("jose carlos") || name.includes("josé carlos");
}

function getFormasManutencao() {
  try {
    const raw = localStorage.getItem(MANUTENCAO_FORMAS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function salvarFormasManutencaoObj(obj) {
  try {
    localStorage.setItem(MANUTENCAO_FORMAS_KEY, JSON.stringify(obj));
  } catch(e) {
    console.error("Erro ao salvar formas manutencao:", e);
  }
}

function mergeFormasManutencao(localObj, remoteRows) {
  const merged = { ...(localObj || {}) };
  (remoteRows || []).forEach((row) => {
    const key = row.id || `${row.setor}_${row.forma_numero}`;
    const local = merged[key];
    const localTime = new Date(local?.updated_at || 0).getTime();
    const remoteTime = new Date(row.updated_at || 0).getTime();
    if (!local || remoteTime >= localTime) merged[key] = row;
  });
  return merged;
}

async function carregarFormasManutencaoSupabase() {
  if (!supabaseClient || !navigator.onLine) return getFormasManutencao();
  try {
    const { data, error } = await supabaseClient
      .from(MANUTENCAO_FORMAS_TABLE)
      .select("*")
      .order("updated_at", { ascending: false });
    if (error) throw error;
    const merged = mergeFormasManutencao(getFormasManutencao(), data || []);
    salvarFormasManutencaoObj(merged);
    return merged;
  } catch (err) {
    console.warn("Manutencao: usando cache local; falha ao carregar o servidor:", err);
    return getFormasManutencao();
  }
}

async function sincronizarFormaManutencaoSupabase(record) {
  if (!supabaseClient || !navigator.onLine || !record) return;
  try {
    const { error } = await supabaseClient
      .from(MANUTENCAO_FORMAS_TABLE)
      .upsert(record, { onConflict: "id" });
    if (error) throw error;
  } catch (err) {
    console.warn("Manutencao: registro mantido offline; falha ao sincronizar:", err);
  }
}

async function sincronizarManutencaoLocalPendente() {
  if (!supabaseClient || !navigator.onLine) return;
  const all = getFormasManutencao();
  await Promise.all(Object.entries(all).map(([key, record]) => sincronizarFormaManutencaoSupabase({ id: key, ...record })));
  await carregarFormasManutencaoSupabase();
}

function getManutencaoKey(setor, formaNumero) {
  return `${String(setor || "").trim()}_${normalizeUpper(formaNumero)}`;
}

function isFormaEmManutencao(setor, formaNumero) {
  const all = getFormasManutencao();
  const key = getManutencaoKey(setor, formaNumero);
  const rec = all[key];
  if (rec && rec.status === "PARADA") {
    return rec;
  }
  return null;
}

function salvarFormaParadaManutencao(setor, formaNumero, motivo, acao) {
  const all = getFormasManutencao();
  const key = getManutencaoKey(setor, formaNumero);
  const nowStr = new Date().toLocaleString("pt-BR");
  const userStr = state.authUser?.name || "Usuário";

  all[key] = {
    id: key,
    setor: String(setor || "").trim(),
    forma_numero: normalizeUpper(formaNumero),
    status: "PARADA",
    motivo_parada: motivo,
    acao_necessaria: acao,
    parada_em: nowStr,
    parada_por: userStr,
    liberada_em: null,
    liberada_por: null,
    obs_liberacao: null,
    updated_at: new Date().toISOString()
  };
  salvarFormasManutencaoObj(all);
  sincronizarFormaManutencaoSupabase(all[key]);
  atualizarIndicadoresManutencaoHub();
}

function liberarFormaManutencao(setor, formaNumero, obs) {
  const all = getFormasManutencao();
  const key = getManutencaoKey(setor, formaNumero);
  const nowStr = new Date().toLocaleString("pt-BR");
  const userStr = state.authUser?.name || "Usuário";

  if (!all[key]) {
    all[key] = {
      id: key,
      setor: String(setor || "").trim(),
      forma_numero: normalizeUpper(formaNumero),
      motivo_parada: "Manutenção",
      acao_necessaria: "Manutenção",
      parada_em: nowStr,
      parada_por: userStr
    };
  }
  all[key].id = key;
  all[key].status = "LIBERADA";
  all[key].liberada_em = nowStr;
  all[key].liberada_por = userStr;
  all[key].obs_liberacao = obs;
  all[key].updated_at = new Date().toISOString();
  salvarFormasManutencaoObj(all);
  sincronizarFormaManutencaoSupabase(all[key]);
  atualizarIndicadoresManutencaoHub();
}

let pendingManutencaoSelection = null;

const state = {
  mode: "HUB",
  authUser: null,
  allowedModes: new Set(["HUB"]),
  hasBootstrapped: false,
  usersCache: [],
  libPhotos: [],
  insPhotos: [],
  montagemPostesAtual: null,
  isSendingLiberacao: false,
  isSendingInspecao: false,
  submitLocks: readSubmitLocks(),
  programmingMode: false,
  liberationMode: false,
  odinMode: false,
  manutencaoMode: false,
  programmedFormas: new Set(),
  dbDataCache: {},
  dbDataStatusCache: {},
  activeInsSector: ""
};

let pendingFormaSelection = null;

const el = {
  appShell: document.getElementById("appShell"),
  loginScreen: document.getElementById("loginScreen"),
  loginNome: document.getElementById("loginNome"),
  loginSenha: document.getElementById("loginSenha"),
  loginEntrar: document.getElementById("loginEntrar"),
  loginFeedback: document.getElementById("loginFeedback"),
  authUserBadge: document.getElementById("authUserBadge"),
  authLogoutBtn: document.getElementById("authLogoutBtn"),
  backMain: document.getElementById("btnBackMain"),
  backButtons: Array.from(document.querySelectorAll("[data-back-btn]")),
  hubView: document.getElementById("viewHub"),
  viewDashboard: document.getElementById("viewDashboard"),
  hubLiberacao: document.getElementById("hubLiberacao"),
  hubLiberacaoS1: document.getElementById("hubLiberacaoS1"),
  hubLiberacaoS2: document.getElementById("hubLiberacaoS2"),
  hubLiberacaoS3: document.getElementById("hubLiberacaoS3"),
  hubLiberacaoS4: document.getElementById("hubLiberacaoS4"),
  hubMandrilCircular: document.getElementById("hubMandrilCircular"),
  viewMandrilCircular: document.getElementById("viewMandrilCircular"),
  mcFiltroData: document.getElementById("mcFiltroData"),
  mcQtdItens: document.getElementById("mcQtdItens"),
  mcTabelaBody: document.getElementById("mcTabelaBody"),
  mcTabMapa: document.getElementById("mcTabMapa"),
  mcTabTabela: document.getElementById("mcTabTabela"),
  mcContainerMapa: document.getElementById("mcContainerMapa"),
  mcContainerTabela: document.getElementById("mcContainerTabela"),
  mcMapaEsquerdo: document.getElementById("mcMapaEsquerdo"),
  mcMapaDireito: document.getElementById("mcMapaDireito"),
  hubInspecao: document.getElementById("hubInspecao"),
  hubMontagemPostes: document.getElementById("hubMontagemPostes"),
  hubSequenciaS3: document.getElementById("hubSequenciaS3"),
  hubMontagemIndicadores: document.getElementById("hubMontagemIndicadores"),
  hubDashboardDefeitos: document.getElementById("hubDashboardDefeitos"),
  hubRelatorio: document.getElementById("hubRelatorio"),
  hubHistorico: document.getElementById("hubHistorico"),
  viewLiberacao: document.getElementById("viewLiberacao"),
  viewInspecao: document.getElementById("viewInspecao"),
  viewMontagemPostes: document.getElementById("viewMontagemPostes"),
  viewSequenciaS3: document.getElementById("viewSequenciaS3"),
  seqS3Data: document.getElementById("seqS3Data"),
  seqS3Search: document.getElementById("seqS3Search"),
  seqS3List: document.getElementById("seqS3List"),
  seqS3BtnSalvar: document.getElementById("seqS3BtnSalvar"),
  seqS3FloatBar: document.getElementById("seqS3FloatBar"),
  viewMontagemIndicadores: document.getElementById("viewMontagemIndicadores"),
  viewDashboardDefeitos: document.getElementById("viewDashboardDefeitos"),
  viewMontagemPostesDetalhe: document.getElementById("viewMontagemPostesDetalhe"),
  viewRelatorio: document.getElementById("viewRelatorio"),
  viewHistorico: document.getElementById("viewHistorico"),
  hubRelatorioManutencao: document.getElementById("hubRelatorioManutencao"),
  viewRelatorioManutencao: document.getElementById("viewRelatorioManutencao"),
  hubTratativaDefeitos: document.getElementById("hubTratativaDefeitos"),
  viewTratativaDefeitos: document.getElementById("viewTratativaDefeitos"),
  kioskManutencaoCheckbox: document.getElementById("kioskManutencaoCheckbox"),
  kioskManutencaoToggleField: document.getElementById("kioskManutencaoToggleField"),
  hubAcmpConcretagem: document.getElementById("hubAcmpConcretagem"),
  viewAcmpConcretagem: document.getElementById("viewAcmpConcretagem"),
  navUsuarios: document.getElementById("navUsuarios"),
  viewUsuarios: document.getElementById("viewUsuarios"),
  ugNomeCompleto: document.getElementById("ugNomeCompleto"),
  ugLogin: document.getElementById("ugLogin"),
  ugPerfil: document.getElementById("ugPerfil"),
  ugSenha: document.getElementById("ugSenha"),
  ugSetor: document.getElementById("ugSetor"),
  ugCriarBtn: document.getElementById("ugCriarBtn"),
  ugFeedback: document.getElementById("ugFeedback"),
  ugListaBody: document.getElementById("ugListaBody"),
  primeiroAcessoModal: document.getElementById("primeiroAcessoModal"),
  paNovaSenha: document.getElementById("paNovaSenha"),
  paConfirmarSenha: document.getElementById("paConfirmarSenha"),
  paSalvarBtn: document.getElementById("paSalvarBtn"),
  paFeedback: document.getElementById("paFeedback"),
  syncStatus: document.getElementById("syncStatus"),
  concretoTipoModal: document.getElementById("concretoTipoModal"),
  concretoTipoSubtitle: document.getElementById("concretoTipoSubtitle"),
  concretoModeloSelect: document.getElementById("concretoModeloSelect"),
  concretoModeloFeedback: document.getElementById("concretoModeloFeedback"),
  concretoTipoOptions: document.getElementById("concretoTipoOptions"),
  concretoTipoCancelBtn: document.getElementById("concretoTipoCancelBtn"),
  concretoVibradoModal: document.getElementById("concretoVibradoModal"),
  concretoVibradoSimBtn: document.getElementById("concretoVibradoSimBtn"),
  concretoVibradoNaoBtn: document.getElementById("concretoVibradoNaoBtn"),

  libData: document.getElementById("libData"),
  libColaborador: document.getElementById("libColaborador"),
  libFeedback: document.getElementById("libFeedback"),
  sheetSetorLabel: document.getElementById("sheetSetorLabel"),
  sheetLeftBody: document.getElementById("sheetLeftBody"),
  sheetRightBody: document.getElementById("sheetRightBody"),
  btnLimparFormas: document.getElementById("btnLimparFormas"),

  libKioskHeader: document.getElementById("libKioskHeader"),
  kioskSectorSubtitle: document.getElementById("kioskSectorSubtitle"),
  kioskSectorTitle: document.getElementById("kioskSectorTitle"),
  kioskProgToggleField: document.getElementById("kioskProgToggleField"),
  kioskProgCheckbox: document.getElementById("kioskProgCheckbox"),
  kioskLibToggleField: document.getElementById("kioskLibToggleField"),
  kioskLibCheckbox: document.getElementById("kioskLibCheckbox"),
  kioskOdinToggleField: document.getElementById("kioskOdinToggleField"),
  kioskOdinCheckbox: document.getElementById("kioskOdinCheckbox"),
  btnCorrecaoConcretagem: document.getElementById("btnCorrecaoConcretagem"),
  btnKioskFullscreen: document.getElementById("btnKioskFullscreen"),
  btnKioskSync: document.getElementById("btnKioskSync"),
  btnKioskBack: document.getElementById("btnKioskBack"),
  kioskLibData: document.getElementById("kioskLibData"),
  kioskLibColaborador: document.getElementById("kioskLibColaborador"),
  kioskProgressoContador: document.getElementById("kioskProgressoContador"),

  insFiltroData: document.getElementById("insFiltroData"),
  insModoCarga: document.getElementById("insModoCarga"),
  insStatusFiltro: document.getElementById("insStatusFiltro"),
  insSetorGroup: document.getElementById("insSetorGroup"),
  insColaborador: document.getElementById("insColaborador"),
  insCarregarLiberados: document.getElementById("insCarregarLiberados"),
  insLiberadosBody: document.getElementById("insLiberadosBody"),
  insQtdItens: document.getElementById("insQtdItens"),
  insChecklistCodigos: document.getElementById("insChecklistCodigos"),
  insObs: document.getElementById("insObs"),
  insFotos: document.getElementById("insFotos"),
  insFotosPreview: document.getElementById("insFotosPreview"),
  salvarInspecao: document.getElementById("salvarInspecao"),
  insFormaFiltro: document.getElementById("insFormaFiltro"),
  salvarInspecaoFloat: document.getElementById("salvarInspecaoFloat"),

  viewInspecaoDetalhe: document.getElementById("viewInspecaoDetalhe"),
  insDetalheHeader: document.getElementById("insDetalheHeader"),
  insChecklistSections: document.getElementById("insChecklistSections"),
  insObservacoes: document.getElementById("insObservacoes"),
  insStatusButtons: document.getElementById("insStatusButtons"),
  insStatusAprovado: document.getElementById("insStatusAprovado"),
  insStatusReprovado: document.getElementById("insStatusReprovado"),
  insStatusRR: document.getElementById("insStatusRR"),
  insFinalizarPoste: document.getElementById("insFinalizarPoste"),

  mpFiltroData: document.getElementById("mpFiltroData"),
  mpModoCarga: document.getElementById("mpModoCarga"),
  mpSetor: document.getElementById("mpSetor"),
  mpStatusFiltro: document.getElementById("mpStatusFiltro"),
  mpCarregarLiberados: document.getElementById("mpCarregarLiberados"),
  mpLiberadosBody: document.getElementById("mpLiberadosBody"),
  mpQtdItens: document.getElementById("mpQtdItens"),
  mpKpiAprovados: document.getElementById("mpKpiAprovados"),
  mpKpiRetrabalho: document.getElementById("mpKpiRetrabalho"),
  mpKpiReprovados: document.getElementById("mpKpiReprovados"),
  mpFormaFiltro: document.getElementById("mpFormaFiltro"),
  mpDetalheHeader: document.getElementById("mpDetalheHeader"),
  mpStatusButtons: document.getElementById("mpStatusButtons"),
  mpStatusAprovado: document.getElementById("mpStatusAprovado"),
  mpStatusReprovado: document.getElementById("mpStatusReprovado"),
  mpStatusRR: document.getElementById("mpStatusRR"),
  mpObservacoes: document.getElementById("mpObservacoes"),
  mpChecklistSections: document.getElementById("mpChecklistSections"),
  mpFinalizarPoste: document.getElementById("mpFinalizarPoste"),
  mpResumoModal: document.getElementById("mpResumoModal"),
  mpResumoBody: document.getElementById("mpResumoBody"),
  mpResumoOkBtn: document.getElementById("mpResumoOkBtn"),

  histData: document.getElementById("histData"),
  histTipo: document.getElementById("histTipo"),
  histForma: document.getElementById("histForma"),
  dashData: document.getElementById("dashData"),
  atualizarDashboard: document.getElementById("atualizarDashboard"),
  dashSetor1Count: document.getElementById("dashSetor1Count"),
  dashSetor2Count: document.getElementById("dashSetor2Count"),
  dashSetor3Count: document.getElementById("dashSetor3Count"),
  dashSetor4Count: document.getElementById("dashSetor4Count"),
  dashTotalCount: document.getElementById("dashTotalCount"),
  dashSetor1Meta: document.getElementById("dashSetor1Meta"),
  dashSetor2Meta: document.getElementById("dashSetor2Meta"),
  dashSetor3Meta: document.getElementById("dashSetor3Meta"),
  dashSetor4Meta: document.getElementById("dashSetor4Meta"),
  dashBarSetor1: document.getElementById("dashBarSetor1"),
  dashBarSetor2: document.getElementById("dashBarSetor2"),
  dashBarSetor3: document.getElementById("dashBarSetor3"),
  dashBarSetor4: document.getElementById("dashBarSetor4"),
  dashBarSetor1Label: document.getElementById("dashBarSetor1Label"),
  dashBarSetor2Label: document.getElementById("dashBarSetor2Label"),
  dashBarSetor3Label: document.getElementById("dashBarSetor3Label"),
  dashBarSetor4Label: document.getElementById("dashBarSetor4Label"),
  dashStatus: document.getElementById("dashStatus"),
  acmpData: document.getElementById("acmpData"),
  acmpModoCarga: document.getElementById("acmpModoCarga"),
  acmpSetor: document.getElementById("acmpSetor"),
  acmpCarregar: document.getElementById("acmpCarregar"),
  acmpSalvar: document.getElementById("acmpSalvar"),
  acmpImprimir: document.getElementById("acmpImprimir"),
  acmpFeedback: document.getElementById("acmpFeedback"),
  acmpOutput: document.getElementById("acmpOutput"),
  filtrarHistorico: document.getElementById("filtrarHistorico"),
  historicoLista: document.getElementById("historicoLista"),
  relData: document.getElementById("relData"),
  relSetor: document.getElementById("relSetor"),
  relEncarregado: document.getElementById("relEncarregado"),
  gerarRelatorioSetor: document.getElementById("gerarRelatorioSetor"),
  relBtnImprimir: document.getElementById("relBtnImprimir"),
  relBtnWhatsapp: document.getElementById("relBtnWhatsapp"),
  relatorioSetorOutput: document.getElementById("relatorioSetorOutput"),
  viewProdAnalise: document.getElementById("viewProdAnalise")
};

/* ── Chart.js instance tracker ───────────────────── */
const chartInstances = {};
function destroyChart(id) {
  if (chartInstances[id]) { chartInstances[id].destroy(); delete chartInstances[id]; }
}

function nowIso() {
  const d = new Date();
  const tzOffset = d.getTimezoneOffset() * 60000;
  return new Date(d.getTime() - tzOffset).toISOString().slice(0, 19).replace("T", "T");
}

function uuid() {
  if (crypto && crypto.randomUUID) return crypto.randomUUID();
  return `id-${Date.now()}-${Math.floor(Math.random() * 999999)}`;
}

function todayYmd() {
  const d = new Date();
  const tzOffset = d.getTimezoneOffset() * 60000;
  const local = new Date(d.getTime() - tzOffset);
  return local.toISOString().slice(0, 10);
}

function baixarArquivoBlob(conteudo, nomeArquivo, mimeType, incluirBom = false) {
  const partes = incluirBom ? ["\uFEFF", conteudo] : [conteudo];
  const blob = conteudo instanceof Blob && !incluirBom
    ? conteudo
    : new Blob(partes, { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = nomeArquivo;
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 30000);
}

function valorCsv(value) {
  return `"${String(value ?? "").replace(/"/g, '""')}"`;
}

function criarCsv(linhas) {
  return (linhas || []).map(linha => linha.map(valorCsv).join(";")).join("\r\n");
}

function normalizeUpper(text) {
  return String(text || "").trim().toUpperCase();
}

function getFormaCatalogKey(forma) {
  const normalized = normalizeUpper(forma).replace(/\s+/g, "");
  if (!normalized) return "";
  if (normalized.startsWith("300-VR")) return "300-VR";
  if (normalized.startsWith("300-VL")) return "300-VL";
  if (normalized.startsWith("SB-E1")) return "SB-E1";
  if (normalized.startsWith("SBE-")) return "SB-E1";
  if (normalized.startsWith("100-")) return "100";
  if (normalized.startsWith("200-")) return "200";
  if (normalized.startsWith("A-TOTEM")) return "A-TOTEM";
  if (normalized.startsWith("TMIE")) return "TMIE";
  if (normalized.startsWith("BC")) return "BC";
  if (normalized.startsWith("C-F1")) return "C-F1";
  if (normalized.startsWith("R-G")) return "R-G";
  if (normalized.startsWith("DTBM")) return "DTBM";
  if (normalized.startsWith("DTB")) return "DTB";
  if (normalized.startsWith("DTD")) return "DTD";
  return normalized.split("-")[0];
}

function getPosteCatalogForForma(forma) {
  const key = getFormaCatalogKey(forma);
  return POSTES_DUPLO_T_BY_CHAVE.get(key) || null;
}

function withPosteData(item, setor) {
  const base = item || {};
  const catalog = getPosteCatalogForForma(base.forma);
  if (!catalog) {
    return {
      ...base,
      codigoPoste: "",
      descricaoPoste: "",
      codigoProduto: ""
    };
  }
  return {
    ...base,
    codigoPoste: catalog.codigo || "",
    descricaoPoste: catalog.descricao || "",
    codigoProduto: catalog.codigoProduto || "",
    setorProduto: catalog.setor || setor || ""
  };
}

function getPosteFieldsForForma(forma, setor) {
  const data = withPosteData({ forma }, setor);
  return {
    codigoPoste: data.codigoPoste || "",
    descricaoPoste: data.descricaoPoste || "",
    codigoProduto: data.codigoProduto || ""
  };
}

function getProductionPosteFields(forma, setor, modelo, card) {
  const cardFields = {
    codigoPoste: card?.dataset?.codigoPoste || "",
    descricaoPoste: card?.dataset?.descricaoPoste || "",
    codigoProduto: card?.dataset?.codigoProduto || ""
  };
  const base = cardFields.codigoProduto || cardFields.descricaoPoste
    ? cardFields : getPosteFieldsForForma(forma, setor);
  if (setor === "Setor 4" && /^R-F[23]-[2-9]$/.test(normalizeUpper(forma))) {
    return { codigoPoste: base.codigoPoste, descricaoPoste: modelo, codigoProduto: "" };
  }
  if (!window.PRODUCTION_MODELS_BY_FORMA?.[setor]?.[normalizeUpper(forma)]) return base;

  const product = window.PRODUCTION_PRODUCTS_BY_MODEL?.[setor]?.[normalizeProductionModelKey(modelo)];
  return {
    codigoPoste: base.codigoPoste,
    descricaoPoste: product?.descricaoPoste || `${modelo}${setor === "Setor 4" ? " DT" : ""}`,
    codigoProduto: product?.codigoProduto || ""
  };
}

function dateToYmd(value) {
  if (!value) return "";
  if (/^\d{4}-\d{2}-\d{2}$/.test(String(value).trim())) return String(value).trim();
  const d = new Date(String(value));
  if (!Number.isNaN(d.getTime())) {
    const tzOffset = d.getTimezoneOffset() * 60000;
    const local = new Date(d.getTime() - tzOffset);
    return local.toISOString().slice(0, 10);
  }
  return String(value).trim();
}

function readDb() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return { records: [], events: [] };
  try {
    const parsed = JSON.parse(raw);
    return {
      records: Array.isArray(parsed.records) ? parsed.records : [],
      events: Array.isArray(parsed.events) ? parsed.events : []
    };
  } catch {
    return { records: [], events: [] };
  }
}

function readSubmitLocks() {
  const raw = localStorage.getItem(SUBMIT_LOCKS_KEY);
  if (!raw) return { liberacao: "", inspecao: "" };
  try {
    const parsed = JSON.parse(raw);
    return {
      liberacao: typeof parsed.liberacao === "string" ? parsed.liberacao : "",
      inspecao: typeof parsed.inspecao === "string" ? parsed.inspecao : ""
    };
  } catch {
    return { liberacao: "", inspecao: "" };
  }
}

function writeSubmitLocks(submitLocks) {
  localStorage.setItem(SUBMIT_LOCKS_KEY, JSON.stringify(submitLocks));
}

function payloadToken(payload) {
  return JSON.stringify(payload);
}

function setSubmitButtonState(button, isLoading) {
  if (!button) return;
  if (!button.dataset.originalText) {
    button.dataset.originalText = button.textContent || "Salvar";
  }
  button.disabled = isLoading;
  button.textContent = isLoading ? "Enviando..." : button.dataset.originalText;
}

function clearSubmitLock(type) {
  if (!state.submitLocks[type]) return;
  state.submitLocks[type] = "";
  writeSubmitLocks(state.submitLocks);
}

function setSubmitLock(type, token) {
  state.submitLocks[type] = token;
  writeSubmitLocks(state.submitLocks);
}

function writeDb(db) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
}

function addEvent(db, event) {
  db.events.push(event);
}

function upsertRecord(db, record) {
  const idx = db.records.findIndex((r) => r.id === record.id);
  if (idx === -1) db.records.push(record);
  else db.records[idx] = record;
}

function hasApiConfigured() {
  return supabaseClient !== null;
}

function hasMontagemApiConfigured() {
  return supabaseClient !== null;
}

const MAPA_REPORT_CACHE_PREFIX = "mapa_concretagem_report_cache_v1";
const MAPA_REPORT_DEFAULT_TIMEOUT_MS = 15000;
const DASHBOARD_PRODUCAO_SELECT = "id,data_hora,setor,forma,modelo,tipo_concreto,colaborador,data_fabricacao,status,codigo_poste,descricao_poste,codigo_produto,vibrado";
const DASHBOARD_MONTAGEM_SELECT = "id,record_id,data_fabricacao,setor,forma_numero,modelo,status_montagem,motivo_recusa,etapa,inicio_inspecao_montagem,finalizado_em,checklists,banco,observacoes_montagem,montador_nome,created_at,updated_at";
const DASHBOARD_MONTAGEM_SCREEN_SELECT = "id,record_id,data_fabricacao,setor,forma_numero,modelo,status_montagem,etapa,inicio_inspecao_montagem,finalizado_em,montador_nome";
const DASHBOARD_DEFEITOS_MONTAGEM_SELECT = "id,record_id,data_fabricacao,setor,forma_numero,modelo,status_montagem,motivo_recusa,etapa,inicio_inspecao_montagem,finalizado_em,checklists,montador_nome";
const DASHBOARD_DEFEITOS_PRODUCAO_SELECT = "data_fabricacao,setor,forma,modelo,tipo_concreto,data_hora,status";
const DASHBOARD_SCOPE_OPTIONS = {
  "": "TOTAL",
  "Todos os Setores": "TOTAL",
  "Setor 1": "S1",
  "Setor 2": "S2",
  "Setor 3": "S3",
  "Setor 4": "S4",
  "Setores 1 e 2": "S1_S2"
};

const dashboardRequestSeq = {
  montagem: 0,
  defeitos: 0,
  produtividade: 0
};

function readMapaReportCache(cacheKey) {
  try {
    const raw = localStorage.getItem(`${MAPA_REPORT_CACHE_PREFIX}:${cacheKey}`);
    if (!raw) return null;
    const payload = JSON.parse(raw);
    if (!payload || !Array.isArray(payload.rows)) return null;
    return payload;
  } catch {
    return null;
  }
}

function writeMapaReportCache(cacheKey, rows) {
  try {
    localStorage.setItem(`${MAPA_REPORT_CACHE_PREFIX}:${cacheKey}`, JSON.stringify({
      ts: Date.now(),
      generated_at: new Date().toISOString(),
      rows: rows || []
    }));
  } catch {}
}

function getDashboardScopeFromSetor(setorValue) {
  return DASHBOARD_SCOPE_OPTIONS[setorValue || ""] || "TOTAL";
}

function getActiveMontagemFilterPrefix() {
  return state.mode === "DASHBOARD_DEFEITOS" ? "df" : "mi";
}

function getDashboardFilterValue(name, fallback = "") {
  const prefix = getActiveMontagemFilterPrefix();
  const id = `${prefix}${name}`;
  const prefixed = document.getElementById(id);
  if (prefixed) return prefixed.value || fallback;
  const legacy = document.getElementById(`mi${name}`);
  return legacy ? (legacy.value || fallback) : fallback;
}

const DASHBOARD_FILTER_FIELDS = {
  mi: ["DataInicio", "DataFim", "FiltroSetor", "FiltroStatus", "FiltroPesquisa"],
  df: ["DataInicio", "DataFim", "FiltroSetor", "FiltroStatus", "FiltroPesquisa"],
  pa: ["DataInicio", "DataFim", "FiltroSetor", "MetaCiclo"]
};
const restoredDashboardFilters = new Set();

function getDashboardPresetDates(preset) {
  const today = new Date(`${todayYmd()}T12:00:00`);
  const asYmd = date => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  const start = new Date(today);
  const end = new Date(today);
  if (preset === "7" || preset === "30") start.setDate(start.getDate() - Number(preset) + 1);
  else if (preset === "month") start.setDate(1);
  else if (preset === "previous") {
    start.setMonth(start.getMonth() - 1, 1);
    end.setDate(0);
  } else if (preset !== "today") return null;
  return [asYmd(start), asYmd(end)];
}

function syncDashboardFilterChips(kind) {
  const start = document.getElementById(`${kind}DataInicio`)?.value;
  const end = document.getElementById(`${kind}DataFim`)?.value;
  const activePreset = ["today", "7", "30", "month", "previous"]
    .find(preset => {
      const dates = getDashboardPresetDates(preset);
      return dates[0] === start && dates[1] === end;
    });
  document.querySelectorAll(`[data-dashboard-presets="${kind}"] [data-date-preset]`).forEach(button => {
    const active = button.dataset.datePreset === activePreset;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
  const status = document.getElementById(`${kind}FiltroStatus`)?.value;
  document.querySelectorAll(`[data-dashboard-quick="${kind}"] [data-quick-status]`).forEach(button => {
    const active = button.dataset.quickStatus === status;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
}

function applyDashboardDatePreset(kind, preset) {
  const dates = getDashboardPresetDates(preset);
  if (!dates) return;
  const start = document.getElementById(`${kind}DataInicio`);
  const end = document.getElementById(`${kind}DataFim`);
  if (!start || !end) return;
  [start.value, end.value] = dates;
  syncDashboardFilterChips(kind);
  miPaginaAtual = 1;
  if (kind === "mi") carregarMontagemIndicadores();
  if (kind === "df") carregarDashboardDefeitos();
}

function saveDashboardFilter(kind, button) {
  const fields = DASHBOARD_FILTER_FIELDS[kind];
  if (!fields) return;
  const values = Object.fromEntries(fields.map(field => [field, document.getElementById(`${kind}${field}`)?.value || ""]));
  try {
    localStorage.setItem(`mapa_dashboard_filtros_${kind}_v1`, JSON.stringify(values));
    if (button) {
      button.textContent = "Filtro salvo";
      setTimeout(() => { button.textContent = "Salvar filtro"; }, 1800);
    }
  } catch (error) {
    if (button) button.textContent = "Não foi possível salvar";
  }
}

function clearSavedDashboardFilter(kind) {
  try {
    localStorage.removeItem(`mapa_dashboard_filtros_${kind}_v1`);
  } catch (error) {
    console.warn("Não foi possível remover o filtro salvo:", error);
  }
}

function restoreDashboardFilter(kind) {
  if (restoredDashboardFilters.has(kind)) return;
  restoredDashboardFilters.add(kind);
  try {
    const saved = JSON.parse(localStorage.getItem(`mapa_dashboard_filtros_${kind}_v1`) || "null");
    if (saved && typeof saved === "object") {
      DASHBOARD_FILTER_FIELDS[kind].forEach(field => {
        const input = document.getElementById(`${kind}${field}`);
        if (input && typeof saved[field] === "string") input.value = saved[field];
      });
    }
  } catch (error) {
    console.warn("Filtro salvo inválido:", error);
  }
  syncDashboardFilterChips(kind);
}

function readMapaReportPayloadCache(cacheKey) {
  try {
    const raw = localStorage.getItem(`${MAPA_REPORT_CACHE_PREFIX}:${cacheKey}`);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function writeMapaReportPayloadCache(cacheKey, payload) {
  try {
    localStorage.setItem(`${MAPA_REPORT_CACHE_PREFIX}:${cacheKey}`, JSON.stringify({
      ts: Date.now(),
      generated_at: new Date().toISOString(),
      payload
    }));
  } catch {}
}

async function chamarDashboardRpcComCache(rpcName, params, cacheKey) {
  if (!supabaseClient) {
    const cached = cacheKey ? readMapaReportPayloadCache(cacheKey) : null;
    return { payload: cached?.payload || null, state: cached ? "OFFLINE_CACHE" : "ERROR" };
  }

  try {
    const { data, error } = await supabaseClient.rpc(rpcName, params);
    if (error) throw error;
    if (cacheKey) writeMapaReportPayloadCache(cacheKey, data);
    return { payload: data, state: data ? "SUCCESS" : "EMPTY" };
  } catch (error) {
    const cached = cacheKey ? readMapaReportPayloadCache(cacheKey) : null;
    if (cached?.payload) {
      console.warn("Dashboard: usando contrato em cache apos falha no RPC:", error);
      return { payload: cached.payload, state: "OFFLINE_CACHE", error };
    }
    throw error;
  }
}

async function carregarLinhasSupabaseComCache(options) {
  const opts = options || {};
  const cacheKey = opts.cacheKey;
  const pageSize = opts.pageSize || 1000;
  const maxPages = opts.maxPages || 20;
  const pageConcurrency = Math.max(1, Math.min(3, Number(opts.pageConcurrency) || 1));
  const timeoutMs = opts.timeoutMs || MAPA_REPORT_DEFAULT_TIMEOUT_MS;

  if (!supabaseClient) {
    const cached = cacheKey ? readMapaReportCache(cacheKey) : null;
    return { rows: cached?.rows || [], state: cached ? "OFFLINE_CACHE" : "ERROR" };
  }

  const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
  const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
  const externalSignal = opts.signal;
  const abortFromExternal = () => controller?.abort();
  if (controller && externalSignal) {
    if (externalSignal.aborted) controller.abort();
    else externalSignal.addEventListener("abort", abortFromExternal, { once: true });
  }

  try {
    let allRows = [];
    const fetchPage = async page => {
      const from = page * pageSize;
      const to = from + pageSize - 1;
      let query = supabaseClient
        .from(opts.table)
        .select(opts.select)
        .range(from, to);

      if (typeof opts.applyFilters === "function") query = opts.applyFilters(query);
      if (opts.orderBy) query = query.order(opts.orderBy, opts.orderOptions || {});
      if (controller && typeof query.abortSignal === "function") query = query.abortSignal(controller.signal);

      const { data, error } = await query;
      if (error) throw error;
      return Array.isArray(data) ? data : [];
    };
    let page = 0;
    let complete = false;
    while (page < maxPages) {
      const batchSize = page === 0 ? 1 : Math.min(pageConcurrency, maxPages - page);
      const pages = await Promise.all(Array.from({ length: batchSize }, (_, index) => fetchPage(page + index)));
      let lastPage = false;
      for (const rows of pages) {
        if (rows.length) allRows = allRows.concat(rows);
        if (rows.length < pageSize) {
          lastPage = true;
          break;
        }
      }
      if (lastPage) {
        complete = true;
        break;
      }
      page += batchSize;
    }
    if (opts.requireComplete && !complete) {
      throw new Error(`Limite de ${maxPages * pageSize} linhas atingido em ${opts.table}; reduza o periodo.`);
    }

    if (cacheKey) writeMapaReportCache(cacheKey, allRows);
    return { rows: allRows, state: allRows.length ? "SUCCESS" : "EMPTY" };
  } catch (error) {
    const cached = cacheKey ? readMapaReportCache(cacheKey) : null;
    if (cached && cached.rows.length) {
      console.warn("Relatorio: usando cache local apos falha no servidor:", error);
      return { rows: cached.rows, state: "OFFLINE_CACHE", error };
    }
    throw error;
  } finally {
    if (timer) clearTimeout(timer);
    if (controller && externalSignal) externalSignal.removeEventListener("abort", abortFromExternal);
  }
}

function setSyncStatus(kind, message) {
  if (!el.syncStatus) return;
  el.syncStatus.className = "sync-status";
  if (kind === "ok") el.syncStatus.classList.add("sync-ok");
  if (kind === "warn") el.syncStatus.classList.add("sync-warn");
  if (kind === "error") el.syncStatus.classList.add("sync-error");
  if (kind === "pending") el.syncStatus.classList.add("sync-pending");
  el.syncStatus.textContent = message;
}

function isSupabaseMissingColumnError(error) {
  const message = String(error?.message || error || "").toLowerCase();
  return (
    (message.includes("column") && message.includes("does not exist"))
    || (message.includes("could not find") && message.includes("column"))
    || (message.includes("schema cache") && message.includes("codigo_"))
  );
}

async function insertWithLegacyFallback(tableName, rows, legacyMapper) {
  const { error } = await supabaseClient.from(tableName).insert(rows);
  if (!error) return;
  if (!isSupabaseMissingColumnError(error)) throw error;
  const legacyRows = rows.map(legacyMapper);
  const legacyResult = await supabaseClient.from(tableName).insert(legacyRows);
  if (legacyResult.error) throw legacyResult.error;
}

async function upsertWithLegacyFallback(tableName, row, legacyMapper) {
  const { error } = await supabaseClient.from(tableName).upsert(row);
  if (!error) return;
  if (!isSupabaseMissingColumnError(error)) throw error;
  const legacyResult = await supabaseClient.from(tableName).upsert(legacyMapper(row));
  if (legacyResult.error) throw legacyResult.error;
}

async function saveProducaoByNaturalKey(row) {
  const { data: existingRows, error: selectError } = await supabaseClient
    .from('producao')
    .select('id')
    .eq('data_fabricacao', row.data_fabricacao)
    .eq('setor', row.setor)
    .eq('forma', row.forma)
    .order('data_hora', { ascending: false, nullsFirst: false });

  if (selectError) throw selectError;

  const [current, ...duplicates] = existingRows || [];
  if (current?.id) {
    const { error: updateError } = await supabaseClient
      .from('producao')
      .update(row)
      .eq('id', current.id);
    if (updateError) {
      if (!isSupabaseMissingColumnError(updateError)) throw updateError;
      const { vibrado, ...legacyRow } = row;
      const { error: legacyUpdateError } = await supabaseClient
        .from('producao')
        .update(legacyRow)
        .eq('id', current.id);
      if (legacyUpdateError) throw legacyUpdateError;
    }

    if (duplicates.length) {
      await supabaseClient
        .from('producao')
        .delete()
        .in('id', duplicates.map((item) => item.id));
    }
    return;
  }

  const { error: insertError } = await supabaseClient.from('producao').insert(row);
  if (insertError) {
    if (!isSupabaseMissingColumnError(insertError)) throw insertError;
    const { vibrado, ...legacyRow } = row;
    const { error: legacyInsertError } = await supabaseClient.from('producao').insert(legacyRow);
    if (legacyInsertError) throw legacyInsertError;
  }
}

async function checkApiStatus() {
  if (!hasApiConfigured()) {
    setSyncStatus("warn", "Servidor não configurado: salvando apenas localmente.");
    return;
  }

  try {
    const { error } = await supabaseClient.from('usuarios').select('id').limit(1);
    if (!error) {
      setSyncStatus("ok", "Conectado: sincronização online ativa.");
    } else {
      setSyncStatus("error", "Falha ao verificar o banco de dados.");
    }
  } catch {
    setSyncStatus("error", "Sem conexão com o servidor no momento.");
  }
}

async function postToApi(action, payload) {
  if (!hasApiConfigured()) {
    return { ok: false, skipped: true, error: "API não configurada" };
  }

  try {
    if (action === "salvar_forma_click") {
      let dtStr = new Date().toISOString();
      if (payload.dia && payload.hora) {
         try {
           const [dd, mm, yyyy] = payload.dia.split('/');
           const [hh, min, ss] = payload.hora.split(':');
           // Força o horário local do apontamento para o fuso de Brasília (-03:00)
           const localStr = `${yyyy}-${mm}-${dd}T${hh}:${min}:${ss || '00'}-03:00`;
           dtStr = new Date(localStr).toISOString();
         } catch(e) {}
      }

      if (payload.status === "P" || payload.status === "PROGRAMADA") {
        const { error } = await supabaseClient.from('programacao_pcp').upsert({
          data_fabricacao: payload.dataFabricacao,
          setor: payload.setor,
          forma: payload.forma,
          modelo: payload.modelo,
          codigo_poste: payload.codigo_poste || null,
          descricao_poste: payload.descricao_poste || null,
          codigo_produto: payload.codigo_produto || null,
          quantidade: 1,
          data_hora: dtStr
        }, { onConflict: 'data_fabricacao,setor,forma' });
        if (error) throw error;
      } else if (payload.status === "L" || (payload.status === "LIBERADO" && payload.tipo_concreto === "Padrão")) {
        const { error } = await supabaseClient.from('liberacao_formas').upsert({
          data_fabricacao: payload.dataFabricacao,
          setor: payload.setor,
          forma: payload.forma,
          colaborador: payload.colaborador,
          data_hora: dtStr
        }, { onConflict: 'data_fabricacao,setor,forma' });
        if (error) throw error;
      } else {
        await saveProducaoByNaturalKey({
          data_fabricacao: payload.dataFabricacao,
          setor: payload.setor,
          forma: payload.forma,
          modelo: payload.modelo,
          codigo_poste: payload.codigo_poste || null,
          descricao_poste: payload.descricao_poste || null,
          codigo_produto: payload.codigo_produto || null,
          tipo_concreto: payload.tipo_concreto || 'Padrão',
          vibrado: payload.vibrado,
          colaborador: payload.colaborador,
          data_hora: dtStr,
          status: 'LIBERADO'
        });
      }

      return { ok: true, message: "Forma salva nos novos esquemas com sucesso" };
    }

    if (action === "salvar_inspecao_lote") {
      const inserts = (payload.entries || []).map(entry => ({
        setor: entry.setor,
        forma: entry.forma || entry.formaNumero,
        modelo: entry.modelo,
        codigo_poste: entry.codigoPoste || entry.codigo_poste || null,
        descricao_poste: entry.descricaoPoste || entry.descricao_poste || null,
        codigo_produto: entry.codigoProduto || entry.codigo_produto || null,
        colaborador: entry.colaborador,
        data_fabricacao: entry.dataProducao,
        tipo_concreto: 'INSPECIONADO',
        status: 'INSPECIONADO'
      }));
      await insertWithLegacyFallback('producao', inserts, ({ codigo_poste, descricao_poste, codigo_produto, ...legacy }) => legacy);
      return { ok: true, message: "Inspeções salvas", results: inserts.map(i => ({forma: i.forma, status: 'ok'})) };
    }

    if (action === "listar_inspecao_pendentes") {
      let query = supabaseClient.from('producao').select('*').eq('status', 'LIBERADO');
      if (payload.data) query = query.eq('data_fabricacao', payload.data);
      if (payload.setor) query = query.eq('setor', payload.setor);
      const { data, error } = await query;
      if (error) throw error;

      const pendentes = data.map(row => ({
        forma: row.forma,
        setor: row.setor,
        modelo: row.modelo,
        codigoPoste: row.codigo_poste || "",
        descricaoPoste: row.descricao_poste || "",
        codigoProduto: row.codigo_produto || "",
        dataProducao: row.data_fabricacao,
        tipoConcreto: row.tipo_concreto
      }));
      return { ok: true, pendentes };
    }

    if (action === "relatorio_setor") {
      let query = supabaseClient.from('producao').select('*');
      if (payload.data) query = query.eq('data_fabricacao', payload.data);
      if (payload.setor) query = query.eq('setor', payload.setor);
      const { data, error } = await query;
      if (error) throw error;

      const relatorio = { liberados: 0, inspecionados: 0, porSetor: {}, porTipo: {} };
      data.forEach(row => {
        if (row.status === "LIBERADO") relatorio.liberados++;
        if (row.status === "INSPECIONADO") relatorio.inspecionados++;

        if (!relatorio.porSetor[row.setor]) relatorio.porSetor[row.setor] = { liberados: 0, inspecionados: 0 };
        if (row.status === "LIBERADO") relatorio.porSetor[row.setor].liberados++;
        if (row.status === "INSPECIONADO") relatorio.porSetor[row.setor].inspecionados++;

        if (!relatorio.porTipo[row.tipo_concreto]) relatorio.porTipo[row.tipo_concreto] = 0;
        relatorio.porTipo[row.tipo_concreto]++;
      });
      return { ok: true, relatorio };
    }

    if (action === "listar_usuarios") {
      const { data, error } = await supabaseClient.from('usuarios').select('*').eq('ativo', true);
      if (error) throw error;
      const users = data.map(u => ({ id: u.id, name: u.nome, role: u.perfil, setor: u.setor || "Todos", active: u.ativo }));
      return { ok: true, users };
    }

    if (action === "autenticar_usuario") {
      // Permite autenticação pelo Nome ou pelo Login (id)
      const { data, error } = await supabaseClient.from('usuarios')
        .select('*')
        .eq('ativo', true)
        .or(`id.ilike.${payload.name},nome.ilike.${payload.name}`)
        .eq('senha', payload.password)
        .limit(1);
      if (error) throw error;
      if (data.length === 0) return { ok: false, error: "Usuário ou senha incorretos." };
      const u = data[0];
      return {
        ok: true,
        user: {
          id: u.id,
          name: u.nome,
          role: u.perfil,
          active: u.ativo,
          setor: u.setor || "Todos",
          primeiro_acesso: u.primeiro_acesso !== false
        }
      };
    }

    if (action === "criar_usuario") {
      const userId = String(payload.login || "").trim().toLowerCase().replace(/[^a-z0-9]+/g, "-");
      const { data, error } = await supabaseClient.from('usuarios').upsert([{
        id: userId,
        nome: payload.name,
        perfil: payload.role,
        senha: payload.password,
        setor: payload.setor || "Todos",
        primeiro_acesso: true, // Sempre ativo no primeiro cadastro
        ativo: true,
        updated_at: nowIso()
      }]).select();
      if (error) throw error;
      return { ok: true, user: { id: userId, name: payload.name, role: payload.role, active: true } };
    }

    if (action === "alterar_senha_primeiro_acesso") {
      const { data, error } = await supabaseClient.from('usuarios').update({
        senha: payload.senha,
        primeiro_acesso: false,
        updated_at: nowIso()
      }).eq('id', payload.id).select();
      if (error) throw error;
      return { ok: true };
    }

    if (action === "excluir_usuario") {
      const { error } = await supabaseClient.from('usuarios').update({ ativo: false }).eq('id', payload.id);
      if (error) throw error;
      return { ok: true, deletedId: payload.id };
    }

    return { ok: false, error: "Ação POST inválida" };
  } catch (error) {
    return { ok: false, error: error.message || String(error) };
  }
}

async function postToMontagemApi(action, payload) {
  if (!hasMontagemApiConfigured()) {
    return { ok: false, skipped: true, error: "API de montagem não configurada" };
  }

  try {
    if (action === "salvar_montagem_poste") {
      let key = payload.key;
      if (!key) key = [payload.recordId, payload.dataFabricacao, payload.setor, payload.formaNumero].join("||");

      await upsertWithLegacyFallback('montagem_poste', {
        id: key,
        record_id: payload.recordId,
        data_fabricacao: payload.dataFabricacao,
        setor: payload.setor,
        forma_numero: payload.formaNumero,
        modelo: payload.modelo,
        codigo_poste: payload.codigoPoste || payload.codigo_poste || null,
        descricao_poste: payload.descricaoPoste || payload.descricao_poste || null,
        codigo_produto: payload.codigoProduto || payload.codigo_produto || null,
        status_montagem: payload.statusMontagem,
        motivo_recusa: payload.motivoRecusa,
        etapa: payload.etapa,
        inicio_inspecao_montagem: payload.inicioInspecaoMontagem || null,
        finalizado_em: payload.finalizadoEm || null,
        checklists: payload.checklists || {},
        banco: payload.banco || 'montagem_poste',
        observacoes_montagem: payload.observacoesMontagem,
        montador_nome: payload.montadorNome
      }, ({ codigo_poste, descricao_poste, codigo_produto, ...legacy }) => legacy);
      return { ok: true, upsert: "update", key };
    }

    return { ok: false, error: "Ação POST inválida na montagem" };
  } catch (error) {
    return { ok: false, error: error.message || String(error) };
  }
}

async function postToMontagemApiWithTimeout(action, payload, timeoutMs = 15000) {
  let timeoutId;
  const timeoutResult = new Promise((resolve) => {
    timeoutId = setTimeout(() => resolve({ ok: false, timeout: true,
      error: "Tempo limite de rede excedido" }), timeoutMs);
  });
  try {
    return await Promise.race([postToMontagemApi(action, payload), timeoutResult]);
  } finally {
    clearTimeout(timeoutId);
  }
}

function formatDateTime(iso) {
  if (!iso) return "-";
  return new Date(iso).toLocaleString("pt-BR");
}

function fmtDate(value) {
  const ymd = dateToYmd(value);
  if (!ymd) return "";
  const [y, m, d] = ymd.split("-");
  return `${d}/${m}/${y}`;
}

function montagemStatusLabel(status) {
  if (status === "A") return "Aprovado";
  if (status === "R") return "Reprovado";
  if (status === "RR") return "Retrabalhado e aprovado";
  return "-";
}

function getMontagemMotivoOptions() {
  return CHECKLIST_INSPECAO_CODIGOS.map((item) => ({
    value: item.codigo,
    label: `${item.codigo} — ${item.descricao}`
  }));
}

// Mapa de icones por codigo de defeito
const DEFEITO_ICONES = {
  A: "",   //   — Falha de Preenchimento / Armação Aparente (vazio/buraco)
  B: "",         //   — Tubulação Entupida (sem fluxo)
  C: "",         //   — Bolhas em Excesso / Fora do Padrão
  D: "",         //   — Problema na Caixa do Relógio/Disjuntor
  E: "",         //   — Furação Obstruída (pinos)
  F: "",   //   — Carimbo de Identificação
  G: "",         //   — Fissuras superficiais
  H: "",         //   — Bolhas nas Caixas
  I: "",               // ⚡  — Trincas em toda extensão
  J: "",         //   — Pequenas Avarias
  K: "",         //   — Manchas Excessivas
  L: "",         //   — Buchas de Fixação
  M: "",         //   — Parafuso Lacre da Caixa do Medidor
  O: "",         //   — Concreto Segregado / Homogeneidade
  P: "",         //   — Grandes Avarias (emergência)
  Q: "",         //   — Rebarbas
  R: "",         //   — Acabamento Face Exposta
  S: "",         //   — Acabamento Abas
};

function getMotivoRecusaLabel(value) {
  if (!value) return "-";
  const parts = String(value).split(/,\s*/);
  const labels = parts.map((part) => {
    const cod = part.trim().toUpperCase();
    const found = CHECKLIST_INSPECAO_CODIGOS.find((item) => item.codigo === cod);
    const icone = DEFEITO_ICONES[cod] || "";
    return found ? `${icone} ${found.codigo} \u2014 ${found.descricao}` : `${icone} ${part}`;
  });
  return labels.join("  |  ");
}

function statusFluxoFromRecord(record) {
  if (!record.liberacao) return "SEM_LIBERACAO";
  if (!record.inspecoes || record.inspecoes.length === 0) return "PENDENTE_INSPECAO";
  const last = record.inspecoes[record.inspecoes.length - 1];
  if (last.status === "A") return "CONCLUIDO_APROVADO";
  if (last.status === "RR") return "CONCLUIDO_RETRABALHO";
  return "CONCLUIDO_REPROVADO";
}

function findRecordByKey(db, dataFabricacao, setor, formaNumero) {
  return db.records.find(
    (record) => record.dataFabricacao === dataFabricacao && record.setor === setor && record.formaNumero === formaNumero
  );
}

function getInspecaoResumo(record) {
  if (!record || !Array.isArray(record.inspecoes) || !record.inspecoes.length) return { status: "", cod: "" };
  const ultima = record.inspecoes[record.inspecoes.length - 1];
  const cod = Array.isArray(ultima.codigos) ? ultima.codigos.join("/") : "";
  return { status: ultima.status || "", cod };
}

function statusFlagsFromCode(statusCodigo) {
  return {
    liberado: statusCodigo === "1" ? 1 : 0,
    naoMontado: statusCodigo === "D" ? 1 : 0,
    manutencao: statusCodigo === "M" ? 1 : 0
  };
}

function getLiberacaoSelectOptions(selectedStatus) {
  const status = selectedStatus || "";
  return `
    <div class="lib-actions" data-lib-actions>
      <input type="hidden" data-lib-status value="${status}">
      <button type="button" class="lib-btn ${status === "1" ? "active btn-liberado" : ""}" data-lib-btn="1">Liberado</button>
      <button type="button" class="lib-btn ${status === "D" ? "active btn-nao" : ""}" data-lib-btn="D">Não montado</button>
      <button type="button" class="lib-btn ${status === "M" ? "active btn-manut" : ""}" data-lib-btn="M">Manutenção</button>
    </div>
  `;
}

function renderInspecaoCodigosChecklist() {
  if (!el.insChecklistCodigos) return;
  el.insChecklistCodigos.innerHTML = "";
  CHECKLIST_INSPECAO_CODIGOS.forEach((item) => {
    const row = document.createElement("div");
    row.className = "check-row";
    row.innerHTML = `<span><strong>${item.codigo}</strong> — ${item.descricao}</span>`;
    el.insChecklistCodigos.appendChild(row);
  });
}

function renderPhotoPreview(container, photos) {
  container.innerHTML = "";
  photos.forEach((photo) => {
    const img = document.createElement("img");
    img.className = "thumb";
    img.src = photo.dataUrl;
    img.alt = photo.name || "foto";
    container.appendChild(img);
  });
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    const timeout = setTimeout(() => reader.abort(), 30000);
    reader.onload = () => {
      clearTimeout(timeout);
      if (typeof reader.result === "string") resolve(reader.result);
      else reject(new Error("Não foi possível ler a foto."));
    };
    reader.onerror = () => {
      clearTimeout(timeout);
      reject(new Error("Não foi possível ler a foto."));
    };
    reader.onabort = () => {
      clearTimeout(timeout);
      reject(new Error("A leitura da foto demorou demais. Tente novamente."));
    };
    try { reader.readAsDataURL(file); } catch (error) { clearTimeout(timeout); reject(error); }
  });
}

function compressImage(dataUrl, maxWidth, quality) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const timeout = setTimeout(() => finish(null, new Error("A foto demorou para abrir. Tente novamente ou use uma foto JPG.")), 15000);
    let finished = false;
    function finish(value, error) {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);
      img.onload = null;
      img.onerror = null;
      if (error) reject(error);
      else resolve(value);
    }
    img.onload = () => {
      try {
        if (!img.width || !img.height) throw new Error("A foto está vazia ou danificada.");
        const ratio = img.width > maxWidth ? maxWidth / img.width : 1;
        const width = Math.round(img.width * ratio);
        const height = Math.round(img.height * ratio);
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) throw new Error("Não foi possível processar a foto neste aparelho.");
        ctx.drawImage(img, 0, 0, width, height);
        const compressed = canvas.toDataURL("image/jpeg", quality);
        if (!compressed.startsWith("data:image/jpeg")) throw new Error("Não foi possível converter a foto para JPG.");
        finish(compressed);
      } catch (error) {
        finish(null, error);
      }
    };
    img.onerror = () => finish(null, new Error("Formato de foto não reconhecido. Use JPG, PNG ou WebP."));
    try { img.src = dataUrl; } catch (error) { finish(null, error); }
  });
}

async function filesToCompressedDataUrls(fileList) {
  const files = Array.from(fileList || []);
  const out = [];
  for (const file of files) {
    const dataUrl = await fileToDataUrl(file);
    const compressed = await compressImage(dataUrl, 1280, 0.72);
    out.push({ id: uuid(), name: file.name, type: file.type, dataUrl: compressed });
  }
  return out;
}

function pad2(value) {
  return String(value).padStart(2, "0");
}

function buildFormaRange(prefix, start, end) {
  const out = [];
  const step = start <= end ? 1 : -1;
  for (let i = start; step > 0 ? i <= end : i >= end; i += step) {
    out.push(`${prefix}${pad2(i)}`);
  }
  return out;
}

function mapCatalogByForma(catalog) {
  const map = new Map();
  (catalog || []).forEach((item) => {
    map.set(normalizeUpper(item.forma), item);
  });
  return map;
}

function resolveFormasFromCatalog(catalog, formas) {
  const map = mapCatalogByForma(catalog);
  return formas.map((forma) => map.get(normalizeUpper(forma))).filter(Boolean);
}

function buildSetor1LeftBlocks(catalog) {
  const block1 = ["100-3", "100-2", "100-1", ...buildFormaRange("AE-", 1, 11)];
  const block2 = buildFormaRange("AE-", 12, 25);
  const block3 = ["AE-26", "AE-27", ...buildFormaRange("BD-", 15, 1), "IE-01"];

  return [
    resolveFormasFromCatalog(catalog, block1),
    resolveFormasFromCatalog(catalog, block2),
    resolveFormasFromCatalog(catalog, block3)
  ];
}

function buildSetor1RightBlocks(catalog) {
  const bottomUp = Array.isArray(catalog) ? [...catalog].reverse() : [];
  return [
    bottomUp.slice(0, 14),
    bottomUp.slice(14, 28),
    bottomUp.slice(28)
  ];
}

function createFormaButton(item, setor) {
  item = withPosteData(item, setor);
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "lib-btn";
  const setBtnLabel = (done = false, tipo = null) => {
    const check = done ? " ✓" : "";
    const tipoText = tipo ? ` (${tipo})` : "";
    btn.innerHTML = `<span class="lib-btn-model">${item.modelo || "-"}</span> <span class="lib-btn-forma">${item.forma}${tipoText}${check}</span>`;
  };
  setBtnLabel(false);
  btn.dataset.formaNumero = normalizeUpper(item.forma);
  btn.dataset.modelo = item.modelo;
  btn.dataset.codigoPoste = item.codigoPoste || "";
  btn.dataset.descricaoPoste = item.descricaoPoste || "";
  btn.dataset.codigoProduto = item.codigoProduto || "";
  if (item.descricaoPoste || item.codigoProduto) {
    btn.title = [item.descricaoPoste, item.codigoProduto ? `Produto ${item.codigoProduto}` : ""].filter(Boolean).join(" - ");
  }

  if (setor && isFormaClicked(item.forma, setor)) {
    const tipo = getConcreteTypeForForma(item.forma, setor);
    btn.classList.add("active", "btn-liberado");
    setBtnLabel(true, tipo);
    btn.disabled = true;
  } else {
    btn.addEventListener("click", () => {
      const data = el.libData?.value;
      const colaborador = getProductionCollaborator();
      if (!data) {
        showLibFeedback("Preencha a data de fabricação antes de registrar.", "error");
        el.libData?.focus();
        return;
      }
      if (!colaborador) {
        showLibFeedback("Preencha o colaborador antes de registrar.", "error");
        el.libColaborador?.focus();
        return;
      }
      showConcreteTypePopup(item.forma, setor, btn, item.modelo || "");
    });
  }

  return btn;
}

function createLiberacaoRow(item, setor) {
  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td class="lib-cell"></td>
    <td>${item.modelo || ""}</td>
    <td class="ins-related">-</td>
    <td class="ins-related">-</td>
  `;
  const formaCell = tr.querySelector("td.lib-cell");
  const btn = createFormaButton(item, setor);
  if (setor && isFormaClicked(item.forma, setor)) {
    tr.classList.add("row-liberada");
  }
  formaCell.appendChild(btn);
  return tr;
}

async function getSetorRowsByDate(setor, dataFabricacao) {
  if (!hasApiConfigured() || !dataFabricacao || !setor) return [];

  try {
    const url = `${CONFIG.API_URL}?action=relatorio_setor&dataFabricacao=${encodeURIComponent(dataFabricacao)}&setor=${encodeURIComponent(setor)}`;
    const response = await fetch(url);
    const text = await response.text();
    const payload = JSON.parse(text);
    if (payload.ok && Array.isArray(payload.rows)) return payload.rows;
  } catch {
    // Usa catalogo local quando a API nao responder.
  }
  return [];
}

async function getSectorFormsForLiberacao(setor) {
  const forms = getSectorForms(setor);
  return forms;
}

function renderSheetBlocks(blocks, container, setor, labels = []) {
  container.innerHTML = "";
  container.classList.add("forma-grid-blocos");

  blocks.forEach((blockItems, index) => {
    const blockWrap = document.createElement("div");
    blockWrap.className = "forma-block-wrap";

    const divider = document.createElement("div");
    divider.className = "forma-block-divider";
    divider.textContent = labels[index] || `Bloco ${index + 1}`;

    const block = document.createElement("div");
    block.className = "forma-block";
    (blockItems || []).forEach((item) => {
      block.appendChild(createFormaButton(item, setor));
    });

    blockWrap.appendChild(divider);
    blockWrap.appendChild(block);
    container.appendChild(blockWrap);
  });
}

function renderSheetSide(items, container, options = {}) {
  const setor = el.libSetor?.value || "";
  container.innerHTML = "";
  container.classList.remove("forma-grid-blocos");

  const catalog = Array.isArray(items) ? items : [];
  const isTableBody = container.tagName === "TBODY";

  if (Array.isArray(options.blocks) && options.blocks.length) {
    renderSheetBlocks(options.blocks, container, setor, options.blockLabels || []);
    return;
  }

  catalog.forEach((item) => {
    if (isTableBody) {
      container.appendChild(createLiberacaoRow(item, setor));
      return;
    }
    const btn = createFormaButton(item, setor);
    container.appendChild(btn);
  });
}

function setCardState(card, cardState) {
  card.classList.remove("is-idle", "is-saving", "is-saved", "is-error", "is-liberada");
  card.classList.add("is-" + cardState);

  // Se for uma célula do mapa do Setor 4, atualizar a linha inteira
  if (card.classList.contains("s4-forma-cell")) {
    if (typeof card.refreshRow === "function") {
      card.refreshRow();
    } else if (cardState === "saved") {
      const tr = card.closest("tr");
      if (tr) {
        const tdLib = tr.querySelector(".td-lib");
        if (tdLib) tdLib.textContent = "1";
      }
    }
  }

  const statusEl = card.querySelector(".fc-status");
  if (!statusEl) return;
  if (cardState === "saving") {
    statusEl.textContent = "⋯";
    card.disabled = true;
  } else if (cardState === "saved") {
    statusEl.textContent = "✓";
    card.disabled = !state.programmingMode && !state.liberationMode && !state.odinMode && !state.manutencaoMode;
  } else if (cardState === "error") {
    statusEl.textContent = "✗";
    card.disabled = false;
  } else {
    statusEl.textContent = "";
    card.disabled = false;
  }
}

function markFormaLiberada(forma, setor) {
  const clicked = getClickedFormsToday();
  const key = setor + "||" + normalizeUpper(forma);
  clicked.formas[key] = "L";
  localStorage.setItem(CLICKED_FORMS_KEY, JSON.stringify(clicked));
}

function createFormaCard(item, setor) {
  item = withPosteData(item, setor);
  const card = document.createElement("button");
  card.type = "button";
  card.className = "forma-card is-idle";
  card.dataset.formaNumero = normalizeUpper(item.forma);
  card.dataset.modelo = item.modelo || "";
  card.dataset.codigoPoste = item.codigoPoste || "";
  card.dataset.descricaoPoste = item.descricaoPoste || "";
  card.dataset.codigoProduto = item.codigoProduto || "";
  if (item.descricaoPoste || item.codigoProduto) {
    card.title = [item.descricaoPoste, item.codigoProduto ? `Produto ${item.codigoProduto}` : ""].filter(Boolean).join(" - ");
  }

  const numEl = document.createElement("span");
  numEl.className = "fc-number";
  numEl.textContent = setor === "Setor 4" ? (item.modelo || item.label || item.forma) : (item.label || item.forma);

  const tipoEl = document.createElement("span");
  tipoEl.className = "fc-tipo";

  const statusEl = document.createElement("span");
  statusEl.className = "fc-status";

  card.appendChild(numEl);
  card.appendChild(tipoEl);
  card.appendChild(statusEl);
  const plannedModel = getProductionProgrammedModel(item.forma, setor);
  if (plannedModel) {
    const planned = document.createElement("span");
    planned.className = "fc-programmed-model";
    planned.textContent = "PCP: " + plannedModel;
    card.appendChild(planned);
  }

  // Verificar se a forma está em manutenção (Parada)
  const manutencaoRec = isFormaEmManutencao(setor, item.forma);
  if (manutencaoRec) {
    card.classList.add("is-manutencao");
    card.title = ` PARADA / MANUTENÇÃO\nMotivo: ${manutencaoRec.motivo_parada}\nArrumar: ${manutencaoRec.acao_necessaria}`;
  }

  // Destacar se estiver programada
  if (state.programmedFormas && state.programmedFormas.has(normalizeUpper(item.forma))) {
    card.classList.add("is-programmed");
  }

  const handleCardClickWithMaintenance = (normalAction) => {
    if (state.manutencaoMode) {
      if (manutencaoRec) {
        openModalLiberacao(setor, item.forma, manutencaoRec);
      } else {
        openModalParada(setor, item.forma);
      }
      return;
    }
    if (manutencaoRec) {
      if (typeof msgbox !== "undefined") {
        msgbox.alert(
          ` FORMA EM MANUTENÇÃO!\n\nA forma ${item.forma} (${setor}) está INATIVA para manutenção e não pode ser programada nem liberada.\n\n• Motivo: ${manutencaoRec.motivo_parada}\n• Serviço: ${manutencaoRec.acao_necessaria}\n• Parada em: ${manutencaoRec.parada_em} por ${manutencaoRec.parada_por}`
        );
      } else {
        alert(` FORMA EM MANUTENÇÃO!\nForma ${item.forma} está inativa.\nMotivo: ${manutencaoRec.motivo_parada}`);
      }
      return;
    }
    normalAction();
  };

  if (isFormaClicked(item.forma, setor)) {
    const badgeText = formatFormaConcreteBadge(getProductionRecordForForma(item.forma, setor));
    if (badgeText) {
      tipoEl.textContent = badgeText;
      tipoEl.style.display = "block";
    }
    setCardState(card, "saved");

    card.addEventListener("click", () => {
      handleCardClickWithMaintenance(() => {
        if (state.programmingMode) {
          toggleFormaProgramada(item.forma, setor, card);
          return;
        }
        if (state.odinMode) {
          cancelarOuDesprogramarOdin(item.forma, setor, card);
          return;
        }
      });
    });
  } else if (isFormaLiberada(item.forma, setor)) {
    card.classList.add("is-liberada");
    card.addEventListener("click", () => {
      handleCardClickWithMaintenance(() => {
        if (state.programmingMode) {
          toggleFormaProgramada(item.forma, setor, card);
          return;
        }
        if (state.odinMode) {
          cancelarOuDesprogramarOdin(item.forma, setor, card);
          return;
        }
        if (state.liberationMode) {
          return;
        }
        const data = el.libData?.value;
        const colaborador = getProductionCollaborator();
        if (!data) {
          showLibFeedback("Preencha a data de fabricação antes de registrar.", "error");
          el.libData?.focus();
          return;
        }
        if (!colaborador) {
          showLibFeedback("Preencha o colaborador antes de registrar.", "error");
          el.libColaborador?.focus();
          return;
        }
        showConcreteTypePopup(item.forma, setor, card, item.modelo || "");
      });
    });
  } else {
    card.addEventListener("click", () => {
      handleCardClickWithMaintenance(() => {
        if (state.programmingMode) {
          toggleFormaProgramada(item.forma, setor, card);
          return;
        }
        if (state.odinMode) {
          cancelarOuDesprogramarOdin(item.forma, setor, card);
          return;
        }
        const data = el.libData?.value;
        const colaborador = getProductionCollaborator();
        if (!data) {
          showLibFeedback("Preencha a data de fabricação antes de registrar.", "error");
          el.libData?.focus();
          return;
        }
        if (!colaborador) {
          showLibFeedback("Preencha o colaborador antes de registrar.", "error");
          el.libColaborador?.focus();
          return;
        }
        if (state.liberationMode) {
          liberarFormaClicada(item.forma, setor, card, item.modelo || "");
        } else {
          showConcreteTypePopup(item.forma, setor, card, item.modelo || "");
        }
      });
    });
  }

  return card;
}

function renderSectorCols(container, leftForms, rightForms, setor) {
  if (!container) return;
  container.innerHTML = "";
  const leftCol = document.createElement("div");
  leftCol.className = "lib-forms-col";
  const rightCol = document.createElement("div");
  rightCol.className = "lib-forms-col";
  leftForms.forEach((item) => leftCol.appendChild(createFormaCard(item, setor)));
  rightForms.forEach((item) => rightCol.appendChild(createFormaCard(item, setor)));
  container.appendChild(leftCol);
  container.appendChild(rightCol);
}

function renderSector3Cols(container, col1Forms, col2Forms, col3Forms, setor) {
  if (!container) return;
  container.innerHTML = "";
  const col1 = document.createElement("div");
  col1.className = "lib-forms-col";
  const col2 = document.createElement("div");
  col2.className = "lib-forms-col";
  const col3 = document.createElement("div");
  col3.className = "lib-forms-col";
  col1Forms.forEach((item) => col1.appendChild(createFormaCard(item, setor)));
  col2Forms.forEach((item) => col2.appendChild(createFormaCard(item, setor)));
  col3Forms.forEach((item) => col3.appendChild(createFormaCard(item, setor)));
  container.appendChild(col1);
  container.appendChild(col2);
  container.appendChild(col3);
}

function createS4TableRow(item, setor) {
  item = withPosteData(item, setor);
  const tr = document.createElement("tr");

  const tdForma = document.createElement("td");
  tdForma.className = "s4-forma-cell";
  if (state.programmedFormas?.has(normalizeUpper(item.forma))) tdForma.classList.add("is-programmed");
  tdForma.textContent = item.label || item.forma;
  tdForma.dataset.formaNumero = normalizeUpper(item.forma);
  tdForma.dataset.modelo = item.modelo || "";
  tdForma.dataset.codigoPoste = item.codigoPoste || "";
  tdForma.dataset.descricaoPoste = item.descricaoPoste || "";
  tdForma.dataset.codigoProduto = item.codigoProduto || "";
  if (item.descricaoPoste || item.codigoProduto) {
    tdForma.title = [item.descricaoPoste, item.codigoProduto ? `Produto ${item.codigoProduto}` : ""].filter(Boolean).join(" - ");
  }

  const tdModelo = document.createElement("td");
  tdModelo.textContent = item.modelo || "";
  if (item.multimodelo) {
    tr.classList.add("s4-multi-model");
    tdModelo.title = "Ao liberar a forma, selecione o modelo produzido: " + item.modelos.join(", ");
  }

  const tdLib = document.createElement("td");
  tdLib.className = "td-lib";

  const tdInsStatus = document.createElement("td");
  tdInsStatus.className = "td-ins-status";

  const tdInsCod = document.createElement("td");
  tdInsCod.className = "td-ins-cod";

  // Verificar se a forma está em manutenção (Parada)
  const manutencaoRec = isFormaEmManutencao(setor, item.forma);
  if (manutencaoRec) {
    tdForma.classList.add("is-manutencao");
    tdForma.title = ` PARADA / MANUTENÇÃO\nMotivo: ${manutencaoRec.motivo_parada}\nArrumar: ${manutencaoRec.acao_necessaria}`;
  }

  const refreshRow = () => {
    if (isFormaClicked(item.forma, setor)) {
      tdForma.classList.add("is-saved");
      tdLib.textContent = "1";
      const db = readDb();
      const rec = findRecordByKey(db, el.libData?.value || todayYmd(), setor, normalizeUpper(item.forma));
      const ins = getInspecaoResumo(rec);
      tdInsStatus.textContent = ins.status || "";
      tdInsCod.textContent = ins.cod || "";
    } else {
      tdForma.classList.remove("is-saved");
      tdLib.textContent = "";
      tdInsStatus.textContent = "";
      tdInsCod.textContent = "";
    }
  };
  tdForma.refreshRow = refreshRow;

  tdForma.addEventListener("click", () => {
    if (state.manutencaoMode) {
      if (manutencaoRec) {
        openModalLiberacao(setor, item.forma, manutencaoRec);
      } else {
        openModalParada(setor, item.forma);
      }
      return;
    }
    if (manutencaoRec) {
      if (typeof msgbox !== "undefined") {
        msgbox.alert(
          ` FORMA EM MANUTENÇÃO!\n\nA forma ${item.forma} (${setor}) está INATIVA para manutenção e não pode ser programada nem liberada.\n\n• Motivo: ${manutencaoRec.motivo_parada}\n• Serviço: ${manutencaoRec.acao_necessaria}\n• Parada em: ${manutencaoRec.parada_em} por ${manutencaoRec.parada_por}`
        );
      } else {
        alert(` FORMA EM MANUTENÇÃO!\nForma ${item.forma} está inativa.\nMotivo: ${manutencaoRec.motivo_parada}`);
      }
      return;
    }
    if (state.programmingMode) {
      toggleFormaProgramada(item.forma, setor, tdForma);
      return;
    }
    if (state.odinMode) {
      cancelarOuDesprogramarOdin(item.forma, setor, tdForma);
      return;
    }
    const data = el.libData?.value;
    const colaborador = getProductionCollaborator();
    if (!data) { showLibFeedback("Preencha a data de fabricação antes de registrar.", "error"); return; }
    if (!colaborador) { showLibFeedback("Preencha o colaborador antes de registrar.", "error"); return; }
    showConcreteTypePopup(item.forma, setor, tdForma, item.modelo || "");
  });

  tr.appendChild(tdForma);
  tr.appendChild(tdModelo);

  refreshRow();
  return tr;
}

const S4_LAYOUT_CACHE_KEY = "mapa_s4_dt_layout_v1";
let setor4DtAreas = null;
let setor4LayoutForms = [];
let setor4LayoutCanEdit = false;

function applyS4DtLayout(payload) {
  if (!Array.isArray(payload?.areas) || !Array.isArray(payload?.formas)) return false;
  const groups = new Map();
  payload.areas.forEach(row => {
    if (!row?.codigo || !row?.area || !Number.isInteger(row.posicao)) return;
    const key = `${row.area_ordem}|${row.area}`;
    if (!groups.has(key)) groups.set(key, { nome: row.area, ordem: row.area_ordem, formas: [] });
    groups.get(key).formas.push({ codigo: row.codigo, posicao: row.posicao });
  });
  setor4DtAreas = [...groups.values()].sort((a, b) => a.ordem - b.ordem);
  setor4DtAreas.forEach(area => area.formas.sort((a, b) => a.posicao - b.posicao));
  setor4LayoutForms = payload.formas.map(form => form.codigo);
  setor4LayoutCanEdit = Boolean(payload.pode_editar);
  return true;
}

async function loadS4DtLayout() {
  try {
    const cached = JSON.parse(localStorage.getItem(S4_LAYOUT_CACHE_KEY) || "null");
    if (applyS4DtLayout(cached)) renderLiberacaoDual();
  } catch { /* cache ausente */ }
  try {
    const response = await fetch("/unificado/mapa/api/forma-layout?unidade_id=1&setor=4", { credentials: "same-origin", cache: "no-store" });
    if (!response.ok) throw new Error(`Layout HTTP ${response.status}`);
    const payload = await response.json();
    if (applyS4DtLayout(payload)) {
      localStorage.setItem(S4_LAYOUT_CACHE_KEY, JSON.stringify({ areas: payload.areas, formas: payload.formas }));
      renderLiberacaoDual();
    }
  } catch (error) { console.warn("Disposição DT indisponível; exibindo formas sem posição ou último layout carregado.", error); }
}

function createS4DtCard(item, posicao) {
  const table = document.createElement("table");
  table.className = "s4-dt-card";
  const body = table.createTBody();
  const row = createS4TableRow(item, "Setor 4");
  const cell = row.querySelector(".s4-forma-cell");
  const modelo = row.lastElementChild;
  const tipo = item.forma.startsWith("DTBM") ? "DTBM" : item.forma.startsWith("DTD") ? "DTD" : "DTB";
  table.dataset.tipo = tipo;
  cell.textContent = "";
  modelo.hidden = true;
  cell.setAttribute("role", "button");
  cell.tabIndex = 0;
  cell.setAttribute("aria-label", `${item.forma}, posição ${posicao}`);
  cell.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      cell.click();
    }
  });
  const position = document.createElement("span");
  position.className = "s4-dt-position";
  position.textContent = posicao ? `POS. ${String(posicao).padStart(2, "0")}` : "SEM POSIÇÃO";
  const code = document.createElement("strong");
  code.className = "s4-dt-code";
  code.textContent = item.label || item.forma;
  const type = document.createElement("span");
  type.className = "s4-dt-type";
  type.textContent = tipo;
  const status = document.createElement("span");
  status.className = "s4-dt-status";
  const oldRefresh = cell.refreshRow;
  cell.refreshRow = () => {
    oldRefresh();
    status.textContent = cell.classList.contains("is-manutencao") ? "Manutenção"
      : cell.classList.contains("is-saved") ? "Apontada"
      : isFormaLiberada(item.forma, "Setor 4") ? "Liberada"
      : cell.classList.contains("is-programmed") ? "Programada" : "";
    cell.classList.toggle("is-official-pending", status.textContent === "Programada");
  };
  cell.append(position, code, type, status);
  const plannedModel = getProductionProgrammedModel(item.forma, "Setor 4");
  if (plannedModel) {
    const planned = document.createElement("span");
    planned.className = "s4-dt-planned-model";
    planned.textContent = "PCP: " + plannedModel;
    cell.appendChild(planned);
  }
  body.appendChild(row);
  cell.refreshRow();
  return table;
}

function renderS4DtArea(nome, items) {
  const area = document.createElement("section");
  area.className = "s4-dt-area";
  const title = document.createElement("h3");
  title.textContent = nome;
  const cards = document.createElement("div");
  cards.className = "s4-dt-cards";
  items.forEach(({ item, posicao }) => cards.appendChild(createS4DtCard(item, posicao)));
  area.append(title, cards);
  return area;
}

function openS4LayoutEditor() {
  if (!setor4LayoutCanEdit || !setor4DtAreas) return;
  const areas = setor4DtAreas.map(area => ({ nome: area.nome, formas: area.formas.map(item => item.codigo) }));
  const assigned = new Set(areas.flatMap(area => area.formas));
  const unplaced = setor4LayoutForms.filter(code => !assigned.has(code));
  const dialog = document.createElement("dialog");
  dialog.className = "s4-layout-editor";
  const heading = document.createElement("h2");
  heading.textContent = "Cadastro da disposição DT";
  const help = document.createElement("p");
  help.textContent = "A ordem de cada lista é a ordem física da esquerda para a direita. Formas sem posição continuam visíveis no apontamento.";
  const content = document.createElement("div");
  const actions = document.createElement("div");
  actions.className = "s4-editor-actions";
  const addArea = document.createElement("button");
  addArea.type = "button";
  addArea.textContent = "Criar área";
  const cancel = document.createElement("button");
  cancel.type = "button";
  cancel.textContent = "Cancelar";
  const save = document.createElement("button");
  save.type = "button";
  save.textContent = "Salvar disposição";
  const feedback = document.createElement("p");
  feedback.setAttribute("role", "status");

  function move(code, destination, before = null) {
    areas.forEach(area => { area.formas = area.formas.filter(value => value !== code); });
    const oldIndex = unplaced.indexOf(code);
    if (oldIndex >= 0) unplaced.splice(oldIndex, 1);
    if (destination === "") unplaced.push(code);
    else {
      const target = areas.find(area => area.nome === destination);
      if (!target) return;
      const beforeIndex = before ? target.formas.indexOf(before) : -1;
      target.formas.splice(beforeIndex < 0 ? target.formas.length : beforeIndex, 0, code);
    }
    draw();
  }

  function draw() {
    content.replaceChildren();
    [...areas, { nome: "Sem posição definida", formas: unplaced, unplaced: true }].forEach(area => {
      const section = document.createElement("section");
      const title = document.createElement("h3");
      title.textContent = area.nome;
      section.appendChild(title);
      area.formas.forEach((code, index) => {
        const row = document.createElement("div");
        row.className = "s4-editor-row";
        row.draggable = true;
        row.addEventListener("dragstart", event => event.dataTransfer.setData("text/plain", code));
        row.addEventListener("dragover", event => event.preventDefault());
        row.addEventListener("drop", event => {
          event.preventDefault();
          const dragged = event.dataTransfer.getData("text/plain");
          if (setor4LayoutForms.includes(dragged) && dragged !== code) move(dragged, area.unplaced ? "" : area.nome, code);
        });
        const label = document.createElement("strong");
        label.textContent = `${area.unplaced ? "—" : index + 1} · ${code}`;
        const up = document.createElement("button");
        up.type = "button";
        up.textContent = "↑";
        up.title = "Subir";
        up.disabled = index === 0;
        up.addEventListener("click", () => { [area.formas[index - 1], area.formas[index]] = [area.formas[index], area.formas[index - 1]]; draw(); });
        const down = document.createElement("button");
        down.type = "button";
        down.textContent = "↓";
        down.title = "Descer";
        down.disabled = index === area.formas.length - 1;
        down.addEventListener("click", () => { [area.formas[index + 1], area.formas[index]] = [area.formas[index], area.formas[index + 1]]; draw(); });
        const target = document.createElement("select");
        target.setAttribute("aria-label", `Mover ${code} para`);
        [...areas.map(item => item.nome), ""].forEach(name => {
          const option = document.createElement("option");
          option.value = name;
          option.textContent = name || "Sem posição";
          target.appendChild(option);
        });
        target.value = area.unplaced ? "" : area.nome;
        target.addEventListener("change", () => move(code, target.value));
        row.append(label, up, down, target);
        section.appendChild(row);
      });
      content.appendChild(section);
    });
  }

  addArea.addEventListener("click", () => {
    const name = window.prompt("Nome da nova área:")?.trim();
    if (!name) return;
    if (areas.some(area => area.nome.toLowerCase() === name.toLowerCase())) {
      feedback.textContent = "Esta área já existe.";
      return;
    }
    areas.push({ nome: name, formas: [] });
    draw();
  });
  cancel.addEventListener("click", () => dialog.close());
  save.addEventListener("click", async () => {
    if (areas.some(area => !area.formas.length)) {
      feedback.textContent = "Mova ao menos uma forma para cada área nova antes de salvar.";
      return;
    }
    save.disabled = true;
    try {
      const response = await fetch("/unificado/mapa/api/forma-layout", {
        method: "PUT", credentials: "same-origin", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ unidade_id: 1, setor: 4, areas })
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.detail || `HTTP ${response.status}`);
      if (applyS4DtLayout(payload)) {
        localStorage.setItem(S4_LAYOUT_CACHE_KEY, JSON.stringify({ areas: payload.areas, formas: payload.formas }));
        dialog.close();
        renderLiberacaoDual();
      }
    } catch (error) { feedback.textContent = `Não foi possível salvar: ${error.message}`; }
    finally { save.disabled = false; }
  });
  actions.append(addArea, cancel, save);
  dialog.append(heading, help, content, feedback, actions);
  dialog.addEventListener("close", () => dialog.remove());
  document.body.appendChild(dialog);
  draw();
  dialog.showModal();
}

function renderSetor4Mapa(container) {
  if (!container) return;
  container.innerHTML = "";
  container.className = "s4-layout-wrapper";

  const setor = "Setor 4";

  // Um único container de grid de 3 colunas
  const grid = document.createElement("div");
  grid.className = "s4-mapa-container";
  grid.style.gridTemplateColumns = "repeat(2, minmax(0, 1fr))";

  // Coluna 1: Copos (Print 1)
  const colCopos = document.createElement("div");
  colCopos.className = "s4-col";

  const wrapCopos = document.createElement("div");
  wrapCopos.className = "s4-table-wrapper";
  const tableCopos = document.createElement("table");
  tableCopos.className = "s4-table";
  tableCopos.innerHTML = `<thead><tr><th>N Forma</th><th>Modelo</th></tr></thead><tbody></tbody>`;
  const bodyCopos = tableCopos.querySelector("tbody");
  SETOR_4_COL2_FORMS.forEach(item => bodyCopos.appendChild(createS4TableRow(item, setor)));
  wrapCopos.appendChild(tableCopos);
  colCopos.appendChild(wrapCopos);
  grid.appendChild(colCopos);

  // Coluna 2: Canaletas (Print 2 e 3)
  const colCanaletas = document.createElement("div");
  colCanaletas.className = "s4-col";

  const wrapCanaletas = document.createElement("div");
  wrapCanaletas.className = "s4-table-wrapper";
  const tableCanaletas = document.createElement("table");
  tableCanaletas.className = "s4-table";
  tableCanaletas.innerHTML = `<thead><tr><th>N Forma</th><th>Modelo</th></tr></thead><tbody></tbody>`;
  const bodyCanaletas = tableCanaletas.querySelector("tbody");
  SETOR_4_COL3_FORMS.forEach(item => {
    if (item.inicioEstoque) {
      const separator = document.createElement("tr");
      separator.className = "s4-stock-heading";
      const heading = document.createElement("th");
      heading.colSpan = 2;
      heading.scope = "colgroup";
      heading.textContent = "ESTOQUE PROVISÓRIO DE POSTES";
      separator.appendChild(heading);
      bodyCanaletas.appendChild(separator);
    }
    bodyCanaletas.appendChild(createS4TableRow(item, setor));
  });
  wrapCanaletas.appendChild(tableCanaletas);
  colCanaletas.appendChild(wrapCanaletas);
  grid.appendChild(colCanaletas);

  container.appendChild(grid);

  const dt = document.createElement("section");
  dt.className = "s4-dt-layout";
  const title = document.createElement("h2");
  title.textContent = "Formas DT · barreiras";
  dt.appendChild(title);
  if (setor4LayoutCanEdit) {
    const edit = document.createElement("button");
    edit.type = "button";
    edit.className = "s4-dt-edit";
    edit.textContent = "Editar disposição";
    edit.addEventListener("click", openS4LayoutEditor);
    dt.appendChild(edit);
  }
  const byForma = new Map(SETOR_4_COL1_FORMS.map(item => [normalizeUpper(item.forma), item]));
  const positioned = new Set();
  (setor4DtAreas || []).forEach(area => {
    const items = area.formas.map(entry => {
      const item = byForma.get(normalizeUpper(entry.codigo));
      if (item) positioned.add(normalizeUpper(entry.codigo));
      return { item, posicao: entry.posicao };
    }).filter(entry => entry.item);
    dt.appendChild(renderS4DtArea(area.nome, items));
  });
  const unplaced = SETOR_4_COL1_FORMS.filter(item => !positioned.has(normalizeUpper(item.forma)));
  if (unplaced.length) {
    dt.appendChild(renderS4DtArea("Sem posição definida", unplaced.map(item => ({ item, posicao: 0 }))));
  }
  container.appendChild(dt);
}

function openModalParada(setor, formaNumero) {
  pendingManutencaoSelection = { setor, formaNumero };
  const titleEl = document.getElementById("mParadaTitle");
  const subEl = document.getElementById("mParadaSub");
  if (titleEl) titleEl.textContent = `Inativar Forma ${formaNumero}`;
  if (subEl) subEl.textContent = `Setor: ${setor} — Registre o motivo da parada`;
  const mot = document.getElementById("mParadaMotivo");
  const aca = document.getElementById("mParadaAcao");
  if (mot) mot.value = "";
  if (aca) aca.value = "";
  document.getElementById("modalManutencaoParada")?.classList.add("modal-visible");
}

function openModalLiberacao(setor, formaNumero, manutencaoRec) {
  pendingManutencaoSelection = { setor, formaNumero };
  const titleEl = document.getElementById("mLiberacaoTitle");
  const subEl = document.getElementById("mLiberacaoSub");
  const infoEl = document.getElementById("mLiberacaoInfo");
  if (titleEl) titleEl.textContent = `Liberar Forma ${formaNumero}`;
  if (subEl) subEl.textContent = `Setor: ${setor} — Retornar para o estado ativo`;
  if (infoEl) {
    infoEl.innerHTML = `
      <div><strong>Parada em:</strong> ${escapeHtml(manutencaoRec.parada_em || "-")} por ${escapeHtml(manutencaoRec.parada_por || "-")}</div>
      <div style="margin-top:2px;"><strong>Motivo:</strong> ${escapeHtml(manutencaoRec.motivo_parada || "-")}</div>
      <div style="margin-top:2px;"><strong>Serviço Solicitado:</strong> ${escapeHtml(manutencaoRec.acao_necessaria || "-")}</div>
    `;
  }
  const obs = document.getElementById("mLiberacaoObs");
  if (obs) obs.value = "";
  document.getElementById("modalManutencaoLiberacao")?.classList.add("modal-visible");
}

function getRelatorioManutencaoFiltros() {
  return {
    status: document.getElementById("rmFiltroStatus")?.value || "TODOS",
    dataInicio: document.getElementById("rmFiltroDataInicio")?.value || "",
    dataFim: document.getElementById("rmFiltroDataFim")?.value || ""
  };
}

function manutencaoRecordMatchesFiltros(item, filtros) {
  if (filtros.status !== "TODOS" && item.status !== filtros.status) return false;
  const updatedAt = item.updated_at ? String(item.updated_at).slice(0, 10) : "";
  if (filtros.dataInicio && updatedAt && updatedAt < filtros.dataInicio) return false;
  if (filtros.dataFim && updatedAt && updatedAt > filtros.dataFim) return false;
  return true;
}

function atualizarIndicadoresManutencaoHub() {
  const counts = { "Setor 1": 0, "Setor 2": 0, "Setor 3": 0, "Setor 4": 0 };
  Object.values(getFormasManutencao()).forEach((item) => {
    if (item.status === "PARADA" && Object.prototype.hasOwnProperty.call(counts, item.setor)) {
      counts[item.setor] += 1;
    }
  });
  const map = {
    manKpiS1: counts["Setor 1"],
    manKpiS2: counts["Setor 2"],
    manKpiS3: counts["Setor 3"],
    manKpiS4: counts["Setor 4"]
  };
  Object.entries(map).forEach(([id, value]) => {
    const node = document.getElementById(id);
    if (node) node.textContent = String(value);
  });
}

function calcularDiasParada(paradaEmStr, liberadaEmStr, status) {
  if (!paradaEmStr) return { dias: 0, label: "-" };

  let dateInicio = null;
  if (paradaEmStr.includes("/")) {
    const parts = paradaEmStr.split(",");
    const dateParts = parts[0].trim().split("/");
    if (dateParts.length === 3) {
      dateInicio = new Date(`${dateParts[2]}-${dateParts[1].padStart(2, "0")}-${dateParts[0].padStart(2, "0")}`);
    }
  }
  if (!dateInicio || isNaN(dateInicio.getTime())) {
    dateInicio = new Date(paradaEmStr);
  }
  if (isNaN(dateInicio.getTime())) return { dias: 0, label: "-" };

  let dateFim = new Date();
  if (status === "LIBERADA" && liberadaEmStr) {
    let dateLib = null;
    if (liberadaEmStr.includes("/")) {
      const parts = liberadaEmStr.split(",");
      const dateParts = parts[0].trim().split("/");
      if (dateParts.length === 3) {
        dateLib = new Date(`${dateParts[2]}-${dateParts[1].padStart(2, "0")}-${dateParts[0].padStart(2, "0")}`);
      }
    }
    if (!dateLib || isNaN(dateLib.getTime())) {
      dateLib = new Date(liberadaEmStr);
    }
    if (dateLib && !isNaN(dateLib.getTime())) {
      dateFim = dateLib;
    }
  }

  const diffMs = Math.max(0, dateFim.getTime() - dateInicio.getTime());
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  let label = "";
  if (diffDays === 0) {
    label = "Hoje (< 1 dia)";
  } else if (diffDays === 1) {
    label = "1 dia";
  } else {
    label = `${diffDays} dias`;
  }
  return { dias: diffDays, label };
}

function renderizarRelatorioManutencao() {
  const tbody = document.getElementById("rmTabelaBody");
  const totalEl = document.getElementById("rmTabelaTotal");
  if (!tbody) return;

  const all = getFormasManutencao();
  const filtros = getRelatorioManutencaoFiltros();
  const list = Object.values(all)
    .filter((item) => manutencaoRecordMatchesFiltros(item, filtros))
    .sort((a, b) => new Date(b.updated_at || 0) - new Date(a.updated_at || 0));

  if (totalEl) totalEl.textContent = list.length;
  atualizarIndicadoresManutencaoHub();

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10" data-visual-print="dae45f31d97e" style="text-align:center;padding:20px;color:var(--c-ink-2);">Nenhuma forma em manutenção registrada até o momento.</td></tr>`;
    return;
  }

  tbody.innerHTML = list.map(item => {
    const isParada = item.status === "PARADA";
    const statusBadge = isParada
      ? `<span data-visual-print="29a6bdfd703e" style="background:var(--c-line-2);color:var(--c-warn);border:1px solid var(--c-orange);padding:4px 10px;border-radius:var(--r);font-weight:800;font-size:0.75rem;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center;gap:4px;"> PARADA</span>`
      : `<span data-visual-print="4323c10286a7" style="background:var(--c-line);color:var(--c-ok);border:1px solid var(--c-ok);padding:4px 10px;border-radius:var(--r);font-weight:800;font-size:0.75rem;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center;gap:4px;">✓ LIBERADA</span>`;

    const tempoInfo = calcularDiasParada(item.parada_em, item.liberada_em, item.status);
    const tempoBadge = isParada
      ? `<span data-visual-print="b0db054702d1" style="background:var(--c-line-2);color:var(--c-crit);border:1px solid var(--c-orange);padding:4px 10px;border-radius:var(--r);font-weight:800;font-size:0.75rem;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center;gap:4px;">⏱ ${tempoInfo.label}</span>`
      : `<span data-visual-print="22ef116f2982" style="background:var(--c-bg);color:var(--c-blue);border:1px solid var(--c-line);padding:4px 10px;border-radius:var(--r);font-weight:700;font-size:0.75rem;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center;gap:4px;"> ${tempoInfo.label}</span>`;

    const acaoBtn = isParada
      ? `<button type="button" class="btn btn-sm btn-liberar-relatorio" data-setor="${escapeHtml(item.setor)}" data-forma="${escapeHtml(item.forma_numero)}" data-visual-print="9d68586654cc" style="background:var(--c-ok);color:var(--c-surface);border:none;padding:6px 12px;font-size:0.78rem;font-weight:800;border-radius:var(--r);cursor:pointer;box-shadow:none;white-space:nowrap;display:inline-flex;align-items:center;gap:4px;"> Liberar</button>`
      : `<button type="button" class="btn btn-sm btn-ver-relatorio" data-setor="${escapeHtml(item.setor)}" data-forma="${escapeHtml(item.forma_numero)}" data-visual-print="f020bfbd0f87" style="background:var(--c-line);color:var(--c-blue);border:none;padding:6px 12px;font-size:0.78rem;font-weight:700;border-radius:var(--r);cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;gap:4px;"> Histórico</button>`;

    return `
      <tr class="rm-tabela-row ${isParada ? 'rm-row-parada' : 'rm-row-liberada'}" data-setor="${escapeHtml(item.setor)}" data-forma="${escapeHtml(item.forma_numero)}" style="cursor:pointer;" title="Clique para ${isParada ? 'liberar esta forma' : 'ver histórico'}">
        <td data-visual-print="274ead937818" style="text-align:center;font-weight:700;color:var(--c-ink-2);">${escapeHtml(item.setor || "-")}</td>
        <td data-visual-print="93fb8e5f9675" style="text-align:center;font-weight:900;color:var(--c-navy);font-size:0.92rem;">${escapeHtml(item.forma_numero || "-")}</td>
        <td style="text-align:center; vertical-align:middle;">${statusBadge}</td>
        <td style="text-align:center; vertical-align:middle;">${tempoBadge}</td>
        <td data-visual-print="e3084c57472f" style="font-size:0.85rem;color:var(--c-navy);">${escapeHtml(item.motivo_parada || "-")}</td>
        <td data-visual-print="e3084c57472f" style="font-size:0.85rem;color:var(--c-navy);">${escapeHtml(item.acao_necessaria || "-")}</td>
        <td data-visual-print="8bd18dba4416" style="font-size:0.8rem;color:var(--c-ink-2);line-height:1.3;">${escapeHtml(item.parada_em || "-")}<br><small data-visual-print="bc143bb9068c" style="color:var(--c-ink-2);font-weight:600;">por ${escapeHtml(item.parada_por || "-")}</small></td>
        <td data-visual-print="8bd18dba4416" style="font-size:0.8rem;color:var(--c-ink-2);line-height:1.3;">${item.liberada_em ? `${escapeHtml(item.liberada_em)}<br><small data-visual-print="bc143bb9068c" style="color:var(--c-ink-2);font-weight:600;">por ${escapeHtml(item.liberada_por || "-")}</small>` : "-"}</td>
        <td data-visual-print="e3084c57472f" style="font-size:0.85rem;color:var(--c-navy);">${escapeHtml(item.obs_liberacao || "-")}</td>
        <td style="text-align:center; vertical-align:middle;">${acaoBtn}</td>
      </tr>
    `;
  }).join("");

  tbody.querySelectorAll(".rm-tabela-row").forEach(row => {
    row.addEventListener("click", () => {
      const setor = row.getAttribute("data-setor");
      const formaNumero = row.getAttribute("data-forma");
      if (!setor || !formaNumero) return;

      const allFormas = getFormasManutencao();
      const manutencaoRec = allFormas[getManutencaoKey(setor, formaNumero)];
      if (manutencaoRec && manutencaoRec.status === "PARADA") {
        openModalLiberacao(setor, formaNumero, manutencaoRec);
      } else if (manutencaoRec) {
        alert(`Forma ${formaNumero} (${setor})\nStatus: LIBERADA em ${manutencaoRec.liberada_em || '-'}\nPor: ${manutencaoRec.liberada_por || '-'}\nObservação: ${manutencaoRec.obs_liberacao || '-'}`);
      }
    });
  });
}

/* =========================================================
   RELATÓRIO DE DEFEITOS & TRATATIVA DE QUALIDADE (A-P)
   ========================================================= */
const TRATATIVA_DEFEITOS_KEY = "mapa_tratativa_defeitos_v1";
let pendingTratativaSelection = null;
let tratativaFonte = null;
let tratativaCarregamento = 0;

function tratativaUsaServidor() {
  return location.pathname.startsWith("/unificado/mapa/operacao/");
}

async function carregarRelatorioTratativaDefeitos() {
  if (!tratativaUsaServidor()) {
    renderizarRelatorioTratativaDefeitos();
    return;
  }
  const requestId = ++tratativaCarregamento;
  const tbody = document.getElementById("tdTabelaBody");
  if (tbody) tbody.innerHTML = '<tr><td colspan="10" style="text-align:center;padding:24px">Carregando ocorrências do servidor...</td></tr>';
  try {
    const query = new URLSearchParams();
    const inicio = document.getElementById("tdFiltroDataInicio")?.value;
    const fim = document.getElementById("tdFiltroDataFim")?.value;
    if (inicio) query.set("inicio", inicio);
    if (fim) query.set("fim", fim);
    const response = await fetch(`/unificado/mapa/api/tratativas-defeitos?${query}`, {
      credentials: "same-origin", cache: "no-store"
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || `HTTP ${response.status}`);
    if (requestId !== tratativaCarregamento) return;
    const existentes = new Set((payload.tratativas || []).map(item => item.id));
    const locais = Object.values(getTratativaDefeitos()).filter(item =>
      item && typeof item.id === "string" && /^INC_(?!DEMO_)/.test(item.id)
      && !existentes.has(item.id) && item.codigo_defeito
      && ["PENDENTE", "EM_ANDAMENTO", "CONCLUIDO"].includes(item.status_tratativa));
    let falhasMigracao = 0;
    for (let i = 0; i < locais.length; i += 10) {
      const resultados = await Promise.allSettled(locais.slice(i, i + 10).map(async item => {
        const res = await fetch("/unificado/mapa/api/tratativas-defeitos", {
          method: "POST", credentials: "same-origin", cache: "no-store",
          headers: { "Content-Type": "application/json" }, body: JSON.stringify(item)
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        payload.tratativas.push(item);
      }));
      falhasMigracao += resultados.filter(result => result.status === "rejected").length;
    }
    if (requestId !== tratativaCarregamento) return;
    tratativaFonte = payload;
    const resumo = document.getElementById("tdFiltroResumo");
    if (resumo) resumo.textContent = "Fonte: montagem e inspeção de defeitos do servidor · tratativas compartilhadas";
    renderizarRelatorioTratativaDefeitos();
    if (falhasMigracao) setSyncStatus("warn", `${falhasMigracao} tratativa(s) deste navegador ainda não foram enviadas ao servidor.`);
  } catch (error) {
    if (requestId !== tratativaCarregamento) return;
    tratativaFonte = null;
    if (tbody) tbody.innerHTML = `<tr><td colspan="10" data-visual-print="bf911734bb71" style="text-align:center;padding:24px;color:var(--c-crit);">${escapeHtml(error.message || "Falha ao carregar ocorrências.")}</td></tr>`;
    setSyncStatus("error", "Tratativa de defeitos: falha ao consultar o servidor.");
  }
}

function getTratativaDefeitos() {
  try {
    const raw = localStorage.getItem(TRATATIVA_DEFEITOS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function salvarTratativaDefeitosObj(obj) {
  try {
    localStorage.setItem(TRATATIVA_DEFEITOS_KEY, JSON.stringify(obj));
  } catch (e) {
    console.error("Erro ao salvar tratativa de defeitos:", e);
  }
}

async function salvarTratativaDefeitoRegistro(record) {
  const all = getTratativaDefeitos();
  const id = record.id || `INC_${record.data_fabricacao || todayYmd()}_${record.setor}_${record.forma_numero}_${record.codigo_defeito}`;
  record.id = id;
  record.updated_at = new Date().toISOString();
  if (tratativaUsaServidor()) {
    const response = await fetch("/unificado/mapa/api/tratativas-defeitos", {
      method: "POST", credentials: "same-origin", cache: "no-store",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify(record)
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || `HTTP ${response.status}`);
    if (tratativaFonte) {
      tratativaFonte.tratativas = (tratativaFonte.tratativas || []).filter(item => item.id !== id);
      tratativaFonte.tratativas.push(record);
    }
  } else {
    all[id] = record;
    salvarTratativaDefeitosObj(all);
  }
  return record;
}

function renderizarRelatorioTratativaDefeitos() {
  const tbody = document.getElementById("tdTabelaBody");
  const totalEl = document.getElementById("tdTabelaTotal");
  if (!tbody) return;

  if (tratativaUsaServidor() && !tratativaFonte) return;
  const savedTratativas = tratativaUsaServidor()
    ? Object.fromEntries((tratativaFonte.tratativas || []).map(item => [item.id, item]))
    : getTratativaDefeitos();
  const dbDataRaw = tratativaUsaServidor() ? [] : (readDb() || []);
  const dbRecords = Array.isArray(dbDataRaw) ? dbDataRaw : (dbDataRaw.records || []);
  const montagemPostes = tratativaUsaServidor()
    ? (tratativaFonte.montagem || []).map(row => ({
        ...row, key: row.id, dataFabricacao: row.data_fabricacao,
        formaNumero: row.forma_numero, finalizadoEm: row.finalizado_em,
        observacoesMontagem: row.observacoes_montagem
      }))
    : Object.values((readMontagemPostesDb() || {}).postes || {});

  const listaOcorrenciasMap = {};

  // 1. Mapear ocorrências dos registros de inspeção (readDb)
  dbRecords.forEach(record => {
    const dataProd = record.dataFabricacao || record.data_fabricacao || todayYmd();
    const setor = record.setor || "Geral";
    const forma = record.formaNumero || record.forma_numero || record.forma || "-";

    (record.inspecoes || []).forEach((ins, idx) => {
      const statusStr = String(ins.status || "").toUpperCase();
      const isDefeito = statusStr === "REPROVADO" || statusStr === "RETRABALHO" || statusStr === "R" || statusStr === "RR" || (Array.isArray(ins.codigos) && ins.codigos.length > 0);
      if (!isDefeito) return;

      const codigosArr = Array.isArray(ins.codigos) && ins.codigos.length > 0
        ? ins.codigos
        : [ins.motivo_recusa || ins.motivoRecusa || "A"];

      codigosArr.forEach(cCode => {
        const codigo = String(cCode || "A").trim().toUpperCase();
        const idKey = `INC_${dataProd}_${setor}_${forma}_${codigo}_${idx}`;
        const infoDefeito = getDefeitoInfo(codigo);
        const tratativaSalva = savedTratativas[idKey] || {};

        listaOcorrenciasMap[idKey] = {
          id: idKey,
          data_fabricacao: dataProd,
          setor: setor,
          forma_numero: forma,
          modelo: record.modelo || "-",
          codigo_defeito: codigo,
          descricao_defeito: infoDefeito.descricao,
          classificacao: infoDefeito.classificacao,
          responsavel_designado: infoDefeito.responsavel,
          responsaveis_lista: infoDefeito.responsaveisLista || [],
          acao_recomendada: infoDefeito.acao,
          status_tratativa: tratativaSalva.status_tratativa || "PENDENTE",
          executado_por: tratativaSalva.executado_por || "",
          acao_realizada: tratativaSalva.acao_realizada || "",
          tratado_em: tratativaSalva.tratado_em || "",
          observacoes_origem: ins.observacoes || record.observacoesMontagem || "",
          updated_at: tratativaSalva.updated_at || ins.timestamp || record.updated_at || new Date().toISOString()
        };
      });
    });
  });

  // 2. Mapear cada reprovacao concluida, incluindo as anteriores ao retrabalho.
  const tratativasMigradas = new Set();
  removerReprovacoesDuplicadasDashboard(montagemPostes).forEach(p => {
    if (!p.finalizadoEm && !p.finalizado_em) return;
    const row = {
      ...p,
      status_montagem: p.statusMontagem || p.status_montagem || p.status,
      motivo_recusa: p.motivoRecusa || p.motivo_recusa || ""
    };
    const ocorrencias = obterOcorrenciasDefeitosRegistradosLinha(row);
    const dataProd = p.dataFabricacao || p.data_fabricacao || "";
    const setor = p.setor || "Setor 3";
    const forma = p.formaNumero || p.forma_numero || "-";
    ocorrencias.forEach(({ codigo, descricao, secao_id, item_id }, index) => {
      const codigoDefeito = String(codigo || "SEM_CODIGO").trim().toUpperCase();
      const legacyId = `INC_MNT_${dataProd}_${setor}_${forma}_${codigoDefeito}`;
      const idKey = `INC_MNT_${encodeURIComponent(String(p.key || p.id || legacyId))}_${index}`;
      const infoDefeito = getDefeitoInfo(codigoDefeito);
      const tratativaSalva = savedTratativas[idKey] || savedTratativas[legacyId] || {};
      if (savedTratativas[legacyId]) tratativasMigradas.add(legacyId);

      listaOcorrenciasMap[idKey] = {
        id: idKey,
        data_fabricacao: dataProd,
        setor,
        forma_numero: forma,
        modelo: p.modelo || "-",
        tipo_concreto: p.tipo_concreto || "",
        vibrado: typeof p.vibrado === "boolean" ? p.vibrado : null,
        montagem_id: p.key || p.id || "",
        foto_secao_id: secao_id || "",
        foto_item_id: item_id || "",
        codigo_defeito: codigoDefeito,
        descricao_defeito: descricao || infoDefeito.descricao,
        classificacao: infoDefeito.classificacao,
        responsavel_designado: infoDefeito.responsavel,
        responsaveis_lista: infoDefeito.responsaveisLista || [],
        acao_recomendada: infoDefeito.acao,
        nome_defeito: tratativaSalva.nome_defeito || "",
        justificativa: tratativaSalva.justificativa || "",
        status_tratativa: tratativaSalva.status_tratativa || "PENDENTE",
        executado_por: tratativaSalva.executado_por || "",
        acao_realizada: tratativaSalva.acao_realizada || "",
        tratado_em: tratativaSalva.tratado_em || "",
        observacoes_origem: p.observacoesMontagem || p.observacoes || "",
        updated_at: tratativaSalva.updated_at || p.updated_at || p.finalizado_em || ""
      };
    });
  });

  // O levantamento de defeitos dos setores 3 e 4 é outra fonte oficial.
  (tratativaFonte?.inspecoes || []).forEach(row => {
    (row.defeitos || []).forEach((defeito, index) => {
      const codigo = String(defeito.codigo || "").trim().toUpperCase();
      if (!codigo) return;
      const quantidade = Math.max(1, Math.min(999, Number.parseInt(defeito.quantidade, 10) || 1));
      for (let numero = 1; numero <= quantidade; numero++) {
        const idKey = `INC_INS_${row.id}_${index}_${numero}`;
        const info = getDefeitoInfo(codigo);
        const salva = savedTratativas[idKey] || {};
        listaOcorrenciasMap[idKey] = {
          id: idKey, data_fabricacao: row.data_desforma, setor: row.setor,
          forma_numero: row.forma_numero, modelo: row.tipo || "-",
          codigo_defeito: codigo, descricao_defeito: info.descricao,
          classificacao: info.classificacao, responsavel_designado: info.responsavel,
          responsaveis_lista: info.responsaveisLista || [], acao_recomendada: info.acao,
          nome_defeito: salva.nome_defeito || "", justificativa: salva.justificativa || "",
          status_tratativa: salva.status_tratativa || "PENDENTE",
          executado_por: salva.executado_por || "", acao_realizada: salva.acao_realizada || "",
          tratado_em: salva.tratado_em || "",
          observacoes_origem: `${defeito.regiao || ""} · ocorrência ${numero}/${quantidade}. ${row.observacoes || ""}`.trim(),
          updated_at: salva.updated_at || row.atualizado_em
        };
      }
    });
  });

  // 3. Mapear tratativas manuais salvas no localStorage
  Object.values(savedTratativas).forEach(item => {
    if (tratativasMigradas.has(item.id)) return;
    if (!listaOcorrenciasMap[item.id]) {
      const infoDefeito = getDefeitoInfo(item.codigo_defeito);
      listaOcorrenciasMap[item.id] = {
        ...item,
        descricao_defeito: item.descricao_defeito || infoDefeito.descricao,
        classificacao: item.classificacao || infoDefeito.classificacao,
        responsavel_designado: item.responsavel_designado || infoDefeito.responsavel,
        responsaveis_lista: item.responsaveis_lista || infoDefeito.responsaveisLista || [],
        acao_recomendada: item.acao_recomendada || infoDefeito.acao
      };
    }
  });

  let list = Object.values(listaOcorrenciasMap);

  // Aplicar filtros da interface
  const fStatus = document.getElementById("tdFiltroStatus")?.value || "TODOS";
  const fCodigo = document.getElementById("tdFiltroCodigo")?.value || "TODOS";
  const fResp = document.getElementById("tdFiltroResponsavel")?.value || "TODOS";
  const fInicio = document.getElementById("tdFiltroDataInicio")?.value || "";
  const fFim = document.getElementById("tdFiltroDataFim")?.value || "";

  list = list.filter(item => {
    if (fStatus !== "TODOS" && item.status_tratativa !== fStatus) return false;
    if (fCodigo !== "TODOS" && item.codigo_defeito !== fCodigo) return false;
    if (fResp !== "TODOS") {
      const respDesignado = String(item.responsavel_designado || "");
      const respExecutado = String(item.executado_por || "");
      const respMatch = respDesignado.includes(fResp) || respExecutado.includes(fResp);
      if (!respMatch) return false;
    }
    if (fInicio && item.data_fabricacao < fInicio) return false;
    if (fFim && item.data_fabricacao > fFim) return false;
    return true;
  });

  list.sort((a, b) => new Date(b.updated_at || 0) - new Date(a.updated_at || 0));

  // KPIs
  const total = list.length;
  const pendentes = list.filter(i => i.status_tratativa === "PENDENTE").length;
  const concluidos = list.filter(i => i.status_tratativa === "CONCLUIDO").length;
  const criticos = list.filter(i => /^CR/i.test(String(i.classificacao || ""))).length;

  if (totalEl) totalEl.textContent = total;
  const kTotal = document.getElementById("tdKpiTotal");
  const kPen = document.getElementById("tdKpiPendentes");
  const kConc = document.getElementById("tdKpiConcluidos");
  const kCrit = document.getElementById("tdKpiCriticos");
  if (kTotal) kTotal.textContent = total;
  if (kPen) kPen.textContent = pendentes;
  if (kConc) kConc.textContent = concluidos;
  if (kCrit) kCrit.textContent = criticos;

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10" data-visual-print="60000301cea1" style="text-align:center;padding:24px;color:var(--c-ink-2);">Nenhuma ocorrência de defeito encontrada para os filtros selecionados.</td></tr>`;
    return;
  }

  tbody.innerHTML = list.map(item => {
    const origem = String(item.id || "").startsWith("INC_INS_") ? "Inspeção de defeitos"
      : String(item.id || "").startsWith("INC_MNT_") ? "Montagem"
      : "Ocorrência manual";
    const isCritico = /^CR/i.test(String(item.classificacao || ""));
    const gravBadge = isCritico
      ? `<span class="td-badge td-badge-critico" data-visual-print="28dd1f86dcce" style="background:var(--c-line-2);color:var(--c-crit);border:1px solid var(--c-orange);padding:4px 8px;border-radius:var(--r);font-weight:800;font-size:0.72rem;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center;gap:3px;max-width:100%;box-sizing:border-box;">● CRÍTICO</span>`
      : `<span class="td-badge td-badge-nao-critico" data-visual-print="312eedaf602d" style="background:var(--c-line-2);color:var(--c-warn);border:1px solid var(--c-orange);padding:4px 8px;border-radius:var(--r);font-weight:700;font-size:0.72rem;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center;gap:3px;max-width:100%;box-sizing:border-box;"> NÃO CRÍTICO</span>`;

    let statusBadge = "";
    if (item.status_tratativa === "CONCLUIDO") {
      statusBadge = `<span class="td-badge td-badge-concluido" data-visual-print="7a588071192a" style="background:var(--c-line);color:var(--c-ok);border:1px solid var(--c-ok);padding:4px 8px;border-radius:var(--r);font-weight:800;font-size:0.72rem;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center;gap:3px;max-width:100%;box-sizing:border-box;">✓ CONCLUÍDO</span>`;
    } else if (item.status_tratativa === "EM_ANDAMENTO") {
      statusBadge = `<span class="td-badge td-badge-andamento" data-visual-print="dfa31b79224c" style="background:var(--c-line);color:var(--c-blue);border:1px solid var(--c-ink-3);padding:4px 8px;border-radius:var(--r);font-weight:800;font-size:0.72rem;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center;gap:3px;max-width:100%;box-sizing:border-box;"> EM ANDAMENTO</span>`;
    } else {
      statusBadge = `<span class="td-badge td-badge-pendente" data-visual-print="28dd1f86dcce" style="background:var(--c-line-2);color:var(--c-crit);border:1px solid var(--c-orange);padding:4px 8px;border-radius:var(--r);font-weight:800;font-size:0.72rem;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center;gap:3px;max-width:100%;box-sizing:border-box;">⏳ PENDENTE</span>`;
    }

    return `
      <tr class="td-tabela-row" data-id="${escapeHtml(item.id)}" style="cursor:pointer;" title="Clique para registrar tratativa / direcionamento">
        <td data-visual-print="a7f62adb0136" style="text-align:center;font-weight:600;font-size:0.8rem;color:var(--c-ink-2);">${escapeHtml(item.data_fabricacao || "-")}</td>
        <td data-visual-print="db728496ad52" style="text-align:center;font-weight:700;color:var(--c-blue);">${escapeHtml(item.setor || "-")}</td>
        <td data-visual-print="93fb8e5f9675" style="text-align:center;font-weight:900;color:var(--c-navy);font-size:0.92rem;">${escapeHtml(item.forma_numero || "-")}</td>
        <td style="text-align:center;"><span data-visual-print="25303a99d324" style="background:var(--c-bg);border:1px solid var(--c-line);padding:2px 8px;border-radius:var(--r-sm);font-weight:900;font-size:0.82rem;color:var(--c-navy);">${escapeHtml(item.codigo_defeito)}</span><br><small data-visual-print="7ffaa642b56a" style="font-weight:600;color:var(--c-ink-2);">${escapeHtml(item.nome_defeito || item.descricao_defeito)}</small><br><small data-visual-print="998aa3df4604" style="color:var(--c-ink-2);">${origem}</small>${item.tipo_concreto ? `<br><small>Concreto: ${escapeHtml(item.tipo_concreto)} · Vibrado: ${item.vibrado === true ? "Sim" : item.vibrado === false ? "Não" : "Não informado"}</small>` : ""}</td>
        <td style="text-align:center; vertical-align:middle;">${gravBadge}</td>
        <td data-visual-print="a03c59c6a461" style="font-weight:800;color:var(--c-blue);"> ${escapeHtml(item.responsavel_designado || "-")}</td>
        <td data-visual-print="4e341b0dbc6a" style="font-size:0.82rem;color:var(--c-blue);">${escapeHtml(item.acao_recomendada || "-")}</td>
        <td data-visual-print="d313a0cfba8a" style="font-size:0.84rem;color:var(--c-navy);">
          ${item.acao_realizada ? `<strong>${escapeHtml(item.acao_realizada)}</strong><br><small data-visual-print="bc143bb9068c" style="color:var(--c-ink-2);font-weight:600;">por ${escapeHtml(item.executado_por || 'Técnico')} em ${escapeHtml(item.tratado_em || '')}</small>` : '<em data-visual-print="9fbb568a76a2" style="color:var(--c-ink-3);">Aguardando direcionamento...</em>'}
        </td>
        <td style="text-align:center; vertical-align:middle;">${statusBadge}</td>
        <td style="text-align:center; vertical-align:middle;">
          <button type="button" class="btn btn-sm btn-tratar-defeito" data-id="${escapeHtml(item.id)}" data-visual-print="3467a0042194" style="background:var(--c-ink-2);color:var(--c-surface);border:none;padding:6px 12px;font-size:0.78rem;font-weight:800;border-radius:var(--r);cursor:pointer;box-shadow:none;white-space:nowrap;"> Tratar</button>
        </td>
      </tr>
    `;
  }).join("");

  tbody.querySelectorAll(".td-tabela-row").forEach(row => {
    row.addEventListener("click", () => {
      const id = row.getAttribute("data-id");
      if (!id || !listaOcorrenciasMap[id]) return;
      openModalTratativaDefeito(listaOcorrenciasMap[id]);
    });
  });
}

function openModalTratativaDefeito(item) {
  pendingTratativaSelection = item;
  const titleEl = document.getElementById("mTratativaTitle");
  const subEl = document.getElementById("mTratativaSub");
  const infoEl = document.getElementById("mTratativaInfo");
  if (titleEl) titleEl.textContent = `Tratativa - Defeito ${item.codigo_defeito}`;
  if (subEl) subEl.textContent = `Forma: ${item.forma_numero} (${item.setor}) — Data: ${item.data_fabricacao}`;

  if (infoEl) {
    infoEl.innerHTML = `
      <div><strong>Defeito:</strong> Código ${escapeHtml(item.codigo_defeito)} - ${escapeHtml(item.descricao_defeito)}</div>
      <div style="margin-top:2px;"><strong>Gravidade:</strong> ${escapeHtml(item.classificacao)}</div>
      <div style="margin-top:2px;"><strong>Responsável Designado:</strong> <span data-visual-print="d7d86efe753d" style="color:var(--c-blue);font-weight:800;"> ${escapeHtml(item.responsavel_designado || "-")}</span></div>
      <div style="margin-top:2px;"><strong>Recomendação Técnica:</strong> ${escapeHtml(item.acao_recomendada || "-")}</div>
      <div style="margin-top:2px;"><strong>Tipo de concreto:</strong> ${escapeHtml(item.tipo_concreto || "Não informado")}</div>
      <div style="margin-top:2px;"><strong>Vibrado:</strong> ${item.vibrado === true ? "Sim" : item.vibrado === false ? "Não" : "Não informado"}</div>
    `;
  }

  const statusSel = document.getElementById("mTratativaStatus");
  const execSel = document.getElementById("mTratativaExecutadoPorSelect");
  const execInput = document.getElementById("mTratativaExecutadoPor");
  const acaoText = document.getElementById("mTratativaAcaoRealizada");

  if (statusSel) statusSel.value = item.status_tratativa || "PENDENTE";

  const defaultResp = item.executado_por || (item.responsaveis_lista?.[0]) || "Alex";
  if (execSel) {
    if (Array.from(execSel.options).some(o => o.value === defaultResp)) {
      execSel.value = defaultResp;
      if (execInput) execInput.classList.add("hidden");
    } else {
      execSel.value = "OUTRO";
      if (execInput) {
        execInput.value = defaultResp;
        execInput.classList.remove("hidden");
      }
    }
  }

  if (acaoText) acaoText.value = item.acao_realizada || "";
  document.getElementById("mTratativaNomeDefeito").value = item.nome_defeito || "";
  document.getElementById("mTratativaJustificativa").value = item.justificativa || "";
  carregarFotosTratativaDefeito(item);

  document.getElementById("modalTratativaDefeito")?.classList.add("modal-visible");
}

async function carregarFotosTratativaDefeito(item) {
  const container = document.getElementById("mTratativaFotos");
  if (!container) return;
  container.replaceChildren();
  const row = (tratativaFonte?.montagem || []).find(entry => entry.id === item.montagem_id)
    || Object.values((readMontagemPostesDb() || {}).postes || {}).find(entry =>
      (entry.key || entry.id) === item.montagem_id);
  let checklists = row?.checklists || {};
  if (typeof checklists === "string") {
    try { checklists = JSON.parse(checklists); } catch { checklists = {}; }
  }
  const fotos = [];
  Object.entries(checklists).forEach(([secao, valores]) => {
    if (!valores || typeof valores !== "object") return;
    Object.entries(valores).forEach(([chave, src]) => {
      if (!chave.endsWith("_photo") || typeof src !== "string" || !src) return;
      fotos.push({
        src,
        label: secao === item.foto_secao_id && chave === `${item.foto_item_id}_photo`
          ? "Foto deste defeito" : `Checklist: ${secao}`,
        destaque: secao === item.foto_secao_id && chave === `${item.foto_item_id}_photo`
      });
    });
  });
  fotos.sort((a, b) => Number(b.destaque) - Number(a.destaque));
  const render = () => {
    if (pendingTratativaSelection !== item) return;
    container.replaceChildren();
    if (!fotos.length) {
      container.textContent = "Nenhuma foto encontrada para esta ocorrência.";
      return;
    }
    fotos.forEach(foto => {
      let src;
      try {
        const remote = new URL(foto.src, location.href);
        const url = remote.pathname.startsWith("/unificado/mapa/api/fotos/")
          ? new URL(remote.pathname + remote.search, location.origin) : remote;
        if (url.origin !== location.origin && url.protocol !== "data:") return;
        if (url.protocol === "data:" && !/^data:image\//i.test(foto.src)) return;
        src = url.href;
      } catch { return; }
      const card = document.createElement("button");
      card.type = "button";
      card.style.cssText = "border:1px solid var(--c-line);border-radius:var(--r);background:var(--c-surface);padding:6px;cursor:pointer;text-align:left;width:150px;";
      const image = document.createElement("img");
      image.src = src;
      image.alt = foto.label;
      image.loading = "lazy";
      image.style.cssText = "width:100%;height:105px;object-fit:cover;border-radius:var(--r);";
      const caption = document.createElement("small");
      caption.textContent = foto.label;
      card.append(image, caption);
      card.addEventListener("click", () => window.abrirFotoVisualizacao(src));
      container.appendChild(card);
    });
  };
  render();
  if (!item.montagem_id) return;
  const backendUrl = tratativaUsaServidor() ? "/unificado/mapa/api" : getBackendUrl();
  try {
    const response = await fetch(`${backendUrl}/inspecoes/${encodeURIComponent(item.montagem_id)}/fotos`, {
      credentials: "same-origin", cache: "no-store"
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const payload = await response.json();
    (Array.isArray(payload.data) ? payload.data : []).forEach(photo => {
      if (photo.url) fotos.push({ src: photo.url, label: photo.arquivo_nome || "Foto da inspeção" });
    });
    render();
  } catch (error) {
    if (pendingTratativaSelection === item && !fotos.length) {
      container.textContent = `Não foi possível carregar as fotos: ${error.message}`;
    }
  }
}

function updateKioskHeader() {
  if (!el.kioskSectorTitle || !el.kioskSectorSubtitle || !el.kioskLibData || !el.kioskLibColaborador) return;

  let sectorLabel = "";
  if (state.activeLiberacaoSector === "LIBERACAO_S1") sectorLabel = "Setor 1";
  else if (state.activeLiberacaoSector === "LIBERACAO_S2") sectorLabel = "Setor 2";
  else if (state.activeLiberacaoSector === "LIBERACAO_S3") sectorLabel = "Setor 3";
  else if (state.activeLiberacaoSector === "LIBERACAO_S4") sectorLabel = "Setor 4";

  el.kioskSectorTitle.textContent = "Produção " + sectorLabel;
  el.kioskSectorSubtitle.textContent = "ÁREA OPERACIONAL QUIOSQUE";

  el.kioskLibData.value = el.libData?.value || todayYmd();
  el.kioskLibColaborador.value = el.libColaborador?.value || "";

  if (el.kioskProgCheckbox) {
    el.kioskProgCheckbox.checked = state.programmingMode || false;
    const toggleField = document.getElementById("kioskProgToggleField");
    if (toggleField) {
      toggleField.classList.toggle("active", state.programmingMode || false);
    }
  }

  const kioskManutencaoToggleField = document.getElementById("kioskManutencaoToggleField");
  if (kioskManutencaoToggleField) {
    const isAuth = isManutencaoAuthorizedUser();
    kioskManutencaoToggleField.classList.toggle("hidden", !isAuth);
  }
  if (el.kioskManutencaoCheckbox) {
    el.kioskManutencaoCheckbox.checked = state.manutencaoMode || false;
    if (kioskManutencaoToggleField) {
      kioskManutencaoToggleField.classList.toggle("active", state.manutencaoMode || false);
    }
  }

  updateKioskProgress();
}

function updateKioskProgress() {
  if (!el.kioskProgressoContador) return;

  let sectorLabel = "";
  let listAll = [];
  if (state.activeLiberacaoSector === "LIBERACAO_S1") {
    sectorLabel = "Setor 1";
    listAll = SETOR_1_LEFT_FORMS.concat(SETOR_1_RIGHT_FORMS);
  } else if (state.activeLiberacaoSector === "LIBERACAO_S2") {
    sectorLabel = "Setor 2";
    listAll = SETOR_2_LEFT_FORMS.concat(SETOR_2_RIGHT_FORMS);
  } else if (state.activeLiberacaoSector === "LIBERACAO_S3") {
    sectorLabel = "Setor 3";
    listAll = SETOR_3_LEFT_FORMS.concat(SETOR_3_RIGHT_FORMS);
  } else if (state.activeLiberacaoSector === "LIBERACAO_S4") {
    sectorLabel = "Setor 4";
    listAll = SETOR_4_COL1_FORMS.concat(SETOR_4_COL2_FORMS).concat(SETOR_4_COL3_FORMS);
  } else {
    return;
  }

  const clicked = getClickedFormsToday();
  const formas = clicked.formas || {};

  let concretados = 0;
  listAll.forEach((item) => {
    if (formas[sectorLabel + "||" + normalizeUpper(item.forma)]) {
      concretados++;
    }
  });

  el.kioskProgressoContador.textContent = `${concretados} / ${listAll.length}`;
}

function readLocalProgramacao() {
  const raw = localStorage.getItem("mapa_concretagem_programacao");
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function writeLocalProgramacao(list) {
  localStorage.setItem("mapa_concretagem_programacao", JSON.stringify(list));
}

async function programFormaInApiOrLocal(data, setor, forma) {
  let synced = false;
  if (hasApiConfigured()) {
    try {
      const payload = {
        dia: new Date().toLocaleDateString("pt-BR"),
        hora: new Date().toLocaleTimeString("pt-BR"),
        setor,
        forma,
        dataFabricacao: data,
        colaborador: state.authUser?.name || "Programador",
        modelo: "",
        tipo_concreto: "Padrão",
        status: "PROGRAMADA"
      };
      const result = await postToApi("salvar_forma_click", payload);
      synced = !!result.ok;
    } catch (err) {
      console.warn("Falha ao salvar programação no servidor, usando local:", err);
    }
  }

  const list = readLocalProgramacao();
  const exists = list.some(item => item.data_fabricacao === data && item.setor === setor && item.forma === forma);
  if (!exists) {
    list.push({ data_fabricacao: data, setor, forma });
    writeLocalProgramacao(list);
  }

  if (synced) {
    setSyncStatus("ok", `Programação da forma ${forma} sincronizada.`);
  } else {
    setSyncStatus("warn", "Programação salva localmente.");
  }
}

async function unprogramFormaInApiOrLocal(data, setor, forma) {
  let synced = false;
  if (hasApiConfigured()) {
    try {
      const { error } = await supabaseClient.from('programacao_pcp').delete()
        .eq('data_fabricacao', data)
        .eq('setor', setor)
        .eq('forma', forma);
      if (!error) synced = true;
    } catch (err) {
      console.warn("Falha ao excluir programação no servidor, usando local:", err);
    }
  }

  const list = readLocalProgramacao();
  const filtered = list.filter(item => !(item.data_fabricacao === data && item.setor === setor && item.forma === forma));
  writeLocalProgramacao(filtered);

  if (synced) {
    setSyncStatus("ok", `Programação da forma ${forma} excluída online.`);
  } else {
    setSyncStatus("warn", "Programação excluída localmente.");
  }
}

async function toggleFormaProgramada(forma, setor, card) {
  const data = el.libData?.value || todayYmd();
  if (!data) {
    showLibFeedback("Preencha a data antes de programar.", "error");
    return;
  }

  const normalized = normalizeUpper(forma);
  const isCurrentlyProgrammed = state.programmedFormas.has(normalized);

  if (isCurrentlyProgrammed) {
    state.programmedFormas.delete(normalized);
    card.classList.remove("is-programmed");
    await unprogramFormaInApiOrLocal(data, setor, normalized);
    showLibFeedback(`Forma ${forma} desprogramada.`, "ok");
  } else {
    const ordered = getOperationalFormsForSector(setor);
    const selected = ordered.find((item) => normalizeUpper(item.forma) === normalized);
    const selectedProduct = normalizeUpper(withPosteData(selected, setor).codigoProduto);
    const selectedGroup = selectedProduct || normalizeUpper(selected?.modelo);
    const nearest = selectedGroup && ordered.find((item) => {
      const product = normalizeUpper(withPosteData(item, setor).codigoProduto);
      const group = product || normalizeUpper(item.modelo);
      return group === selectedGroup && !state.programmedFormas.has(normalizeUpper(item.forma))
        && !isFormaEmManutencao(setor, item.forma);
    });
    if (nearest && normalizeUpper(nearest.forma) !== normalized) {
      showLibFeedback(`Programe primeiro a forma ${nearest.forma}, mais próxima da monovia para este produto.`, "error");
      return;
    }
    state.programmedFormas.add(normalized);
    card.classList.add("is-programmed");
    await programFormaInApiOrLocal(data, setor, normalized);
    showLibFeedback(`Forma ${forma} programada!`, "ok");
  }

  updateKioskProgress();
}

async function fetchFormStatusRowsFromTables(data) {
  const [progRes, libRes, prodRes] = await Promise.all([
    supabaseClient.from('programacao_pcp').select('*').eq('data_fabricacao', data),
    supabaseClient.from('liberacao_formas').select('*').eq('data_fabricacao', data),
    supabaseClient.from('producao').select('*').eq('data_fabricacao', data)
  ]);

  const firstError = [progRes.error, libRes.error, prodRes.error].find(Boolean);
  if (firstError) throw firstError;

  const rowsByKey = new Map();
  const ensureRow = (setor, forma) => {
    const key = `${setor}||${normalizeUpper(forma)}`;
    if (!rowsByKey.has(key)) rowsByKey.set(key, { setor, forma: normalizeUpper(forma) });
    return rowsByKey.get(key);
  };

  (progRes.data || []).forEach((row) => {
    if (!row.setor || !row.forma) return;
    Object.assign(ensureRow(row.setor, row.forma), {
      prog_id: row.id || true,
      prog_data_hora: row.data_hora || row.created_at || null
    });
  });

  (libRes.data || []).forEach((row) => {
    if (!row.setor || !row.forma) return;
    Object.assign(ensureRow(row.setor, row.forma), {
      lib_id: row.id || true,
      lib_colaborador: row.colaborador || "",
      lib_data_hora: row.data_hora || row.created_at || null
    });
  });

  (prodRes.data || [])
    .filter((row) => row.status === "LIBERADO" || row.status === "CONCRETADO" || row.tipo_concreto)
    .forEach((row) => {
      if (!row.setor || !row.forma) return;
      Object.assign(ensureRow(row.setor, row.forma), {
        prod_id: row.id || true,
        prod_tipo_concreto: row.tipo_concreto || "Padrão",
        prod_modelo: row.modelo || "",
        prod_codigo_produto: row.codigo_produto || "",
        prod_descricao_poste: row.descricao_poste || "",
        prod_vibrado: row.vibrado ?? null,
        prod_colaborador: row.colaborador || "",
        prod_data_hora: row.data_hora || row.created_at || null
      });
    });

  return Array.from(rowsByKey.values());
}

async function loadClickedFormsFromSupabase(dateOverride) {
  const data = dateOverride || el.libData?.value || todayYmd();
  if (!hasApiConfigured()) return;

  try {
    // Busca todas as concretagens feitas na data selecionada a partir da View unificada
    const { data: statusRows, error } = await supabaseClient.from('vw_formas_status')
      .select('*')
      .eq('data_fabricacao', data);

    let rows = error ? await fetchFormStatusRowsFromTables(data) : statusRows;
    if (!Array.isArray(rows)) rows = [];
    if (!rows.length) rows = await fetchFormStatusRowsFromTables(data);
    if (Array.isArray(rows)) {
      const clicked = getClickedFormsToday();
      // Limpa os registros locais de clique para re-popular com os dados atualizados em nuvem
      clicked.formas = {};
      clicked.dia = new Date().toLocaleDateString("pt-BR");

      const db = readDb();
      let dbUpdated = false;

      rows.forEach(row => {
        if (row.forma && row.setor) {
          let statusVal = 'L';
          let tipoConcreto = 'Padrão';
          let colaborador = row.lib_colaborador || '';
          let dataHora = row.lib_data_hora || nowIso();
          const hasVibradoFromRow = Object.prototype.hasOwnProperty.call(row, "prod_vibrado")
            || Object.prototype.hasOwnProperty.call(row, "vibrado");
          let vibrado = hasVibradoFromRow ? (row.prod_vibrado ?? row.vibrado ?? null) : undefined;

          if (row.prod_id) {
            statusVal = '1';
            tipoConcreto = row.prod_tipo_concreto || 'Padrão';
            colaborador = row.prod_colaborador || '';
            dataHora = row.prod_data_hora || nowIso();
          } else if (row.lib_id) {
            statusVal = 'L';
            tipoConcreto = 'Padrão';
            colaborador = row.lib_colaborador || row.prod_colaborador || '';
            dataHora = row.lib_data_hora || row.prod_data_hora || nowIso();
          } else if (row.prog_id) {
            statusVal = 'P';
            tipoConcreto = 'Padrão';
            colaborador = '';
            dataHora = row.prog_data_hora || nowIso();
          } else {
            return;
          }

          const modeloBanco = row.prod_id ? (row.prod_modelo || "") : (row.prog_modelo || "");
          const codigoProdutoBanco = row.prod_id ? (row.prod_codigo_produto || "") : (row.prog_codigo_produto || "");
          const descricaoPosteBanco = row.prod_id ? (row.prod_descricao_poste || "") : (row.prog_descricao_poste || "");
          const key = row.setor + "||" + normalizeUpper(row.forma);
          clicked.formas[key] = statusVal;

          // Sincroniza no banco local para que a exibição do tipo de concreto e status seja fiel
          let record = findRecordByKey(db, data, row.setor, normalizeUpper(row.forma));
          if (!record) {
            record = {
              id: uuid(),
              dataFabricacao: data,
              setor: row.setor,
              formaNumero: normalizeUpper(row.forma),
              concretoTipo: tipoConcreto,
              modelo: modeloBanco,
              codigoProduto: codigoProdutoBanco,
              descricaoPoste: descricaoPosteBanco,
              vibrado: vibrado ?? null,
              createdAt: nowIso(),
              updatedAt: nowIso(),
              liberacao: { status: statusVal, timestamp: dataHora, colaborador: colaborador },
              inspecoes: []
            };
            upsertRecord(db, record);
            dbUpdated = true;
          } else if (!record.liberacao || record.liberacao.status !== statusVal || record.concretoTipo !== tipoConcreto || (hasVibradoFromRow && record.vibrado !== vibrado) ||
            (modeloBanco && record.modelo !== modeloBanco) ||
            record.codigoProduto !== codigoProdutoBanco || record.descricaoPoste !== descricaoPosteBanco) {
            record.concretoTipo = tipoConcreto;
            if (modeloBanco) record.modelo = modeloBanco;
            record.codigoProduto = codigoProdutoBanco;
            record.descricaoPoste = descricaoPosteBanco;
            if (hasVibradoFromRow) record.vibrado = vibrado;
            record.liberacao = record.liberacao || { status: statusVal, timestamp: nowIso() };
            record.liberacao.status = statusVal;
            record.liberacao.timestamp = dataHora;
            record.liberacao.colaborador = colaborador;
            record.updatedAt = nowIso();
            upsertRecord(db, record);
            dbUpdated = true;
          }
        }
      });

      if (dbUpdated) {
        writeDb(db);
      }

      // Re-aplica os cliques pendentes locais que ainda não foram sincronizados para a nuvem
      const pendingEvents = (db.events || []).filter(ev => ev.pendingSync === true && ev.etapa === "LIBERACAO" && ev.dataFabricacao === data);
      pendingEvents.forEach(ev => {
        const key = ev.setor + "||" + normalizeUpper(ev.formaNumero);
        clicked.formas[key] = (ev.status === "1" || ev.status === "CONCRETADO") ? "1" : ((ev.status === "PROGRAMADA" || ev.status === "P") ? "P" : "L");
      });

      localStorage.setItem(CLICKED_FORMS_KEY, JSON.stringify(clicked));
    }
  } catch (err) {
    console.warn("Erro ao buscar concretagens do servidor:", err);
  }
}

function getOperationalFormsForSector(setor) {
  const groups = SECTOR_FORMS[setor] || {};
  const lanes = (groups.left || groups.right)
    ? [groups.left || [], groups.right || []]
    : [groups.col1 || [], groups.col2 || [], groups.col3 || []];
  const ordered = [];
  const depth = Math.max(0, ...lanes.map((lane) => lane.length));
  for (let position = 0; position < depth; position++) {
    for (const lane of lanes) {
      if (lane[position]) ordered.push(lane[position]);
    }
  }
  return ordered;
}

function resolveOfficialProgrammedFormas(rows, setor) {
  const operationalForms = getOperationalFormsForSector(setor);
  const operationalFormsWithProducts = operationalForms.map((item) => withPosteData(item, setor));
  const visibleForms = new Set(operationalForms.map((item) => normalizeUpper(item.forma)));
  const visibleProductCodes = new Set(operationalFormsWithProducts.map((item) => normalizeUpper(item.codigoProduto)).filter(Boolean));
  const programmed = new Set();
  const remainingByProduct = new Map();

  (Array.isArray(rows) ? rows : []).forEach((row) => {
    const quantidade = Math.max(0, Number.parseInt(row.quantidade_programada, 10) || 0);
    if (!quantidade) return;

    const forma = normalizeUpper(row.codigo_forma || row.forma);
    if (forma) {
      if (visibleForms.has(forma)) programmed.add(forma);
      return;
    }

    const produtoCodigo = normalizeUpper(row.produto?.codigo || row.produto_codigo || row.codigo);
    if (!produtoCodigo || !visibleProductCodes.has(produtoCodigo)) return;
    remainingByProduct.set(produtoCodigo, (remainingByProduct.get(produtoCodigo) || 0) + quantidade);
  });

  operationalFormsWithProducts.forEach((item) => {
    const produtoCodigo = normalizeUpper(item.codigoProduto);
    const restante = remainingByProduct.get(produtoCodigo) || 0;
    if (!produtoCodigo || restante <= 0 || programmed.has(normalizeUpper(item.forma))) return;
    programmed.add(normalizeUpper(item.forma));
    remainingByProduct.set(produtoCodigo, restante - 1);
  });

  remainingByProduct.forEach((restante, produtoCodigo) => {
    if (restante > 0) {
      console.warn(`[programacao PCP] Produto ${produtoCodigo}: ${restante} unidade(s) sem forma operacional disponível no ${setor}.`);
    }
  });

  return programmed;
}

async function readOfficialFormAssignments(data, setor) {
  const screen = setor === "Setor 3" ? "LIBERACAO_S3" : "LIBERACAO_S4";
  const params = new URLSearchParams({data, setor});
  const response = await fetch(`/unificado/mapa/api/operations/programmed-forms?${params}`, {
    credentials: "same-origin", cache: "no-store", headers: {"X-Unificado-Screen": screen}
  });
  if (!response.ok) throw new Error(`Programação por forma: HTTP ${response.status}`);
  const rows = await response.json();
  if (!Array.isArray(rows)) throw new Error("Resposta de programação inválida");
  return rows;
}

async function loadOfficialProgrammedFormas(data, setor) {
  if (!data || !setor) return new Set();
  if (setor === "Setor 3" || setor === "Setor 4") {
    try {
      const rows = await readOfficialFormAssignments(data, setor);
      state.programmedProductsByForma = new Map(rows.map(row => [normalizeUpper(row.forma_operacional || row.codigo_forma), row.modelo]));
      return resolveOfficialProgrammedFormas(rows.map(row => ({
        codigo_forma: row.forma_operacional || row.codigo_forma, quantidade_programada: 1,
        produto_codigo: row.codigo_produto
      })), setor);
    } catch (err) {
      console.warn(`Programação por forma do ${setor} indisponível:`, err);
      state.programmedProductsByForma = new Map();
      return new Set();
    }
  }
  try {
    const params = new URLSearchParams({data_inicio: data, data_fim: data});
    const response = await fetch(`${PCP_PROGRAMACAO_URL}?${params}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return resolveOfficialProgrammedFormas(await response.json(), setor);
  } catch (err) { console.warn("Programação por produto indisponível:", err); return new Set(); }
}

async function loadProgrammedFormas() {
  const data = el.libData?.value || todayYmd();
  let sectorLabel = "";
  if (state.activeLiberacaoSector === "LIBERACAO_S1") sectorLabel = "Setor 1";
  else if (state.activeLiberacaoSector === "LIBERACAO_S2") sectorLabel = "Setor 2";
  else if (state.activeLiberacaoSector === "LIBERACAO_S3") sectorLabel = "Setor 3";
  else if (state.activeLiberacaoSector === "LIBERACAO_S4") sectorLabel = "Setor 4";

  // Sincroniza as fôrmas concretadas do Supabase antes de renderizar
  await loadClickedFormsFromSupabase();

  if (!sectorLabel) return;

  state.programmedProductsByForma = new Map();
  state.programmedFormas = await loadOfficialProgrammedFormas(data, sectorLabel);
  const officialProgrammedFormas = new Set(state.programmedFormas);
  const formsAlreadyInDb = new Set();

  let loadedFromDb = false;
  if (hasApiConfigured()) {
    try {
      const { data: rows, error } = await supabaseClient.from('programacao_pcp')
        .select('forma')
        .eq('data_fabricacao', data)
        .eq('setor', sectorLabel);
      if (!error && Array.isArray(rows)) {
        rows.forEach(row => {
          if (row.forma) {
            const forma = normalizeUpper(row.forma);
            formsAlreadyInDb.add(forma);
            state.programmedFormas.add(forma);
          }
        });
        loadedFromDb = true;
      }
    } catch (err) {
      console.warn("Erro ao buscar programação do servidor, usando local:", err);
    }
  }

  if (!loadedFromDb) {
    const list = readLocalProgramacao();
    list.filter(item => item.data_fabricacao === data && item.setor === sectorLabel)
      .forEach(item => {
        state.programmedFormas.add(normalizeUpper(item.forma));
      });
  }

  // Load from local DB / cache records that are marked as status 'P'
  const db = readDb();
  if (Array.isArray(db.records)) {
    db.records.forEach(record => {
      if (record.dataFabricacao === data && record.setor === sectorLabel && record.liberacao?.status === 'P') {
        state.programmedFormas.add(normalizeUpper(record.formaNumero));
      }
    });
  }

  // Keep the provisional S3/S4 form marker tied to its live PCP assignment.
  // The product schedule alone does not identify a physical form.
  if (hasApiConfigured() && loadedFromDb && officialProgrammedFormas.size > 0 &&
      !["Setor 3", "Setor 4"].includes(sectorLabel)) {
    for (const forma of officialProgrammedFormas) {
      const isClick = isFormaClicked(forma, sectorLabel);
      const isLib = isFormaLiberada(forma, sectorLabel);
      if (!formsAlreadyInDb.has(forma) && !isClick && !isLib) {
        const payload = {
          dia: new Date().toLocaleDateString("pt-BR"),
          hora: new Date().toLocaleTimeString("pt-BR"),
          setor: sectorLabel,
          forma,
          dataFabricacao: data,
          colaborador: "PCP",
          modelo: state.programmedProductsByForma.get(forma) || "",
          tipo_concreto: "Padrão",
          status: "PROGRAMADA"
        };
        await postToApi("salvar_forma_click", payload);
      }
    }
  }
}

function renderLiberacaoDual() {
  const isAll = state.activeLiberacaoSector === "LIBERACAO";
  const isS1 = isAll || state.activeLiberacaoSector === "LIBERACAO_S1";
  const isS2 = isAll || state.activeLiberacaoSector === "LIBERACAO_S2";
  const isS3 = isAll || state.activeLiberacaoSector === "LIBERACAO_S3";
  const isS4 = isAll || state.activeLiberacaoSector === "LIBERACAO_S4";

  const sec1 = document.querySelector(".lib-sector-1");
  if(sec1) sec1.style.display = isS1 ? "block" : "none";
  const sec2 = document.querySelector(".lib-sector-2");
  if(sec2) sec2.style.display = isS2 ? "block" : "none";
  const sec3 = document.querySelector(".lib-sector-3");
  if(sec3) sec3.style.display = isS3 ? "block" : "none";
  const sec4 = document.querySelector(".lib-setor4-panel");
  if(sec4) sec4.style.display = isS4 ? "block" : "none";

  if (isS1) {
    renderSectorCols(
      document.getElementById("libSetor1Cols"),
      SETOR_1_LEFT_FORMS,
      SETOR_1_RIGHT_FORMS,
      "Setor 1"
    );
  }
  if (isS2) {
    renderSectorCols(
      document.getElementById("libSetor2Cols"),
      SETOR_2_LEFT_FORMS,
      SETOR_2_RIGHT_FORMS,
      "Setor 2"
    );
  }
  if (isS3) {
    renderSectorCols(
      document.getElementById("libSetor3Cols"),
      SETOR_3_LEFT_FORMS,
      SETOR_3_RIGHT_FORMS,
      "Setor 3"
    );
  }
  if (isS4) {
    renderSetor4Mapa(
      document.getElementById("libSetor4Cols")
    );
  }
  updateSectorCounters();
}

function updateSectorCounters() {
  const clicked = getClickedFormsToday();
  const formas = clicked.formas || {};

  const s1All = SETOR_1_LEFT_FORMS.concat(SETOR_1_RIGHT_FORMS);
  const s2All = SETOR_2_LEFT_FORMS.concat(SETOR_2_RIGHT_FORMS);
  const s3All = SETOR_3_LEFT_FORMS.concat(SETOR_3_RIGHT_FORMS);
  const s4All = SETOR_4_COL1_FORMS.concat(SETOR_4_COL2_FORMS).concat(SETOR_4_COL3_FORMS);

  // Setor 1
  let s1P = 0, s1L = 0, s1C = 0;
  s1All.forEach((item) => {
    const val = formas["Setor 1||" + normalizeUpper(item.forma)];
    if (val === "P") s1P++;
    else if (val === "L") s1L++;
    else if (val === true || val === "1") s1C++;
  });

  // Setor 2
  let s2P = 0, s2L = 0, s2C = 0;
  s2All.forEach((item) => {
    const val = formas["Setor 2||" + normalizeUpper(item.forma)];
    if (val === "P") s2P++;
    else if (val === "L") s2L++;
    else if (val === true || val === "1") s2C++;
  });

  // Setor 3
  let s3P = 0, s3L = 0, s3C = 0;
  s3All.forEach((item) => {
    const val = formas["Setor 3||" + normalizeUpper(item.forma)];
    if (val === "P") s3P++;
    else if (val === "L") s3L++;
    else if (val === true || val === "1") s3C++;
    else if (state.activeLiberacaoSector === "LIBERACAO_S3" && state.programmedFormas?.has(normalizeUpper(item.forma))) s3P++;
  });

  // Setor 4
  let s4P = 0, s4L = 0, s4C = 0;
  s4All.forEach((item) => {
    const val = formas["Setor 4||" + normalizeUpper(item.forma)];
    if (val === "P") s4P++;
    else if (val === "L") s4L++;
    else if (val === true || val === "1") s4C++;
    else if (state.activeLiberacaoSector === "LIBERACAO_S4" && state.programmedFormas?.has(normalizeUpper(item.forma))) s4P++;
  });

  const c1 = document.getElementById("libCounterSetor1");
  const c2 = document.getElementById("libCounterSetor2");
  const c3 = document.getElementById("libCounterSetor3");
  const c4 = document.getElementById("libCounterSetor4");

  if (c1) {
    c1.innerHTML = `<span data-visual-print="e5bdd3caac1e" style="color:var(--c-line);">P: ${s1P}</span> | <span data-visual-print="5a76780f3d69" style="color:var(--c-line);">L: ${s1L}</span> | <span data-visual-print="e10ff3402272" style="color:var(--c-ink-3);">C: ${s1C}</span> <span style="opacity:0.75">/ ${s1All.length}</span>`;
    c1.classList.toggle("counter-done", s1C === s1All.length && s1All.length > 0);
  }
  if (c2) {
    c2.innerHTML = `<span data-visual-print="e5bdd3caac1e" style="color:var(--c-line);">P: ${s2P}</span> | <span data-visual-print="5a76780f3d69" style="color:var(--c-line);">L: ${s2L}</span> | <span data-visual-print="e10ff3402272" style="color:var(--c-ink-3);">C: ${s2C}</span> <span style="opacity:0.75">/ ${s2All.length}</span>`;
    c2.classList.toggle("counter-done", s2C === s2All.length && s2All.length > 0);
  }
  if (c3) {
    c3.innerHTML = `<span data-visual-print="e5bdd3caac1e" style="color:var(--c-line);">P: ${s3P}</span> | <span data-visual-print="5a76780f3d69" style="color:var(--c-line);">L: ${s3L}</span> | <span data-visual-print="e10ff3402272" style="color:var(--c-ink-3);">C: ${s3C}</span> <span style="opacity:0.75">/ ${s3All.length}</span>`;
    c3.classList.toggle("counter-done", s3C === s3All.length && s3All.length > 0);
  }
  if (c4) {
    c4.innerHTML = `<span data-visual-print="e5bdd3caac1e" style="color:var(--c-line);">P: ${s4P}</span> | <span data-visual-print="5a76780f3d69" style="color:var(--c-line);">L: ${s4L}</span> | <span data-visual-print="e10ff3402272" style="color:var(--c-ink-3);">C: ${s4C}</span> <span style="opacity:0.75">/ ${s4All.length}</span>`;
    c4.classList.toggle("counter-done", s4C === s4All.length && s4All.length > 0);
  }

  // Atualizar progresso do quiosque também
  updateKioskProgress();
}

async function renderSheetGrid() {
  const setor = el.sheetSetorLabel?.textContent || "Setor 2";
  const forms = await getSectorFormsForLiberacao(setor);
  if (el.sheetLeftBody) renderSheetSide(forms.left, el.sheetLeftBody);
  if (el.sheetRightBody) renderSheetSide(forms.right, el.sheetRightBody);
}

function showLibFeedback(message, type) {
  if (!el.libFeedback) return;
  el.libFeedback.textContent = message;
  el.libFeedback.className = "lib-feedback";
  if (type === "ok") el.libFeedback.classList.add("feedback-ok");
  if (type === "error") el.libFeedback.classList.add("feedback-error");
  el.libFeedback.classList.remove("hidden");
  setTimeout(() => el.libFeedback.classList.add("hidden"), 3000);
}

function closeConcreteTypePopup() {
  if (!el.concretoTipoModal) return;
  el.concretoTipoModal.classList.remove("modal-visible");
  pendingFormaSelection = null;
}

function showConcreteTypePopup(forma, setor, card, modelo) {
  if (!el.concretoTipoModal || !el.concretoTipoOptions || !el.concretoTipoSubtitle || !el.concretoModeloSelect) return;

  pendingFormaSelection = { forma, setor, card, modelo };
  el.concretoTipoSubtitle.textContent = `Forma ${forma} . ${setor}`;
  const modeloDefinidoNoSaque = setor === "Setor 3";
  document.getElementById("concretoModeloField")?.classList.toggle("hidden", modeloDefinidoNoSaque);
  const modelosPermitidos = getProductionModelOptions(forma, setor, modelo);
  const modeloSalvo = getProductionRecordForForma(forma, setor)?.modelo || "";
  const candidatos = [modeloSalvo, getProductionProgrammedModel(forma, setor), modelo];
  const modeloInicial = candidatos.map((value) => modelosPermitidos.find((allowed) => normalizeProductionModelKey(allowed) === normalizeProductionModelKey(value)))
    .find(Boolean) || (modelosPermitidos.length === 1 ? modelosPermitidos[0] : "");
  el.concretoModeloSelect.innerHTML = '<option value="" disabled>Selecione o modelo produzido</option>'
    + modelosPermitidos.map((value) => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join("");
  el.concretoModeloSelect.value = modeloInicial;
  el.concretoModeloFeedback.textContent = "";
  el.concretoModeloSelect.onchange = () => { el.concretoModeloFeedback.textContent = ""; };

  const optionsHtml = [
    {
      tipo: "Concreto Padrão",
      title: "Concreto padrao",
      desc: "Tudo certo",
      icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="16 8 10 14 8 12"></polyline></svg>`,
      className: "concreto-opt-padrao"
    },
    {
      tipo: "Concreto Seco - Vibrado",
      title: "Concreto seco - vibrado",
      desc: "Faltou agua / endureceu",
      icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.92 2.92l18.16 18.16"></path><path d="M8.21 13.79c-.14-.59-.21-1.19-.21-1.79 0-2 1-3.9 3-5.5s3.5-4 4-6.5c.34 1.71 1.25 3.32 2.12 4.67"></path><path d="M18.8 14.8C18.93 15.2 19 15.6 19 16a7 7 0 0 1-12.28 4.6"></path></svg>`,
      className: "concreto-opt-seco"
    },
    {
      tipo: "Concreto Segregado",
      title: "Concreto segregado",
      desc: "Pedra separou e desceu",
      icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="1.5"></circle><circle cx="12" cy="8" r="1.5"></circle><circle cx="8" cy="12" r="1.5"></circle><circle cx="12" cy="12" r="1.5"></circle><circle cx="8" cy="16" r="1.5"></circle><path d="M16 10v10"></path><polyline points="13 17 16 20 19 17"></polyline></svg>`,
      className: "concreto-opt-segregado"
    },
    {
      tipo: "Concreto Exsudado",
      title: "Concreto exsudado",
      desc: "Agua subiu na superficie",
      icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C2 11.1 1 13 1 15a7 7 0 0 0 7 7z"></path><path d="M18 16v-6"></path><polyline points="15 13 18 10 21 13"></polyline></svg>`,
      className: "concreto-opt-exsudado"
    }
  ];

  if (isAutoResponsibleUser()) {
    optionsHtml.push({
      tipo: "Teste Lab.",
      title: "Teste Lab.",
      desc: "Uso exclusivo laboratorio",
      icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 2v7.31"></path><path d="M14 9.3V2"></path><path d="M8.5 2h7"></path><path d="M14 9.3a6.5 6.5 0 1 1-4 0"></path><path d="M6.5 16h11"></path></svg>`,
      className: "concreto-opt-lab"
    });
  }

  el.concretoTipoOptions.innerHTML = optionsHtml.map(opt => `
    <button type="button" class="btn-concreto-rich ${opt.className}" data-tipo="${escapeHtml(opt.tipo)}">
      <div class="btn-concreto-icon">${opt.icon}</div>
      <div class="btn-concreto-text">
        <span class="btn-concreto-title">${opt.title}</span>
        <span class="btn-concreto-desc">${opt.desc}</span>
      </div>
    </button>
  `).join("");

  el.concretoTipoOptions.querySelectorAll(".btn-concreto-rich").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const tipo = String(btn.dataset.tipo || "").trim();
      if (tipo) {
        const modeloProduzido = modeloDefinidoNoSaque ? "SC" : el.concretoModeloSelect.value;
        if (!modeloDefinidoNoSaque && !modelosPermitidos.includes(modeloProduzido)) {
          el.concretoModeloFeedback.textContent = "Selecione um modelo permitido para esta forma.";
          el.concretoModeloSelect.focus();
          return;
        }
        closeConcreteTypePopup();
        const vibrado = await getVibradoValueForConcreteSelection(setor, tipo);
        await salvarFormaClicada(forma, setor, card, modeloProduzido, tipo, vibrado);
      }
    });
  });

  el.concretoTipoModal.classList.add("modal-visible");
}

function isConcretoPadraoTipo(tipo) {
  const normalized = String(tipo || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase();
  return normalized === "CONCRETO PADRAO" || normalized === "PADRAO";
}

async function getVibradoValueForConcreteSelection(setor, concretoTipo) {
  if (setor !== "Setor 3" || !isConcretoPadraoTipo(concretoTipo)) return null;
  return showConcretoVibradoModal();
}

function showConcretoVibradoModal() {
  const modal = el.concretoVibradoModal;
  const simBtn = el.concretoVibradoSimBtn;
  const naoBtn = el.concretoVibradoNaoBtn;
  if (!modal || !simBtn || !naoBtn) return Promise.resolve(false);

  return new Promise((resolve) => {
    const close = (value) => {
      modal.classList.remove("modal-visible");
      simBtn.removeEventListener("click", onSim);
      naoBtn.removeEventListener("click", onNao);
      modal.removeEventListener("click", onOverlay);
      document.removeEventListener("keydown", onKeydown);
      resolve(value);
    };
    const onSim = () => close(true);
    const onNao = () => close(false);
    const onOverlay = (event) => {
      if (event.target === modal) close(false);
    };
    const onKeydown = (event) => {
      if (event.key === "Escape") close(false);
    };

    simBtn.addEventListener("click", onSim);
    naoBtn.addEventListener("click", onNao);
    modal.addEventListener("click", onOverlay);
    document.addEventListener("keydown", onKeydown);
    modal.classList.add("modal-visible");
    simBtn.focus();
  });
}

async function postToApiWithTimeout(action, payload, timeoutMs = 7000) {
  let timeoutId;
  const timeoutResult = new Promise((resolve) => {
    timeoutId = setTimeout(() => {
      resolve({ ok: false, timeout: true, error: "Tempo limite de rede excedido" });
    }, timeoutMs);
  });

  try {
    return await Promise.race([
      postToApi(action, payload),
      timeoutResult
    ]);
  } finally {
    clearTimeout(timeoutId);
  }
}

async function liberarFormaClicada(forma, setor, card, modelo) {
  setCardState(card, "saving");

  const agora = new Date();
  const dia = agora.toLocaleDateString("pt-BR");
  const hora = agora.toLocaleTimeString("pt-BR");
  const dataFabricacao = el.libData?.value || todayYmd();
  const colaborador = getProductionCollaborator();
  const modeloFinal = modelo || card.dataset.modelo || "";
  const posteFields = {
    codigoPoste: card.dataset.codigoPoste || "",
    descricaoPoste: card.dataset.descricaoPoste || "",
    codigoProduto: card.dataset.codigoProduto || ""
  };
  const resolvedPosteFields = posteFields.codigoProduto || posteFields.descricaoPoste
    ? posteFields
    : getPosteFieldsForForma(forma, setor);

  const payload = {
    dia,
    hora,
    setor,
    forma,
    dataFabricacao,
    colaborador,
    modelo: modeloFinal,
    tipo_concreto: "Padrão", // Temporário, até ser concretado de fato
    codigo_poste: resolvedPosteFields.codigoPoste,
    descricao_poste: resolvedPosteFields.descricaoPoste,
    codigo_produto: resolvedPosteFields.codigoProduto,
    status: "LIBERADO"
  };

  const apiResult = await postToApiWithTimeout("salvar_forma_click", payload);

  const isNetworkFailure = !apiResult.ok && !apiResult.skipped;
  if (apiResult.ok || apiResult.skipped || isNetworkFailure) {
    const db = readDb();
    let record = findRecordByKey(db, dataFabricacao, setor, normalizeUpper(forma));
    if (!record) {
      record = {
        id: uuid(),
        dataFabricacao,
        setor,
        formaNumero: normalizeUpper(forma),
        modelo: modeloFinal,
        codigoPoste: resolvedPosteFields.codigoPoste,
        descricaoPoste: resolvedPosteFields.descricaoPoste,
        codigoProduto: resolvedPosteFields.codigoProduto,
        concretoTipo: "Padrão",
        createdAt: nowIso(),
        updatedAt: nowIso(),
        liberacao: null,
        inspecoes: []
      };
    }
    record.codigoPoste = resolvedPosteFields.codigoPoste;
    record.descricaoPoste = resolvedPosteFields.descricaoPoste;
    record.codigoProduto = resolvedPosteFields.codigoProduto;
    if (!record.liberacao || record.liberacao.status !== "L") {
      record.liberacao = { status: "L", colaborador, observacoes: "", fotos: [], timestamp: agora.toISOString(), origem: "LIBERACAO_FORMA" };
      record.updatedAt = nowIso();
    }
    upsertRecord(db, record);
    addEvent(db, {
      id: uuid(),
      recordId: record.id,
      etapa: "LIBERACAO",
      status: "L",
      dataFabricacao: record.dataFabricacao,
      setor: record.setor,
      formaNumero: record.formaNumero,
      codigoPoste: record.codigoPoste || "",
      descricaoPoste: record.descricaoPoste || "",
      codigoProduto: record.codigoProduto || "",
      tipoConcreto: "Padrão",
      colaborador,
      timestamp: record.liberacao?.timestamp || nowIso(),
      fotosCount: 0,
      codigos: [],
      observacoes: "",
      pendingSync: isNetworkFailure
    });
    writeDb(db);
  }

  if (apiResult.ok) {
    markFormaLiberada(forma, setor);
    card.classList.remove("is-saving", "is-idle");
    card.classList.add("is-liberada");
    card.disabled = false;
    const statusEl = card.querySelector(".fc-status");
    if (statusEl) statusEl.textContent = "";
    setSyncStatus("ok", `Forma ${forma} liberada com sucesso.`);
    showLibFeedback(`${forma} — liberada!`, "ok");
  } else if (apiResult.skipped) {
    markFormaLiberada(forma, setor);
    card.classList.remove("is-saving", "is-idle");
    card.classList.add("is-liberada");
    card.disabled = false;
    setSyncStatus("warn", "API não configurada. Forma liberada localmente.");
    showLibFeedback(`${forma} — liberada (local).`, "ok");
  } else {
    markFormaLiberada(forma, setor);
    card.classList.remove("is-saving", "is-idle");
    card.classList.add("is-liberada");
    card.disabled = false;
    setSyncStatus("warn", `Forma ${forma} liberada localmente (sem sinal de rede).`);
    showLibFeedback(`${forma} — liberada (offline)`, "warn");
  }
}

async function salvarFormaClicada(forma, setor, card, modelo, concretoTipo = "Concreto Padrão", vibrado = null) {
  setCardState(card, "saving");

  const agora = new Date();
  const dia = agora.toLocaleDateString("pt-BR");
  const hora = agora.toLocaleTimeString("pt-BR");
  const dataFabricacao = el.libData?.value || todayYmd();
  const colaborador = getProductionCollaborator();
  const modeloFinal = modelo || card.dataset.modelo || "";
  const resolvedPosteFields = setor === "Setor 3"
    ? { codigoPoste: "", descricaoPoste: "", codigoProduto: "" }
    : getProductionPosteFields(forma, setor, modeloFinal, card);

  const payload = {
    dia,
    hora,
    setor,
    forma,
    dataFabricacao,
    colaborador,
    modelo: modeloFinal,
    tipo_concreto: concretoTipo,
    vibrado,
    codigo_poste: resolvedPosteFields.codigoPoste,
    descricao_poste: resolvedPosteFields.descricaoPoste,
    codigo_produto: resolvedPosteFields.codigoProduto
  };

  const apiResult = await postToApiWithTimeout("salvar_forma_click", payload);

  const isNetworkFailure = !apiResult.ok && !apiResult.skipped;
  if (apiResult.ok || apiResult.skipped || isNetworkFailure) {
    const db = readDb();
    let record = findRecordByKey(db, dataFabricacao, setor, normalizeUpper(forma));
    if (!record) {
      record = {
        id: uuid(),
        dataFabricacao,
        setor,
        formaNumero: normalizeUpper(forma),
        modelo: modeloFinal,
        codigoPoste: resolvedPosteFields.codigoPoste,
        descricaoPoste: resolvedPosteFields.descricaoPoste,
        codigoProduto: resolvedPosteFields.codigoProduto,
        concretoTipo,
        vibrado,
        createdAt: nowIso(),
        updatedAt: nowIso(),
        liberacao: null,
        inspecoes: []
      };
    }
    record.concretoTipo = concretoTipo;
    record.vibrado = vibrado;
    record.modelo = modeloFinal;
    record.codigoPoste = resolvedPosteFields.codigoPoste;
    record.descricaoPoste = resolvedPosteFields.descricaoPoste;
    record.codigoProduto = resolvedPosteFields.codigoProduto;
    if (!record.liberacao || record.liberacao.status !== "1") {
      record.liberacao = { status: "1", colaborador, observacoes: "", fotos: [], timestamp: nowIso() };
      record.updatedAt = nowIso();
    }
    upsertRecord(db, record);
    addEvent(db, {
      id: uuid(),
      recordId: record.id,
      etapa: "LIBERACAO",
      status: "1",
      dataFabricacao: record.dataFabricacao,
      setor: record.setor,
      formaNumero: record.formaNumero,
      codigoPoste: record.codigoPoste || "",
      descricaoPoste: record.descricaoPoste || "",
      codigoProduto: record.codigoProduto || "",
      tipoConcreto: concretoTipo,
      vibrado,
      colaborador,
      timestamp: record.liberacao?.timestamp || nowIso(),
      fotosCount: 0,
      codigos: [],
      observacoes: "",
      pendingSync: isNetworkFailure
    });
    writeDb(db);
  }

  if (apiResult.ok) {
    markFormaClicked(forma, setor);
    setCardState(card, "saved");
    updateProductionCardBadge(card, setor, modeloFinal, concretoTipo, vibrado);
    updateSectorCounters();
    setSyncStatus("ok", `Forma ${forma} registrada com sucesso.`);
    showLibFeedback(`${forma} — registrado!`, "ok");
  } else if (apiResult.skipped) {
    markFormaClicked(forma, setor);
    setCardState(card, "saved");
    updateProductionCardBadge(card, setor, modeloFinal, concretoTipo, vibrado);
    updateSectorCounters();
    setSyncStatus("warn", "API não configurada. Forma salva localmente.");
    showLibFeedback(`${forma} — salvo localmente.`, "ok");
  } else {
    // Falha de rede: salva localmente mas marca como pendente de sync
    markFormaClicked(forma, setor);
    setCardState(card, "saved");
    updateProductionCardBadge(card, setor, modeloFinal, concretoTipo, vibrado);
    updateSectorCounters();
    setSyncStatus("warn", `Forma ${forma} salva localmente (sem sinal de rede).`);
    showLibFeedback(`${forma} — salvo localmente (offline)`, "warn");
  }
}

function getInspecaoCodeOptions(selectedCode) {
  const first = '<option value="">Selecione</option>';
  const options = CHECKLIST_INSPECAO_CODIGOS.map((item) => {
    const selected = selectedCode === item.codigo ? "selected" : "";
    return `<option value="${item.codigo}" ${selected}>${item.codigo} — ${item.descricao}</option>`;
  }).join("");
  return first + options;
}

function normalizeForma(s) {
  if (!s) return "";
  s = String(s).trim().toUpperCase();
  s = s.replace(/[\s\-]+/g, '');

  const match = s.match(/^([A-Z]+)0*([0-9]+)$/);
  if (match) {
    const num = match[2];
    const numStr = num.replace(/^0+/, '');
    return match[1] + (numStr || '0');
  }

  const matchNum = s.match(/^0*([0-9]+)$/);
  if (matchNum) {
    const numStr = matchNum[1].replace(/^0+/, '');
    return numStr || '0';
  }

  return s;
}

function withTimeout(promise, timeoutMs, fallbackValue) {
  let timer;
  return Promise.race([
    promise,
    new Promise((resolve) => {
      timer = setTimeout(() => resolve(fallbackValue), timeoutMs);
    })
  ]).finally(() => clearTimeout(timer));
}

async function fetchSetor3Models(filtroData) {
  try {
    const rows = await readOfficialFormAssignments(filtroData, "Setor 3");
    return Object.fromEntries(rows.filter(row => row.modelo).map(row => [normalizeForma(row.forma_operacional || row.codigo_forma), row.modelo]));
  } catch (err) { console.warn("Modelos programados do setor 3 indisponíveis:", err); return {}; }
}

async function fetchPolesForDate(filtroData, setor = "", setoresPadrao = ['Setor 3', 'Setor 4']) {
  if (!hasApiConfigured()) return [];

  try {
    const setoresFiltro = setor ? [setor] : setoresPadrao;
    const shouldLoadModels = setoresFiltro.some(item => item === "Setor 3" || item === "Setor 4");
    const modelsPromise = shouldLoadModels
      ? withTimeout(fetchSetor3Models(filtroData), 2500, {}).catch((err) => {
          console.warn("[fetchPolesForDate] Modelos Setor 3 indisponiveis:", err);
          return {};
        })
      : Promise.resolve({});

    const [formToModelMap, producaoRes, montagemRes] = await Promise.all([
      modelsPromise,
      carregarLinhasSupabaseComCache({
        cacheKey: `montagem-postes:producao:${filtroData}:${setoresFiltro.join(",")}`,
        table: "producao",
        select: DASHBOARD_PRODUCAO_SELECT,
        orderBy: "data_hora",
        orderOptions: { ascending: false },
        applyFilters: query => query
          .eq('data_fabricacao', filtroData)
          .in('setor', setoresFiltro)
      }),
      carregarLinhasSupabaseComCache({
        cacheKey: `montagem-postes:montagem_poste:${filtroData}:${setoresFiltro.join(",")}`,
        table: "montagem_poste",
        select: DASHBOARD_MONTAGEM_SELECT,
        orderBy: "finalizado_em",
        orderOptions: { ascending: false, nullsFirst: false },
        applyFilters: query => query
          .eq('data_fabricacao', filtroData)
          .in('setor', setoresFiltro)
      })
    ]);

    const producaoRows = (producaoRes.rows || []).filter((row) => {
      const status = String(row.status || "").toUpperCase();
      const tipoConcreto = String(row.tipo_concreto || "").trim();
      return status === "LIBERADO" || status === "CONCRETADO" || !!tipoConcreto;
    });
    const montagemRows = montagemRes.rows || [];

    // 3. Deduplicate producaoRows by form name, keeping the latest row
    const formsMap = {};
    (producaoRows || []).forEach(row => {
      const forma = row.forma;
      if (!forma) return;
      if (!formsMap[forma]) {
        formsMap[forma] = [];
      }
      formsMap[forma].push(row);
    });

    const combinedList = [];
    Object.entries(formsMap).forEach(([forma, rows]) => {
      rows.sort((a, b) => new Date(b.data_hora || 0) - new Date(a.data_hora || 0));
      const latestRow = rows[0];

      // Find if there is an inspected status for this form
      const insRecord = (montagemRows || []).find(m => m.forma_numero === forma && m.setor === latestRow.setor && m.etapa === 'INSPECAO');
      const montRecord = (montagemRows || []).find(m => m.forma_numero === forma && m.setor === latestRow.setor && m.etapa !== 'INSPECAO' && !isHistoricoReprovacao(m));

      let modeloFinal = latestRow.modelo || "";
      const normForma = normalizeForma(forma);
      if ((latestRow.setor === "Setor 3" || latestRow.setor === "Setor 4")
        && (!modeloFinal || /^(SC|DTB|DTBM|DTD)$/i.test(modeloFinal))
        && formToModelMap[normForma]) {
        modeloFinal = formToModelMap[normForma];
      }
      if (/^A-?\d+$/i.test(forma)) {
        modeloFinal = "1 CX VR";
      }

      combinedList.push({
        recordId: latestRow.id,
        dataFabricacao: latestRow.data_fabricacao,
        setor: latestRow.setor,
        formaNumero: forma,
        modelo: modeloFinal,
        codigoPoste: latestRow.codigo_poste || "",
        descricaoPoste: latestRow.descricao_poste || "",
        codigoProduto: latestRow.codigo_produto || "",
        colaboradorProducao: latestRow.colaborador || "",
        statusProducao: latestRow.status,
        tipoConcreto: latestRow.tipo_concreto || "",
        inspecao: insRecord ? {
          status: insRecord.status_montagem,
          codigo: insRecord.motivo_recusa || "",
          observacoes: insRecord.observacoes_montagem || "",
          colaborador: insRecord.montador_nome || "",
          timestamp: insRecord.finalizado_em || null,
          raw: insRecord
        } : null,
        montagem: montRecord || null
      });
    });

    combinedList.sort((a, b) => a.formaNumero.localeCompare(b.formaNumero, undefined, { numeric: true, sensitivity: 'base' }));
    return combinedList;
  } catch (err) {
    console.error("[fetchPolesForDate] Erro:", err);
    return [];
  }
}

function filtrarFormasTabela() {
  const texto = (el.insFormaFiltro?.value || "").trim().toUpperCase();
  Array.from(el.insLiberadosBody.querySelectorAll("tr[data-forma-numero]")).forEach((tr) => {
    const forma = (tr.dataset.formaNumero || "").toUpperCase();
    tr.style.display = !texto || forma.includes(texto) ? "" : "none";
  });
}

function showInspecaoModal(counts, syncStatus) {
  const modal = document.getElementById("inspecaoModal");
  const icon = document.getElementById("modalIcon");
  const subtitle = document.getElementById("modalSubtitle");
  const stats = document.getElementById("modalStats");
  const okBtn = document.getElementById("modalOkBtn");
  if (!modal) return;

  const total = (counts.A || 0) + (counts.R || 0) + (counts.RR || 0);

  if (syncStatus === "ok") {
    icon.textContent = "✓";
    subtitle.textContent = "Sincronizado com a planilha com sucesso.";
  } else if (syncStatus === "warn") {
    icon.textContent = "Abrir";
    subtitle.textContent = "Salvo localmente. Configure a API para sincronizar com a planilha.";
  } else {
    icon.textContent = "";
    subtitle.textContent = "Salvo localmente, mas falhou atualização na planilha.";
  }

  const rows = [
    { label: "✓ Aprovados (Liberados)", count: counts.A || 0, cls: "stat-ok" },
    { label: " Retrabalhados", count: counts.RR || 0, cls: "stat-rr" },
    { label: "× Rejeitados", count: counts.R || 0, cls: "stat-r" }
  ];

  stats.innerHTML = rows.map((row) =>
    `<div class="stat-row ${row.cls}">
      <span class="stat-label">${row.label}</span>
      <span class="stat-count">${row.count} poste${row.count !== 1 ? "s" : ""}</span>
    </div>`
  ).join("");

  modal.classList.add("modal-visible");

  const close = () => {
    modal.classList.remove("modal-visible");
    okBtn.removeEventListener("click", close);
    modal.removeEventListener("click", onOverlay);
  };
  const onOverlay = (e) => { if (e.target === modal) close(); };
  okBtn.addEventListener("click", close);
  modal.addEventListener("click", onOverlay);
}

async function renderInspecaoLiberados() {
  state.insInicioLocal = nowIso();
  const filtroData = el.insFiltroData.value || todayYmd();
  const modoCarga = el.insModoCarga?.value || "data";
  const setor = state.activeInsSector || "";

  el.insLiberadosBody.innerHTML = "";
  if (!filtroData) {
    el.insQtdItens.textContent = "0";
    el.insLiberadosBody.innerHTML = '<tr><td colspan="4" class="muted">Selecione a data de produção para carregar os itens liberados.</td></tr>';
    return;
  }

  // Busca dados em tempo real diretamente do Supabase sem cache local
  let poles = await fetchPolesForDate(filtroData, setor);

  // Se o setor não for informado ("Todos"), filtramos estritamente para mostrar apenas Setor 3 e Setor 4
  if (!setor) {
    poles = poles.filter((pole) => pole.setor === "Setor 3" || pole.setor === "Setor 4");
  }

  // Filtra de acordo com modoCarga
  const rows = poles.filter((pole) => {
    if (modoCarga === "pendentes") {
      return !pole.inspecao || !pole.inspecao.timestamp;
    }
    return true;
  });

  rows.sort((a, b) => {
    const valA = String(a.formaNumero || "");
    const valB = String(b.formaNumero || "");
    return valA.localeCompare(valB, undefined, { numeric: true, sensitivity: 'base' });
  });

  const statusFiltro = el.insStatusFiltro?.value || "";
  const displayRows = rows.filter((record) => {
    if (statusFiltro) {
      const isFinalizado = record.inspecao && !!record.inspecao.timestamp;
      const statusVal = record.inspecao?.status || "";
      if (statusFiltro === "PENDENTE") {
        if (isFinalizado) return false;
      } else {
        if (!isFinalizado || statusVal !== statusFiltro) return false;
      }
    }
    return true;
  });

  el.insQtdItens.textContent = String(displayRows.length);

  if (!displayRows.length) {
    el.insLiberadosBody.innerHTML = '<tr><td colspan="4" class="muted">Nenhum poste apontado ou pendente de inspeção para os filtros informados.</td></tr>';
    return;
  }

  displayRows.forEach((record) => {
    const isFinalizado = record.inspecao && !!record.inspecao.timestamp;
    const status = record.inspecao?.status || "";
    const rowClass = isFinalizado ? "row-montado" : "";

    const tr = document.createElement("tr");
    if (rowClass) {
      tr.className = rowClass;
    }
    tr.dataset.recordId = record.recordId;
    tr.dataset.dataFabricacao = record.dataFabricacao;
    tr.dataset.setor = record.setor;
    tr.dataset.formaNumero = record.formaNumero;
    tr.dataset.modelo = record.modelo;
    tr.dataset.codigoPoste = record.codigoPoste || "";
    tr.dataset.descricaoPoste = record.descricaoPoste || "";
    tr.dataset.codigoProduto = record.codigoProduto || "";

    // Armazena o registro de inspecao completo serializado em JSON para uso posterior ao clicar
    tr.dataset.inspecaoRaw = record.inspecao && record.inspecao.raw ? JSON.stringify(record.inspecao.raw) : "";

    let acaoContent = "";
    if (isFinalizado) {
      if (status === "A") {
        acaoContent = `<button type="button" class="btn ins-ver-checklist-btn" data-visual-print="cd129ef7ee48" style="background-color:var(--c-ok);color:white;border:none;font-weight:bold;width:100%;height:38px;border-radius:var(--r);cursor:pointer;">Aprovado (Ver Checklist)</button>`;
      } else if (status === "RR") {
        acaoContent = `<button type="button" class="btn ins-ver-checklist-btn" data-visual-print="480a94bd618c" style="background-color:var(--c-orange);color:white;border:none;font-weight:bold;width:100%;height:38px;border-radius:var(--r);">Aprovado e Retrabalhado · Fotos</button>`;
      } else {
        acaoContent = `<button type="button" class="btn ins-ver-checklist-btn" data-visual-print="acd0fbc07f2f" style="background-color:var(--c-orange);color:white;border:none;font-weight:bold;width:100%;height:38px;border-radius:var(--r);cursor:pointer;">Fotos e 2ª inspeção</button>`;
      }
    } else {
      acaoContent = `<button type="button" class="btn ins-open-btn primary" style="width: 100%; height: 38px; border-radius: 6px;">Inspecionar</button>`;
    }

    // Monta o status/defeito com icone para exibir na lista
    let statusDefeitoHtml = "";
    if (isFinalizado) {
      const insCodigo = record.inspecao?.codigo || "";
      if (status === "A") {
        statusDefeitoHtml = `<span data-visual-print="e83c6a65af52" style="color:var(--c-ok);font-weight:700;font-size:.85rem;">✓ Aprovado</span>`;
      } else if (status === "RR") {
        const iconeDefeito = DEFEITO_ICONES[insCodigo.toUpperCase()] || "\u26a0\ufe0f";
        const descDefeito = insCodigo ? getMotivoRecusaLabel(insCodigo) : "Retrabalho";
        statusDefeitoHtml = `<span data-visual-print="76bcb7420fe0" style="color:var(--c-orange);font-weight:700;font-size:.82rem;">${iconeDefeito} Aprovado e Retrabalhado</span> <span data-visual-print="a0a326241d09" style="font-size:.78rem;color:var(--c-warn);">${descDefeito}</span>`;
      } else if (status === "R") {
        const iconeDefeito = DEFEITO_ICONES[insCodigo.toUpperCase()] || "×";
        const descDefeito = insCodigo ? getMotivoRecusaLabel(insCodigo) : "Reprovado";
        const segregado = record.inspecao?.raw?.checklists?.__segunda_inspecao?.resultado === "SEGREGADO";
        statusDefeitoHtml = `<span data-visual-print="a2cbd607e3d8" style="color:var(--c-crit);font-weight:700;font-size:.82rem;">${iconeDefeito} ${segregado ? "Perda do poste" : "Reprovado · 2ª inspeção pendente"}</span><br><span data-visual-print="0b440914f336" style="font-size:.78rem;color:var(--c-crit);">${descDefeito}</span>`;
      } else {
        statusDefeitoHtml = `<span data-visual-print="f846b07683fd" style="color:var(--c-ink-2);font-size:.82rem;">${status || "—"}</span>`;
      }
    } else {
      statusDefeitoHtml = `<span data-visual-print="dfb55fd140ad" style="color:var(--c-ink-3);font-size:.82rem;">Pendente</span>`;
    }

    tr.innerHTML = `
      <td data-label="N Forma">${record.formaNumero || ""}</td>
      <td data-label="Modelo">${record.modelo || ""}</td>
      <td data-label="Data Prod.">${fmtDate(record.dataFabricacao || "")}</td>
      <td data-label="Status / Defeito" style="max-width:220px;line-height:1.4">${statusDefeitoHtml}</td>
      <td data-label="Ação">${acaoContent}<button type="button" class="btn ins-def-select-btn" style="width:100%;margin-top:6px">Registrar defeitos</button></td>
    `;
    el.insLiberadosBody.appendChild(tr);
  });
  filtrarFormasTabela();
}

function readMontagemPostesDb() {
  const raw = localStorage.getItem(MONTAGEM_POSTES_KEY);
  if (!raw) return { postes: {} };
  try {
    const parsed = JSON.parse(raw);
    return parsed && parsed.postes && typeof parsed.postes === "object" ? parsed : { postes: {} };
  } catch {
    return { postes: {} };
  }
}

function writeMontagemPostesDb(db) {
  try {
    localStorage.setItem(MONTAGEM_POSTES_KEY, JSON.stringify(db));
  } catch (err) {
    if (err?.name !== "QuotaExceededError" && err?.code !== 22 && err?.code !== 1014) throw err;

    // Fotos em Base64 crescem cerca de 33% e podem esgotar rapidamente a cota
    // do localStorage. Elas continuam no estado atual e são sincronizadas no
    // Supabase; o cache local guarda apenas os dados operacionais da montagem.
    const cacheDb = JSON.parse(JSON.stringify(db));
    Object.values(cacheDb.postes || {}).forEach((poste) => {
      Object.values(poste?.checklists || {}).forEach((section) => {
        if (!section || typeof section !== "object" || Array.isArray(section)) return;
        Object.keys(section).forEach((key) => {
          if (key.endsWith("_photo")) delete section[key];
        });
      });
    });
    localStorage.setItem(MONTAGEM_POSTES_KEY, JSON.stringify(cacheDb));
  }
}

function getMontagemPosteKey({ recordId, dataFabricacao, setor, formaNumero }) {
  return [recordId || "", dataFabricacao || "", setor || "", formaNumero || ""].join("||");
}

function getMontagemPosteByKey(key) {
  const db = readMontagemPostesDb();
  return db.postes[key] || null;
}

const ETAPA_HISTORICO_REPROVACAO = "HISTORICO_REPROVACAO";

function isHistoricoReprovacao(row) {
  return String(row?.etapa || "").toUpperCase() === ETAPA_HISTORICO_REPROVACAO;
}

function getHistoricoReprovacaoKey(key, finalizadoEm) {
  return `${key}||${ETAPA_HISTORICO_REPROVACAO}||${finalizadoEm}`;
}

function criarHistoricoReprovacao(poste) {
  if (!poste?.key || !poste?.finalizadoEm) return null;
  const status = String(poste.statusMontagem || "").trim().toUpperCase();
  const checklists = {};
  Object.entries(poste.checklists || {}).forEach(([sectionId, answers]) => {
    if (!answers || typeof answers !== "object" || Array.isArray(answers)) return;
    const rejeitados = Object.fromEntries(Object.entries(answers).filter(([, value]) => value === "nao"));
    if (Object.keys(rejeitados).length) checklists[sectionId] = rejeitados;
  });
  if (!Object.keys(checklists).length && !["R", "RR", "REPROVADO", "RETRABALHO"].includes(status)) return null;
  return {
    ...poste,
    key: getHistoricoReprovacaoKey(poste.key, poste.finalizadoEm),
    etapa: ETAPA_HISTORICO_REPROVACAO,
    checklists,
    pendingSync: true
  };
}

async function registrarHistoricoReprovacao(poste) {
  const historico = criarHistoricoReprovacao(poste);
  if (!historico) return { synced: true };
  upsertMontagemPoste(historico);
  return syncMontagemPosteToApi(historico, ETAPA_HISTORICO_REPROVACAO, { silent: true });
}

function upsertMontagemPoste(entry) {
  const db = readMontagemPostesDb();
  db.postes[entry.key] = entry;
  writeMontagemPostesDb(db);
}

function buildMontagemPostePayload(entry, etapa = "") {
  return {
    banco: "montagem_poste",
    etapa,
    key: entry.key || "",
    recordId: entry.recordId || "",
    dataFabricacao: entry.dataFabricacao || "",
    setor: entry.setor || "",
    formaNumero: entry.formaNumero || "",
    modelo: entry.modelo || "",
    codigoPoste: entry.codigoPoste || "",
    descricaoPoste: entry.descricaoPoste || "",
    codigoProduto: entry.codigoProduto || "",
    statusMontagem: entry.statusMontagem || "",
    motivoRecusa: entry.motivoRecusa || "",
    inicioInspecaoMontagem: entry.inicioInspecaoMontagem || "",
    finalizadoEm: entry.finalizadoEm || "",
    observacoesMontagem: entry.observacoesMontagem || "",
    montadorNome: state.authUser?.name || "",
    checklists: entry.checklists || {}
  };
}

async function syncMontagemPosteToApi(entry, etapa = "", options = {}) {
  const payload = buildMontagemPostePayload(entry, etapa);
  const apiResult = await postToMontagemApiWithTimeout("salvar_montagem_poste", payload);

  if (apiResult.ok) {
    if (!options.silent) setSyncStatus("ok", "Montagem de poste sincronizada com a planilha.");
    // Marcar como sincronizado no local storage
    const db = readMontagemPostesDb();
    if (db.postes[entry.key]) {
      db.postes[entry.key].pendingSync = false;
      writeMontagemPostesDb(db);
    }
    return { ok: true, synced: true };
  }

  if (apiResult.skipped) {
    if (!options.silent) setSyncStatus("warn", "API não configurada. Montagem de poste salva localmente.");
    return { ok: true, synced: false, skipped: true };
  }

  // Falha na rede: marca como pendente de sincronização
  const db = readMontagemPostesDb();
  if (db.postes[entry.key]) {
    db.postes[entry.key].pendingSync = true;
    writeMontagemPostesDb(db);
  }
  if (!options.silent) setSyncStatus("warn", "Montagem salva localmente, mas sem sincronização no momento.");
  return { ok: false, synced: false, error: apiResult.error || "falha de sincronização" };
}

function isChecklistSectionComplete(sectionId, respostas = {}, mode = "MONTAGEM", modelo = "") {
  if (!modelo) {
    modelo = (mode === "INSPECAO" ? state.inspecaoPostesAtual?.modelo : state.montagemPostesAtual?.modelo) || "";
  }
  const sections = mode === "INSPECAO" ? getInspecaoChecklistSections(modelo) : getMontagemChecklistSections(modelo);
  const section = sections.find((s) => s.id === sectionId);
  if (!section) return false;
  return section.itens.every((item) => respostas[sectionId]?.[item.id] === "sim" || respostas[sectionId]?.[item.id] === "nao");
}

function renderMontagemChecklistSections() {
  if (!el.mpChecklistSections || !state.montagemPostesAtual) return;
  const current = state.montagemPostesAtual;
  el.mpChecklistSections.innerHTML = "";

  const sections = getMontagemChecklistSections(current.modelo || "");
  let sectionEnabled = true;

  sections.forEach((section) => {
    const article = document.createElement("article");
    article.className = "mp-checklist-section";
    if (!sectionEnabled) {
      article.style.opacity = "0.5";
      article.style.pointerEvents = "none";
    }

    const isComplete = isChecklistSectionComplete(section.id, current.checklists || {});

    const sectionHeader = document.createElement("div");
    sectionHeader.className = "mp-checklist-header";
    sectionHeader.innerHTML = `
      <strong>${section.titulo}</strong>
      <span class="mp-checklist-flag ${isComplete ? "ok" : "pendente"}">${isComplete ? "OK" : "Pendente"}</span>
    `;
    article.appendChild(sectionHeader);

    section.itens.forEach((item) => {
      const selected = current.checklists?.[section.id]?.[item.id] || "";
      const photoBase64 = current.checklists?.[section.id]?.[item.id + "_photo"] || "";
      const isFinalizado = !!current.finalizadoEm;

      const disableItem = isFinalizado || !sectionEnabled;

      const itemWrapper = document.createElement("div");
      itemWrapper.className = "mp-checklist-item-wrapper";

      let itemHtml = `
        <div class="mp-checklist-item">
          <span class="mp-checklist-item-text">
            ${item.critico ? '<span class="critico-dot" data-visual-print="cdd1b94371e6" style="color:var(--c-orange);">●</span>' : ''}
            ${item.texto}
          </span>
          <div class="mp-yn-group">
            <button type="button" class="mp-yn-btn btn-aprovado ${selected === "sim" ? "active" : ""}"
                    data-mp-section="${section.id}" data-mp-item="${item.id}" data-mp-value="sim"
                    ${disableItem ? "disabled" : ""}>Aprovado</button>
            <button type="button" class="mp-yn-btn btn-reprovado ${selected === "nao" ? "active" : ""}"
                    data-mp-section="${section.id}" data-mp-item="${item.id}" data-mp-value="nao"
                    ${disableItem ? "disabled" : ""}>Reprovado</button>
          </div>
        </div>
      `;

      if (selected === "nao") {
        let actionsHtml = `<div class="mp-reprovado-actions">`;
        if (item.critico) {
          actionsHtml += `<div class="mp-segregar-badge"> Falha crítica: segunda inspeção</div>`;
        }
        if (!isFinalizado) {
          actionsHtml += `
            <label class="mp-photo-upload-label">
               Tirar Foto da Falha
              <input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" class="mp-item-photo-input"
                     data-mp-section="${section.id}" data-mp-item="${item.id}" ${disableItem ? "disabled" : ""} />
            </label>
          `;
        }
        if (photoBase64) {
          actionsHtml += `
            <div class="mp-item-photo-preview">
              <img src="${photoBase64}" class="mp-item-photo-thumbnail" alt="Foto da falha" />
            </div>
          `;
        }
        actionsHtml += `</div>`;
        itemHtml += actionsHtml;
      }

      itemWrapper.innerHTML = itemHtml;
      article.appendChild(itemWrapper);
    });

    el.mpChecklistSections.appendChild(article);
    const hasCriticalReproved = section.itens.some((i) => i.critico && current.checklists?.[section.id]?.[i.id] === "nao");
    sectionEnabled = sectionEnabled && isComplete && !hasCriticalReproved;
  });
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
}

async function uploadChecklistPhoto(poste, photoBase64) {
  const response = await fetch(photoBase64);
  const blob = await response.blob();
  const form = new FormData();
  form.append("foto", blob, "inspecao.jpg");
  form.append("usuario", state.authUser?.name || "sistema");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);
  let upload;
  let result;
  try {
    upload = await fetch(`${getBackendUrl()}/inspecoes/${encodeURIComponent(poste.key)}/fotos`, {
      method: "POST",
      body: form,
      signal: controller.signal
    });
    result = await upload.json().catch(() => ({}));
  } catch (error) {
    if (controller.signal.aborted) {
      throw new Error("O envio demorou demais. Confira as fotos antes de tentar novamente.");
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
  if (!upload.ok || !result?.success || !result.data?.url) {
    throw new Error(result?.error || `O servidor não confirmou o salvamento da foto (HTTP ${upload.status}).`);
  }
  return new URL(result.data.url, getBackendUrl()).href;
}

async function setMontagemChecklistPhoto(sectionId, itemId, photoBase64) {
  if (!state.montagemPostesAtual) return;
  const current = { ...state.montagemPostesAtual };
  const photoUrl = await uploadChecklistPhoto(current, photoBase64);
  if (!current.checklists) current.checklists = {};
  if (!current.checklists[sectionId]) current.checklists[sectionId] = {};

  current.checklists[sectionId][itemId + "_photo"] = photoUrl;
  state.montagemPostesAtual = current;
  upsertMontagemPoste(current);
  const sync = await syncMontagemPosteToApi(current, "CHECKLIST", { silent: true });
  if (!sync.synced) setSyncStatus("warn", "Foto salva; o checklist aguarda sincronização.");
  renderMontagemChecklistSections();
  return sync;
}

function setMontagemChecklistAnswer(sectionId, itemId, value) {
  if (!state.montagemPostesAtual) return;
  const current = { ...state.montagemPostesAtual };
  if (!current.checklists) current.checklists = {};
  if (!current.checklists[sectionId]) current.checklists[sectionId] = {};

  const wasComplete = isChecklistSectionComplete(sectionId, current.checklists);

  current.checklists[sectionId][itemId] = value;

  if (value === "sim") {
    delete current.checklists[sectionId][itemId + "_photo"];
  }

  const sections = getMontagemChecklistSections(current.modelo || "");
  const section = sections.find((s) => s.id === sectionId);
  const item = section?.itens.find((i) => i.id === itemId);

  if (value === "nao") {
    if (item?.critico) {
      showMsgBox("segregar poste", "error");
    }
    if (item?.codigoFalha) {
      current.statusMontagem = "R";
      current.motivoRecusa = item.codigoFalha;
    }
  }

  const isNowComplete = isChecklistSectionComplete(sectionId, current.checklists);

  state.montagemPostesAtual = current;
  upsertMontagemPoste(current);
  syncMontagemPosteToApi(current, "CHECKLIST", { silent: true }).catch(() => {});

  const hasCriticalReproved = section?.itens.some((i) => i.critico && current.checklists[sectionId][i.id] === "nao");

  if (!wasComplete && isNowComplete) {
    if (hasCriticalReproved) {
      showMsgBox(`A inspeção de ${section?.titulo || sectionId} contém falhas críticas. Próximas seções bloqueadas.`, "error");
    } else {
      showMsgBox(`Inspeção de ${section?.titulo || sectionId} concluída!`, "success");
    }
  }

  renderMontagemChecklistSections();
  renderMontagemStatusUI();
}

function renderMontagemStatusUI() {
  const poste = state.montagemPostesAtual;
  if (!poste || !el.mpStatusButtons) return;

  const status = poste.statusMontagem || "";
  const isFinalizado = !!poste.finalizadoEm;

  el.mpStatusButtons.querySelectorAll("[data-mp-status]").forEach((btn) => {
    if (!(btn instanceof HTMLElement)) return;
    if (btn.dataset.mpStatus === "RR") btn.classList.add("hidden");
    btn.classList.toggle("active", btn.dataset.mpStatus === status);
    btn.disabled = isFinalizado;
  });
}

function setMontagemStatus(status) {
  if (!state.montagemPostesAtual) return;
  if (status === "RR") {
    showMsgBox("Aprovação com retrabalho é uma decisão da segunda inspeção.", "error");
    return;
  }
  const current = { ...state.montagemPostesAtual };
  current.statusMontagem = status;
  if (status === "A") current.motivoRecusa = "";
  state.montagemPostesAtual = current;
  upsertMontagemPoste(current);
  syncMontagemPosteToApi(current, "CHECKLIST", { silent: true }).catch(() => {});
  renderMontagemStatusUI();
}

function setMontagemMotivoRecusa(value) {
  if (!state.montagemPostesAtual) return;
  const current = { ...state.montagemPostesAtual, motivoRecusa: value || "" };
  state.montagemPostesAtual = current;
  upsertMontagemPoste(current);
  syncMontagemPosteToApi(current, "CHECKLIST", { silent: true }).catch(() => {});
}

function showMontagemResumoModal(poste, options = {}) {
  if (!el.mpResumoModal || !el.mpResumoBody || !el.mpResumoOkBtn) return;
  const onClose = typeof options.onClose === "function" ? options.onClose : null;
  const statusLabel = montagemStatusLabel(poste.statusMontagem || "");
  const motivo = poste.statusMontagem === "A" ? "-" : getMotivoRecusaLabel(poste.motivoRecusa || "");
  const dtMontagem = formatDateTime(poste.finalizadoEm || "");

  // Calcular o tempo decorrido de inspeção e montagem
  let tempoGasto = "-";
  if (poste.inicioInspecaoMontagem && poste.finalizadoEm) {
    const tInicio = new Date(poste.inicioInspecaoMontagem);
    const tFim = new Date(poste.finalizadoEm);
    const diffMs = tFim - tInicio;
    if (diffMs > 0) {
      const diffSecs = Math.floor(diffMs / 1000);
      const mins = Math.floor(diffSecs / 60);
      const secs = diffSecs % 60;
      tempoGasto = `${mins}m ${secs}s`;
    }
  }

  el.mpResumoBody.innerHTML = `
    <div><strong>Montador:</strong> ${escapeHtml(state.authUser?.name || "-")}</div>
    <div><strong>Setor:</strong> ${escapeHtml(poste.setor || "-")}</div>
    <div><strong>Poste Modelo:</strong> ${escapeHtml(poste.modelo || "-")}</div>
    <div><strong>Produto:</strong> ${escapeHtml(poste.codigoProduto || "-")} ${poste.descricaoPoste ? "- " + escapeHtml(poste.descricaoPoste) : ""}</div>
    <div><strong>Forma:</strong> ${escapeHtml(poste.formaNumero || "-")}</div>
    <div><strong>Dt. Produção:</strong> ${fmtDate(poste.dataFabricacao || "") || "-"}</div>
    <div><strong>Dt. Montagem:</strong> ${dtMontagem}</div>
    <div><strong>Tempo de Inspeção:</strong> <span data-visual-print="1470f4bef851" style="color:var(--c-orange);font-weight:700;">${tempoGasto}</span></div>
    <div><strong>Status:</strong> ${statusLabel}</div>
    <div><strong>Motivo da recusa:</strong> ${motivo}</div>
    <div><strong>Observações:</strong> ${escapeHtml(poste.observacoesMontagem || "-")}</div>
    <div><strong>Registro:</strong> ${escapeHtml(poste.key || "-")}</div>
    <div><strong>Persistência:</strong> ${escapeHtml(poste.resumoSync || "-")}</div>
  `;

  const close = () => {
    el.mpResumoModal.classList.remove("modal-visible");
    el.mpResumoOkBtn.removeEventListener("click", close);
    el.mpResumoModal.removeEventListener("click", onOverlay);
    if (onClose) onClose();
  };
  const onOverlay = (event) => {
    if (event.target === el.mpResumoModal) close();
  };

  el.mpResumoModal.classList.add("modal-visible");
  el.mpResumoOkBtn.addEventListener("click", close);
  el.mpResumoModal.addEventListener("click", onOverlay);
}

function renderMontagemPosteDetalhe() {
  if (!el.mpDetalheHeader || !state.montagemPostesAtual) return;
  const poste = state.montagemPostesAtual;

  let tempoGasto = "-";
  if (poste.inicioInspecaoMontagem && poste.finalizadoEm) {
    const tInicio = new Date(poste.inicioInspecaoMontagem);
    const tFim = new Date(poste.finalizadoEm);
    const diffMs = tFim - tInicio;
    if (diffMs > 0) {
      const diffSecs = Math.floor(diffMs / 1000);
      const mins = Math.floor(diffSecs / 60);
      const secs = diffSecs % 60;
      tempoGasto = `${mins}m ${secs}s`;
    }
  }

  el.mpDetalheHeader.innerHTML = `
    <div style="margin-bottom: 15px; display: flex;">
      <button class="btn btn-back" type="button" onclick="navigateBack()" style="flex: 1;">← Voltar para a lista</button>
    </div>
    <div><strong>Forma:</strong> ${poste.formaNumero || "-"}</div>
    <div><strong>Modelo:</strong> ${poste.modelo || "-"}</div>
    <div><strong>Produto:</strong> ${escapeHtml(poste.codigoProduto || "-")} ${poste.descricaoPoste ? "- " + escapeHtml(poste.descricaoPoste) : ""}</div>
    <div><strong>Setor:</strong> ${poste.setor || "-"}</div>
    <div><strong>Data Produção:</strong> ${fmtDate(poste.dataFabricacao || "") || "-"}</div>
    <div><strong>Início inspeção/montagem:</strong> ${formatDateTime(poste.inicioInspecaoMontagem || "")}</div>
    <div><strong>Finalizado em:</strong> ${poste.finalizadoEm ? formatDateTime(poste.finalizadoEm) : "-"}</div>
    <div><strong>Tempo de Inspeção:</strong> <span data-visual-print="1470f4bef851" style="color:var(--c-orange);font-weight:700;">${tempoGasto}</span></div>
  `;

  renderMontagemChecklistSections();
  if (el.mpObservacoes) {
    el.mpObservacoes.value = poste.observacoesMontagem || "";
    el.mpObservacoes.disabled = !!poste.finalizadoEm;
  }
  renderMontagemStatusUI();

  if (el.mpFinalizarPoste) {
    el.mpFinalizarPoste.disabled = !!poste.finalizadoEm;
    el.mpFinalizarPoste.textContent = poste.finalizadoEm ? "Salvo" : "Salvar";
  }
}

async function openMontagemPosteDetalhe(posteBase) {
  const recordId = posteBase.recordId;
  const dataFabricacao = posteBase.dataFabricacao;
  const setor = posteBase.setor;
  const formaNumero = posteBase.formaNumero;
  const key = [recordId, dataFabricacao, setor, formaNumero].join("||");
  const now = nowIso();

  let atual = null;
  if (hasMontagemApiConfigured()) {
    try {
      const { data, error } = await supabaseClient.from('montagem_poste').select('*').eq('id', key).maybeSingle();
      if (!error && data) {
        atual = {
          key: data.id,
          recordId: data.record_id || "",
          dataFabricacao: data.data_fabricacao || "",
          setor: data.setor || "",
          formaNumero: data.forma_numero || "",
          modelo: data.modelo || "",
          codigoPoste: data.codigo_poste || "",
          descricaoPoste: data.descricao_poste || "",
          codigoProduto: data.codigo_produto || "",
          statusMontagem: data.status_montagem || "",
          motivoRecusa: data.motivo_recusa || "",
          etapa: data.etapa || "",
          inicioInspecaoMontagem: data.inicio_inspecao_montagem || "",
          finalizadoEm: data.finalizado_em || "",
          checklists: data.checklists || {},
          observacoesMontagem: data.observacoes_montagem || "",
          montadorNome: data.montador_nome || ""
        };
      }
    } catch (err) {
      console.warn("Erro ao buscar montagem_poste específico do servidor:", err);
    }
  }

  const isRework = (atual?.statusMontagem === "RR" || Boolean(posteBase?.segundaInspecao));

  if (isRework) await registrarHistoricoReprovacao(atual);

  const merged = {
    key,
    recordId: posteBase.recordId || "",
    dataFabricacao: posteBase.dataFabricacao || "",
    setor: posteBase.setor || "",
    formaNumero: posteBase.formaNumero || "",
    modelo: posteBase.modelo || "",
    codigoPoste: posteBase.codigoPoste || atual?.codigoPoste || getPosteFieldsForForma(posteBase.formaNumero, posteBase.setor).codigoPoste,
    descricaoPoste: posteBase.descricaoPoste || atual?.descricaoPoste || getPosteFieldsForForma(posteBase.formaNumero, posteBase.setor).descricaoPoste,
    codigoProduto: posteBase.codigoProduto || atual?.codigoProduto || getPosteFieldsForForma(posteBase.formaNumero, posteBase.setor).codigoProduto,
    statusMontagem: isRework ? "" : (atual?.statusMontagem || ""),
    motivoRecusa: isRework ? "" : (atual?.motivoRecusa || ""),
    inicioInspecaoMontagem: isRework ? now : (atual?.inicioInspecaoMontagem || now),
    finalizadoEm: isRework ? "" : (atual?.finalizadoEm || ""),
    observacoesMontagem: isRework ? "" : (atual?.observacoesMontagem || ""),
    checklists: isRework ? {} : (atual?.checklists || {}),
    segundaInspecao: Boolean(posteBase?.segundaInspecao)
  };

  upsertMontagemPoste(merged);
  await syncMontagemPosteToApi(merged, "INICIO", { silent: true });
  state.montagemPostesAtual = merged;
  setMode("MONTAGEM_POSTES_DETALHE");
  renderMontagemPosteDetalhe();
}

function getDeviceGeolocation() {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      resolve({ error: "Não suportado pelo navegador" });
      return;
    }
    let finished = false;
    const finish = (result) => {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);
      resolve(result);
    };
    const timeout = setTimeout(() => finish({ error: "Tempo limite atingido" }), 7000);
    try {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          finish({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: position.timestamp
          });
        },
        (error) => {
          let errorMsg = "Erro desconhecido";
          if (error.code === error.PERMISSION_DENIED) {
            errorMsg = "Permissão negada";
          } else if (error.code === error.POSITION_UNAVAILABLE) {
            errorMsg = "Posição indisponível";
          } else if (error.code === error.TIMEOUT) {
            errorMsg = "Tempo limite atingido";
          }
          finish({ error: errorMsg });
        },
        { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
      );
    } catch (error) {
      finish({ error: error.message || "Geolocalização indisponível" });
    }
  });
}

async function finalizarMontagemPosteAtual() {
  const poste = state.montagemPostesAtual;
  if (!poste) {
    showMsgBox("Nenhum poste selecionado.", "error");
    return;
  }

  const status = poste.statusMontagem || "";
  if (!status) {
    showMsgBox("Selecione o resultado da primeira avaliação: Aprovado ou Reprovado.", "error");
    return;
  }

  const sections = getMontagemChecklistSections(poste.modelo || "");
  const allSectionsOk = sections.every((section) =>
    isChecklistSectionComplete(section.id, poste.checklists || {})
  );

  const temReprovadoPrimeiraSecao = Object.values(poste.checklists?.["checagem_inicial"] || {}).includes("nao");

  if (!allSectionsOk && !(temReprovadoPrimeiraSecao && (status === "R" || status === "RR"))) {
    showMsgBox("Responda todos os itens (Aprovado/Reprovado) de todas as seções antes de finalizar.", "error");
    return;
  }

  const loadingModal = document.getElementById("loadingModal");
  const loadingMsg = loadingModal ? loadingModal.querySelector(".loading-msg") : null;
  if (loadingMsg) loadingMsg.textContent = "Obtendo geolocalização...";
  if (loadingModal) loadingModal.classList.add("modal-visible");

  try {
    const geoResult = await getDeviceGeolocation();
    if (loadingMsg) loadingMsg.textContent = "Salvando montagem...";

    const now = new Date();
    const diaInspecao = now.toLocaleDateString("pt-BR");
    const horarioDispositivo = now.toLocaleTimeString("pt-BR");

    const updated = {
      ...poste,
      checklists: {
        ...(poste.checklists || {}),
        dia_inspecao: diaInspecao,
        horario_dispositivo: horarioDispositivo,
        geolocation: geoResult
      },
      finalizadoEm: nowIso()
    };

    if (poste.segundaInspecao) {
      const approvedAfterRework = updated.statusMontagem === "A";
      updated.statusMontagem = approvedAfterRework ? "RR" : "R";
      updated.checklists.__segunda_inspecao = {
        primeira_inspecao: "R",
        resultado: approvedAfterRework ? "APROVADO_RETRABALHADO" : "SEGREGADO",
        em: updated.finalizadoEm,
        por: state.authUser?.name || ""
      };
    }

    const syncResult = await syncMontagemPosteToApi(updated, "FINALIZACAO", { silent: false });
    const finalEntry = {
      ...updated,
      pendingSync: !syncResult.synced
    };
    upsertMontagemPoste(finalEntry);
    await registrarHistoricoReprovacao(finalEntry);
    state.montagemPostesAtual = finalEntry;

    renderMontagemPosteDetalhe();
    if (loadingModal) loadingModal.classList.remove("modal-visible");

    showMontagemResumoModal({
      ...finalEntry,
      resumoSync: syncResult.synced ? "Sincronizado" : "Salvo localmente"
    }, {
      onClose: async () => {
        setMode("MONTAGEM_POSTES");
        await renderMontagemPostesLiberados();
        if (el.mpFormaFiltro) {
          el.mpFormaFiltro.value = "";
        }
        filtrarMontagemTabela();
      }
    });
  } catch (e) {
    console.error("Erro ao finalizar montagem:", e);
    showMsgBox("Erro ao finalizar montagem: " + (e.message || String(e)), "error");
  } finally {
    if (loadingModal) loadingModal.classList.remove("modal-visible");
  }
}

function filtrarMontagemTabela() {
  const texto = (el.mpFormaFiltro?.value || "").trim().toUpperCase();
  Array.from(el.mpLiberadosBody?.querySelectorAll("tr[data-forma-numero]") || []).forEach((tr) => {
    const forma = (tr.dataset.formaNumero || "").toUpperCase();
    tr.style.display = !texto || forma.includes(texto) ? "" : "none";
  });
}

async function syncMontagemPostesFromApi(filtroData, modoCarga, setor) {
  if (!hasMontagemApiConfigured()) return;
  try {
    let query = supabaseClient.from('montagem_poste').select('*');
    if (setor) query = query.eq('setor', setor);
    if (modoCarga === "data" && filtroData) query = query.eq('data_fabricacao', filtroData);

    const { data, error } = await query;
    if (error) throw error;

    if (Array.isArray(data) && data.length > 0) {
      const db = readMontagemPostesDb();
      data.forEach(row => {
        const key = row.id;
        db.postes[key] = {
          key: row.id,
          recordId: row.record_id || "",
          dataFabricacao: row.data_fabricacao || "",
          setor: row.setor || "",
          formaNumero: row.forma_numero || "",
          modelo: row.modelo || "",
          codigoPoste: row.codigo_poste || "",
          descricaoPoste: row.descricao_poste || "",
          codigoProduto: row.codigo_produto || "",
          statusMontagem: row.status_montagem || "",
          motivoRecusa: row.motivo_recusa || "",
          etapa: row.etapa || "",
          inicioInspecaoMontagem: row.inicio_inspecao_montagem || "",
          finalizadoEm: row.finalizado_em || "",
          checklists: row.checklists || {},
          observacoesMontagem: row.observacoes_montagem || "",
          montadorNome: row.montador_nome || ""
        };
      });
      writeMontagemPostesDb(db);
    }
  } catch (err) {
    console.warn("Erro ao carregar montagem_poste do servidor:", err);
  }
}

async function renderMontagemPostesLiberados() {
  if (!el.mpLiberadosBody || !el.mpQtdItens) return;

  const filtroData = el.mpFiltroData?.value || todayYmd();
  const modoCarga = el.mpModoCarga?.value || "data";
  const setor = el.mpSetor?.value || "";
  const statusFiltro = el.mpStatusFiltro?.value || "";

  el.mpLiberadosBody.innerHTML = "";
  if (el.mpKpiAprovados) el.mpKpiAprovados.textContent = "0";
  if (el.mpKpiRetrabalho) el.mpKpiRetrabalho.textContent = "0";
  if (el.mpKpiReprovados) el.mpKpiReprovados.textContent = "0";

  if (!filtroData) {
    el.mpQtdItens.textContent = "0";
    el.mpLiberadosBody.innerHTML = '<tr><td colspan="4" class="muted">Selecione a data de produção para carregar os itens liberados.</td></tr>';
    return;
  }

  // Busca dados em tempo real diretamente do Supabase sem cache local
  let poles = await fetchPolesForDate(filtroData, setor, ['Setor 1', 'Setor 2']);

  // Se o setor não for informado ("Todos (1 e 2)"), filtramos estritamente para mostrar apenas Setor 1 e Setor 2
  if (!setor) {
    poles = poles.filter((pole) => pole.setor === "Setor 1" || pole.setor === "Setor 2");
  }

  // Filtra de acordo com modoCarga para fins de cálculo de KPIs
  const baseRows = poles.filter((record) => {
    if (modoCarga === "pendentes") {
      return !record.montagem || !record.montagem.finalizado_em;
    }
    return true;
  });

  let countAprovados = 0;
  let countRetrabalho = 0;
  let countReprovados = 0;

  baseRows.forEach((record) => {
    const isFinalizado = !!record.montagem?.finalizado_em;
    const status = record.montagem?.status_montagem || "";
    if (isFinalizado) {
      if (status === "A") countAprovados++;
      else if (status === "RR") countRetrabalho++;
      else if (status === "R") countReprovados++;
    }
  });

  if (el.mpKpiAprovados) el.mpKpiAprovados.textContent = String(countAprovados);
  if (el.mpKpiRetrabalho) el.mpKpiRetrabalho.textContent = String(countRetrabalho);
  if (el.mpKpiReprovados) el.mpKpiReprovados.textContent = String(countReprovados);

  // Filtra de acordo com statusFiltro para a exibição na tabela
  const rows = baseRows.filter((record) => {
    if (statusFiltro) {
      const isFinalizado = !!record.montagem?.finalizado_em;
      const statusVal = record.montagem?.status_montagem || "";
      if (statusFiltro === "PENDENTE") {
        if (isFinalizado) return false;
      } else {
        if (!isFinalizado || statusVal !== statusFiltro) return false;
      }
    }
    return true;
  });

  el.mpQtdItens.textContent = String(rows.length);

  if (!rows.length) {
    el.mpLiberadosBody.innerHTML = '<tr><td colspan="4" class="muted">Nenhum poste concretado ou pendente de montagem para os filtros informados.</td></tr>';
    return;
  }

  rows.forEach((record) => {
    const isFinalizado = !!record.montagem?.finalizado_em;
    const status = record.montagem?.status_montagem || "";
    const rowClass = isFinalizado ? "row-montado" : "";

    const tr = document.createElement("tr");
    if (rowClass) {
      tr.className = rowClass;
    }
    tr.dataset.recordId = record.recordId;
    tr.dataset.dataFabricacao = record.dataFabricacao;
    tr.dataset.setor = record.setor;
    tr.dataset.formaNumero = record.formaNumero;
    tr.dataset.modelo = record.modelo;
    tr.dataset.codigoPoste = record.codigoPoste || "";
    tr.dataset.descricaoPoste = record.descricaoPoste || "";
    tr.dataset.codigoProduto = record.codigoProduto || "";

    // Armazena o registro de montagem completo serializado em JSON para uso posterior ao clicar
    tr.dataset.montagemRaw = record.montagem ? JSON.stringify(record.montagem) : "";

    let acaoContent = "";
    if (isFinalizado) {
      if (status === "A") {
        acaoContent = `<button type="button" class="btn mp-ver-checklist-btn" data-visual-print="cd129ef7ee48" style="background-color:var(--c-ok);color:white;border:none;font-weight:bold;width:100%;height:38px;border-radius:var(--r);cursor:pointer;">Aprovado (Ver Checklist)</button>`;
      } else if (status === "RR") {
        acaoContent = `<button type="button" class="btn mp-ver-checklist-btn" data-visual-print="480a94bd618c" style="background-color:var(--c-orange);color:white;border:none;font-weight:bold;width:100%;height:38px;border-radius:var(--r);">Aprovado e Retrabalhado · Fotos</button>`;
      } else {
        acaoContent = `<button type="button" class="btn mp-ver-checklist-btn" data-visual-print="acd0fbc07f2f" style="background-color:var(--c-orange);color:white;border:none;font-weight:bold;width:100%;height:38px;border-radius:var(--r);cursor:pointer;">Fotos e 2ª inspeção</button>`;
      }
    } else {
      const extraClass = record.status === 'INSPECIONADO' ? 'mp-open-btn--inspecionado' : '';
      acaoContent = `<button type="button" class="btn mp-open-btn ${extraClass}">Inspecionar / Montar Poste</button>`;
    }

    tr.innerHTML = `
      <td data-label="N Forma" style="text-align:center; font-weight:900;">${record.formaNumero || ""}</td>
      <td data-label="Modelo">${record.modelo || ""}</td>
      <td data-label="Data Prod." style="text-align:center;">${fmtDate(record.dataFabricacao || "")}</td>
      <td data-label="Ação" style="text-align:center; vertical-align:middle;">
        <div style="display:inline-flex; gap:8px; align-items:center; justify-content:center; width:100%;">
          ${acaoContent}
        </div>
      </td>
    `;
    el.mpLiberadosBody.appendChild(tr);
  });

  filtrarMontagemTabela();
}

async function saveInspecao() {}

function abrirEscolhaPosteReprovado(rawRow, posteBase, modo = "INSPECAO") {
  document.getElementById("unificado-second-choice")?.remove();
  const overlay = document.createElement("div");
  overlay.id = "unificado-second-choice";
  overlay.setAttribute("role", "dialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-labelledby", "unificado-second-choice-title");
  overlay.innerHTML = `
    <section class="unificado-second-choice-card">
      <h2 id="unificado-second-choice-title">Poste reprovado</h2>
      <p>Escolha como deseja continuar.</p>
      <div class="unificado-second-choice-actions">
        <button type="button" data-action="second">Segunda inspeção (retrabalho)</button>
        <button type="button" data-action="report">Ver relatório</button>
        <button type="button" data-action="cancel" class="secondary">Cancelar</button>
      </div>
    </section>`;
  const close = () => overlay.remove();
  overlay.addEventListener("click", async (event) => {
    if (event.target === overlay || event.target.closest('[data-action="cancel"]')) return close();
    if (event.target.closest('[data-action="report"]')) {
      close();
      return window.abrirVisualizacaoChecklist(rawRow);
    }
    if (event.target.closest('[data-action="second"]')) {
      close();
      if (modo === "MONTAGEM_POSTES") {
        await openMontagemPosteDetalhe({ ...posteBase, segundaInspecao: true });
      } else {
        await openInspecaoPosteDetalhe({ ...posteBase, segundaInspecao: true });
      }
    }
  });
  document.body.appendChild(overlay);
  overlay.querySelector('[data-action="second"]')?.focus();
}

async function openInspecaoPosteDetalhe(posteBase) {
  const recordId = posteBase.recordId;
  const dataFabricacao = posteBase.dataFabricacao;
  const setor = posteBase.setor;
  const formaNumero = posteBase.formaNumero;
  const key = [recordId, dataFabricacao, setor, formaNumero, 'INSPECAO'].join("||");
  const now = nowIso();

  let atual = null;
  if (hasMontagemApiConfigured()) {
    try {
      const { data, error } = await supabaseClient.from('montagem_poste').select('*').eq('id', key).maybeSingle();
      if (!error && data) {
        atual = {
          key: data.id,
          recordId: data.record_id || "",
          dataFabricacao: data.data_fabricacao || "",
          setor: data.setor || "",
          formaNumero: data.forma_numero || "",
          modelo: data.modelo || "",
          codigoPoste: data.codigo_poste || "",
          descricaoPoste: data.descricao_poste || "",
          codigoProduto: data.codigo_produto || "",
          statusMontagem: data.status_montagem || "",
          motivoRecusa: data.motivo_recusa || "",
          etapa: data.etapa || "",
          inicioInspecaoMontagem: data.inicio_inspecao_montagem || "",
          finalizadoEm: data.finalizado_em || "",
          checklists: data.checklists || {},
          observacoesMontagem: data.observacoes_montagem || "",
          montadorNome: data.montador_nome || ""
        };
      }
    } catch (err) {
      console.warn("Erro ao buscar montagem_poste específico do servidor:", err);
    }
  }

  const isRework = (atual?.statusMontagem === "RR" || Boolean(posteBase?.segundaInspecao));

  if (isRework) await registrarHistoricoReprovacao(atual);

  const merged = {
    key,
    recordId: posteBase.recordId || "",
    dataFabricacao: posteBase.dataFabricacao || "",
    setor: posteBase.setor || "",
    formaNumero: posteBase.formaNumero || "",
    modelo: posteBase.modelo || "",
    codigoPoste: posteBase.codigoPoste || atual?.codigoPoste || getPosteFieldsForForma(posteBase.formaNumero, posteBase.setor).codigoPoste,
    descricaoPoste: posteBase.descricaoPoste || atual?.descricaoPoste || getPosteFieldsForForma(posteBase.formaNumero, posteBase.setor).descricaoPoste,
    codigoProduto: posteBase.codigoProduto || atual?.codigoProduto || getPosteFieldsForForma(posteBase.formaNumero, posteBase.setor).codigoProduto,
    statusMontagem: isRework ? "" : (atual?.statusMontagem || ""),
    motivoRecusa: isRework ? "" : (atual?.motivoRecusa || ""),
    inicioInspecaoMontagem: isRework ? now : (atual?.inicioInspecaoMontagem || now),
    finalizadoEm: isRework ? "" : (atual?.finalizadoEm || ""),
    observacoesMontagem: isRework ? "" : (atual?.observacoesMontagem || ""),
    checklists: isRework ? {} : (atual?.checklists || {}),
    etapa: "INSPECAO",
    segundaInspecao: Boolean(posteBase?.segundaInspecao)
  };

  upsertMontagemPoste(merged);
  await syncMontagemPosteToApi(merged, "INSPECAO", { silent: true });
  state.inspecaoPostesAtual = merged;
  setMode("INSPECAO_DETALHE");
  renderInspecaoPosteDetalhe();
}

function renderInspecaoPosteDetalhe() {
  if (!el.insDetalheHeader || !state.inspecaoPostesAtual) return;
  const poste = state.inspecaoPostesAtual;

  let tempoGasto = "-";
  if (poste.inicioInspecaoMontagem && poste.finalizadoEm) {
    const tInicio = new Date(poste.inicioInspecaoMontagem);
    const tFim = new Date(poste.finalizadoEm);
    const diffMs = tFim - tInicio;
    if (diffMs > 0) {
      const diffSecs = Math.floor(diffMs / 1000);
      const mins = Math.floor(diffSecs / 60);
      const secs = diffSecs % 60;
      tempoGasto = `${mins}m ${secs}s`;
    }
  }

  el.insDetalheHeader.innerHTML = `
    <div style="margin-bottom: 15px; display: flex;">
      <button class="btn btn-back" type="button" onclick="navigateBack()" style="flex: 1;">← Voltar para a lista</button>
    </div>
    <div><strong>Forma:</strong> ${poste.formaNumero || "-"}</div>
    <div><strong>Modelo:</strong> ${poste.modelo || "-"}</div>
    <div><strong>Produto:</strong> ${escapeHtml(poste.codigoProduto || "-")} ${poste.descricaoPoste ? "- " + escapeHtml(poste.descricaoPoste) : ""}</div>
    <div><strong>Setor:</strong> ${poste.setor || "-"}</div>
    <div><strong>Data Produção:</strong> ${fmtDate(poste.dataFabricacao || "") || "-"}</div>
    <div><strong>Início inspeção:</strong> ${formatDateTime(poste.inicioInspecaoMontagem || "")}</div>
    <div><strong>Finalizado em:</strong> ${poste.finalizadoEm ? formatDateTime(poste.finalizadoEm) : "-"}</div>
    <div><strong>Tempo de Inspeção:</strong> <span data-visual-print="1470f4bef851" style="color:var(--c-orange);font-weight:700;">${tempoGasto}</span></div>
  `;

  renderInspecaoChecklistSections();
  if (el.insObservacoes) {
    el.insObservacoes.value = poste.observacoesMontagem || "";
    el.insObservacoes.disabled = !!poste.finalizadoEm;
  }
  renderInspecaoStatusUI();

  if (el.insFinalizarPoste) {
    el.insFinalizarPoste.disabled = !!poste.finalizadoEm;
    el.insFinalizarPoste.textContent = poste.finalizadoEm ? "Salvo" : "Salvar";
  }
}

function renderInspecaoChecklistSections() {
  if (!el.insChecklistSections || !state.inspecaoPostesAtual) return;
  const current = state.inspecaoPostesAtual;
  el.insChecklistSections.innerHTML = "";

  const sections = getInspecaoChecklistSections(current.modelo || "");
  let sectionEnabled = true;

  sections.forEach((section) => {
    const article = document.createElement("article");
    article.className = "mp-checklist-section";
    if (!sectionEnabled) {
      article.style.opacity = "0.5";
      article.style.pointerEvents = "none";
    }

    const isComplete = isChecklistSectionComplete(section.id, current.checklists || {}, "INSPECAO", current.modelo || "");

    const sectionHeader = document.createElement("div");
    sectionHeader.className = "mp-checklist-header";
    sectionHeader.innerHTML = `
      <strong>${section.titulo}</strong>
      <span class="mp-checklist-flag ${isComplete ? "ok" : "pendente"}">${isComplete ? "OK" : "Pendente"}</span>
    `;
    article.appendChild(sectionHeader);

    section.itens.forEach((item) => {
      const selected = current.checklists?.[section.id]?.[item.id] || "";
      const photoBase64 = current.checklists?.[section.id]?.[item.id + "_photo"] || "";
      const isFinalizado = !!current.finalizadoEm;

      const disableItem = isFinalizado || !sectionEnabled;

      const itemWrapper = document.createElement("div");
      itemWrapper.className = "mp-checklist-item-wrapper";

      const itemIcone = item.codigoFalha ? (DEFEITO_ICONES[item.codigoFalha] || "") : "";
      let itemHtml = `
        <div class="mp-checklist-item">
          <span class="mp-checklist-item-text">
            ${itemIcone ? `<span class="item-defeito-icon" title="Código ${item.codigoFalha}">${itemIcone}</span>` : ""}
            ${item.critico ? '<span class="critico-dot" title="Item crítico — pode segregar o poste">&#9888;</span>' : ""}
            ${item.texto}
          </span>
          <div class="mp-yn-group">
            <button type="button" class="mp-yn-btn btn-aprovado ${selected === "sim" ? "active" : ""}"
                    data-ins-section="${section.id}" data-ins-item="${item.id}" data-ins-value="sim"
                    ${disableItem ? "disabled" : ""}>Aprovado</button>
            <button type="button" class="mp-yn-btn btn-reprovado ${selected === "nao" ? "active" : ""}"
                    data-ins-section="${section.id}" data-ins-item="${item.id}" data-ins-value="nao"
                    ${disableItem ? "disabled" : ""}>Reprovado</button>
          </div>
        </div>
      `;

      if (selected === "nao") {
        let actionsHtml = `<div class="mp-reprovado-actions">`;
        if (item.critico) {
          actionsHtml += `<div class="mp-segregar-badge"> Falha crítica: segunda inspeção</div>`;
        }
        if (!isFinalizado) {
          actionsHtml += `
            <label class="mp-photo-upload-label">
               Tirar Foto da Falha
              <input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" class="ins-item-photo-input"
                     data-ins-section="${section.id}" data-ins-item="${item.id}" ${disableItem ? "disabled" : ""} />
            </label>
          `;
        }
        if (photoBase64) {
          actionsHtml += `
            <div class="mp-item-photo-preview">
              <img src="${photoBase64}" class="mp-item-photo-thumbnail" alt="Foto da falha" />
            </div>
          `;
        }
        actionsHtml += `</div>`;
        itemHtml += actionsHtml;
      }

      itemWrapper.innerHTML = itemHtml;
      article.appendChild(itemWrapper);
    });

    el.insChecklistSections.appendChild(article);
    const hasCriticalReproved = section.itens.some((i) => i.critico && current.checklists?.[section.id]?.[i.id] === "nao");
    sectionEnabled = sectionEnabled && isComplete && !hasCriticalReproved;
  });
}

function renderInspecaoStatusUI() {
  const poste = state.inspecaoPostesAtual;
  if (!poste || !el.insStatusButtons) return;

  const status = poste.statusMontagem || "";
  const isFinalizado = !!poste.finalizadoEm;

  el.insStatusButtons.querySelectorAll("[data-ins-status]").forEach((btn) => {
    if (!(btn instanceof HTMLElement)) return;
    if (btn.dataset.insStatus === "RR") btn.classList.add("hidden");
    btn.classList.toggle("active", btn.dataset.insStatus === status);
    btn.disabled = isFinalizado;
  });
}

function setInspecaoStatus(status) {
  if (!state.inspecaoPostesAtual) return;
  if (status === "RR") {
    showMsgBox("Aprovação com retrabalho é uma decisão da segunda inspeção.", "error");
    return;
  }
  const current = { ...state.inspecaoPostesAtual };

  const sections = getInspecaoChecklistSections(current.modelo || "");
  const hasFailures = sections.some((sec) =>
    sec.itens.some((it) => current.checklists[sec.id]?.[it.id] === "nao")
  );

  if (status === "A" && hasFailures) {
    showMsgBox("Não é possível aprovar um poste que possui itens reprovados no checklist.", "error");
    return;
  }

  current.statusMontagem = status;
  if (status === "A") {
    current.motivoRecusa = "";
  }
  state.inspecaoPostesAtual = current;
  upsertMontagemPoste(current);
  syncMontagemPosteToApi(current, "INSPECAO", { silent: true }).catch(() => {});
  renderInspecaoStatusUI();
}

function setInspecaoChecklistAnswer(sectionId, itemId, value) {
  if (!state.inspecaoPostesAtual) return;
  const current = { ...state.inspecaoPostesAtual };
  if (!current.checklists) current.checklists = {};
  if (!current.checklists[sectionId]) current.checklists[sectionId] = {};

  const wasComplete = isChecklistSectionComplete(sectionId, current.checklists, "INSPECAO", current.modelo || "");

  current.checklists[sectionId][itemId] = value;

  if (value === "sim") {
    delete current.checklists[sectionId][itemId + "_photo"];
  }

  const sections = getInspecaoChecklistSections(current.modelo || "");
  const section = sections.find((s) => s.id === sectionId);

  const reprovedCodes = [];
  sections.forEach((sec) => {
    sec.itens.forEach((it) => {
      if (current.checklists[sec.id]?.[it.id] === "nao" && it.codigoFalha) {
        reprovedCodes.push(it.codigoFalha);
      }
    });
  });

  const uniqueCodes = [...new Set(reprovedCodes)];

  if (uniqueCodes.length > 0) {
    if (current.statusMontagem !== "R" && current.statusMontagem !== "RR") {
      current.statusMontagem = "R";
    }
    current.motivoRecusa = uniqueCodes.join(", ");
  } else {
    current.statusMontagem = "A";
    current.motivoRecusa = "";
  }

  const isNowComplete = isChecklistSectionComplete(sectionId, current.checklists, "INSPECAO", current.modelo || "");

  state.inspecaoPostesAtual = current;
  upsertMontagemPoste(current);
  syncMontagemPosteToApi(current, "INSPECAO", { silent: true }).catch(() => {});

  const hasCriticalReproved = section?.itens.some((i) => i.critico && current.checklists[sectionId][i.id] === "nao");

  if (!wasComplete && isNowComplete) {
    if (hasCriticalReproved) {
      showMsgBox(`A inspeção visual contém falhas críticas. Poste deve ser reprovado.`, "error");
    } else {
      showMsgBox(`Inspeção visual concluída com sucesso!`, "success");
    }
  }

  renderInspecaoChecklistSections();
  renderInspecaoStatusUI();
}

async function setInspecaoChecklistPhoto(sectionId, itemId, photoBase64) {
  if (!state.inspecaoPostesAtual) return;
  const current = { ...state.inspecaoPostesAtual };
  const photoUrl = await uploadChecklistPhoto(current, photoBase64);
  if (!current.checklists) current.checklists = {};
  if (!current.checklists[sectionId]) current.checklists[sectionId] = {};

  current.checklists[sectionId][itemId + "_photo"] = photoUrl;
  state.inspecaoPostesAtual = current;
  upsertMontagemPoste(current);
  const sync = await syncMontagemPosteToApi(current, "INSPECAO", { silent: true });
  if (!sync.synced) setSyncStatus("warn", "Foto salva; a inspeção aguarda sincronização.");
  renderInspecaoChecklistSections();
  return sync;
}

async function finalizarInspecaoPosteAtual() {
  const poste = state.inspecaoPostesAtual;
  if (!poste) {
    showMsgBox("Nenhum poste selecionado.", "error");
    return;
  }

  const status = poste.statusMontagem || "";
  if (!status) {
    showMsgBox("Selecione o resultado da primeira inspeção: Aprovado ou Reprovado.", "error");
    return;
  }

  const sections = getInspecaoChecklistSections(poste.modelo || "");
  const allSectionsOk = sections.every((section) =>
    isChecklistSectionComplete(section.id, poste.checklists || {}, "INSPECAO", poste.modelo || "")
  );

  const temReprovadoPrimeiraSecao = Object.values(poste.checklists?.["inspecao_visual"] || {}).includes("nao");

  if (!allSectionsOk && !(temReprovadoPrimeiraSecao && (status === "R" || status === "RR"))) {
    showMsgBox("Responda todos os itens (Aprovado/Reprovado) antes de finalizar.", "error");
    return;
  }

  const loadingModal = document.getElementById("loadingModal");
  const loadingMsg = loadingModal ? loadingModal.querySelector(".loading-msg") : null;
  if (loadingMsg) loadingMsg.textContent = "Obtendo geolocalização...";
  if (loadingModal) loadingModal.classList.add("modal-visible");

  try {
    const geoResult = await getDeviceGeolocation();
    if (loadingMsg) loadingMsg.textContent = "Salvando inspeção...";

    const now = new Date();
    const diaInspecao = now.toLocaleDateString("pt-BR");
    const horarioDispositivo = now.toLocaleTimeString("pt-BR");

    const updated = {
      ...poste,
      checklists: {
        ...(poste.checklists || {}),
        dia_inspecao: diaInspecao,
        horario_dispositivo: horarioDispositivo,
        geolocation: geoResult
      },
      finalizadoEm: nowIso()
    };
    if (poste.segundaInspecao) {
      const approvedAfterRework = updated.statusMontagem === "A";
      updated.statusMontagem = approvedAfterRework ? "RR" : "R";
      updated.checklists.__segunda_inspecao = {
        primeira_inspecao: "R",
        resultado: approvedAfterRework ? "APROVADO_RETRABALHADO" : "SEGREGADO",
        em: updated.finalizadoEm,
        por: state.authUser?.name || ""
      };
    }

    const syncResult = await syncMontagemPosteToApi(updated, "INSPECAO", { silent: false });
    const finalEntry = {
      ...updated,
      pendingSync: !syncResult.synced
    };
    upsertMontagemPoste(finalEntry);
    await registrarHistoricoReprovacao(finalEntry);
    state.inspecaoPostesAtual = finalEntry;

    renderInspecaoPosteDetalhe();
    if (loadingModal) loadingModal.classList.remove("modal-visible");

    const colaborador = el.insColaborador?.value?.trim() || state.authUser?.name || "Apontador";
    const observacaoGlobal = el.insObservacoes?.value?.trim() || "";

    const legacyEntry = {
      recordId: finalEntry.recordId,
      dataFabricacao: finalEntry.dataFabricacao,
      setor: finalEntry.setor,
      formaNumero: finalEntry.formaNumero,
      modelo: finalEntry.modelo,
      codigoPoste: finalEntry.codigoPoste,
      descricaoPoste: finalEntry.descricaoPoste,
      codigoProduto: finalEntry.codigoProduto,
      tipo: "INSPECAO",
      status: finalEntry.statusMontagem,
      codigo: finalEntry.motivoRecusa,
      colaborador: colaborador,
      observacoes: observacaoGlobal,
      fotosCount: 0,
      timestamp: finalEntry.finalizadoEm
    };

    const apiResult = await postToApiWithTimeout("salvar_inspecao_lote", { entries: [legacyEntry] });
    if (!syncResult.synced) {
      setSyncStatus("warn", "Inspeção salva no aparelho; sincronização pendente.");
    } else if (apiResult.ok) {
      setSyncStatus("ok", "Inspeção sincronizada com sucesso.");
    } else {
      setSyncStatus("ok", "Inspeção salva online.");
    }

    showMontagemResumoModal({
      ...finalEntry,
      observacoesMontagem: observacaoGlobal,
      montadorNome: colaborador,
      resumoSync: syncResult.synced ? "Sincronizado" : "Salvo localmente"
    }, {
      onClose: async () => {
        setMode("INSPECAO");
        await renderInspecaoLiberados();
        if (el.insFormaFiltro) {
          el.insFormaFiltro.value = "";
        }
        filtrarFormasTabela();
      }
    });
  } catch (e) {
    console.error("Erro ao finalizar inspeção:", e);
    showMsgBox("Erro ao finalizar inspeção: " + (e.message || String(e)), "error");
  } finally {
    if (loadingModal) loadingModal.classList.remove("modal-visible");
  }
}

function renderDashboardCharts() {
  const db = readDb();
  const dbDataEl = document.getElementById("dbData");
  const selectedDate = dbDataEl ? dbDataEl.value : "";

  // Considerar APENAS eventos vindos do Supabase API
  const apiEventsOnly = db.events.filter(ev => ev.isFromApi === true);

  // Aggregate events by date
  const prodByDate = {};
  const insByDate = {};
  const insStatusTotal = { A: 0, R: 0, RR: 0 };
  const prodS1ByDate = {};
  const prodS2ByDate = {};
  const prodS3ByDate = {};
  const prodS4ByDate = {};
  const insS1 = { A: 0, R: 0, RR: 0 };
  const insS2 = { A: 0, R: 0, RR: 0 };
  const ncCount = {};

  apiEventsOnly.forEach((ev) => {
    const etapa = (ev.etapa || "").toUpperCase();
    const d = ev.dataFabricacao || "";
    const setor = (ev.setor || "").toLowerCase();
    const isS1 = setor.includes("1");
    const isS2 = setor.includes("2");
    const isS3 = setor.includes("3");
    const isS4 = setor.includes("4");

    if (etapa === "LIBERACAO") {
      prodByDate[d] = (prodByDate[d] || 0) + 1;
      if (isS1) prodS1ByDate[d] = (prodS1ByDate[d] || 0) + 1;
      else if (isS2) prodS2ByDate[d] = (prodS2ByDate[d] || 0) + 1;
      else if (isS3) prodS3ByDate[d] = (prodS3ByDate[d] || 0) + 1;
      else if (isS4) prodS4ByDate[d] = (prodS4ByDate[d] || 0) + 1;
    } else if (etapa === "INSPECAO" || etapa === "REINSPECAO") {
      if (!insByDate[d]) insByDate[d] = { A: 0, R: 0, RR: 0, total: 0 };
      insByDate[d].total++;
      const s = (ev.status || "").toUpperCase();
      if (s in insStatusTotal) {
        insStatusTotal[s]++;
        insByDate[d][s]++;
        if (isS1 && s in insS1) insS1[s]++;
        if (isS2 && s in insS2) insS2[s]++;
      }
      const codigos = Array.isArray(ev.codigos) ? ev.codigos : [];
      codigos.forEach((c) => { if (c) ncCount[c.toUpperCase()] = (ncCount[c.toUpperCase()] || 0) + 1; });
    }
  });

  const montagemCache = (db.montagemDashboardCache || []).filter(row => !isHistoricoReprovacao(row));
  montagemCache.forEach((row) => {
    if (!row.status_montagem) return;
    const d = row.data_fabricacao || "";
    if (!d) return;
    const s = (row.status_montagem || "").toUpperCase();
    if (!insByDate[d]) {
      insByDate[d] = { A: 0, R: 0, RR: 0, total: 0 };
    }
    insByDate[d].total++;
    if (s in insStatusTotal) {
      insStatusTotal[s]++;
      insByDate[d][s]++;
    }
    const motivo = row.motivo_recusa;
    if (motivo) {
      const code = motivo.toUpperCase();
      ncCount[code] = (ncCount[code] || 0) + 1;
    }
  });

  // KPI for selected date or all
  let kpiProd = 0, kpiIns = 0, kpiA = 0, kpiR = 0, kpiRR = 0;
  if (selectedDate) {
    kpiProd = prodByDate[selectedDate] || 0;
    const iv = insByDate[selectedDate] || { A: 0, R: 0, RR: 0, total: 0 };
    kpiIns = iv.total; kpiA = iv.A; kpiR = iv.R; kpiRR = iv.RR;
  } else {
    kpiProd = Object.values(prodByDate).reduce((s, v) => s + v, 0);
    kpiA = insStatusTotal.A; kpiR = insStatusTotal.R; kpiRR = insStatusTotal.RR;
    kpiIns = kpiA + kpiR + kpiRR;
  }
  const rejPct = kpiIns > 0 ? Math.round(((kpiR + kpiRR) / kpiIns) * 100) : 0;

  const setTxt = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  setTxt("dbKpiProd", kpiProd);
  setTxt("dbKpiIns", kpiIns);
  setTxt("dbKpiA", kpiA);
  setTxt("dbKpiR", kpiR);
  setTxt("dbKpiRR", kpiRR);
  setTxt("dbKpiRejPct", rejPct + "%");

  // Qualidade por Setor
  const qcSetores = {
    S1: { A:0, R:0, RR:0, total:0 },
    S2: { A:0, R:0, RR:0, total:0 },
    S3: { A:0, R:0, RR:0, total:0 },
    S4: { A:0, R:0, RR:0, total:0 }
  };

  const targetDate = selectedDate || todayYmd();
  const montagemCacheFiltered = montagemCache.filter(ev => {
    const day = (ev.finalizado_em || ev.updated_at || "").split("T")[0];
    return day === targetDate;
  });

  montagemCacheFiltered.forEach(ev => {
    if (!ev.status_montagem && ev.etapa === "INICIO") return;

    const setor = (ev.setor || "").toLowerCase();
    const s = (ev.status_montagem || "").toUpperCase();

    let key = "";
    if (setor.includes("1")) key = "S1";
    else if (setor.includes("2")) key = "S2";
    else if (setor.includes("3")) key = "S3";
    else if (setor.includes("4")) key = "S4";

    if (key) {
      qcSetores[key].total++;
      if (s === "APROVADO" || s === "A") qcSetores[key].A++;
      else if (s === "REPROVADO" || s === "R" || s === "RR") qcSetores[key].R++;
    }
  });

  Object.keys(qcSetores).forEach(k => {
    setTxt("dbQcTot" + k, qcSetores[k].total);
    setTxt("dbQcOk" + k, qcSetores[k].A);
    setTxt("dbQcRej" + k, qcSetores[k].R + qcSetores[k].RR);
  });

  // Resumo de Postes Montados
  const resumoMontagem = {};
  montagemCacheFiltered.forEach(ev => {
    if (!ev.status_montagem && ev.etapa === "INICIO") return;

    const mod = ev.modelo || "Desconhecido";
    const dataFab = ev.data_fabricacao || "N/A";
    const key = `${mod}||${dataFab}`;

    if (!resumoMontagem[key]) {
      resumoMontagem[key] = { modelo: mod, data_fabricacao: dataFab, qtd: 0 };
    }
    resumoMontagem[key].qtd++;
  });

  const tbodyResumo = document.getElementById("dbTbodyMontagemResumo");
  if (tbodyResumo) {
    const listResumo = Object.values(resumoMontagem).sort((a, b) => b.qtd - a.qtd);
    if (listResumo.length === 0) {
      tbodyResumo.innerHTML = `<tr><td colspan="3" data-visual-print="35c7163d3ca6" style="text-align:center;color:var(--c-ink-2);">Nenhum poste montado nesta data.</td></tr>`;
    } else {
      tbodyResumo.innerHTML = listResumo.map(item => {
        const dFmt = item.data_fabricacao !== "N/A" ? item.data_fabricacao.split("-").reverse().join("/") : "N/A";
        return `
          <tr>
            <td style="font-weight: 600;">${item.modelo}</td>
            <td style="text-align: center;">${dFmt}</td>
            <td data-visual-print="7c04d5e5e36e" style="text-align:center;color:var(--c-ink-2);font-weight:600;">${item.qtd}</td>
          </tr>
        `;
      }).join("");
    }
  }

  // Cadência de Produção (Tempo Médio por Setor)
  const targetDateForCadence = selectedDate || todayYmd();
  const cadenceEvents = apiEventsOnly.filter(ev =>
    (ev.etapa || "").toUpperCase() === "LIBERACAO" &&
    ev.dataFabricacao === targetDateForCadence &&
    ev.timestamp
  );

  const cadenceBySector = { "S1": [], "S2": [], "S3": [], "S4": [] };
  cadenceEvents.forEach(ev => {
    const s = (ev.setor || "").toLowerCase();
    if (s.includes("1")) cadenceBySector["S1"].push(ev.timestamp);
    if (s.includes("2")) cadenceBySector["S2"].push(ev.timestamp);
    if (s.includes("3")) cadenceBySector["S3"].push(ev.timestamp);
    if (s.includes("4")) cadenceBySector["S4"].push(ev.timestamp);
  });

  Object.keys(cadenceBySector).forEach(s => {
    const parsedTimes = cadenceBySector[s]
      .map(ts => new Date(ts).getTime())
      .filter(t => !isNaN(t))
      .sort((a, b) => a - b);

    let txt = "N/A";
    if (parsedTimes.length >= 2) {
      const validDiffs = [];
      for (let i = 1; i < parsedTimes.length; i++) {
        const diffMs = parsedTimes[i] - parsedTimes[i - 1];
        // Desconsidera intervalos maiores que 1 hora (3600000 ms), por exemplo almoço ou intervalos de turno
        // E também ignora diffs de 0 ms que ocorrem em cadastros simultâneos/duplicados
        if (diffMs > 0 && diffMs <= 3600000) {
          validDiffs.push(diffMs);
        }
      }

      if (validDiffs.length > 0) {
        const sumMs = validDiffs.reduce((sum, d) => sum + d, 0);
        const avgMs = sumMs / validDiffs.length;
        const avgMin = Math.round(avgMs / 60000);
        txt = avgMin > 0 ? avgMin + " min" : "< 1 min";
      } else {
        txt = "N/A (>1h int)";
      }
    } else if (parsedTimes.length === 1) {
      txt = "N/A (1 item)";
    }
    setTxt("dbCad" + s, txt);
  });

  setTxt("dbProdS1", cadenceBySector["S1"].length);
  setTxt("dbProdS2", cadenceBySector["S2"].length);
  setTxt("dbProdS3", cadenceBySector["S3"].length);
  setTxt("dbProdS4", cadenceBySector["S4"].length);

  // Last 7 working days (excluding weekends), ordered from newest to oldest
  const allDates = [];
  const baseDate = selectedDate ? new Date(selectedDate + "T12:00:00") : new Date();
  let d = new Date(baseDate);
  let count = 0;
  while (count < 7) {
    const dayOfWeek = d.getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) { // 0 = Dom, 6 = Sáb
      allDates.push(d.toISOString().split("T")[0]);
      count++;
    }
    d.setDate(d.getDate() - 1);
  }

  const labels = allDates.map((d) => d.split("-").reverse().join("/"));

  // Destroy old charts to prevent memory leaks and clean references
  destroyChart("chartProd");
  destroyChart("chartIns");
  destroyChart("chartProdSetor");
  destroyChart("chartInsSetor");
  destroyChart("chartNc");

  // Re-create chartProdTotalDia (Total Production of the Day)
  destroyChart("chartProdTotalDia");
  const ctxProdTotal = document.getElementById("chartProdTotalDia");
  if (ctxProdTotal && typeof Chart !== "undefined") {
    chartInstances["chartProdTotalDia"] = new Chart(ctxProdTotal, {
      type: "bar",
      data: {
        labels,
        datasets: [
          {
            label: "Total Produzido",
            data: allDates.map((d) => prodByDate[d] || 0),
            backgroundColor: "rgba(30, 64, 175, 0.85)",
            borderColor: "#1e40af",
            borderWidth: 2,
            borderRadius: 6,
            barPercentage: 0.65
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: "top", labels: { usePointStyle: true, boxWidth: 8, font: { weight: 'bold' } } },
          tooltip: { backgroundColor: 'rgba(15, 23, 42, 0.9)', padding: 12 },
          datalabels: {
            display: function(context) { return context.dataset.data[context.dataIndex] > 0; },
            color: '#0f172a',
            anchor: 'end',
            align: 'top',
            offset: 2,
            font: { weight: 'bold', size: 11 },
            formatter: Math.round
          }
        },
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true, grid: { color: '#f1f5f9' }, ticks: { stepSize: 1, precision: 0 }, suggestedMax: Math.max(...allDates.map((d) => prodByDate[d] || 0)) * 1.15 }
        }
      },
      plugins: [typeof ChartDataLabels !== 'undefined' ? ChartDataLabels : {}]
    });
  }

  // Re-create chartProdSetores (Production separated by each sector)
  destroyChart("chartProdSetores");
  const ctxProdSetores = document.getElementById("chartProdSetores");
  if (ctxProdSetores && typeof Chart !== "undefined") {
    chartInstances["chartProdSetores"] = new Chart(ctxProdSetores, {
      type: "bar",
      data: {
        labels,
        datasets: [
          { label: "Setor 1", data: allDates.map((d) => prodS1ByDate[d] || 0), backgroundColor: "rgba(59, 130, 246, 0.85)", borderRadius: 4 },
          { label: "Setor 2", data: allDates.map((d) => prodS2ByDate[d] || 0), backgroundColor: "rgba(16, 185, 129, 0.85)", borderRadius: 4 },
          { label: "Setor 3", data: allDates.map((d) => prodS3ByDate[d] || 0), backgroundColor: "rgba(139, 92, 246, 0.85)", borderRadius: 4 },
          { label: "Setor 4", data: allDates.map((d) => prodS4ByDate[d] || 0), backgroundColor: "rgba(249, 115, 22, 0.85)", borderRadius: 4 }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: "top", labels: { usePointStyle: true, boxWidth: 8, font: { weight: 'bold' } } },
          tooltip: { backgroundColor: 'rgba(15, 23, 42, 0.9)', padding: 12 },
          datalabels: {
            display: function(context) { return context.dataset.data[context.dataIndex] > 0; },
            color: '#ffffff',
            anchor: 'center',
            align: 'center',
            font: { weight: 'bold', size: 10 },
            formatter: Math.round
          }
        },
        scales: {
          x: { stacked: true, grid: { display: false } },
          y: { stacked: true, beginAtZero: true, grid: { color: '#f1f5f9' }, ticks: { stepSize: 1, precision: 0 }, suggestedMax: Math.max(...allDates.map((d) => prodByDate[d] || 0)) * 1.15 }
        }
      },
      plugins: [typeof ChartDataLabels !== 'undefined' ? ChartDataLabels : {}]
    });
  }

  const histEl = document.getElementById("dbHistory");
  if (!histEl) return;
  const histDates = [...allDates];
  const maxProd = histDates.reduce((m, d) => Math.max(m, prodByDate[d] || 0), 1);
  if (!histDates.length) {
    histEl.innerHTML = '<p class="muted" style="font-size:.82rem;margin:0">Nenhum registro encontrado.</p>';
    return;
  }
  histEl.innerHTML = histDates.map((d) => {
    const prod = prodByDate[d] || 0;
    const ins = (insByDate[d] || {}).total || 0;
    const rj = (insByDate[d] || { R: 0, RR: 0 }).R + (insByDate[d] || { R: 0, RR: 0 }).RR;
    const pct = Math.round((prod / maxProd) * 100);
    const fmt = d.split("-").reverse().join("/");
    return `<div class="ins-dash-hist-row">
  <span class="ins-dash-hist-date">${fmt}</span>
  <div class="ins-dash-hist-bar-track"><div class="ins-dash-hist-bar" style="width:${pct}%"></div></div>
  <span class="ins-dash-hist-count">${prod}</span>
  <span data-visual-print="72bee7c4825f" style="color:var(--c-ok);font-weight:600;font-size:.78rem;min-width:50px;">✔ ${ins}</span>
  <span data-visual-print="8049041101ae" style="color:var(--c-crit);font-weight:600;font-size:.78rem;min-width:46px;">✘ ${rj}</span>
</div>`;
  }).join("");
}

async function carregarDadosGlobaisDashboard(selectedDateOverride = "") {
  if (!hasApiConfigured()) return;

  const dbDataEl = document.getElementById("dbData");
  const selectedDate = selectedDateOverride || (dbDataEl ? dbDataEl.value : todayYmd());

  setSyncStatus("pending", "Atualizando dados globais do dashboard...");

  // Calcula o intervalo de 7 dias correspondente ao que é exibido no Dashboard
  const baseDate = selectedDate ? new Date(selectedDate + "T12:00:00") : new Date();
  const startDate = new Date(baseDate);
  startDate.setDate(baseDate.getDate() - 6);
  const startDateStr = startDate.toISOString().split("T")[0];
  const endDateStr = baseDate.toISOString().split("T")[0];

  try {
    let allRows = [];
    let page = 0;
    const pageSize = 1000;
    let keepFetching = true;

    while (keepFetching) {
      const from = page * pageSize;
      const to = from + pageSize - 1;

      const { data: rows, error } = await supabaseClient
        .from('producao')
        .select(DASHBOARD_PRODUCAO_SELECT)
        .gte('data_fabricacao', startDateStr)
        .lte('data_fabricacao', endDateStr)
        .order('data_fabricacao', { ascending: false })
        .range(from, to);

      if (error) throw error;

      if (rows && rows.length > 0) {
        allRows = allRows.concat(rows);
      }

      if (!rows || rows.length < pageSize || page >= 10) {
        keepFetching = false;
      } else {
        page++;
      }
    }

    let montagemRows = [];
    try {
      const startOfRangeISO = new Date(startDateStr + "T00:00:00-03:00").toISOString();

      const { data: mRows, error: mError } = await supabaseClient
        .from('montagem_poste')
        .select(DASHBOARD_MONTAGEM_SELECT)
        .or(`data_fabricacao.gte.${startDateStr},updated_at.gte.${startOfRangeISO}`);

      if (!mError && mRows) montagemRows = mRows;
    } catch (e) {
      console.warn("Erro ao buscar montagem_poste no Dashboard global:", e);
    }

    const db = readDb();
    db.montagemDashboardCache = montagemRows;

    const apiEvents = allRows.map(r => ({
      etapa: r.status === 'LIBERADO' ? 'LIBERACAO' : 'INSPECAO',
      status: r.status,
      dataFabricacao: r.data_fabricacao,
      setor: r.setor,
      formaNumero: r.forma,
      colaborador: r.colaborador,
      timestamp: r.data_hora || r.updated_at,
      codigos: r.ins_codigo ? [r.ins_codigo] : [],
      observacoes: r.ins_observacoes || "",
      isFromApi: true
    }));

    db.events = db.events.filter(ev => !ev.isFromApi && ev.pendingSync === true).concat(apiEvents);
    writeDb(db);

    renderDashboardCharts();
    setSyncStatus("ok", "Dashboard global atualizado com dados da nuvem.");
  } catch (err) {
    console.error("Erro ao carregar dados globais:", err);
    setSyncStatus("error", "Erro ao carregar dados globais do dashboard.");
  }
}

function renderDashboardStats() {
  const db = readDb();
  const dataInput = document.getElementById("insDashData");
  const selectedDate = dataInput ? dataInput.value : "";

  // Considerar APENAS eventos vindos do Supabase API
  const apiEventsOnly = db.events.filter(ev => ev.isFromApi === true);

  // Aggregate inspection events from local DB
  // Group by dataFabricacao, count statuses
  const byDate = {};
  apiEventsOnly.forEach((ev) => {
    const etapa = (ev.etapa || "").toUpperCase();
    if (etapa !== "INSPECAO" && etapa !== "REINSPECAO") return;
    const d = ev.dataFabricacao || "";
    if (!byDate[d]) byDate[d] = { total: 0, A: 0, R: 0, RR: 0 };
    byDate[d].total++;
    const s = (ev.status || "").toUpperCase();
    if (s === "A") byDate[d].A++;
    else if (s === "R") byDate[d].R++;
    else if (s === "RR") byDate[d].RR++;
  });

  // Summary for selected date (or all if no date)
  const summary = selectedDate && byDate[selectedDate]
    ? byDate[selectedDate]
    : Object.values(byDate).reduce((acc, v) => {
        acc.total += v.total; acc.A += v.A; acc.R += v.R; acc.RR += v.RR;
        return acc;
      }, { total: 0, A: 0, R: 0, RR: 0 });

  const rejeitados = summary.R + summary.RR;
  const rejPct = summary.total > 0 ? Math.round((rejeitados / summary.total) * 100) : 0;

  const setTxt = (id, val) => { const e = document.getElementById(id); if (e) e.textContent = val; };
  setTxt("insDashTotal", summary.total);
  setTxt("insDashAprovados", summary.A);
  setTxt("insDashRejeitados", summary.R);
  setTxt("insDashRetrabalho", summary.RR);
  setTxt("insDashRatePct", rejPct + "%");
  const rateBar = document.getElementById("insDashRateBar");
  if (rateBar) rateBar.style.width = rejPct + "%";

  // History rows (last 7 dates sorted desc)
  const histEl = document.getElementById("insDashHistory");
  if (!histEl) return;
  const dates = Object.keys(byDate).sort((a, b) => (a < b ? 1 : -1)).slice(0, 7);
  const maxTotal = dates.reduce((m, d) => Math.max(m, byDate[d].total), 1);

  if (!dates.length) {
    histEl.innerHTML = '<p class="muted" style="font-size:0.82rem;margin:0">Nenhum registro de inspeção encontrado.</p>';
    return;
  }

  histEl.innerHTML = dates.map((d) => {
    const row = byDate[d];
    const pct = Math.round((row.total / maxTotal) * 100);
    const fmt = d.split("-").reverse().join("/");
    const rj = row.R + row.RR;
    return `<div class="ins-dash-hist-row">
  <span class="ins-dash-hist-date">${fmt}</span>
  <div class="ins-dash-hist-bar-track"><div class="ins-dash-hist-bar" style="width:${pct}%"></div></div>
  <span class="ins-dash-hist-count">${row.total}</span>
  <span data-visual-print="f9e6bc4d25ee" style="color:var(--c-crit);font-size:0.78rem;min-width:46px;">× ${rj}</span>
</div>`;
  }).join("");
}

async function renderHistorico() {
  const db = readDb();
  const data = el.histData.value;
  const tipo = (el.histTipo?.value || "").trim();
  const forma = normalizeUpper(el.histForma.value);

  let rows = db.events
    .filter((event) => !data || event.dataFabricacao === data)
    .filter((event) => {
      if (!tipo) return true;
      if (tipo === "LIBERACAO") return event.etapa === "LIBERACAO";
      if (tipo === "INSPECAO") return event.etapa === "INSPECAO" || event.etapa === "REINSPECAO";
      return true;
    })
    .filter((event) => !forma || event.formaNumero === forma);

  if (hasApiConfigured() && data) {
    try {
      const [setor1, setor2, setor3, setor4] = await Promise.all([
        getRowsForDashboard(data, "Setor 1"),
        getRowsForDashboard(data, "Setor 2"),
        getRowsForDashboard(data, "Setor 3"),
        getRowsForDashboard(data, "Setor 4")
      ]);
      const apiRows = [
        ...(setor1.rows || []),
        ...(setor2.rows || []),
        ...(setor3.rows || []),
        ...(setor4.rows || [])
      ];
      const apiEvents = [];
      apiRows.forEach((row) => {
        const formaNumero = String(row.forma_numero || "");
        const setor = String(row.setor || "");
        const baseTs = row.data_hora || row.updated_at || nowIso();

        // Evitamos duplicar eventos que já existem localmente (mesma forma, setor e etapa)
        const existsLocally = (etapa) => rows.some(e => e.etapa === etapa && e.formaNumero === formaNumero && e.setor === setor);

        if (row.status === "LIBERADO" && !existsLocally("LIBERACAO")) {
          apiEvents.push({
            etapa: "LIBERACAO",
            status: "LIBERADO",
            dataFabricacao: String(row.data_fabricacao || data),
            setor,
            formaNumero,
            colaborador: String(row.colaborador || ""),
            timestamp: baseTs,
            fotosCount: 0,
            codigos: [],
            observacoes: "",
            tipoConcreto: row.tipo_concreto || "",
            isFromApi: true
          });
        }
        if (row.status === "INSPECIONADO" && !existsLocally("INSPECAO")) {
          apiEvents.push({
            etapa: "INSPECAO",
            status: "INSPECIONADO",
            dataFabricacao: String(row.data_fabricacao || data),
            setor,
            formaNumero,
            colaborador: String(row.colaborador || ""),
            timestamp: row.updated_at || baseTs,
            fotosCount: 0,
            codigos: row.ins_codigo ? [String(row.ins_codigo)] : [],
            observacoes: String(row.ins_observacoes || ""),
            tipoConcreto: row.tipo_concreto || "",
            isFromApi: true
          });
        }
      });
      rows = [...rows, ...apiEvents];
    } catch (e) {
      console.warn("Falha ao buscar histórico da API:", e);
    }
  }

  rows.sort((a, b) => (a.timestamp < b.timestamp ? 1 : -1));

  el.historicoLista.innerHTML = "";
  if (!rows.length) {
    el.historicoLista.innerHTML = '<p class="muted">Sem eventos para o filtro informado.</p>';
    return;
  }

  rows.forEach((evt) => {
    const item = document.createElement("article");
    item.className = "item";
    item.innerHTML = `
      <div class="item-main">
        <strong>${evt.etapa} • ${evt.status}</strong>
        <div class="item-meta">${evt.dataFabricacao} • ${evt.setor} • ${evt.formaNumero} ${evt.tipoConcreto ? ` • <span class="tag-concreto">${evt.tipoConcreto}</span>` : ""}</div>
        <div class="item-meta">${evt.colaborador || "-"} • ${formatDateTime(evt.timestamp)} • Fotos: ${evt.fotosCount || 0}</div>
        ${Array.isArray(evt.codigos) && evt.codigos.length ? `<div class="item-meta">Códigos: ${evt.codigos.join(", ")}</div>` : ""}
        ${evt.statusFlags ? `<div class="item-meta">1/0: L=${evt.statusFlags.liberado} D=${evt.statusFlags.naoMontado} M=${evt.statusFlags.manutencao}</div>` : ""}
        ${evt.observacoes ? `<div class="item-meta">Obs: ${evt.observacoes}</div>` : ""}
      </div>
    `;
    el.historicoLista.appendChild(item);
  });
}

function statusLabelFromCode(code) {
  if (code === "1") return "Liberado";
  if (code === "D") return "Não montado";
  if (code === "M") return "Manutenção";
  return "-";
}

function formatTime(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return String(iso);
  return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

const ACMP_NOTES_KEY = "pwa_acmp_notas_v1";
const ACMP_MASSADAS_URL = "https://dautomacao.com/api/usina/massadas";
const ACMP_PRODUTO_VOLUMES_URL = "./data/produto-volumes.json";
const ACMP_LEITURAS_QR_CSV_URL = "https://docs.google.com/spreadsheets/d/1CdQhQ0AJ4mWJqAgnP371ez4r-P7ESX5KuTHI96nI0g8/export?format=csv&gid=0";
const ACMP_MASSADA_VOLUME_PADRAO_M3 = 0.9;
const ACMP_DELAY_APLICACAO_MS = 60 * 1000;
const ACMP_TOLERANCIA_ANTES_MS = 4 * 60 * 1000;
const ACMP_TOLERANCIA_DEPOIS_MS = 6 * 60 * 1000;
let acmpVolumeCache = null;

function getAcmpNoteKey(data, setor, forma) {
  return `${data}||${setor}||${forma}`;
}

function readAcmpNotes() {
  try { return JSON.parse(localStorage.getItem(ACMP_NOTES_KEY) || "{}"); } catch { return {}; }
}

function writeAcmpNotes(notes) {
  localStorage.setItem(ACMP_NOTES_KEY, JSON.stringify(notes));
}

function showAcmpFeedback(msg, type) {
  if (!el.acmpFeedback) return;
  el.acmpFeedback.textContent = msg;
  el.acmpFeedback.className = "lib-feedback";
  el.acmpFeedback.classList.add(type === "ok" ? "feedback-ok" : "feedback-error");
  el.acmpFeedback.classList.remove("hidden");
  setTimeout(() => el.acmpFeedback.classList.add("hidden"), 3000);
}

function salvarAcmp() {
  const output = el.acmpOutput;
  if (!output) return;
  const data = el.acmpData?.value || "";
  const notes = readAcmpNotes();
  output.querySelectorAll("tr[data-acmp-forma]").forEach((tr) => {
    const forma = tr.dataset.acmpForma;
    const setor = tr.dataset.acmpSetor;
    const traco = tr.querySelector("input[data-acmp-traco]")?.value || "";
    const obs = tr.querySelector("input[data-acmp-obs]")?.value || "";
    notes[getAcmpNoteKey(data, setor, forma)] = { traco, obs };
  });
  writeAcmpNotes(notes);
  showAcmpFeedback("Dados salvos com sucesso!", "ok");
}

function imprimirAcmp() {
  window.print();
}

function normalizeAcmpText(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9]+/g, " ")
    .trim()
    .toLowerCase();
}

function normalizeAcmpCode(value) {
  if (value === null || value === undefined) return "";
  const raw = String(value).trim();
  if (!raw) return "";
  const asNumber = Number(raw);
  return Number.isFinite(asNumber) ? String(Math.trunc(asNumber)) : raw;
}

function parseAcmpTimestamp(value, dataRef = "") {
  if (!value) return null;
  const raw = String(value);
  const normalized = /^\d{2}:\d{2}(:\d{2})?$/.test(raw)
    ? `${dataRef}T${raw.length === 5 ? `${raw}:00` : raw}`
    : raw;
  const d = new Date(normalized);
  return Number.isNaN(d.getTime()) ? null : d;
}

function parseAcmpBrTimestamp(value) {
  const match = String(value || "").trim().match(/^(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2})(?::(\d{2}))?$/);
  if (!match) return null;
  const [, dd, mm, yyyy, hh, min, ss = "00"] = match;
  const d = new Date(Number(yyyy), Number(mm) - 1, Number(dd), Number(hh), Number(min), Number(ss));
  return Number.isNaN(d.getTime()) ? null : d;
}

function getAcmpLocalDateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function parseAcmpCsv(text) {
  const rows = [];
  let row = [];
  let value = "";
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    const next = text[i + 1];
    if (quoted) {
      if (ch === '"' && next === '"') {
        value += '"';
        i += 1;
      } else if (ch === '"') {
        quoted = false;
      } else {
        value += ch;
      }
      continue;
    }
    if (ch === '"') {
      quoted = true;
    } else if (ch === ",") {
      row.push(value);
      value = "";
    } else if (ch === "\n") {
      row.push(value);
      rows.push(row);
      row = [];
      value = "";
    } else if (ch !== "\r") {
      value += ch;
    }
  }
  if (value || row.length) {
    row.push(value);
    rows.push(row);
  }
  if (!rows.length) return [];
  const headers = rows.shift().map((h) => h.trim());
  return rows
    .filter((r) => r.some((v) => String(v || "").trim()))
    .map((r) => headers.reduce((acc, header, idx) => {
      acc[header] = r[idx] || "";
      return acc;
    }, {}));
}

async function loadAcmpVolumeIndex() {
  if (acmpVolumeCache) return acmpVolumeCache;
  const index = { bySetorCodigo: new Map(), byCodigo: new Map(), bySetorProduto: new Map(), byProduto: new Map() };
  try {
    const res = await fetch(ACMP_PRODUTO_VOLUMES_URL, { cache: "no-store" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const payload = await res.json();
    (payload.registros || []).forEach((item) => {
      const setor = normalizeAcmpText(item.setor);
      const codigo = normalizeAcmpCode(item.codigo_produto);
      const produto = normalizeAcmpText(item.produto);
      const volume = Number(item.volume_m3);
      if (!Number.isFinite(volume) || volume <= 0) return;
      const record = { ...item, volume_m3: volume };
      if (setor && codigo) index.bySetorCodigo.set(`${setor}||${codigo}`, record);
      if (codigo && !index.byCodigo.has(codigo)) index.byCodigo.set(codigo, record);
      if (setor && produto) index.bySetorProduto.set(`${setor}||${produto}`, record);
      if (produto && !index.byProduto.has(produto)) index.byProduto.set(produto, record);
    });
  } catch (err) {
    console.warn("Nao foi possivel carregar cadastro de volumes:", err);
  }
  acmpVolumeCache = index;
  return index;
}

function getAcmpRowCodigoProduto(row) {
  return normalizeAcmpCode(row.codigo_produto || row.codigoProduto || row.codigo_poste || row.codigoPoste);
}

function getAcmpRowProduto(row) {
  return normalizeAcmpText(
    row.descricao_poste ||
    row.descricaoPoste ||
    row.produto ||
    row.nome_produto ||
    row.nomeProduto ||
    row.modelo
  );
}

function findAcmpVolume(row, volumeIndex) {
  const setor = normalizeAcmpText(row._setor || row.setor);
  const codigo = getAcmpRowCodigoProduto(row);
  const produto = getAcmpRowProduto(row);
  if (setor && codigo && volumeIndex.bySetorCodigo.has(`${setor}||${codigo}`)) {
    return { match: volumeIndex.bySetorCodigo.get(`${setor}||${codigo}`), regra: "setor+codigo" };
  }
  if (codigo && volumeIndex.byCodigo.has(codigo)) {
    return { match: volumeIndex.byCodigo.get(codigo), regra: "codigo" };
  }
  if (setor && produto && volumeIndex.bySetorProduto.has(`${setor}||${produto}`)) {
    return { match: volumeIndex.bySetorProduto.get(`${setor}||${produto}`), regra: "setor+produto" };
  }
  if (produto && volumeIndex.byProduto.has(produto)) {
    return { match: volumeIndex.byProduto.get(produto), regra: "produto" };
  }
  return { match: null, regra: "" };
}

function getAcmpProgS3Model(data, forma) {
  if (!data || !forma || typeof window.readProgS3S4Db !== "function") return "";
  const db = window.readProgS3S4Db();
  const key = `${data}||${forma}||Setor 3`;
  return db?.programacoes?.[key]?.modelo || "";
}

async function fetchAcmpMassadas(data) {
  if (!data) return [];
  try {
    const url = `${ACMP_MASSADAS_URL}?data=${encodeURIComponent(data)}&limit=5000`;
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const payload = await res.json();
    return (payload.massadas || [])
      .map((m) => {
        const ts = parseAcmpTimestamp(m.data_hora_operacional || m.data_hora || m.hora, data);
        const qtd = Number(m.qtd);
        return {
          ...m,
          _ts: ts,
          _remaining: Number.isFinite(qtd) && qtd > 0 ? qtd : ACMP_MASSADA_VOLUME_PADRAO_M3
        };
      })
      .filter((m) => m._ts)
      .sort((a, b) => a._ts - b._ts);
  } catch (err) {
    console.warn("Nao foi possivel carregar massadas da usina:", err);
    return [];
  }
}

async function fetchAcmpLeiturasQr(data) {
  if (!data) return [];
  try {
    const res = await fetch(ACMP_LEITURAS_QR_CSV_URL, { cache: "no-store" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const rows = parseAcmpCsv(await res.text());
    return rows
      .map((r) => {
        const ts = parseAcmpBrTimestamp(r.DATAHORA);
        return {
          id: Number(r.ID),
          setor: r.QR_RAW || "",
          setorKey: normalizeAcmpText(r.QR_RAW),
          dataHora: r.DATAHORA || "",
          ts
        };
      })
      .filter((r) => r.ts && getAcmpLocalDateKey(r.ts) === data && r.setorKey)
      .sort((a, b) => (a.ts - b.ts) || ((a.id || 0) - (b.id || 0)));
  } catch (err) {
    console.warn("Nao foi possivel carregar leituras QR:", err);
    return [];
  }
}

function indexAcmpLeiturasBySetor(leituras) {
  const bySetor = new Map();
  leituras.forEach((leitura) => {
    if (!bySetor.has(leitura.setorKey)) bySetor.set(leitura.setorKey, []);
    bySetor.get(leitura.setorKey).push({ ...leitura, _used: false });
  });
  return bySetor;
}

function matchAcmpLeitura(item, leiturasBySetor) {
  const setorKey = normalizeAcmpText(item.row._setor || item.row.setor);
  const queue = leiturasBySetor.get(setorKey) || [];
  if (!queue.length) return null;
  const rowTs = item.ts.getTime();
  const minTs = rowTs - ACMP_TOLERANCIA_ANTES_MS;
  const maxTs = rowTs + ACMP_TOLERANCIA_DEPOIS_MS;
  let best = null;
  for (const leitura of queue) {
    if (leitura._used) continue;
    const ts = leitura.ts.getTime();
    if (ts < minTs) {
      leitura._used = true;
      continue;
    }
    if (ts > maxTs) break;
    const diff = Math.abs(ts - rowTs);
    if (!best || diff < best.diff) best = { leitura, diff };
  }
  if (!best) return null;
  best.leitura._used = true;
  return best.leitura;
}

function describeAcmpAllocation(allocation, volume, volumeInfo) {
  if (!allocation || !allocation.parts.length) return "Massada nao localizada";
  const ids = allocation.parts.map((part) => part.massada.numero_serie || part.massada.id).filter(Boolean);
  const formulas = [...new Set(allocation.parts.map((part) => part.massada.formula).filter(Boolean))];
  const diff = Math.round((allocation.bestDiffMs || 0) / 1000);
  const volumeTxt = Number.isFinite(volume) ? `${volume.toFixed(3).replace(".", ",")} m³` : "volume indefinido";
  const regra = volumeInfo?.regra ? ` • volume por ${volumeInfo.regra}` : "";
  const sequencia = allocation.leitura ? ` • sequência ${allocation.leitura.setor} #${allocation.leitura.id}` : "";
  const base = `Massada ${ids.join("/")} • ${volumeTxt} • Δ ${Math.abs(diff)}s${regra}${sequencia}`;
  if (allocation.parts.length > 1) return `${base} • múltiplas massadas`;
  if (formulas.length > 1) return `${base} • traços diferentes`;
  return base;
}

function allocateAcmpTracos(rows, massadas, volumeIndex, leiturasQr, data) {
  const sorted = rows
    .map((row, idx) => ({ row, idx, ts: parseAcmpTimestamp(row.lib_timestamp || row.data_hora || row.timestamp, data) }))
    .filter((item) => item.ts)
    .sort((a, b) => a.ts - b.ts);

  const suggestions = new Map();
  const leiturasBySetor = indexAcmpLeiturasBySetor(leiturasQr || []);
  sorted.forEach((item) => {
    const volumeInfo = findAcmpVolume(item.row, volumeIndex);
    const volume = Number(volumeInfo.match?.volume_m3);
    if (!Number.isFinite(volume) || volume <= 0) {
      suggestions.set(item.idx, { traco: "", obs: "Sem volume cadastrado", confidence: "sem_volume" });
      return;
    }

    let restante = volume;
    const parts = [];
    const leitura = matchAcmpLeitura(item, leiturasBySetor);
    const anchorTs = leitura ? leitura.ts.getTime() : item.ts.getTime();
    const expected = anchorTs - ACMP_DELAY_APLICACAO_MS;
    const minTs = expected - ACMP_TOLERANCIA_ANTES_MS;
    const maxTs = anchorTs + ACMP_TOLERANCIA_DEPOIS_MS;
    let bestDiffMs = null;

    for (const massada of massadas) {
      if (restante <= 0.0001) break;
      const ts = massada._ts.getTime();
      if (ts < minTs || ts > maxTs || massada._remaining <= 0.0001) continue;
      const usado = Math.min(restante, massada._remaining);
      restante -= usado;
      const diff = ts - expected;
      bestDiffMs = bestDiffMs === null || Math.abs(diff) < Math.abs(bestDiffMs) ? diff : bestDiffMs;
      parts.push({ massada, volume: usado, diffMs: diff });
    }

    if (restante > 0.0001 || !parts.length) {
      suggestions.set(item.idx, { traco: "", obs: "Massada nao localizada", confidence: "sem_massada" });
      return;
    }

    parts.forEach((part) => {
      part.massada._remaining -= part.volume;
    });

    const formulas = [...new Set(parts.map((part) => part.massada.formula).filter(Boolean))];
    const traco = formulas.length === 1 ? formulas[0] : (formulas.length > 1 ? "Misto" : "");
    suggestions.set(item.idx, {
      traco,
      obs: describeAcmpAllocation({ parts, bestDiffMs, leitura }, volume, volumeInfo),
      confidence: formulas.length > 1 ? "misto" : (leitura ? "sequencia" : "ok")
    });
  });
  return suggestions;
}

function enrichAcmpRowsFromProgS3(rows, data) {
  if (!data) return rows;
  return rows.map((row) => {
    if (row._setor !== "Setor 3" && row.setor !== "Setor 3") return row;
    const forma = row.forma_numero || row.forma || "";
    const modeloProg = getAcmpProgS3Model(data, forma);
    if (!modeloProg) return row;
    return {
      ...row,
      modelo: modeloProg,
      descricaoPoste: modeloProg,
      produto: modeloProg
    };
  });
}

async function renderAcmpConcretagem() {
  const output = el.acmpOutput;
  if (!output) return;

  const data = el.acmpData?.value || "";
  const modoCarga = el.acmpModoCarga?.value || "data";
  const setorFiltro = el.acmpSetor?.value || "";

  if (modoCarga === "data" && !data) {
    output.innerHTML = '<p class="muted">Selecione a data para carregar o relatório.</p>';
    return;
  }

  output.innerHTML = '<p class="muted">Carregando...</p>';
  const notes = readAcmpNotes();

  const setores = setorFiltro ? [setorFiltro] : ["Setor 1", "Setor 2", "Setor 3", "Setor 4"];
  const allRows = [];

  for (const setor of setores) {
    let fetched = false;
    if (hasApiConfigured()) {
      try {
        let query = supabaseClient.from('producao').select('*').eq('setor', setor);
        if (data) query = query.eq('data_fabricacao', data);

        const { data: qData, error } = await query;
        if (!error && Array.isArray(qData)) {
          let rows = qData;
          rows = rows.filter((r) => r.status === 'LIBERADO' || r.status === 'CONCRETADO');
          if (modoCarga === "pendentes") rows = rows.filter((r) => r.status !== 'INSPECIONADO');
          rows.forEach((r) => allRows.push({ ...r, _setor: setor, forma_numero: r.forma, lib_timestamp: r.data_hora }));
          fetched = true;
        }
      } catch { /* fallback local */ }
    }
    if (!fetched) {
      const db = readDb();
      db.records
        .filter((r) => r.setor === setor && r.liberacao && r.liberacao.status === "1")
        .filter((r) => modoCarga === "data" ? r.dataFabricacao === data : true)
        .filter((r) => modoCarga === "pendentes" ? (!r.inspecoes || !r.inspecoes.length) : true)
        .forEach((r) => allRows.push({
          forma_numero: r.formaNumero,
          modelo: r.modelo || "",
          descricaoPoste: r.descricaoPoste || "",
          codigoProduto: r.codigoProduto || "",
          lib_timestamp: r.liberacao.timestamp || "",
          _setor: setor,
          tipo_concreto: r.concretoTipo || ""
        }));
    }
  }

  if (!allRows.length) {
    output.innerHTML = '<p class="muted">Nenhuma forma concretada para os filtros informados.</p>';
    return;
  }

  let massadas = [];
  let leiturasQr = [];
  let volumeIndex = { bySetorCodigo: new Map(), byCodigo: new Map(), bySetorProduto: new Map(), byProduto: new Map() };
  if (data) {
    for (let i = 0; i < allRows.length; i += 1) {
      allRows[i] = enrichAcmpRowsFromProgS3([allRows[i]], data)[0];
    }
    [massadas, volumeIndex, leiturasQr] = await Promise.all([
      fetchAcmpMassadas(data),
      loadAcmpVolumeIndex(),
      fetchAcmpLeiturasQr(data)
    ]);
    const suggestions = allocateAcmpTracos(allRows, massadas, volumeIndex, leiturasQr, data);
    allRows.forEach((row, idx) => {
      row._acmpSuggestion = suggestions.get(idx) || null;
    });
  }

  const grouped = {};
  allRows.forEach((r) => {
    const s = r._setor || r.setor || "Sem Setor";
    if (!grouped[s]) grouped[s] = [];
    grouped[s].push(r);
  });

  let totalCount = 0;
  let html = "";
  Object.keys(grouped).sort().forEach((setor) => {
    const rows = grouped[setor].sort((a, b) =>
      (parseAcmpTimestamp(a.lib_timestamp || a.data_hora || a.timestamp, data)?.getTime() || 0) -
      (parseAcmpTimestamp(b.lib_timestamp || b.data_hora || b.timestamp, data)?.getTime() || 0)
    );
    totalCount += rows.length;
    const linhas = rows.map((r) => {
      const forma = r.forma_numero || "";
      const saved = notes[getAcmpNoteKey(data, setor, forma)] || {};
      const tipoConcreto = r.tipo_concreto || "";
      const suggestion = r._acmpSuggestion || {};
      const tracoValue = saved.traco || suggestion.traco || "";
      const obsValue = saved.obs || suggestion.obs || tipoConcreto;
      return `<tr data-acmp-forma="${forma}" data-acmp-setor="${setor}">
        <td>${escapeHtml(forma)}</td>
        <td>${escapeHtml(r.modelo || "")}</td>
        <td>${formatTime(r.lib_timestamp)}</td>
        <td><input type="text" class="acmp-input" data-acmp-traco placeholder="" value="${escapeHtml(tracoValue)}"></td>
        <td><input type="text" class="acmp-input" data-acmp-obs placeholder="" value="${escapeHtml(obsValue)}"></td>
      </tr>`;
    }).join("");
    html += `
      <div class="acmp-setor-grupo">
        <div class="acmp-setor-header">${setor} — ${rows.length} formas concretadas</div>
        <table class="sheet-table acmp-table">
          <thead><tr><th>Nº Forma</th><th>Modelo</th><th>Horário</th><th>Traço</th><th>Obs</th></tr></thead>
          <tbody>${linhas}</tbody>
        </table>
      </div>`;
  });

  const massadasInfo = data
    ? ` | Massadas carregadas: ${massadas.length} | Leituras QR: ${leiturasQr.length} | Traços sugeridos: ${allRows.filter((r) => r._acmpSuggestion?.traco).length}`
    : "";
  output.innerHTML = `<div class="acmp-total">Total: ${totalCount} formas concretadas | Data: ${data}${massadasInfo}</div>` + html;
}

function buildReportDataFromRows(rows) {
  const total = rows.length;
  const liberado = rows.filter((r) => String(r.liberacao_status || r.liberacaoStatus || "") === "1").length;
  const manutencao = rows.filter((r) => String(r.liberacao_status || r.liberacaoStatus || "") === "M").length;
  const naoMontado = rows.filter((r) => String(r.liberacao_status || r.liberacaoStatus || "") === "D").length;
  return { total, liberado, naoMontado, manutencao };
}

function getRowsFromLocalForDashboard(data, setor) {
  const db = readDb();
  return db.records
    .filter((r) => r.dataFabricacao === data)
    .filter((r) => r.setor === setor)
    .map((r) => ({
      forma_numero: r.formaNumero,
      modelo: r.modelo,
      liberacao_status: r.liberacao?.status || ""
    }));
}

async function getRowsForDashboard(data, setor) {
  if (!hasApiConfigured()) {
    return { rows: getRowsFromLocalForDashboard(data, setor), source: "local" };
  }

  try {
    let query = supabaseClient.from('producao').select(DASHBOARD_PRODUCAO_SELECT).eq('setor', setor).eq('data_fabricacao', data);
    const { data: rows, error } = await query;
    if (!error && Array.isArray(rows)) {
      return {
        rows: rows.map(r => ({
          ...r,
          forma_numero: r.forma,
          liberacao_status: (r.status === 'LIBERADO' || r.status === 'CONCRETADO') ? '1' : '0'
        })),
        source: "api"
      };
    }
  } catch {
    // Fallback local em caso de falha temporária da API.
  }

  return { rows: getRowsFromLocalForDashboard(data, setor), source: "local" };
}

function renderDashboardConcretagem({ setor1, setor2, setor3, setor4, source, data }) {
  const r1 = Array.isArray(setor1) ? setor1 : [];
  const r2 = Array.isArray(setor2) ? setor2 : [];
  const r3 = Array.isArray(setor3) ? setor3 : [];
  const r4 = Array.isArray(setor4) ? setor4 : [];

  const concretadasSetor1 = buildReportDataFromRows(r1).liberado;
  const concretadasSetor2 = buildReportDataFromRows(r2).liberado;
  const concretadasSetor3 = buildReportDataFromRows(r3).liberado;
  const concretadasSetor4 = buildReportDataFromRows(r4).liberado;
  const totalConcretadas = concretadasSetor1 + concretadasSetor2 + concretadasSetor3 + concretadasSetor4;

  const max = Math.max(concretadasSetor1, concretadasSetor2, concretadasSetor3, concretadasSetor4, 1);
  const width1 = Math.round((concretadasSetor1 / max) * 100);
  const width2 = Math.round((concretadasSetor2 / max) * 100);
  const width3 = Math.round((concretadasSetor3 / max) * 100);
  const width4 = Math.round((concretadasSetor4 / max) * 100);

  if (el.dashSetor1Count) el.dashSetor1Count.textContent = String(concretadasSetor1);
  if (el.dashSetor2Count) el.dashSetor2Count.textContent = String(concretadasSetor2);
  if (el.dashSetor3Count) el.dashSetor3Count.textContent = String(concretadasSetor3);
  if (el.dashSetor4Count) el.dashSetor4Count.textContent = String(concretadasSetor4);
  if (el.dashTotalCount) el.dashTotalCount.textContent = String(totalConcretadas);

  if (el.dashSetor1Meta) el.dashSetor1Meta.textContent = `${concretadasSetor1} de ${r1.length} leituras concretadas`;
  if (el.dashSetor2Meta) el.dashSetor2Meta.textContent = `${concretadasSetor2} de ${r2.length} leituras concretadas`;
  if (el.dashSetor3Meta) el.dashSetor3Meta.textContent = `${concretadasSetor3} de ${r3.length} leituras concretadas`;
  if (el.dashSetor4Meta) el.dashSetor4Meta.textContent = `${concretadasSetor4} de ${r4.length} leituras concretadas`;

  if (el.dashBarSetor1) el.dashBarSetor1.style.width = `${width1}%`;
  if (el.dashBarSetor2) el.dashBarSetor2.style.width = `${width2}%`;
  if (el.dashBarSetor3) el.dashBarSetor3.style.width = `${width3}%`;
  if (el.dashBarSetor4) el.dashBarSetor4.style.width = `${width4}%`;
  if (el.dashBarSetor1Label) el.dashBarSetor1Label.textContent = String(concretadasSetor1);
  if (el.dashBarSetor2Label) el.dashBarSetor2Label.textContent = String(concretadasSetor2);
  if (el.dashBarSetor3Label) el.dashBarSetor3Label.textContent = String(concretadasSetor3);
  if (el.dashBarSetor4Label) el.dashBarSetor4Label.textContent = String(concretadasSetor4);

  // Canvas chart for Acompanhamento
  destroyChart("chartAcmp");
  const ctxAcmp = document.getElementById("chartAcmp");
  if (ctxAcmp && typeof Chart !== "undefined") {
    chartInstances["chartAcmp"] = new Chart(ctxAcmp, {
      type: "bar",
      data: {
        labels: ["Setor 1", "Setor 2", "Setor 3", "Setor 4"],
        datasets: [{
          label: "Produzidos",
          data: [concretadasSetor1, concretadasSetor2, concretadasSetor3, concretadasSetor4],
          backgroundColor: ["#1e40af", "#059669", "#7c3aed", "#ea580c"],
          borderRadius: 10
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, ticks: { stepSize: 1, precision: 0 } } }
      }
    });
  }

  if (el.dashStatus) {
    el.dashStatus.textContent = `Painel atualizado para ${data} (${source === "api" ? "dados da planilha" : "cache local"}).`;
  }
}

async function carregarDashboardConcretagem() {
  if (!el.dashData || !el.dashStatus) return;
  if (!el.dashData?.value) {
    el.dashStatus.textContent = "Selecione uma data para atualizar o painel.";
    return;
  }

  const data = el.dashData.value;
  el.dashStatus.textContent = "Atualizando painel de concretagem...";

  const [setor1Result, setor2Result, setor3Result, setor4Result] = await Promise.all([
    getRowsForDashboard(data, "Setor 1"),
    getRowsForDashboard(data, "Setor 2"),
    getRowsForDashboard(data, "Setor 3"),
    getRowsForDashboard(data, "Setor 4")
  ]);

  const source = setor1Result.source === "api"
    && setor2Result.source === "api"
    && setor3Result.source === "api"
    && setor4Result.source === "api"
    ? "api"
    : "local";
  renderDashboardConcretagem({
    setor1: setor1Result.rows,
    setor2: setor2Result.rows,
    setor3: setor3Result.rows,
    setor4: setor4Result.rows,
    source,
    data
  });
}

function getRelatorioTimestamp(row) {
  return row.timestamp || row.data_hora || row.dataHora || row.updated_at || row.updatedAt || row.created_at || row.createdAt || "";
}

function getRelatorioLiberacaoTimestamp(row) {
  return row.liberacao_timestamp || row.liberacaoTimestamp || row.liberacao?.timestamp || "";
}

function getRelatorioProgramacaoTimestamp(row) {
  return row.programacao_timestamp || row.programacaoTimestamp || row.programacao?.timestamp || "";
}

function getRelatorioConcretagemTimestamp(row) {
  return row.concretagem_timestamp || row.concretagemTimestamp || getRelatorioTimestamp(row);
}

function getRelatorioOperador(row) {
  return row.operador || row.colaborador || row.colaboradorProducao || row.usuario || row.liberacao_colaborador || "";
}

function getRelatorioTipoConcreto(row) {
  return row.tipo_concreto || row.tipoConcreto || row.concretoTipo || "Padrão";
}

function getRelatorioModelo(row) {
  const forma = String(row.forma_numero || row.formaNumero || row.forma || "").trim().toUpperCase();
  const catalogo = getPosteFieldsForForma(forma, row.setor || "");
  if (window.PRODUCTION_MODELS_BY_FORMA?.[row.setor]?.[forma]
    && row.modelo && !/^(SC|DTB|DTBM|DTD)$/i.test(String(row.modelo).trim())) {
    return row.modelo;
  }
  return catalogo.descricaoPoste || row.modelo || row.descricaoPoste || row.descricao_poste || "Sem modelo";
}

function getRelatorioCodigoProduto(row) {
  const forma = String(row.forma_numero || row.forma || "").trim().toUpperCase();
  const catalogo = getPosteFieldsForForma(forma, row.setor || "");
  if (window.PRODUCTION_MODELS_BY_FORMA?.[row.setor]?.[forma]) {
    return row.codigo_produto || row.codigoProduto || "-";
  }
  return row.codigo_produto || row.codigoProduto || catalogo.codigoProduto || "-";
}

function getFormaStatusKey(dataFabricacao, setor, forma) {
  return `${dataFabricacao || ""}||${setor || ""}||${normalizeUpper(forma || "")}`;
}

function formatRelatorioDuracao(ms) {
  if (!Number.isFinite(ms) || ms < 0) return "-";
  const totalMin = Math.round(ms / 60000);
  const horas = Math.floor(totalMin / 60);
  const minutos = totalMin % 60;
  if (horas <= 0) return `${minutos} min`;
  return `${horas}h ${String(minutos).padStart(2, "0")}min`;
}

function calcularTempoTotalSemAlmoco(timestamps) {
  if (timestamps.length < 2) return "-";
  const sorted = [...timestamps].sort((a, b) => a - b);
  let totalMs = sorted[sorted.length - 1] - sorted[0];

  // Desconsidera intervalos de almoço/pausas (ex: diffMs >= 40 min (2400000 ms) e <= 2.5 horas (9000000 ms))
  for (let i = 1; i < sorted.length; i++) {
    const diffMs = sorted[i] - sorted[i - 1];
    if (diffMs >= 2400000 && diffMs <= 9000000) {
      totalMs -= diffMs;
    }
  }
  return formatRelatorioDuracao(totalMs);
}

function renderRelatorioSetor({ data, setor, encarregado, rows }) {
  if (!el.relatorioSetorOutput) return;

  const printOrder = [
    "1 CX VR",
    "1 CX VL",
    "2 CX VR",
    "2 CX VL",
    "3 CX VR",
    "3 CX VL",
    "4 CX VR",
    "4 CX VL",
    "2 CX VR - 300 DAN",
    "2 CX VL - 300 DAN",
    "POSTE CAIXA LENTE 1 CX VL",
    "ECON 1 CX VR",
    "ECON 1 CX VL",
    "ECON 2 CX VR",
    "ECON 3 CX VR",
    "SUB 100",
    "SUB 200",
    "SUB 200 TC",
    "SUB 100 ELEKTRO",
    "ELEKTRO 1 CX VR",
    "ELEKTRO 1 CX VL",
    "ELEKTRO 2 CX VR",
    "ELEKTRO 2 CX VL",
    "ELEKTRO 3 CX VL",
    "EDP 1 CX VL",
    "7,5X600 TC VR",
    "7,5X600 TC VL",
    "7,5X600 BARR VR",
    "7,5X600 BARR VL",
    "TOTEM MEDIÇÃO INDIRETA ELEKTRO",
    "POSTE COLUNA",
    "CEMIG 7X150 1 CX VL",
    "CEMIG 7X150 2 CX VL"
  ];
  const printOrderNormalized = printOrder.map(m => m.trim().toUpperCase());

  function getModelOrderIndex(modelo) {
    const idx = printOrderNormalized.indexOf(modelo.trim().toUpperCase());
    return idx !== -1 ? idx : 999999;
  }

  function sortSummaryList(list) {
    return list.sort((a, b) => {
      if (a.setor === "Setor 3" && b.setor === "Setor 3") {
        return b.total - a.total || a.modelo.localeCompare(b.modelo);
      }
      const idxA = getModelOrderIndex(a.modelo);
      const idxB = getModelOrderIndex(b.modelo);
      if (idxA !== 999999 || idxB !== 999999) {
        if (idxA !== idxB) {
          return idxA - idxB;
        }
      }
      if (a.setor !== b.setor) {
        return a.setor.localeCompare(b.setor);
      }
      return b.total - a.total || a.modelo.localeCompare(b.modelo);
    });
  }

  const normalizedRows = Array.isArray(rows) ? rows.slice() : [];
  const rowsOrdenadas = normalizedRows.sort((a, b) => {
    const tsA = new Date(getRelatorioTimestamp(a)).getTime();
    const tsB = new Date(getRelatorioTimestamp(b)).getTime();
    if (Number.isFinite(tsA) && Number.isFinite(tsB) && tsA !== tsB) return tsA - tsB;
    return String(a.forma_numero || a.formaNumero || "").localeCompare(String(b.forma_numero || b.formaNumero || ""), undefined, { numeric: true, sensitivity: "base" });
  });

  const emitidoEm = formatDateTime(nowIso());

  if (setor === "Todos") {
    // Calculo geral
    const timestamps = rowsOrdenadas
      .map((row) => new Date(getRelatorioTimestamp(row)).getTime())
      .filter((value) => Number.isFinite(value));
    const tempoTotal = calcularTempoTotalSemAlmoco(timestamps);

    const resumoPorPoste = rowsOrdenadas.reduce((acc, row) => {
      const modelo = getRelatorioModelo(row);
      const cod = getRelatorioCodigoProduto(row);
      const s = row.setor || "Todos";
      const key = `${s}||${modelo}||${cod}`;
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {});
    const summaryList = Object.entries(resumoPorPoste).map(([key, total]) => {
      const [s, modelo, cod] = key.split("||");
      return { setor: s, modelo, cod, total };
    });
    sortSummaryList(summaryList);
    const resumoPostesHtml = summaryList
      .map((item) => `<tr><td>${escapeHtml(item.setor)}</td><td>${escapeHtml(item.cod)}</td><td>${escapeHtml(item.modelo)}</td><td>${item.total}</td></tr>`)
      .join("");

    // Contagem por setor
    const setoresCounts = { "Setor 1": 0, "Setor 2": 0, "Setor 3": 0, "Setor 4": 0 };
    rowsOrdenadas.forEach(r => {
      const s = r.setor || "";
      if (setoresCounts[s] !== undefined) {
        setoresCounts[s]++;
      }
    });

    const setoresDisponiveis = ["Setor 1", "Setor 2", "Setor 3", "Setor 4"];

    el.relatorioSetorOutput.innerHTML = `
      <article id="relPrintDoc" class="rel-print-doc">
        <!-- PRIMEIRA PAGINA: RESUMO GERAL -->
        <div class="rel-print-page">
          <header class="rel-print-header">
            <div>
              <div class="rel-company">Concrefer</div>
              <h3>Relatório Enc. Produção - Resumo Geral</h3>
            </div>
            <div class="rel-meta">
              <span>Data: <strong>${escapeHtml(fmtDate(data) || data)}</strong></span>
              <span>Setor: <strong>Todos os Setores</strong></span>
              <span>Emitido: <strong>${escapeHtml(emitidoEm)}</strong></span>
            </div>
          </header>

          <section class="rel-kpi-grid">
            <div><span>Total de Formas Enchidas</span><strong>${rowsOrdenadas.length}</strong></div>
            <div><span>Tempo Total de Produção</span><strong>${tempoTotal}</strong></div>
            <div><span>Encarregado</span><strong>${escapeHtml(encarregado || "-")}</strong></div>
          </section>

          <!-- Indicadores Resumidos Coloridos por Setor -->
          <section class="rel-section">
            <h4>Indicadores por Setor</h4>
            <div class="rel-sector-kpis-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 12px; margin-bottom: 16px;">
              <div data-visual-print="7c2ac85804ac" style="border-left:4px solid var(--c-ink-2);background:var(--c-bg);padding:10px;border-radius:var(--r);">
                <span data-visual-print="5effb1e2d017" style="font-size:0.75rem;color:var(--c-blue);font-weight:bold;display:block;">Setor 1</span>
                <strong data-visual-print="94f351bf3b11" style="font-size:1.25rem;color:var(--c-blue);display:block;margin-top:4px;">${setoresCounts["Setor 1"]} formas</strong>
              </div>
              <div data-visual-print="820158287983" style="border-left:4px solid var(--c-ok);background:var(--c-bg);padding:10px;border-radius:var(--r);">
                <span data-visual-print="dd0b0b539d21" style="font-size:0.75rem;color:var(--c-ok);font-weight:bold;display:block;">Setor 2</span>
                <strong data-visual-print="2a1f4d7a40a6" style="font-size:1.25rem;color:var(--c-ok);display:block;margin-top:4px;">${setoresCounts["Setor 2"]} formas</strong>
              </div>
              <div data-visual-print="08fff49a4897" style="border-left:4px solid var(--c-ink-3);background:var(--c-bg);padding:10px;border-radius:var(--r);">
                <span data-visual-print="7fffd6192c4c" style="font-size:0.75rem;color:var(--c-ink-2);font-weight:bold;display:block;">Setor 3</span>
                <strong data-visual-print="456f1ff1c741" style="font-size:1.25rem;color:var(--c-blue);display:block;margin-top:4px;">${setoresCounts["Setor 3"]} formas</strong>
              </div>
              <div data-visual-print="71a748db21bb" style="border-left:4px solid var(--c-orange);background:var(--c-bg);padding:10px;border-radius:var(--r);">
                <span data-visual-print="d765296d2a9e" style="font-size:0.75rem;color:var(--c-crit);font-weight:bold;display:block;">Setor 4</span>
                <strong data-visual-print="9d826efd9246" style="font-size:1.25rem;color:var(--c-crit);display:block;margin-top:4px;">${setoresCounts["Setor 4"]} formas</strong>
              </div>
            </div>
          </section>

          <section class="rel-section rel-summary-section">
            <h4>Resumo por tipo de poste (Todos os Setores)</h4>
            <table class="sheet-table report-table rel-summary-table">
              <thead><tr><th>Setor</th><th>Cód. Prod.</th><th>Tipo de poste</th><th>Quantidade</th></tr></thead>
              <tbody>${resumoPostesHtml || '<tr><td colspan="4">Sem registros</td></tr>'}</tbody>
            </table>
          </section>

          <footer class="rel-print-footer">
            <div class="rel-sign-block">
              <span>Assinatura do encarregado de produção</span>
            </div>
          </footer>
        </div>

        <!-- QUEBRAS POR SETOR -->
        ${setoresDisponiveis.map(s => {
          const sRows = rowsOrdenadas.filter(r => r.setor === s);
          if (sRows.length === 0) return "";

          const sTimestamps = sRows
            .map((row) => new Date(getRelatorioTimestamp(row)).getTime())
            .filter((value) => Number.isFinite(value));
          const sTempoTotal = calcularTempoTotalSemAlmoco(sTimestamps);

          const sResumoPorPoste = sRows.reduce((acc, row) => {
            const modelo = getRelatorioModelo(row);
            const cod = getRelatorioCodigoProduto(row);
            const key = `${s}||${modelo}||${cod}`;
            acc[key] = (acc[key] || 0) + 1;
            return acc;
          }, {});
          const sSummaryList = Object.entries(sResumoPorPoste).map(([key, total]) => {
            const [sec, modelo, cod] = key.split("||");
            return { setor: sec, modelo, cod, total };
          });
          sortSummaryList(sSummaryList);
          const sResumoPostesHtml = sSummaryList
            .map((item) => `<tr><td>${escapeHtml(item.setor)}</td><td>${escapeHtml(item.cod)}</td><td>${escapeHtml(item.modelo)}</td><td>${item.total}</td></tr>`)
            .join("");

          const sLinhas = sRows.map((r) => {
            const forma = r.forma_numero || r.formaNumero || "";
            const modelo = getRelatorioModelo(r);
            const operador = getRelatorioOperador(r) || "-";
            const horarioProgramacao = formatTime(getRelatorioProgramacaoTimestamp(r));
            const horarioLiberacao = formatTime(getRelatorioLiberacaoTimestamp(r));
            const horarioConcretagem = formatTime(getRelatorioConcretagemTimestamp(r));
            const tipoConcreto = getRelatorioTipoConcreto(r);
            return `
              <tr>
                <td>${escapeHtml(forma)}</td>
                <td>${escapeHtml(modelo)}</td>
                <td>${escapeHtml(operador)}</td>
                <td>${escapeHtml(horarioProgramacao || "-")}</td>
                <td>${escapeHtml(horarioLiberacao)}</td>
                <td>${escapeHtml(horarioConcretagem)}</td>
                <td>${escapeHtml(tipoConcreto)}</td>
              </tr>`;
          }).join("");

          return `
            <div class="page-break" style="page-break-before: always; break-before: page; height: 1px;"></div>
            <div class="rel-print-page" style="margin-top: 24px;">
              <header class="rel-print-header">
                <div>
                  <div class="rel-company">Concrefer</div>
                  <h3>Relatório Enc. Produção - ${escapeHtml(s)}</h3>
                </div>
                <div class="rel-meta">
                  <span>Data: <strong>${escapeHtml(fmtDate(data) || data)}</strong></span>
                  <span>Setor: <strong>${escapeHtml(s)}</strong></span>
                  <span>Emitido: <strong>${escapeHtml(emitidoEm)}</strong></span>
                </div>
              </header>

              <section class="rel-kpi-grid">
                <div><span>Formas enchidas</span><strong>${sRows.length}</strong></div>
                <div><span>Tempo total de produção</span><strong>${sTempoTotal}</strong></div>
                <div><span>Encarregado</span><strong>${escapeHtml(encarregado || "-")}</strong></div>
              </section>

              <section class="rel-section">
                <h4>Formas enchidas - ${escapeHtml(s)}</h4>
                <div class="rel-table-wrap">
                  <table class="sheet-table report-table rel-full-table">
                    <thead>
                      <tr>
                        <th>Forma</th>
                        <th>Tipo de poste</th>
                        <th>Operador</th>
                        <th>PCP</th>
                        <th>Lib.</th>
                        <th>Concre.</th>
                        <th>Tipo de concreto</th>
                      </tr>
                    </thead>
                    <tbody>${sLinhas || '<tr><td colspan="7">Sem registros</td></tr>'}</tbody>
                  </table>
                </div>
              </section>

              <section class="rel-section rel-summary-section">
                <h4>Resumo por tipo de poste - ${escapeHtml(s)}</h4>
                <table class="sheet-table report-table rel-summary-table">
                  <thead><tr><th>Setor</th><th>Cód. Prod.</th><th>Tipo de poste</th><th>Quantidade</th></tr></thead>
                  <tbody>${sResumoPostesHtml || '<tr><td colspan="4">Sem registros</td></tr>'}</tbody>
                </table>
              </section>

              <footer class="rel-print-footer">
                <div class="rel-sign-block">
                  <span>Assinatura do encarregado de produção</span>
                </div>
              </footer>
            </div>
          `;
        }).join("")}
      </article>
    `;
  } else {
    // Modo tradicional (Setor único)
    const timestamps = rowsOrdenadas
      .map((row) => new Date(getRelatorioTimestamp(row)).getTime())
      .filter((value) => Number.isFinite(value));
    const tempoTotal = calcularTempoTotalSemAlmoco(timestamps);
    const resumoPorPoste = rowsOrdenadas.reduce((acc, row) => {
      const modelo = getRelatorioModelo(row);
      const cod = getRelatorioCodigoProduto(row);
      const s = row.setor || setor;
      const key = `${s}||${modelo}||${cod}`;
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {});
    const summaryList = Object.entries(resumoPorPoste).map(([key, total]) => {
      const [sec, modelo, cod] = key.split("||");
      return { setor: sec, modelo, cod, total };
    });
    sortSummaryList(summaryList);
    const resumoPostesHtml = summaryList
      .map((item) => `<tr><td>${escapeHtml(item.setor)}</td><td>${escapeHtml(item.cod)}</td><td>${escapeHtml(item.modelo)}</td><td>${item.total}</td></tr>`)
      .join("");
    const linhas = rowsOrdenadas.map((r) => {
      const forma = r.forma_numero || r.formaNumero || "";
      const modelo = getRelatorioModelo(r);
      const operador = getRelatorioOperador(r) || "-";
      const horarioProgramacao = formatTime(getRelatorioProgramacaoTimestamp(r));
      const horarioLiberacao = formatTime(getRelatorioLiberacaoTimestamp(r));
      const horarioConcretagem = formatTime(getRelatorioConcretagemTimestamp(r));
      const tipoConcreto = getRelatorioTipoConcreto(r);
      return `
        <tr>
          <td>${escapeHtml(forma)}</td>
          <td>${escapeHtml(modelo)}</td>
          <td>${escapeHtml(operador)}</td>
          <td>${escapeHtml(horarioProgramacao || "-")}</td>
          <td>${escapeHtml(horarioLiberacao)}</td>
          <td>${escapeHtml(horarioConcretagem)}</td>
          <td>${escapeHtml(tipoConcreto)}</td>
        </tr>`;
    }).join("");

    el.relatorioSetorOutput.innerHTML = `
      <article id="relPrintDoc" class="rel-print-doc">
        <header class="rel-print-header">
          <div>
            <div class="rel-company">Concrefer</div>
            <h3>Relatório Enc. Produção</h3>
          </div>
          <div class="rel-meta">
            <span>Data: <strong>${escapeHtml(fmtDate(data) || data)}</strong></span>
            <span>Setor: <strong>${escapeHtml(setor)}</strong></span>
            <span>Emitido: <strong>${escapeHtml(emitidoEm)}</strong></span>
          </div>
        </header>

        <section class="rel-kpi-grid">
          <div><span>Formas enchidas</span><strong>${rowsOrdenadas.length}</strong></div>
          <div><span>Tempo total de produção</span><strong>${tempoTotal}</strong></div>
          <div><span>Encarregado</span><strong>${escapeHtml(encarregado || "-")}</strong></div>
        </section>

        <section class="rel-section">
          <h4>Formas enchidas</h4>
          <div class="rel-table-wrap">
            <table class="sheet-table report-table rel-full-table">
              <thead>
                <tr>
                  <th>Forma</th>
                  <th>Tipo de poste</th>
                  <th>Operador</th>
                  <th>PCP</th>
                  <th>Lib.</th>
                  <th>Concre.</th>
                  <th>Tipo de concreto</th>
                </tr>
              </thead>
              <tbody>${linhas || '<tr><td colspan="7">Sem registros</td></tr>'}</tbody>
            </table>
          </div>
        </section>

        <section class="rel-section rel-summary-section">
          <h4>Resumo por tipo de poste</h4>
          <table class="sheet-table report-table rel-summary-table">
            <thead><tr><th>Setor</th><th>Cód. Prod.</th><th>Tipo de poste</th><th>Quantidade</th></tr></thead>
            <tbody>${resumoPostesHtml || '<tr><td colspan="4">Sem registros</td></tr>'}</tbody>
          </table>
        </section>

        <footer class="rel-print-footer">
          <div class="rel-sign-block">
            <span>Assinatura do encarregado de produção</span>
          </div>
        </footer>
      </article>
    `;
  }
}

function imprimirRelatorioSetor() {
  if (!document.getElementById("relPrintDoc")) {
    showMsgBox("Gere o relatório antes de imprimir ou salvar em PDF.", "error");
    return;
  }
  document.body.classList.add("print-relatorio");
  window.print();
  setTimeout(() => document.body.classList.remove("print-relatorio"), 500);
}

function loadHtml2Pdf() {
  return new Promise((resolve, reject) => {
    if (window.html2pdf) return resolve(window.html2pdf);
    const script = document.createElement("script");
    script.src = "/unificado/vendor/html2pdf/html2pdf.bundle.min.js";
    script.onload = () => resolve(window.html2pdf);
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

async function enviarRelatorioWhatsapp() {
  const element = document.getElementById("relPrintDoc");
  if (!element) {
    showMsgBox("Gere o relatório antes de enviar.", "error");
    return;
  }

  const data = el.relData.value;
  const setor = el.relSetor.value;
  const encarregado = el.relEncarregado.value.trim() || "Não informado";

  // Buscar kpis e totais do relatório
  const totalFormas = element.querySelector(".rel-kpi-grid div:nth-child(1) strong")?.textContent || "0";
  const tempoTotal = element.querySelector(".rel-kpi-grid div:nth-child(2) strong")?.textContent || "-";

  // Resumo por tipo
  let resumoTexto = "";
  const rowsResumo = element.querySelectorAll(".rel-summary-table tbody tr");
  rowsResumo.forEach(r => {
    const cols = r.querySelectorAll("td");
    if (cols.length >= 2) {
      resumoTexto += `• ${cols[0].textContent}: ${cols[1].textContent}\n`;
    }
  });

  const standardMsg = `Envio automático de relatório de Produção Setor ${setor}`;
  const textMsg = `${standardMsg}\n\n*RELATÓRIO ENCARREGADO DE PRODUÇÃO*\n\n*Setor:* ${setor}\n*Data:* ${fmtDate(data) || data}\n*Encarregado:* ${encarregado}\n*Formas Enchidas:* ${totalFormas}\n*Tempo Total:* ${tempoTotal}\n\n*Resumo por Tipo:*\n${resumoTexto}`;

  setSyncStatus("pending", "Gerando PDF do relatório...");
  try {
    const html2pdf = await loadHtml2Pdf();
    const opt = {
      margin: 10,
      filename: `Envio_automatico_de_relatorio_de_Producao_Setor_${setor.replace(/\s+/g, '_')}_${data}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    const pdfBlob = await html2pdf().set(opt).from(element).output('blob');
    const file = new File([pdfBlob], opt.filename, { type: 'application/pdf' });

    setSyncStatus("ok", "PDF gerado.");

    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({
        files: [file],
        title: standardMsg,
        text: textMsg
      });
    } else {
      // Baixar PDF localmente e redirecionar para whatsapp
      html2pdf().set(opt).from(element).save();
      const instructionMsg = `${textMsg}\n\n_O PDF foi baixado para o seu aparelho. Envie-o no chat do WhatsApp a seguir._`;
      window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(instructionMsg)}`, '_blank');
    }
  } catch (err) {
    console.error("Erro ao gerar/enviar PDF:", err);
    setSyncStatus("error", "Erro ao gerar PDF.");
    // Fallback: abrir whatsapp somente com o texto se falhar
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(textMsg)}`, '_blank');
  }
}

function readMandrilModelosProduzidos() {
  try {
    const parsed = JSON.parse(localStorage.getItem(MANDRIL_MODELOS_PRODUZIDOS_KEY) || "{}");
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    const normalized = {};
    Object.entries(parsed).forEach(([key, entry]) => {
      const [date, forma] = key.split("||");
      const canonicalKey = date && forma ? getMandrilModeloKey(date, forma) : key;
      if (!normalized[canonicalKey] || String(entry?.updatedAt || "") >= String(normalized[canonicalKey]?.updatedAt || "")) {
        normalized[canonicalKey] = entry;
      }
    });
    return normalized;
  } catch {
    return {};
  }
}

function writeMandrilModelosProduzidos(data) {
  localStorage.setItem(MANDRIL_MODELOS_PRODUZIDOS_KEY, JSON.stringify(data));
}

function getMandrilModeloKey(dataFabricacao, forma) {
  return `${dataFabricacao}||${normalizeMandrilForma(forma)}`;
}

function normalizeMandrilForma(forma) {
  const normalized = normalizeUpper(forma).replace(/[\s-]/g, "");
  const match = normalized.match(/^SC0*(\d+)$/);
  return match ? `SC${String(Number(match[1])).padStart(2, "0")}` : normalized;
}

function getMandrilModeloEntry(data, dataFabricacao, forma) {
  return data[getMandrilModeloKey(dataFabricacao, forma)];
}

function getMandrilModeloSalvo(data, dataFabricacao, forma) {
  const entry = getMandrilModeloEntry(data, dataFabricacao, forma);
  return typeof entry === "string" ? entry : (entry?.modelo || "");
}

function getMandrilModelosPermitidos(forma) {
  const modelos = typeof window.getModelosForFormaS3 === "function"
    ? window.getModelosForFormaS3(normalizeMandrilForma(forma))
    : [];
  return modelos.filter(Boolean);
}

function renderMandrilModeloSelect(forma, modeloSelecionado, concretada, producaoId = "", pendingSync = false, saqueRegistrado = false) {
  if (!concretada) {
    return '<span class="mc-modelo-aguardando">Disponível após concretagem</span>';
  }

  const modelosPermitidos = getMandrilModelosPermitidos(forma);
  const selecionadoValido = modelosPermitidos.find((modelo) => normalizeProductionModelKey(modelo) === normalizeProductionModelKey(modeloSelecionado)) || "";
  const options = modelosPermitidos.map((modelo) => (
    `<option value="${escapeHtml(modelo)}"${modelo === selecionadoValido ? " selected" : ""}>${escapeHtml(modelo)}</option>`
  )).join("");

  return `
    <div class="mc-modelo-field">
      <select class="mc-modelo-select" data-mc-forma="${escapeHtml(forma)}" data-mc-producao-id="${escapeHtml(producaoId)}" aria-label="Modelo produzido na forma ${escapeHtml(forma)}"${saqueRegistrado ? " disabled" : ""}>
        <option value="" disabled${selecionadoValido ? "" : " selected"}>Selecione o produzido</option>
        ${options}
      </select>
      <span class="mc-modelo-status${pendingSync ? " is-local" : ""}" aria-live="polite">${pendingSync ? "Pendente de sincronização" : ""}</span>
    </div>
  `;
}

async function persistirMandrilModeloNaConcretagem(dataFabricacao, forma, modelo, producaoId = "") {
  const formaCanonica = normalizeMandrilForma(forma);
  let id = producaoId;
  if (!id) {
    const { data: rows, error } = await supabaseClient.from("producao")
      .select("id")
      .eq("data_fabricacao", dataFabricacao)
      .eq("setor", "Setor 3")
      .eq("forma", formaCanonica)
      .eq("status", "LIBERADO")
      .order("data_hora", { ascending: false, nullsFirst: false })
      .limit(1);
    if (error) throw error;
    id = rows?.[0]?.id;
  }
  if (!id) throw new Error(`Concretagem da forma ${formaCanonica} não encontrada no banco.`);

  const product = getProductionPosteFields(formaCanonica, "Setor 3", modelo);
  const { data: updatedRows, error } = await supabaseClient.from("producao")
    .update({
      modelo,
      descricao_poste: product.descricaoPoste || modelo,
      codigo_produto: product.codigoProduto || null
    })
    .eq("id", id)
    .eq("data_fabricacao", dataFabricacao)
    .eq("setor", "Setor 3")
    .eq("status", "LIBERADO")
    .select("id,modelo,descricao_poste,codigo_produto");
  if (error) throw error;
  const saved = updatedRows?.[0];
  if (!saved || normalizeProductionModelKey(saved.modelo) !== normalizeProductionModelKey(modelo)) {
    throw new Error(`O modelo da forma ${formaCanonica} não foi confirmado no banco.`);
  }
  return saved;
}

async function sincronizarMandrilModelosPendentes(selectedDate, rows = []) {
  if (!hasApiConfigured() || !navigator.onLine) return;
  const savedData = readMandrilModelosProduzidos();
  const rowsByForma = new Map(rows.map(row => [normalizeMandrilForma(row.forma), row]));
  const pendingEntries = Object.entries(savedData).filter(([key, entry]) => {
    if (!key.startsWith(`${selectedDate}||`)) return false;
    const forma = key.split("||")[1] || "";
    const modelo = typeof entry === "string" ? entry : entry?.modelo;
    const row = rowsByForma.get(forma);
    return modelo && (entry?.pendingSync || (row && (!row.modelo || normalizeUpper(row.modelo) === "SC")));
  });
  if (!pendingEntries.length) return;

  await Promise.all(pendingEntries.map(async ([key, entry]) => {
    const forma = key.split("||")[1] || "";
    const modelo = typeof entry === "string" ? entry : entry.modelo;
    const modeloPermitido = getMandrilModelosPermitidos(forma)
      .find(option => normalizeProductionModelKey(option) === normalizeProductionModelKey(modelo));
    if (!modeloPermitido) return;
    const row = rowsByForma.get(forma);
    try {
      const saved = await persistirMandrilModeloNaConcretagem(selectedDate, forma, modeloPermitido, row?.id || entry?.producaoId || "");
      savedData[key] = { modelo: modeloPermitido, producaoId: saved.id, pendingSync: false, updatedAt: entry?.updatedAt || new Date().toISOString() };
      if (row) {
        row.modelo = saved.modelo;
        row.codigo_produto = saved.codigo_produto;
        row.descricao_poste = saved.descricao_poste;
      }
    } catch (err) {
      savedData[key] = { modelo, producaoId: row?.id || entry?.producaoId || "", pendingSync: true, updatedAt: entry?.updatedAt || new Date().toISOString() };
      console.warn(`Sincronização pendente do modelo da forma ${forma}:`, err);
    }
  }));
  writeMandrilModelosProduzidos(savedData);
}

async function salvarMandrilModeloProduzido(select) {
  const selectedDate = el.mcFiltroData?.value;
  const forma = normalizeMandrilForma(select?.dataset?.mcForma || "");
  const modelo = select?.value || "";
  const status = select?.closest(".mc-modelo-field")?.querySelector(".mc-modelo-status");
  if (!selectedDate || !forma || !modelo) return false;
  if (!getMandrilModelosPermitidos(forma).includes(modelo)) {
    showMsgBox(`O modelo ${modelo} não é permitido para a forma ${forma}.`, "error");
    return false;
  }
  select.disabled = true;
  if (status) {
    status.textContent = "Salvando no banco...";
    status.className = "mc-modelo-status is-saving";
  }
  let saved;
  if (hasApiConfigured() && navigator.onLine) {
    try {
      saved = await persistirMandrilModeloNaConcretagem(
        selectedDate, forma, modelo, select.dataset.mcProducaoId || "");
    } catch (error) {
      console.error(`Erro ao salvar modelo produzido da forma ${forma}:`, error);
    }
  }
  select.disabled = false;
  if (!saved) {
    if (status) {
      status.textContent = "Modelo não salvo; saque não registrado";
      status.className = "mc-modelo-status is-local";
    }
    setSyncStatus("error", `Não foi possível confirmar o modelo da forma ${forma} no banco.`);
    return false;
  }
  const savedData = readMandrilModelosProduzidos();
  savedData[getMandrilModeloKey(selectedDate, forma)] = {
    modelo, producaoId: saved.id, pendingSync: false, updatedAt: new Date().toISOString()
  };
  writeMandrilModelosProduzidos(savedData);
  select.dataset.mcProducaoId = saved.id;
  const product = getProductionPosteFields(forma, "Setor 3", modelo);
  const db = readDb();
  let localChanged = false;
  db.records.forEach((record) => {
    if (record.dataFabricacao === selectedDate && record.setor === "Setor 3" &&
        normalizeMandrilForma(record.formaNumero || "") === forma) {
      record.modelo = modelo;
      record.descricaoPoste = product.descricaoPoste || modelo;
      record.codigoProduto = product.codigoProduto || "";
      record.updatedAt = new Date().toISOString();
      localChanged = true;
    }
  });
  if (localChanged) writeDb(db);
  if (status) {
    status.textContent = "Salvo no banco";
    status.className = "mc-modelo-status is-saved";
  }
  return true;
}

const SAQUE_MANDRIL_API = "https://pcp.concretrack.com.br/api/saques-mandril";
const SAQUE_MANDRIL_MIGRATED_KEY = "pwa_saque_mandril_db_migrated_v2";

function lerSaquesMandrilLocais() {
  try { return JSON.parse(localStorage.getItem("pwa_saque_mandril_v1") || "{}"); }
  catch (_) { return {}; }
}

function mostrarEstadoSaquesMandril(mensagem, erro = false) {
  const status = document.getElementById("mcSaqueStatus");
  if (!status) return;
  status.textContent = mensagem;
  status.style.color = erro ? "#b91c1c" : "#15803d";
}

async function buscarSaquesMandril(data) {
  const response = await fetch(`${SAQUE_MANDRIL_API}?data=${encodeURIComponent(data)}`, { cache: "no-store" });
  if (!response.ok) throw new Error(`Falha ao consultar saques: HTTP ${response.status}`);
  const rows = await response.json();
  if (!Array.isArray(rows)) throw new Error("Resposta inesperada da consulta de saques");
  return Object.fromEntries(rows.map(row => [`${row.data}||${normalizeForma(row.codigo_forma)}`, row.data_hora_saque]));
}

async function sincronizarSaquesMandrilLocais(data, saquesBanco) {
  let migrados = {};
  try { migrados = JSON.parse(localStorage.getItem(SAQUE_MANDRIL_MIGRATED_KEY) || "{}"); }
  catch (_) { migrados = {}; }
  const locais = lerSaquesMandrilLocais();
  // A versão anterior já importou esses registros; não recriar saques removidos em outro aparelho.
  if (localStorage.getItem("pwa_saque_mandril_db_migrated_v1") === "1"
      && !localStorage.getItem(SAQUE_MANDRIL_MIGRATED_KEY)) {
    Object.entries(locais).forEach(([key, timestamp]) => { migrados[key] = timestamp; });
  }
  Object.entries(locais).forEach(([key, timestamp]) => {
    const [dia, codigoForma] = key.split("||");
    if (dia === data && saquesBanco[`${dia}||${normalizeForma(codigoForma)}`]) migrados[key] = timestamp;
  });
  localStorage.setItem(SAQUE_MANDRIL_MIGRATED_KEY, JSON.stringify(migrados));
  const pendentes = Object.entries(locais).flatMap(([key, timestamp]) => {
    const [dia, codigoForma] = key.split("||");
    const forma = normalizeForma(codigoForma || "");
    if (dia !== data || !/^SC\d{1,2}$/.test(forma) || isNaN(Date.parse(timestamp)) || migrados[key]) return [];
    return [{ data: dia, codigo_forma: codigoForma, data_hora_saque: timestamp, localKey: key }];
  });
  if (!pendentes.length) return saquesBanco;
  const response = await fetch(`${SAQUE_MANDRIL_API}/importar`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ registros: pendentes.map(({ localKey, ...registro }) => registro) }),
  });
  if (!response.ok) throw new Error(`Falha ao sincronizar saques locais: HTTP ${response.status}`);
  const atualizados = await buscarSaquesMandril(data);
  pendentes.forEach(({ localKey, data_hora_saque, codigo_forma }) => {
    if (atualizados[`${data}||${normalizeForma(codigo_forma)}`]) migrados[localKey] = data_hora_saque;
  });
  localStorage.setItem(SAQUE_MANDRIL_MIGRATED_KEY, JSON.stringify(migrados));
  return atualizados;
}

function renderAcaoSaqueMandril(forma, timestamp) {
  if (!timestamp) return `<button onclick="window.registrarSaque('${forma}')" style="padding: 6px 12px; font-size: 0.8rem; background: var(--accent); color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; transition: background 0.2s; box-shadow: 0 2px 6px rgba(232, 118, 42, 0.2);" onmouseover="this.style.background="var(--accent-dark)"" onmouseout="this.style.background="var(--accent)"">Sacar Mandril</button>`;
  const hora = new Date(timestamp).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  return `<div style="display: flex; align-items: center; justify-content: center; gap: 8px;">
    <span data-visual-print="8fded34d4505" style="color:var(--c-ok);font-weight:bold;background:var(--c-line);padding:4px 10px;border-radius:var(--r);font-size:0.85rem;border:1px solid var(--c-line);">Saque: ${hora}</span>
    <button onclick="window.limparSaque('${forma}')" style="background: none; border: none; color: var(--danger); cursor: pointer; font-size: 1.1rem; padding: 0;" title="Limpar Saque">×</button>
  </div>`;
}

async function atualizarSaquesMandrilVisiveis() {
  if (document.hidden || el.viewMandrilCircular?.classList.contains("hidden")) return;
  const data = el.mcFiltroData?.value;
  if (!data) return;
  try {
    let saques = await buscarSaquesMandril(data);
    let pendencias = false;
    try { saques = await sincronizarSaquesMandrilLocais(data, saques); }
    catch (error) { console.warn("Saques locais ainda não sincronizados:", error); pendencias = true; }
    if (data !== el.mcFiltroData?.value) return;
    el.mcTabelaBody.querySelectorAll("[data-mc-saque-forma]").forEach(cell => {
      const forma = cell.dataset.mcSaqueForma;
      const saque = saques[`${data}||${normalizeForma(forma)}`];
      const select = cell.closest("tr")?.querySelector(".mc-modelo-select");
      if (select) select.disabled = Boolean(saque);
      cell.innerHTML = cell.dataset.mcConcretado === "1" || saque
        ? renderAcaoSaqueMandril(forma, saque)
        : `<span style="color: var(--muted); font-size: 0.85rem;">Aguardando Concretagem</span>`;
    });
    mostrarEstadoSaquesMandril(pendencias
      ? "Saques antigos deste aparelho pendentes de sincronização."
      : `Saques sincronizados às ${new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`, pendencias);
  } catch (error) {
    console.warn("Não foi possível atualizar os saques do mandril:", error);
    mostrarEstadoSaquesMandril("Sem conexão com os saques; confira antes de registrar outro saque.", true);
  }
}

setInterval(atualizarSaquesMandrilVisiveis, 30000);

async function carregarMandrilCircular() {
  const selectedDate = el.mcFiltroData?.value;
  if (!selectedDate) {
    el.mcTabelaBody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 30px; color: var(--muted); font-size: 1.05rem;">Selecione uma data para carregar os dados.</td></tr>`;
    el.mcQtdItens.textContent = "0";
    return;
  }

  el.mcTabelaBody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 20px; color: var(--muted);">Carregando dados...</td></tr>`;
  el.mcQtdItens.textContent = "0";

  // Sync Supabase data to local database first
  try {
    await loadClickedFormsFromSupabase(selectedDate);
  } catch (err) {
    console.warn("Erro ao sincronizar fôrmas do servidor para Mandril Circular:", err);
  }

  // 1. Fetch programmed models from PCP
  let formToModelMap = {};
  try {
    formToModelMap = await fetchSetor3Models(selectedDate);
  } catch (err) {
    console.warn("Erro ao buscar modelos do PCP para Mandril Circular:", err);
  }

  let rows = [];

  // 2. Fetch concreted shapes for Sector 3
  if (hasApiConfigured()) {
    try {
      const { data: dbRows, error } = await supabaseClient
        .from('producao')
        .select('*')
        .eq('data_fabricacao', selectedDate)
        .eq('setor', 'Setor 3')
        .eq('status', 'LIBERADO');

      if (error) throw error;

      if (Array.isArray(dbRows)) {
        rows = dbRows.map(r => ({
          id: r.id || "",
          forma: r.forma || r.forma_numero,
          modelo: r.modelo,
          data_hora: r.data_hora || r.updated_at || r.created_at,
          tipo_concreto: r.tipo_concreto || r.tipoConcreto || r.concretoTipo
        }));
      }
    } catch (err) {
      console.error("Erro ao buscar no servidor, tentando local...", err);
    }
  }

  // 3. Fallback to offline if online returned empty or failed
  if (rows.length === 0) {
    const db = readDb();
    if (db && Array.isArray(db.records)) {
      const localRows = db.records
        .filter(r => r.dataFabricacao === selectedDate)
        .filter(r => r.setor === 'Setor 3')
        .filter(r => String(r.status || r.liberacao?.status) === 'LIBERADO' || String(r.liberacao?.status) === '1');

      rows = localRows.map(r => ({
        forma: r.formaNumero,
        modelo: r.modelo,
        data_hora: r.liberacao?.timestamp || r.updatedAt || r.createdAt,
        tipo_concreto: r.concretoTipo
      }));
    }
  }

  // 4. Deduplicate shapes by shape name
  const seenFormas = new Set();
  const uniqueRows = [];
  rows.forEach(r => {
    const fn = normalizeForma(r.forma || "");
    if (!seenFormas.has(fn)) {
      seenFormas.add(fn);
      uniqueRows.push(r);
    }
  });

  await sincronizarMandrilModelosPendentes(selectedDate, uniqueRows);

  // Create lookup maps for quick checking
  const concretedLookup = {};
  uniqueRows.forEach(r => {
    concretedLookup[normalizeForma(r.forma || "")] = r;
  });

  // 5. Generate list of shapes (SC01 to SC52)
  const allS3Forms = [];
  for (let i = 1; i <= 52; i++) {
    allS3Forms.push(`SC${String(i).padStart(2, '0')}`);
  }

  // O banco é a fonte compartilhada; registros antigos locais são enviados quando faltam nele.
  let saqueData = {};
  try {
    saqueData = await buscarSaquesMandril(selectedDate);
    let pendencias = false;
    try { saqueData = await sincronizarSaquesMandrilLocais(selectedDate, saqueData); }
    catch (error) { console.warn("Saques locais ainda não sincronizados:", error); pendencias = true; }
    mostrarEstadoSaquesMandril(pendencias
      ? "Saques antigos deste aparelho pendentes de sincronização."
      : `Saques sincronizados às ${new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`, pendencias);
  } catch (error) {
    console.warn("Não foi possível consultar os saques do mandril:", error);
    mostrarEstadoSaquesMandril("Sem conexão com os saques; tente atualizar a página.", true);
  }

  const modelosProduzidosData = readMandrilModelosProduzidos();

  let htmlTable = "";
  let totalConcretados = 0;

  allS3Forms.forEach(forma => {
    const fn = normalizeForma(forma);
    const concretedRow = concretedLookup[fn];
    const programmedModel = formToModelMap[fn] || "--";
    const savedEntry = getMandrilModeloEntry(modelosProduzidosData, selectedDate, forma);
    const modeloPersistido = getMandrilModeloSalvo(modelosProduzidosData, selectedDate, forma);
    const modeloDoRegistro = concretedRow?.modelo && concretedRow.modelo !== "SC" ? concretedRow.modelo : "";
    const modeloSelecionado = savedEntry?.pendingSync ? modeloPersistido : (modeloDoRegistro || modeloPersistido);

    let tipoConcreto = "--";
    let horaConcretado = "--:--";
    let previsaoSaque = "--:--";
    let actionHtml = "";

    const savedIso = saqueData[`${selectedDate}||${fn}`];
    if (concretedRow) {
      totalConcretados++;
      tipoConcreto = concretedRow.tipo_concreto || "Concreto Padrão";
      if (concretedRow.data_hora) {
        try {
          const d = new Date(concretedRow.data_hora);
          if (!isNaN(d.getTime())) {
            horaConcretado = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

            // Previsão de Saque = Concretado + 3 horas
            const dSaque = new Date(d.getTime());
            dSaque.setHours(dSaque.getHours() + 3);
            previsaoSaque = dSaque.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
          }
        } catch (e) {}
      }

      actionHtml = renderAcaoSaqueMandril(forma, savedIso);
    } else if (savedIso) {
      actionHtml = renderAcaoSaqueMandril(forma, savedIso);
    } else {
      actionHtml = `<span style="color: var(--muted); font-size: 0.85rem;">Aguardando Concretagem</span>`;
    }

    htmlTable += `
      <tr style="border-bottom: 1px solid var(--line); transition: background 0.2s;">
        <td data-label="Nº Forma" style="padding: 12px 16px;"><strong class="mc-forma-numero">${forma}</strong></td>
        <td data-label="Poste Programado" style="padding: 12px 16px;">${escapeHtml(programmedModel)}</td>
        <td data-label="Modelo Produzido" style="padding: 12px 16px;">${renderMandrilModeloSelect(forma, modeloSelecionado, Boolean(concretedRow), concretedRow?.id || "", Boolean(savedEntry?.pendingSync || (modeloPersistido && !modeloDoRegistro)), Boolean(savedIso))}</td>
        <td data-label="Tipo de Concreto" style="padding: 12px 16px;">${escapeHtml(tipoConcreto)}</td>
        <td data-label="Concretado às" style="padding: 12px 16px;">${horaConcretado}</td>
        <td data-label="Saque previsto (+3h)" data-visual-print="9b7e652033aa" style="padding:12px 16px;color:var(--c-warn);font-weight:bold;">${previsaoSaque}</td>
        <td data-label="Ação / Saque Realizado" data-mc-saque-forma="${forma}" data-mc-concretado="${concretedRow ? "1" : "0"}" style="padding: 12px 16px; text-align: center;">${actionHtml}</td>
      </tr>
    `;
  });

  el.mcTabelaBody.innerHTML = htmlTable;
  el.mcTabelaBody.querySelectorAll(".mc-modelo-select").forEach((select) => {
    select.addEventListener("change", () => {
      const status = select.closest(".mc-modelo-field")?.querySelector(".mc-modelo-status");
      if (status) status.textContent = "Será salvo ao sacar o mandril";
    });
  });
  el.mcQtdItens.textContent = totalConcretados;
}

window.registrarSaque = async function(forma) {
  const selectedDate = el.mcFiltroData?.value;
  if (!selectedDate) return;
  const select = el.mcTabelaBody?.querySelector(`.mc-modelo-select[data-mc-forma="${normalizeMandrilForma(forma)}"]`);
  if (!select?.value) {
    showMsgBox(`Selecione o modelo produzido na forma ${forma} antes de sacar o mandril.`, "error");
    select?.focus();
    return;
  }
  if (!await salvarMandrilModeloProduzido(select)) {
    showMsgBox("Não foi possível confirmar o produto produzido. O saque não foi registrado.", "error");
    return;
  }
  const timestamp = new Date().toISOString();
  try {
    const response = await fetch(SAQUE_MANDRIL_API, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ data: selectedDate, codigo_forma: forma, data_hora_saque: timestamp }),
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
  } catch (error) {
    showMsgBox("O produto foi salvo, mas o saque não. Tente registrar o saque novamente.", "error");
    return;
  }
  const data = lerSaquesMandrilLocais();
  const key = `${selectedDate}||${normalizeForma(forma)}`;
  data[key] = timestamp;
  localStorage.setItem("pwa_saque_mandril_v1", JSON.stringify(data));
  let migrados = {};
  try { migrados = JSON.parse(localStorage.getItem(SAQUE_MANDRIL_MIGRATED_KEY) || "{}"); } catch (_) {}
  migrados[key] = timestamp;
  localStorage.setItem(SAQUE_MANDRIL_MIGRATED_KEY, JSON.stringify(migrados));
  carregarMandrilCircular();
};

window.limparSaque = async function(forma) {
  const selectedDate = el.mcFiltroData?.value;
  if (!selectedDate) return;
  try {
    const query = new URLSearchParams({ data: selectedDate, codigo_forma: forma });
    const response = await fetch(`${SAQUE_MANDRIL_API}?${query}`, { method: "DELETE" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
  } catch (error) {
    showMsgBox("Não foi possível remover o saque do banco. Tente novamente.", "error");
    return;
  }
  const data = lerSaquesMandrilLocais();
  const key = `${selectedDate}||${normalizeForma(forma)}`;
  delete data[key];
  localStorage.setItem("pwa_saque_mandril_v1", JSON.stringify(data));
  let migrados = {};
  try { migrados = JSON.parse(localStorage.getItem(SAQUE_MANDRIL_MIGRATED_KEY) || "{}"); } catch (_) {}
  delete migrados[key];
  localStorage.setItem(SAQUE_MANDRIL_MIGRATED_KEY, JSON.stringify(migrados));
  carregarMandrilCircular();
};

async function gerarRelatorioSetor() {
  const data = el.relData.value;
  const setor = el.relSetor.value;
  const encarregado = getReportManagerName();

  if (!data || !setor) {
    showMsgBox("Informe data e setor para gerar o relatório.", "error");
    return;
  }

  let formToModelMap = {};
  if (setor === "Todos" || setor === "Setor 3" || setor === "Setor 4") {
    try {
      formToModelMap = await fetchSetor3Models(data);
    } catch (err) {
      console.warn("Erro ao carregar modelos reais do pcp para o relatório:", err);
    }
  }

  if (hasApiConfigured()) {
    try {
      let query = supabaseClient.from('producao').select('*').eq('data_fabricacao', data);
      if (setor !== "Todos") {
        query = query.eq('setor', setor);
      }
      const { data: rows, error } = await query;

      if (!error && Array.isArray(rows)) {
        let programacaoMap = new Map();
        let liberacaoMap = new Map();
        try {
          let progQuery = supabaseClient.from('programacao_pcp').select('data_fabricacao,setor,forma,data_hora').eq('data_fabricacao', data);
          let libQuery = supabaseClient.from('liberacao_formas').select('data_fabricacao,setor,forma,data_hora,colaborador').eq('data_fabricacao', data);
          if (setor !== "Todos") {
            progQuery = progQuery.eq('setor', setor);
            libQuery = libQuery.eq('setor', setor);
          }
          const [progRes, libRes] = await Promise.all([progQuery, libQuery]);
          if (!progRes.error && Array.isArray(progRes.data)) {
            programacaoMap = new Map(progRes.data.map((row) => [getFormaStatusKey(row.data_fabricacao, row.setor, row.forma), row]));
          }
          if (!libRes.error && Array.isArray(libRes.data)) {
            liberacaoMap = new Map(libRes.data.map((row) => [getFormaStatusKey(row.data_fabricacao, row.setor, row.forma), row]));
          }
        } catch (lookupErr) {
          console.warn("Erro ao carregar horarios de programacao/liberacao para o relatorio:", lookupErr);
        }

        // O relatório de produção considera somente a concretagem confirmada pela liberação.
        const uniqueRows = deduplicarLinhasProducao(rows.filter((r) => r.status === "LIBERADO"));
        const mappedRows = uniqueRows.map(r => {
          const formaNorm = normalizeForma(r.forma || r.forma_numero || "");
          const statusKey = getFormaStatusKey(r.data_fabricacao || data, r.setor, r.forma || r.forma_numero);
          const programacaoRow = programacaoMap.get(statusKey);
          const liberacaoRow = liberacaoMap.get(statusKey);
          let modeloFinal = r.modelo;
          if ((r.setor === "Setor 3" || r.setor === "Setor 4") && (modeloFinal === "SC" || !modeloFinal) && formToModelMap[formaNorm]) {
            modeloFinal = formToModelMap[formaNorm];
          }
          return {
            forma_numero: r.forma || r.forma_numero,
            modelo: modeloFinal,
            descricao_poste: r.descricao_poste,
            codigo_produto: r.codigo_produto,
            liberacao_status: "1",
            colaborador: r.colaborador,
            timestamp: r.data_hora || r.updated_at || r.created_at,
            concretagem_timestamp: r.data_hora || r.updated_at || r.created_at,
            programacao_timestamp: programacaoRow?.data_hora || "",
            liberacao_timestamp: liberacaoRow?.data_hora || "",
            liberacao_colaborador: liberacaoRow?.colaborador || "",
            tipo_concreto: r.tipo_concreto || r.tipoConcreto || r.concretoTipo,
            setor: r.setor
          };
        });
        renderRelatorioSetor({ data, setor, encarregado, rows: mappedRows });
        setSyncStatus("ok", `Relatório do ${setor} em ${data} gerado pela nuvem.`);
        return;
      }
    } catch (e) {
      console.error(e);
      setSyncStatus("warn", "Falha ao buscar relatório. Gerando pelo cache local.");
    }
  }

  const db = readDb();
  let baseQuery = db.records
    .filter((r) => r.dataFabricacao === data)
    .filter((r) => String(r.liberacao?.status || "") === "1");

  if (setor !== "Todos") {
    baseQuery = baseQuery.filter((r) => r.setor === setor);
  }

  const rows = baseQuery.map((r) => {
    const formaNorm = normalizeForma(r.formaNumero || "");
    let modeloFinal = r.modelo;
    if ((r.setor === "Setor 3" || r.setor === "Setor 4") && (modeloFinal === "SC" || !modeloFinal) && formToModelMap[formaNorm]) {
      modeloFinal = formToModelMap[formaNorm];
    }
    return {
      forma_numero: r.formaNumero,
      modelo: modeloFinal,
      descricaoPoste: r.descricaoPoste,
      codigoProduto: r.codigoProduto,
      liberacao_status: r.liberacao?.status || "",
      colaborador: r.liberacao?.colaborador || "",
      timestamp: r.liberacao?.timestamp || r.updatedAt || r.createdAt,
      concretagem_timestamp: r.liberacao?.timestamp || r.updatedAt || r.createdAt,
      programacao_timestamp: "",
      liberacao_timestamp: r.liberacao?.timestamp || r.updatedAt || r.createdAt,
      tipoConcreto: r.concretoTipo,
      setor: r.setor,
      data_fabricacao: r.dataFabricacao,
      forma: r.formaNumero,
      status: r.liberacao?.status === "1" ? "LIBERADO" : r.liberacao?.status,
      tipo_concreto: r.concretoTipo
    };
  });

  const uniqueRows = deduplicarLinhasProducao(rows);
  renderRelatorioSetor({ data, setor, encarregado, rows: uniqueRows });
}

function getRoleConfig(role) {
  return ROLE_PERMISSIONS[role] || ROLE_PERMISSIONS.MONTADOR;
}

function setAccessByRole(role) {
  const cfg = getRoleConfig(role);
  const next = new Set(["HUB", ...cfg.modes]);
  if (String(state.authUser?.id || "").trim().toLowerCase() === "diegobat") {
    next.add("MANDRIL_CIRCULAR");
    next.add("INSPECAO");
  }
  if (String(state.authUser?.id || "").trim().toLowerCase() === "cgomes") {
    next.add("MANDRIL_CIRCULAR");
  }
  if (next.has("MONTAGEM_POSTES")) next.add("MONTAGEM_POSTES_DETALHE");
  if (next.has("INSPECAO")) next.add("INSPECAO_DETALHE");

  // Liberar explicitamente "USUARIOS" para o usuário Ricardo
  const userName = String(state.authUser?.name || "").trim().toLowerCase();
  if (userName === "ricardo") {
    next.add("USUARIOS");
  }

  if (Array.isArray(window.__unificadoAllowedModes)) {
    const visible = new Set(window.__unificadoAllowedModes);
    for (const mode of next) {
      if (mode !== "HUB" && !visible.has(mode) &&
          !(mode === "INSPECAO_DETALHE" && visible.has("INSPECAO")) &&
          !(mode === "MONTAGEM_POSTES_DETALHE" && visible.has("MONTAGEM_POSTES"))) next.delete(mode);
    }
  }
  state.allowedModes = next;
}

function isModeAllowed(mode) {
  if (mode === "HUB") return true;
  if (!state.authUser) return false;
  return state.allowedModes.has(mode);
}

function readAuthSession() {
  const raw = localStorage.getItem(AUTH_SESSION_KEY);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || !parsed.role || !ROLE_PERMISSIONS[parsed.role]) return null;
    return {
      id: String(parsed.id || "").trim(),
      name: String(parsed.name || "").trim() || "Usuário",
      role: parsed.role,
      roleLabel: getRoleConfig(parsed.role).label,
      setor: parsed.setor || "Todos"
    };
  } catch {
    return null;
  }
}

function saveAuthSession(auth) {
  localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify({ id: auth.id, name: auth.name, role: auth.role, setor: auth.setor || "Todos" }));
}

function clearAuthSession() {
  localStorage.removeItem(AUTH_SESSION_KEY);
}

function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

async function listUsersFromApi(options = {}) {
  const result = await postToApi("listar_usuarios", {});
  if (result.ok) {
    state.usersCache = Array.isArray(result.users) ? result.users : [];
    return { ok: true, users: state.usersCache };
  }

  if (!options.silent) {
    setUgFeedback(result.error || "Não foi possível carregar os usuários da planilha.", false);
  }
  return { ok: false, error: result.error || "Falha ao carregar usuários.", users: [] };
}

async function authenticateUserInApi(name, password) {
  return postToApi("autenticar_usuario", { name, password });
}

async function createUserInApi(name, login, role, password, setor) {
  return postToApi("criar_usuario", { name, login, role, password, setor });
}

async function deleteUserInApi(id) {
  return postToApi("excluir_usuario", { id });
}

function setUgFeedback(message, isOk) {
  if (!el.ugFeedback) return;
  if (!message) {
    el.ugFeedback.classList.add("hidden");
    el.ugFeedback.textContent = "";
    return;
  }
  el.ugFeedback.textContent = message;
  el.ugFeedback.style.background = isOk ? "#dcfce7" : "#fef2f2";
  el.ugFeedback.style.borderColor = isOk ? "#86efac" : "#fecaca";
  el.ugFeedback.style.color = isOk ? "#166534" : "#991b1b";
  el.ugFeedback.classList.remove("hidden");
}

async function renderUsuarios() {
  if (!el.ugListaBody) return;
  el.ugListaBody.innerHTML = '<tr><td colspan="5" data-visual-print="ca0d0825971e" style="text-align:center;color:var(--c-ink-2);">Carregando usuários...</td></tr>';
  const result = await listUsersFromApi({ silent: true });
  if (!result.ok) {
    el.ugListaBody.innerHTML = '<tr><td colspan="5" data-visual-print="2e35e3306087" style="text-align:center;color:var(--c-crit);">Falha ao carregar usuários da planilha.</td></tr>';
    return;
  }

  const users = result.users;
  if (users.length === 0) {
    el.ugListaBody.innerHTML = '<tr><td colspan="5" data-visual-print="ca0d0825971e" style="text-align:center;color:var(--c-ink-2);">Nenhum usuário cadastrado.</td></tr>';
    return;
  }
  el.ugListaBody.innerHTML = users.map((u) => `
    <tr>
      <td data-label="Nome completo" style="text-align:center">${escapeHtml(u.name)}</td>
      <td data-label="Login" style="text-align:center">${escapeHtml(u.id)}</td>
      <td data-label="Setor" style="text-align:center">${escapeHtml(u.setor || "Todos")}</td>
      <td data-label="Alçada" style="text-align:center">${escapeHtml(getRoleConfig(u.role).label)}</td>
      <td data-label="Ação" style="text-align:center"><button class="ug-del-btn" type="button" data-ug-id="${escapeHtml(u.id)}">Excluir</button></td>
    </tr>
  `).join("");

  el.ugListaBody.querySelectorAll(".ug-del-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const userId = String(btn.dataset.ugId || "").trim();
      const removed = state.usersCache.find((user) => user.id === userId);
      if (!userId || !removed) return;

      const resultDelete = await deleteUserInApi(userId);
      if (!resultDelete.ok) {
        setUgFeedback(resultDelete.error || "Não foi possível excluir o usuário.", false);
        return;
      }

      await renderUsuarios();
      setUgFeedback(`Usuário "${removed.name}" excluído.`, true);
    });
  });
}

function setLoginFeedback(message) {
  if (!el.loginFeedback) return;
  if (!message) {
    el.loginFeedback.classList.add("hidden");
    el.loginFeedback.textContent = "";
    return;
  }
  el.loginFeedback.textContent = message;
  el.loginFeedback.classList.remove("hidden");
}

function setPaFeedback(message) {
  if (!el.paFeedback) return;
  if (!message) {
    el.paFeedback.classList.add("hidden");
    el.paFeedback.textContent = "";
    return;
  }
  el.paFeedback.textContent = message;
  el.paFeedback.classList.remove("hidden");
}

async function salvarNovaSenhaPrimeiroAcesso() {
  const novaSenha = (el.paNovaSenha?.value || "").trim();
  const confirmarSenha = (el.paConfirmarSenha?.value || "").trim();

  if (!state.paTempUser) {
    setPaFeedback("Erro: Nenhum usuário em sessão temporária.");
    return;
  }

  if (novaSenha.length < 4) {
    setPaFeedback("A nova senha deve ter pelo menos 4 caracteres.");
    return;
  }

  if (novaSenha !== confirmarSenha) {
    setPaFeedback("As senhas não coincidem.");
    return;
  }

  try {
    setPaFeedback("Salvando nova senha...");
    const res = await postToApi("alterar_senha_primeiro_acesso", {
      id: state.paTempUser.id,
      senha: novaSenha
    });

    if (!res.ok) {
      setPaFeedback(res.error || "Erro ao salvar a nova senha.");
      return;
    }

    // Ocultar modal de primeiro acesso
    if (el.primeiroAcessoModal) {
      el.primeiroAcessoModal.classList.remove("modal-visible");
    }

    const user = state.paTempUser;
    state.paTempUser = null;

    // Login definitivo
    state.authUser = {
      id: user.id,
      name: user.name,
      role: user.role,
      roleLabel: getRoleConfig(user.role).label,
      setor: user.setor || "Todos"
    };

    setAccessByRole(user.role);
    saveAuthSession(state.authUser);
    setLoginFeedback("");
    unlockAppAfterLogin();
    applyRoleVisibility();
    applyAutoResponsibleFields();
    ensurePostLoginBootstrap();
    setMode("HUB");
    setSyncStatus("ok", `Acesso liberado para ${state.authUser.roleLabel}.`);

  } catch (err) {
    console.error(err);
    setPaFeedback("Erro inesperado: " + err.message);
  }
}

function isAutoResponsibleUser() {
  const name = String(state.authUser?.name || "").trim().toLowerCase();
  return name.includes("ricardo") || name.includes("philippe");
}

function getCurrentResponsibleName() {
  return isAutoResponsibleUser() ? String(state.authUser?.name || "").trim() : "";
}

function ensureSelectValue(selectEl, value) {
  if (!selectEl || !value) return;
  const exists = Array.from(selectEl.options || []).some((option) => option.value === value);
  if (!exists) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    selectEl.appendChild(option);
  }
  selectEl.value = value;
}

function applyAutoResponsibleFields() {
  const responsible = getCurrentResponsibleName();
  const enabled = !!responsible;

  if (enabled) {
    ensureSelectValue(el.libColaborador, responsible);
    if (el.kioskLibColaborador) el.kioskLibColaborador.value = responsible;
    if (el.relEncarregado) el.relEncarregado.value = responsible;
  }

  if (el.libColaborador) el.libColaborador.disabled = enabled;
  if (el.kioskLibColaborador) el.kioskLibColaborador.disabled = enabled;
  if (el.relEncarregado) el.relEncarregado.disabled = enabled;
}

function getProductionCollaborator() {
  return getCurrentResponsibleName() || (el.libColaborador?.value || "").trim();
}

function getReportManagerName() {
  return getCurrentResponsibleName() || (el.relEncarregado?.value || "").trim();
}
function lockAppForLogin() {
  document.body.classList.add("auth-locked");
  if (el.loginScreen) el.loginScreen.classList.remove("hidden");
}

function unlockAppAfterLogin() {
  document.body.classList.remove("auth-locked");
  if (el.loginScreen) el.loginScreen.classList.add("hidden");
}

function applyRoleVisibility() {
  const navByMode = {
    DASHBOARD: "navDashboard",
    PROD_ANALISE: "navProdAnalise",
    LIBERACAO: "hubLiberacao",
      LIBERACAO_S1: "hubLiberacaoS1",
      LIBERACAO_S2: "hubLiberacaoS2",
      LIBERACAO_S3: "hubLiberacaoS3",
      LIBERACAO_S4: "hubLiberacaoS4",
    INSPECAO: "hubInspecao",
    MONTAGEM_POSTES: "hubMontagemPostes",
    SEQUENCIA_S3: "hubSequenciaS3",
    MONTAGEM_INDICADORES: "hubMontagemIndicadores",
    DASHBOARD_DEFEITOS: "hubDashboardDefeitos",
    RELATORIO: "hubRelatorio",
    HISTORICO: "hubHistorico",
    ACMP_CONCRETAGEM: "hubAcmpConcretagem",
    USUARIOS: "navUsuarios",
    MANDRIL_CIRCULAR: "hubMandrilCircular",
    RELATORIO_MANUTENCAO: "hubRelatorioManutencao",
    TRATATIVA_DEFEITOS: "hubTratativaDefeitos"
  };

  Object.entries(navByMode).forEach(([mode, id]) => {
    const btn = document.getElementById(id);
    if (!btn) return;
    btn.classList.toggle("hidden", !isModeAllowed(mode));
  });

  // Also hide hub icons in the initial menu grid
  document.querySelectorAll(".hub-icon-btn").forEach((btn) => {
    const mode = btn.dataset.hubMode;
    if (mode) {
      btn.classList.toggle("hidden", !isModeAllowed(mode));
    }
  });

  document.querySelectorAll("[data-hub-mode]").forEach((btn) => {
    const mode = btn.dataset.hubMode || "";
    btn.classList.toggle("hidden", !isModeAllowed(mode));
  });

  document.querySelectorAll("#viewHub .hub-group-section").forEach((group) => {
    group.classList.toggle("hidden", !group.querySelector(".hub-icon-btn:not(.hidden)"));
  });

  const isOdinAllowed = ["user-ricardo", "alex", "philippe"].includes(String(state.authUser?.id || ""));
  if (el.btnCorrecaoConcretagem) {
    el.btnCorrecaoConcretagem.classList.toggle("hidden", !isOdinAllowed);
  }
  el.kioskOdinToggleField?.classList.toggle("hidden", !isOdinAllowed);

  if (el.authUserBadge) {
    if (state.authUser) {
      el.authUserBadge.textContent = `${state.authUser.name} · ${state.authUser.roleLabel}`;
      el.authUserBadge.classList.remove("hidden");
    } else {
      el.authUserBadge.classList.add("hidden");
    }
  }

  applyAutoResponsibleFields();

  if (el.authLogoutBtn) {
    el.authLogoutBtn.classList.toggle("hidden", !state.authUser);
  }
}

function ensurePostLoginBootstrap() {
  if (state.hasBootstrapped) return;
  renderLiberacaoDual();
  loadS4DtLayout();
  renderInspecaoLiberados();
  renderMontagemPostesLiberados();
  renderHistorico();
  carregarDashboardConcretagem();
  checkApiStatus();
  state.hasBootstrapped = true;
}

async function loginWithRole(name, password) {
  const cleanName = String(name || "").trim();
  if (!cleanName) {
    setLoginFeedback("Informe seu usuário para entrar.");
    return false;
  }

  if (!password) {
    setLoginFeedback("Informe a senha para entrar.");
    return false;
  }

  const authResult = await authenticateUserInApi(cleanName, password);
  if (!authResult.ok || !authResult.user) {
    setLoginFeedback(authResult.error || "Usuário ou senha incorretos.");
    return false;
  }

  const user = authResult.user;
  const role = user.role;
  if (!ROLE_PERMISSIONS[role]) {
    setLoginFeedback("Perfil inválido.");
    return false;
  }

  // Intercepta e requer troca de senha de primeiro acesso!
  if (user.primeiro_acesso) {
    state.paTempUser = user;
    if (el.primeiroAcessoModal) {
      el.paNovaSenha.value = "";
      el.paConfirmarSenha.value = "";
      setPaFeedback("");
      el.primeiroAcessoModal.classList.add("modal-visible");
    }
    return false;
  }

  state.authUser = {
    id: user.id,
    name: user.name,
    role,
    roleLabel: getRoleConfig(role).label,
    setor: user.setor || "Todos"
  };

  setAccessByRole(role);
  saveAuthSession(state.authUser);
  setLoginFeedback("");
  unlockAppAfterLogin();
  applyRoleVisibility();
  applyAutoResponsibleFields();
  ensurePostLoginBootstrap();
  setMode("HUB");
  setSyncStatus("ok", `Acesso liberado para ${state.authUser.roleLabel}.`);
  return true;
}

function logoutUser() {
  state.authUser = null;
  state.allowedModes = new Set(["HUB"]);
  clearAuthSession();
  applyRoleVisibility();
  setMode("HUB");
  lockAppForLogin();
  if (el.loginNome) el.loginNome.focus();
}

function setMode(mode) {
  if (mode === "DASHBOARD") mode = "PROD_ANALISE";
  if (mode !== "HUB" && !isModeAllowed(mode)) {
    mode = "HUB";
    if (state.authUser) {
      setSyncStatus("warn", "Seu perfil não possui acesso a esta opção.");
    }
  }

  state.mode = mode;
  if (!/^LIBERACAO_S[1-4]$/.test(mode)) document.body.classList.remove("kiosk-active");
  [el.hubView, el.viewDashboard, el.viewLiberacao, el.viewInspecao, el.viewInspecaoDetalhe, el.viewMontagemPostes, el.viewMontagemPostesDetalhe, el.viewRelatorio, el.viewHistorico, el.viewAcmpConcretagem, el.viewUsuarios, el.viewProdAnalise, el.viewMontagemIndicadores, el.viewDashboardDefeitos, el.viewSequenciaS3, el.viewMandrilCircular, el.viewRelatorioManutencao, el.viewTratativaDefeitos]
    .filter(Boolean).forEach((view) => view.classList.add("hidden"));
  if (mode === "HUB") el.hubView.classList.remove("hidden");
  if (mode === "DASHBOARD") {
    if (el.viewDashboard) el.viewDashboard.classList.remove("hidden");
    const dbDataEl = document.getElementById("dbData");
    if (dbDataEl && !dbDataEl.value) {
      dbDataEl.value = todayYmd();
    }
    renderDashboardCharts();
    carregarDadosGlobaisDashboard();
  }
  if (mode === "PROD_ANALISE") {
    if (el.viewProdAnalise) el.viewProdAnalise.classList.remove("hidden");
    const paDataInicio = document.getElementById("paDataInicio");
    const paDataFim = document.getElementById("paDataFim");
    if (paDataInicio && !paDataInicio.value) paDataInicio.value = todayYmd();
    if (paDataFim && !paDataFim.value) paDataFim.value = todayYmd();
    restoreDashboardFilter("pa");
    carregarProdutividadeConcretagem();
  }
  if (mode === "LIBERACAO" || mode.startsWith("LIBERACAO_")) {
    applyAutoResponsibleFields();
    el.viewLiberacao.classList.remove("hidden");
    state.activeLiberacaoSector = mode;

    const isKioskSector = mode === "LIBERACAO_S1" || mode === "LIBERACAO_S2" || mode === "LIBERACAO_S3" || mode === "LIBERACAO_S4";
    if (isKioskSector) {
      document.body.classList.add("kiosk-active");
      updateKioskHeader();
    } else {
      document.body.classList.remove("kiosk-active");
    }
  }
  if (mode === "INSPECAO") el.viewInspecao.classList.remove("hidden");
  if (mode === "INSPECAO_DETALHE") {
    if (el.viewInspecaoDetalhe) el.viewInspecaoDetalhe.classList.remove("hidden");
  }
  if (mode === "MONTAGEM_POSTES") el.viewMontagemPostes.classList.remove("hidden");
  if (mode === "MONTAGEM_POSTES_DETALHE") el.viewMontagemPostesDetalhe.classList.remove("hidden");
  if (mode === "RELATORIO") {
    applyAutoResponsibleFields();
    el.viewRelatorio.classList.remove("hidden");
  }
  if (mode === "HISTORICO") el.viewHistorico.classList.remove("hidden");
  if (mode === "ACMP_CONCRETAGEM") el.viewAcmpConcretagem.classList.remove("hidden");
  if (mode === "USUARIOS") {
    if (el.viewUsuarios) el.viewUsuarios.classList.remove("hidden");
    renderUsuarios().catch(() => {
      setUgFeedback("Não foi possível carregar os usuários da planilha.", false);
    });
  }
  if (mode === "MONTAGEM_INDICADORES") {
    if (el.viewMontagemIndicadores) el.viewMontagemIndicadores.classList.remove("hidden");
    const dashboardTitle = document.getElementById("miDashboardTitle");
    if (dashboardTitle) dashboardTitle.textContent = "Dashboard Montagem";
    const miDataInicio = document.getElementById("miDataInicio");
    const miDataFim = document.getElementById("miDataFim");
    if (miDataInicio && !miDataInicio.value) miDataInicio.value = `${todayYmd().slice(0, 7)}-01`;
    if (miDataFim && !miDataFim.value) miDataFim.value = todayYmd();
    restoreDashboardFilter("mi");
    limparLayoutDashboardDefeitos();
    ativarAbaMontagem("resumo");
    carregarMontagemIndicadores();
  }
  if (mode === "DASHBOARD_DEFEITOS") {
    const viewDashboardDefeitos = document.getElementById("viewDashboardDefeitos");
    if (viewDashboardDefeitos) viewDashboardDefeitos.classList.remove("hidden");
    const dfDataInicio = document.getElementById("dfDataInicio");
    const dfDataFim = document.getElementById("dfDataFim");
    if (dfDataInicio && !dfDataInicio.value) dfDataInicio.value = todayYmd();
    if (dfDataFim && !dfDataFim.value) dfDataFim.value = todayYmd();
    restoreDashboardFilter("df");
    aplicarLayoutDashboardDefeitos();
    carregarDashboardDefeitos();
  }
  if (mode === "SEQUENCIA_S3") {
    if (el.viewSequenciaS3) el.viewSequenciaS3.classList.remove("hidden");
    const seqS3Data = document.getElementById("seqS3Data");
    if (seqS3Data && !seqS3Data.value) seqS3Data.value = todayYmd();
    renderSequenciaS3();
  }
  if (mode === "MANDRIL_CIRCULAR") {
    if (el.viewMandrilCircular) el.viewMandrilCircular.classList.remove("hidden");
    if (el.mcFiltroData && !el.mcFiltroData.value) el.mcFiltroData.value = todayYmd();
    carregarMandrilCircular();
  }
  if (mode === "RELATORIO_MANUTENCAO") {
    if (el.viewRelatorioManutencao) el.viewRelatorioManutencao.classList.remove("hidden");
    renderizarRelatorioManutencao();
    carregarFormasManutencaoSupabase().then(() => {
      renderizarRelatorioManutencao();
      renderLiberacaoDual();
    });
  }
  if (mode === "TRATATIVA_DEFEITOS") {
    if (el.viewTratativaDefeitos) el.viewTratativaDefeitos.classList.remove("hidden");
    const inicioTratativa = document.getElementById("tdFiltroDataInicio");
    const fimTratativa = document.getElementById("tdFiltroDataFim");
    if (tratativaUsaServidor() && inicioTratativa && fimTratativa
        && !inicioTratativa.value && !fimTratativa.value) {
      const inicio = new Date(`${todayYmd()}T12:00:00`);
      inicio.setFullYear(inicio.getFullYear() - 1);
      inicioTratativa.value = dateToYmd(inicio);
      fimTratativa.value = todayYmd();
    }
    carregarRelatorioTratativaDefeitos();
  }
  document.body.classList.remove("mode-hub", "mode-dashboard", "mode-prod-analise", "mode-liberacao", "mode-inspecao", "mode-inspecao-detalhe", "mode-montagem-postes", "mode-montagem-postes-detalhe", "mode-relatorio", "mode-historico", "mode-acmp-concretagem", "mode-usuarios", "mode-montagem-indicadores", "mode-dashboard-defeitos", "mode-sequencia-s3", "mode-mandril-circular", "mode-relatorio-manutencao", "mode-tratativa-defeitos");
  if (mode === "RELATORIO_MANUTENCAO") document.body.classList.add("mode-relatorio-manutencao");
  if (mode === "TRATATIVA_DEFEITOS") document.body.classList.add("mode-tratativa-defeitos");
  if (mode === "HUB") {
    document.body.classList.add("mode-hub");
    applyAutoResponsibleFields();
    atualizarIndicadoresManutencaoHub();
  }
  if (mode === "DASHBOARD") document.body.classList.add("mode-dashboard");
  if (mode === "PROD_ANALISE") document.body.classList.add("mode-prod-analise");
  if (mode === "LIBERACAO" || mode.startsWith("LIBERACAO_")) {
    document.body.classList.add("mode-liberacao");
    applyAutoResponsibleFields();
  }
  if (mode === "SEQUENCIA_S3") document.body.classList.add("mode-sequencia-s3");
  if (mode === "INSPECAO") {
    document.body.classList.add("mode-inspecao");
    if (state.authUser?.name && el.insColaborador) {
      el.insColaborador.value = state.authUser.name;
    }
    if ((el.insModoCarga?.value || "data") === "data" && !el.insFiltroData.value) {
      el.insLiberadosBody.innerHTML = '<tr><td colspan="4" class="muted">Selecione a data de produção para carregar os itens liberados.</td></tr>';
      el.insQtdItens.textContent = "0";
    }
  }
  if (mode === "INSPECAO_DETALHE") document.body.classList.add("mode-inspecao-detalhe");
  if (mode === "MONTAGEM_POSTES") {
    document.body.classList.add("mode-montagem-postes");
    if ((el.mpModoCarga?.value || "data") === "data" && !el.mpFiltroData?.value) {
      el.mpLiberadosBody.innerHTML = '<tr><td colspan="4" class="muted">Selecione a data de produção para carregar os itens liberados.</td></tr>';
      el.mpQtdItens.textContent = "0";
      if (el.mpKpiAprovados) el.mpKpiAprovados.textContent = "0";
      if (el.mpKpiRetrabalho) el.mpKpiRetrabalho.textContent = "0";
      if (el.mpKpiReprovados) el.mpKpiReprovados.textContent = "0";
    }
  }
  if (mode === "MONTAGEM_POSTES_DETALHE") document.body.classList.add("mode-montagem-postes-detalhe");
  if (mode === "RELATORIO") {
    document.body.classList.add("mode-relatorio");
    applyAutoResponsibleFields();
  }
  if (mode === "HISTORICO") document.body.classList.add("mode-historico");
  if (mode === "ACMP_CONCRETAGEM") document.body.classList.add("mode-acmp-concretagem");
  if (mode === "USUARIOS") document.body.classList.add("mode-usuarios");
  if (mode === "MONTAGEM_INDICADORES" || mode === "DASHBOARD_DEFEITOS") document.body.classList.add("mode-montagem-indicadores");
  if (mode === "DASHBOARD_DEFEITOS") document.body.classList.add("mode-dashboard-defeitos");

  // Update sidebar nav + topbar title
  const navTitles = {
    HUB: ["navInicio", "Início"],
    DASHBOARD: ["navDashboard", "Dashboard"],
    PROD_ANALISE: ["navProdAnalise", "Dashboard Concretagem Matriz"],
    LIBERACAO: ["hubLiberacao", "Produção / Liberação"],
      LIBERACAO_S1: ["hubLiberacaoS1", "Produção Setor 1"],
      LIBERACAO_S2: ["hubLiberacaoS2", "Produção Setor 2"],
      LIBERACAO_S3: ["hubLiberacaoS3", "Produção Setor 3"],
      LIBERACAO_S4: ["hubLiberacaoS4", "Produção Setor 4"],
    INSPECAO: ["hubInspecao", "Inspeção Setor 3 e 4"],
    MONTAGEM_POSTES: ["hubMontagemPostes", "Montagem Postes"],
    MONTAGEM_POSTES_DETALHE: ["hubMontagemPostes", "Inspecionar / Montar Poste"],
    MONTAGEM_INDICADORES: ["hubMontagemIndicadores", "Dashboard montagem"],
    DASHBOARD_DEFEITOS: ["hubDashboardDefeitos", "Dashboard Defeitos"],
    RELATORIO: ["hubRelatorio", "Relatório Enc. Produção"],
    HISTORICO: ["hubHistorico", "Histórico"],
    ACMP_CONCRETAGEM: ["hubAcmpConcretagem", "Acmp. Concretagem"],
    USUARIOS: ["navUsuarios", "Gerenciar Usuários"],
    SEQUENCIA_S3: ["hubSequenciaS3", "Sequência Setor 3"],
    MANDRIL_CIRCULAR: ["hubMandrilCircular", "Saque Mandril Circular"],
    RELATORIO_MANUTENCAO: ["hubRelatorioManutencao", "Relatório de manutenção"],
    TRATATIVA_DEFEITOS: ["hubTratativaDefeitos", "Tratativa de defeitos"]
  };
  const navInfo = navTitles[mode];
  document.querySelectorAll(".nav-item").forEach((btn) => btn.classList.remove("nav-active"));
  if (navInfo) {
    const activeBtn = document.getElementById(navInfo[0]);
    if (activeBtn) activeBtn.classList.add("nav-active");
    const titleEl = document.getElementById("topbarTitle");
    if (titleEl) titleEl.textContent = navInfo[1];
  }
}

function navigateBack() {
  if (state.mode === "MONTAGEM_POSTES_DETALHE") {
    setMode("MONTAGEM_POSTES");
    renderMontagemPostesLiberados();
    return;
  }
  if (state.mode === "INSPECAO_DETALHE") {
    setMode("INSPECAO");
    renderInspecaoLiberados();
    return;
  }

  if (state.mode !== "HUB") {
    setMode("HUB");
    return;
  }

  setSyncStatus("warn", "Voce ja esta na tela principal.");
}

function handleHubModeNavigation(mode) {
  if (!mode) return;
  if (mode === "DASHBOARD") {
    setMode("DASHBOARD");
  } else if (mode === "MONTAGEM_INDICADORES" || mode === "DASHBOARD_DEFEITOS") {
    setMode(mode);
  } else if (mode === "PROD_ANALISE") {
    setMode("PROD_ANALISE");
  } else if (mode === "LIBERACAO" || mode.startsWith("LIBERACAO_")) {
    setMode(mode);
    if (el.libData && !el.libData.value) el.libData.value = todayYmd();
    // Hub tiles must load the selected day's PCP assignments, like the sidebar.
    loadProgrammedFormas().then(() => renderLiberacaoDual()).catch(error => {
      console.error("Falha ao carregar a programacao:", error);
      setSyncStatus("error", "Falha ao carregar a programacao. Tente Sincronizar.");
    });
  } else if (mode === "INSPECAO") {
    setMode("INSPECAO");
    if (el.insFiltroData && !el.insFiltroData.value) el.insFiltroData.value = todayYmd();
    renderInspecaoLiberados();
  } else if (mode === "MONTAGEM_POSTES") {
    setMode("MONTAGEM_POSTES");
    if (el.mpFiltroData && !el.mpFiltroData.value) el.mpFiltroData.value = todayYmd();
    renderMontagemPostesLiberados();
  } else if (mode === "RELATORIO") {
    setMode("RELATORIO");
    if (el.relData && !el.relData.value) el.relData.value = todayYmd();
  } else if (mode === "HISTORICO") {
    setMode("HISTORICO");
    renderHistorico();
  } else if (mode === "ACMP_CONCRETAGEM") {
    setMode("ACMP_CONCRETAGEM");
    if (el.acmpData && !el.acmpData.value) el.acmpData.value = todayYmd();
    renderAcmpConcretagem();
  } else if (mode === "USUARIOS") {
    setMode("USUARIOS");
  } else if (mode === "MANDRIL_CIRCULAR") {
    setMode("MANDRIL_CIRCULAR");
  } else if (mode === "SEQUENCIA_S3" || mode === "RELATORIO_MANUTENCAO" || mode === "TRATATIVA_DEFEITOS") {
    setMode(mode);
  }
}

function bindEssentialNavigation() {
  if (state.essentialNavigationBound) return;
  state.essentialNavigationBound = true;

  const appSidebar = document.getElementById("appSidebar");
  const sidebarOverlay = document.getElementById("sidebarOverlay");
  const sidebarToggle = document.getElementById("sidebarToggle");

  if (localStorage.getItem("sidebarCollapsed") === "1") {
    document.body.classList.add("sidebar-hidden");
    sidebarToggle?.setAttribute("aria-expanded", "false");
  }

  function closeMobileSidebar() {
    appSidebar?.classList.remove("sidebar-open");
    sidebarOverlay?.classList.remove("visible");
    sidebarToggle?.setAttribute("aria-expanded", "false");
  }

  if (sidebarToggle && appSidebar) {
    sidebarToggle.addEventListener("click", () => {
      if (window.innerWidth <= 1024) {
        const open = appSidebar.classList.toggle("sidebar-open");
        sidebarOverlay?.classList.toggle("visible", open);
        sidebarToggle.setAttribute("aria-expanded", String(open));
      } else {
        const hidden = document.body.classList.toggle("sidebar-hidden");
        localStorage.setItem("sidebarCollapsed", hidden ? "1" : "0");
        sidebarToggle.setAttribute("aria-expanded", String(!hidden));
      }
    });
  }

  sidebarOverlay?.addEventListener("click", closeMobileSidebar);
  document.querySelectorAll(".nav-item").forEach((btn) => {
    btn.addEventListener("click", () => {
      if (window.innerWidth <= 1024) closeMobileSidebar();
    });
  });

  document.querySelectorAll("[data-hub-mode]").forEach((btn) => {
    btn.dataset.hubNavBound = "1";
    btn.addEventListener("click", () => handleHubModeNavigation(btn.dataset.hubMode || ""));
  });
}

function bindEvents() {
  bindEssentialNavigation();

  if (el.loginEntrar) {
    el.loginEntrar.addEventListener("click", async () => {
      await loginWithRole(el.loginNome?.value || "", el.loginSenha?.value || "");
    });
  }

  if (el.loginSenha) {
    el.loginSenha.addEventListener("keydown", async (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        await loginWithRole(el.loginNome?.value || "", el.loginSenha?.value || "");
      }
    });
  }

  if (el.loginNome) {
    el.loginNome.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        el.loginSenha?.focus();
      }
    });
  }

  applyAutoResponsibleFields();

  if (el.authLogoutBtn) {
    el.authLogoutBtn.addEventListener("click", logoutUser);
  }

  if (el.concretoTipoCancelBtn) {
    el.concretoTipoCancelBtn.addEventListener("click", closeConcreteTypePopup);
  }

  if (el.concretoTipoModal) {
    el.concretoTipoModal.addEventListener("click", (event) => {
      if (event.target === el.concretoTipoModal) {
        closeConcreteTypePopup();
      }
    });
  }

  if (el.ugCriarBtn) {
    el.ugCriarBtn.addEventListener("click", async () => {
      const nome = (el.ugNomeCompleto?.value || "").trim();
      const login = (el.ugLogin?.value || "").trim();
      const perfil = el.ugPerfil?.value || "MONTADOR";
      const senha = (el.ugSenha?.value || "").trim();
      const setor = el.ugSetor?.value || "Todos";

      if (!nome) { setUgFeedback("Informe o nome completo do usuário.", false); return; }
      if (!login) { setUgFeedback("Informe o login / usuário.", false); return; }
      if (!senha) { setUgFeedback("Informe a senha.", false); return; }

      const resultCreate = await createUserInApi(nome, login, perfil, senha, setor);
      if (!resultCreate.ok) {
        setUgFeedback(resultCreate.error || "Não foi possível criar o usuário.", false);
        return;
      }

      if (el.ugNomeCompleto) el.ugNomeCompleto.value = "";
      if (el.ugLogin) el.ugLogin.value = "";
      if (el.ugSenha) el.ugSenha.value = "";
      if (el.ugSetor) el.ugSetor.value = "Todos";
      if (el.ugPerfil) el.ugPerfil.value = "MONTADOR";
      await renderUsuarios();
      setUgFeedback(`Usuário "${nome}" criado com sucesso!`, true);
    });
  }

  if (el.navUsuarios) {
    el.navUsuarios.addEventListener("click", () => setMode("USUARIOS"));
  }


    if (el.hubLiberacao) {
      el.hubLiberacao.addEventListener("click", () => {
        setMode("LIBERACAO");
        if (!el.libData.value) el.libData.value = todayYmd();
        loadProgrammedFormas().then(() => renderLiberacaoDual());
      });
    }
    if (el.hubLiberacaoS1) {
      el.hubLiberacaoS1.addEventListener("click", () => {
        setMode("LIBERACAO_S1");
        if (!el.libData.value) el.libData.value = todayYmd();
        loadProgrammedFormas().then(() => renderLiberacaoDual());
      });
    }
    if (el.hubLiberacaoS2) {
      el.hubLiberacaoS2.addEventListener("click", () => {
        setMode("LIBERACAO_S2");
        if (!el.libData.value) el.libData.value = todayYmd();
        loadProgrammedFormas().then(() => renderLiberacaoDual());
      });
    }
    if (el.hubLiberacaoS3) {
      el.hubLiberacaoS3.addEventListener("click", () => {
        setMode("LIBERACAO_S3");
        if (!el.libData.value) el.libData.value = todayYmd();
        loadProgrammedFormas().then(() => renderLiberacaoDual());
      });
    }
    if (el.hubLiberacaoS4) {
      el.hubLiberacaoS4.addEventListener("click", () => {
        setMode("LIBERACAO_S4");
        if (!el.libData.value) el.libData.value = todayYmd();
        loadProgrammedFormas().then(() => renderLiberacaoDual());
      });
    }

  el.hubInspecao.addEventListener("click", () => {
    setMode("INSPECAO");
    if (!el.insFiltroData.value) el.insFiltroData.value = todayYmd();
    renderInspecaoLiberados();
  });
  el.hubMontagemPostes?.addEventListener("click", () => {
    setMode("MONTAGEM_POSTES");
    if (!el.mpFiltroData.value) el.mpFiltroData.value = todayYmd();
    renderMontagemPostesLiberados();
  });
  el.hubSequenciaS3?.addEventListener("click", () => {
    setMode("SEQUENCIA_S3");
    if (el.seqS3Data && !el.seqS3Data.value) el.seqS3Data.value = todayYmd();
    renderSequenciaS3();
  });
  el.hubMontagemIndicadores?.addEventListener("click", () => {
    setMode("MONTAGEM_INDICADORES");
  });
  el.hubDashboardDefeitos?.addEventListener("click", () => {
    setMode("DASHBOARD_DEFEITOS");
  });

  // Configuração dos Filtros e Abas do Dashboard Montagem
  document.getElementById("miBtnLimparFiltros")?.addEventListener("click", () => {
    clearSavedDashboardFilter("mi");
    const miDataInicio = document.getElementById("miDataInicio");
    const miDataFim = document.getElementById("miDataFim");
    if (miDataInicio) miDataInicio.value = todayYmd();
    if (miDataFim) miDataFim.value = todayYmd();

    const fSetor = document.getElementById("miFiltroSetor");
    if (fSetor) fSetor.value = "";
    const fStatus = document.getElementById("miFiltroStatus");
    if (fStatus) fStatus.value = "";
    const fPesquisa = document.getElementById("miFiltroPesquisa");
    if (fPesquisa) fPesquisa.value = "";

    miPaginaAtual = 1;
    aplicarFiltrosEExibirMontagem();
  });
  document.getElementById("miBtnAtualizar")?.addEventListener("click", () => {
    carregarMontagemIndicadores();
  });
  document.getElementById("miBtnExportarXlsx")?.addEventListener("click", () => {
    exportarMontagemIndicadoresXlsx();
  });
  document.getElementById("miBtnFiltrar")?.addEventListener("click", () => {
    carregarMontagemIndicadores();
  });
  document.getElementById("miDataInicio")?.addEventListener("change", () => {
    miPaginaAtual = 1;
    carregarMontagemIndicadores();
  });
  document.getElementById("miDataFim")?.addEventListener("change", () => {
    miPaginaAtual = 1;
    carregarMontagemIndicadores();
  });
  document.getElementById("miFiltroSetor")?.addEventListener("change", () => {
    miPaginaAtual = 1;
    aplicarFiltrosEExibirMontagem();
  });
  document.getElementById("miFiltroStatus")?.addEventListener("change", () => {
    miPaginaAtual = 1;
    aplicarFiltrosEExibirMontagem();
  });
  document.getElementById("miFiltroPesquisa")?.addEventListener("input", () => {
    miPaginaAtual = 1;
    aplicarFiltrosEExibirMontagem();
  });

  document.getElementById("dfBtnLimparFiltros")?.addEventListener("click", () => {
    clearSavedDashboardFilter("df");
    const dfDataInicio = document.getElementById("dfDataInicio");
    const dfDataFim = document.getElementById("dfDataFim");
    if (dfDataInicio) dfDataInicio.value = todayYmd();
    if (dfDataFim) dfDataFim.value = todayYmd();
    const fSetor = document.getElementById("dfFiltroSetor");
    if (fSetor) fSetor.value = "";
    const fStatus = document.getElementById("dfFiltroStatus");
    if (fStatus) fStatus.value = "";
    const fPesquisa = document.getElementById("dfFiltroPesquisa");
    if (fPesquisa) fPesquisa.value = "";
    miPaginaAtual = 1;
    sincronizarDfScopeTabs();
    carregarDashboardDefeitos();
  });
  document.getElementById("dfBtnAtualizar")?.addEventListener("click", () => carregarDashboardDefeitos(true));
  document.getElementById("dfBtnFiltrar")?.addEventListener("click", () => carregarDashboardDefeitos());
  document.getElementById("miDefeitosPorTipo")?.addEventListener("click", event => {
    const button = event.target.closest(".df-defect-toggle");
    if (button) alternarDetalheDefeito(button);
  });
  document.getElementById("dfBtnExportarCsv")?.addEventListener("click", exportarDashboardDefeitosCsv);
  document.getElementById("dfBtnApresentacao")?.addEventListener("click", abrirApresentacaoDefeitos);
  document.getElementById("dfPresentationPrev")?.addEventListener("click", () => exibirSlideApresentacaoDefeitos(dfPresentationSlideIndex - 1));
  document.getElementById("dfPresentationNext")?.addEventListener("click", () => exibirSlideApresentacaoDefeitos(dfPresentationSlideIndex + 1));
  document.getElementById("dfPresentationClose")?.addEventListener("click", fecharApresentacaoDefeitos);
  document.getElementById("dfPresentationFullscreen")?.addEventListener("click", alternarTelaCheiaApresentacaoDefeitos);
  document.getElementById("dfPresentationPrint")?.addEventListener("click", imprimirApresentacaoDefeitos);
  window.addEventListener("resize", ajustarEscalaApresentacaoDefeitos);
  window.addEventListener("afterprint", finalizarImpressaoApresentacaoDefeitos);
  document.addEventListener("fullscreenchange", () => {
    const fullscreenBtn = document.getElementById("dfPresentationFullscreen");
    if (fullscreenBtn) fullscreenBtn.textContent = document.fullscreenElement ? "Sair da tela cheia" : "Tela cheia";
    ajustarEscalaApresentacaoDefeitos();
  });
  document.addEventListener("keydown", event => {
    const overlay = document.getElementById("dfPresentationOverlay");
    if (!overlay || overlay.classList.contains("hidden")) return;
    if (event.key === "Escape") fecharApresentacaoDefeitos();
    if (event.key === "ArrowLeft") exibirSlideApresentacaoDefeitos(dfPresentationSlideIndex - 1);
    if (event.key === "ArrowRight" || event.key === " ") {
      event.preventDefault();
      exibirSlideApresentacaoDefeitos(dfPresentationSlideIndex + 1);
    }
  });
  ["dfDataInicio", "dfDataFim", "dfFiltroSetor", "dfFiltroStatus"].forEach(id => {
    document.getElementById(id)?.addEventListener("change", () => {
      miPaginaAtual = 1;
      if (id === "dfFiltroSetor") sincronizarDfScopeTabs();
      carregarDashboardDefeitos();
    });
  });
  document.querySelectorAll("[data-df-scope]").forEach(btn => {
    btn.addEventListener("click", (event) => {
      const select = document.getElementById("dfFiltroSetor");
      if (select) select.value = event.currentTarget.dataset.dfScope || "";
      miPaginaAtual = 1;
      sincronizarDfScopeTabs();
      carregarDashboardDefeitos();
    });
  });
  document.querySelectorAll(".df-v4-dash-tabs [data-hub-mode]").forEach(btn => {
    btn.addEventListener("click", (event) => setMode(event.currentTarget.dataset.hubMode));
  });
  let dfPesquisaTimer = null;
  document.getElementById("dfFiltroPesquisa")?.addEventListener("input", () => {
    miPaginaAtual = 1;
    clearTimeout(dfPesquisaTimer);
    if (state.mode === "DASHBOARD_DEFEITOS") {
      dfPesquisaTimer = setTimeout(() => carregarDashboardDefeitos(), 200);
    } else {
      aplicarFiltrosEExibirMontagem();
    }
  });

  document.querySelectorAll("[data-dashboard-presets] [data-date-preset]").forEach(button => {
    button.addEventListener("click", () => {
      applyDashboardDatePreset(button.closest("[data-dashboard-presets]")?.dataset.dashboardPresets, button.dataset.datePreset);
    });
  });
  ["mi", "df", "pa"].forEach(kind => {
    ["DataInicio", "DataFim", "FiltroStatus"].forEach(field => {
      document.getElementById(`${kind}${field}`)?.addEventListener("change", () => syncDashboardFilterChips(kind));
    });
    document.getElementById(`${kind}BtnLimparFiltros`)?.addEventListener("click", () => syncDashboardFilterChips(kind));
  });
  document.querySelectorAll("[data-dashboard-quick] [data-quick-status]").forEach(button => {
    button.addEventListener("click", () => {
      const kind = button.closest("[data-dashboard-quick]")?.dataset.dashboardQuick;
      const select = document.getElementById(`${kind}FiltroStatus`);
      if (!select) return;
      select.value = select.value === button.dataset.quickStatus ? "" : button.dataset.quickStatus;
      select.dispatchEvent(new Event("change", { bubbles: true }));
    });
  });
  document.querySelectorAll("[data-save-dashboard-filter]").forEach(button => {
    button.addEventListener("click", () => saveDashboardFilter(button.dataset.saveDashboardFilter, button));
  });

  // Troca de Abas do Dashboard
  document.querySelectorAll(".mi-tab-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const targetTab = e.currentTarget.dataset.tab;
      limparLayoutDashboardDefeitos();
      ativarAbaMontagem(targetTab || "resumo");
      if (targetTab === "produtividade" && e.currentTarget.closest("#viewMontagemIndicadores")) {
        requestAnimationFrame(() => document.querySelector("#miSecaoProdutividade .mi-taxa-card")?.scrollIntoView({ block: "start", behavior: "smooth" }));
      }
    });
  });

  // Close listeners for Visualizar Checklist Modal
  const vcClose = document.getElementById("vcBtnCloseModal");
  const vcOk = document.getElementById("vcBtnOk");
  const vcModal = document.getElementById("visualizarChecklistModal");
  if (vcClose) {
    vcClose.addEventListener("click", () => {
      vcModal.classList.remove("modal-visible");
    });
  }
  el.hubAcmpConcretagem?.addEventListener("click", () => {
    setMode("ACMP_CONCRETAGEM");
    if (!el.acmpData.value) el.acmpData.value = todayYmd();
    renderAcmpConcretagem();
  });
  el.hubRelatorioManutencao?.addEventListener("click", () => {
    setMode("RELATORIO_MANUTENCAO");
  });
  el.hubTratativaDefeitos?.addEventListener("click", () => {
    setMode("TRATATIVA_DEFEITOS");
  });

  document.getElementById("tdBtnAtualizar")?.addEventListener("click", carregarRelatorioTratativaDefeitos);

  document.getElementById("tdBtnImprimirPDF")?.addEventListener("click", () => {
    document.body.classList.add("print-relatorio-defeitos");
    window.print();
    document.body.classList.remove("print-relatorio-defeitos");
  });

  document.getElementById("tdBtnLimparFiltros")?.addEventListener("click", () => {
    const st = document.getElementById("tdFiltroStatus");
    const cod = document.getElementById("tdFiltroCodigo");
    const resp = document.getElementById("tdFiltroResponsavel");
    const ini = document.getElementById("tdFiltroDataInicio");
    const fim = document.getElementById("tdFiltroDataFim");
    if (st) st.value = "TODOS";
    if (cod) cod.value = "TODOS";
    if (resp) resp.value = "TODOS";
    if (ini) ini.value = "";
    if (fim) fim.value = "";
    carregarRelatorioTratativaDefeitos();
  });

  ["tdFiltroStatus", "tdFiltroCodigo", "tdFiltroResponsavel", "tdFiltroDataInicio", "tdFiltroDataFim"].forEach(id => {
    const render = id === "tdFiltroDataInicio" || id === "tdFiltroDataFim"
      ? carregarRelatorioTratativaDefeitos : renderizarRelatorioTratativaDefeitos;
    document.getElementById(id)?.addEventListener("change", render);
    if (render === renderizarRelatorioTratativaDefeitos)
      document.getElementById(id)?.addEventListener("input", render);
  });

  document.getElementById("mTratativaCancelBtn")?.addEventListener("click", () => {
    document.getElementById("modalTratativaDefeito")?.classList.remove("modal-visible");
  });

  document.getElementById("mTratativaExecutadoPorSelect")?.addEventListener("change", (e) => {
    const input = document.getElementById("mTratativaExecutadoPor");
    if (e.target.value === "OUTRO") {
      input?.classList.remove("hidden");
      input?.focus();
    } else {
      input?.classList.add("hidden");
    }
  });

  document.getElementById("tdBtnNovaOcorrencia")?.addEventListener("click", () => {
    const dataInput = document.getElementById("mNovaData");
    if (dataInput && !dataInput.value) dataInput.value = todayYmd();
    document.getElementById("modalNovaOcorrenciaDefeito")?.classList.add("modal-visible");
  });

  document.getElementById("mNovaCancelBtn")?.addEventListener("click", () => {
    document.getElementById("modalNovaOcorrenciaDefeito")?.classList.remove("modal-visible");
  });

  document.getElementById("mNovaConfirmBtn")?.addEventListener("click", async () => {
    const setor = document.getElementById("mNovaSetor")?.value || "Setor 1";
    const forma = document.getElementById("mNovaForma")?.value?.trim() || "";
    const data = document.getElementById("mNovaData")?.value || todayYmd();
    const modelo = document.getElementById("mNovaModelo")?.value?.trim() || "Poste Concretrack";
    const codigo = document.getElementById("mNovaCodigoDefeito")?.value || "A";
    const obs = document.getElementById("mNovaObservacoes")?.value?.trim() || "";

    if (!forma) {
      alert("Por favor, preencha o número da forma ou poste.");
      document.getElementById("mNovaForma")?.focus();
      return;
    }

    const info = getDefeitoInfo(codigo);
    const idKey = `INC_MAN_${data}_${setor}_${forma}_${codigo}_${Date.now()}`;

    const rec = {
      id: idKey,
      data_fabricacao: data,
      setor: setor,
      forma_numero: forma,
      modelo: modelo,
      codigo_defeito: codigo,
      descricao_defeito: info.descricao,
      classificacao: info.classificacao,
      responsavel_designado: info.responsavel,
      responsaveis_lista: info.responsaveisLista || [],
      acao_recomendada: info.acao,
      status_tratativa: "PENDENTE",
      executado_por: "",
      acao_realizada: "",
      tratado_em: "",
      observacoes_origem: obs
    };

    try {
      await salvarTratativaDefeitoRegistro(rec);
      document.getElementById("modalNovaOcorrenciaDefeito")?.classList.remove("modal-visible");
      renderizarRelatorioTratativaDefeitos();
      setSyncStatus("ok", `Nova ocorrência do defeito ${codigo} registrada com sucesso.`);
    } catch (error) {
      setSyncStatus("error", `Falha ao salvar ocorrência: ${error.message}`);
    }
  });

  document.getElementById("mTratativaConfirmBtn")?.addEventListener("click", async () => {
    if (!pendingTratativaSelection) return;
    const status = document.getElementById("mTratativaStatus")?.value || "PENDENTE";
    const execSel = document.getElementById("mTratativaExecutadoPorSelect")?.value || "";
    const execCustom = document.getElementById("mTratativaExecutadoPor")?.value?.trim() || "";
    const executadoPor = execSel === "OUTRO" ? execCustom : execSel;
    const acaoRealizada = document.getElementById("mTratativaAcaoRealizada")?.value?.trim() || "";
    const nomeDefeito = document.getElementById("mTratativaNomeDefeito")?.value?.trim() || "";
    const justificativa = document.getElementById("mTratativaJustificativa")?.value?.trim() || "";

    if (!acaoRealizada) {
      alert("Por favor, preencha o direcionamento / ação corretiva realizada.");
      document.getElementById("mTratativaAcaoRealizada")?.focus();
      return;
    }

    const rec = {
      ...pendingTratativaSelection,
      nome_defeito: nomeDefeito,
      justificativa,
      status_tratativa: status,
      executado_por: executadoPor || state.authUser?.name || "Técnico",
      acao_realizada: acaoRealizada,
      tratado_em: new Date().toLocaleString("pt-BR")
    };

    try {
      await salvarTratativaDefeitoRegistro(rec);
      document.getElementById("modalTratativaDefeito")?.classList.remove("modal-visible");
      renderizarRelatorioTratativaDefeitos();
      setSyncStatus("ok", `Tratativa do defeito ${rec.codigo_defeito} atualizada com sucesso.`);
    } catch (error) {
      setSyncStatus("error", `Falha ao salvar tratativa: ${error.message}`);
    }
  });

  if (el.paSalvarBtn) {
    el.paSalvarBtn.addEventListener("click", salvarNovaSenhaPrimeiroAcesso);
  }

  el.backButtons.forEach((btn) => btn.addEventListener("click", navigateBack));
  if (el.backMain) {
    el.backMain.addEventListener("click", () => {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.location.href = "../index.html";
      }
    });
  }
  el.libData.addEventListener("change", () => {
    loadProgrammedFormas().then(() => renderLiberacaoDual());
  });

  // Sincronização dos campos do Quiosque em tempo real
  if (el.libData && el.kioskLibData) {
    el.libData.addEventListener("input", () => {
      el.kioskLibData.value = el.libData.value;
      loadProgrammedFormas().then(() => renderLiberacaoDual());
    });
    el.kioskLibData.addEventListener("input", () => {
      el.libData.value = el.kioskLibData.value;
      loadProgrammedFormas().then(() => renderLiberacaoDual());
    });
  }
  if (el.libColaborador && el.kioskLibColaborador) {
    el.libColaborador.addEventListener("input", () => {
      el.kioskLibColaborador.value = el.libColaborador.value;
    });
    el.kioskLibColaborador.addEventListener("input", () => {
      el.libColaborador.value = el.kioskLibColaborador.value;
    });
  }

  // Ouvintes de evento de Programação do Quiosque
  if (el.kioskProgCheckbox) {
    el.kioskProgCheckbox.addEventListener("change", () => {
      state.programmingMode = el.kioskProgCheckbox.checked;
      if (state.programmingMode) {
        if (el.kioskLibCheckbox && el.kioskLibCheckbox.checked) {
          el.kioskLibCheckbox.checked = false;
          el.kioskLibCheckbox.dispatchEvent(new Event("change"));
        }
        if (el.kioskOdinCheckbox && el.kioskOdinCheckbox.checked) {
          el.kioskOdinCheckbox.checked = false;
          el.kioskOdinCheckbox.dispatchEvent(new Event("change"));
        }
        if (el.kioskManutencaoCheckbox && el.kioskManutencaoCheckbox.checked) {
          el.kioskManutencaoCheckbox.checked = false;
          el.kioskManutencaoCheckbox.dispatchEvent(new Event("change"));
        }
      }
      const toggleField = document.getElementById("kioskProgToggleField");
      if (toggleField) {
        toggleField.classList.toggle("active", state.programmingMode);
      }
      renderLiberacaoDual();
    });
  }
  if (el.kioskProgToggleField && el.kioskProgCheckbox) {
    el.kioskProgToggleField.addEventListener("click", (e) => {
      if (e.target !== el.kioskProgCheckbox && !el.kioskProgCheckbox.contains(e.target)) {
        el.kioskProgCheckbox.checked = !el.kioskProgCheckbox.checked;
        el.kioskProgCheckbox.dispatchEvent(new Event("change"));
      }
    });
  }

  if (el.kioskLibCheckbox) {
    el.kioskLibCheckbox.addEventListener("change", () => {
      state.liberationMode = el.kioskLibCheckbox.checked;
      document.body.classList.toggle("liberation-active", state.liberationMode);
      if (state.liberationMode) {
        if (el.kioskProgCheckbox && el.kioskProgCheckbox.checked) {
          el.kioskProgCheckbox.checked = false;
          el.kioskProgCheckbox.dispatchEvent(new Event("change"));
        }
        if (el.kioskOdinCheckbox && el.kioskOdinCheckbox.checked) {
          el.kioskOdinCheckbox.checked = false;
          el.kioskOdinCheckbox.dispatchEvent(new Event("change"));
        }
        if (el.kioskManutencaoCheckbox && el.kioskManutencaoCheckbox.checked) {
          el.kioskManutencaoCheckbox.checked = false;
          el.kioskManutencaoCheckbox.dispatchEvent(new Event("change"));
        }
      }
      const toggleField = document.getElementById("kioskLibToggleField");
      if (toggleField) {
        toggleField.classList.toggle("active", state.liberationMode);
      }
      renderLiberacaoDual();
    });
  }

  if (el.kioskLibToggleField && el.kioskLibCheckbox) {
    el.kioskLibToggleField.addEventListener("click", (e) => {
      if (e.target !== el.kioskLibCheckbox && !el.kioskLibCheckbox.contains(e.target)) {
        el.kioskLibCheckbox.checked = !el.kioskLibCheckbox.checked;
        el.kioskLibCheckbox.dispatchEvent(new Event("change"));
      }
    });
  }

  if (el.kioskOdinCheckbox) {
    el.kioskOdinCheckbox.addEventListener("change", () => {
      if (el.kioskOdinCheckbox.checked && !["user-ricardo", "alex", "philippe"].includes(String(state.authUser?.id || ""))) {
        el.kioskOdinCheckbox.checked = false;
      }
      state.odinMode = el.kioskOdinCheckbox.checked;
      document.body.classList.toggle("odin-active", state.odinMode);
      if (el.btnCorrecaoConcretagem) {
        el.btnCorrecaoConcretagem.textContent = state.odinMode ? "Encerrar ODIN" : "Modo ODIN";
        el.btnCorrecaoConcretagem.classList.toggle("primary", state.odinMode);
      }
      if (state.odinMode) {
        if (el.kioskProgCheckbox && el.kioskProgCheckbox.checked) {
          el.kioskProgCheckbox.checked = false;
          el.kioskProgCheckbox.dispatchEvent(new Event("change"));
        }
        if (el.kioskLibCheckbox && el.kioskLibCheckbox.checked) {
          el.kioskLibCheckbox.checked = false;
          el.kioskLibCheckbox.dispatchEvent(new Event("change"));
        }
        if (el.kioskManutencaoCheckbox && el.kioskManutencaoCheckbox.checked) {
          el.kioskManutencaoCheckbox.checked = false;
          el.kioskManutencaoCheckbox.dispatchEvent(new Event("change"));
        }
      }
      const toggleField = document.getElementById("kioskOdinToggleField");
      if (toggleField) {
        toggleField.classList.toggle("active", state.odinMode);
      }
      renderLiberacaoDual();
    });
  }

  if (el.btnCorrecaoConcretagem && el.kioskOdinCheckbox) {
    el.btnCorrecaoConcretagem.addEventListener("click", () => el.kioskOdinCheckbox.click());
  }

  if (el.kioskManutencaoCheckbox) {
    el.kioskManutencaoCheckbox.addEventListener("change", () => {
      state.manutencaoMode = el.kioskManutencaoCheckbox.checked;
      document.body.classList.toggle("manutencao-active", state.manutencaoMode);
      if (state.manutencaoMode) {
        if (el.kioskProgCheckbox && el.kioskProgCheckbox.checked) {
          el.kioskProgCheckbox.checked = false;
          el.kioskProgCheckbox.dispatchEvent(new Event("change"));
        }
        if (el.kioskLibCheckbox && el.kioskLibCheckbox.checked) {
          el.kioskLibCheckbox.checked = false;
          el.kioskLibCheckbox.dispatchEvent(new Event("change"));
        }
        if (el.kioskOdinCheckbox && el.kioskOdinCheckbox.checked) {
          el.kioskOdinCheckbox.checked = false;
          el.kioskOdinCheckbox.dispatchEvent(new Event("change"));
        }
      }
      const toggleField = document.getElementById("kioskManutencaoToggleField");
      if (toggleField) {
        toggleField.classList.toggle("active", state.manutencaoMode);
      }
      renderLiberacaoDual();
    });
  }

  const kioskManutencaoToggleField = document.getElementById("kioskManutencaoToggleField");
  if (kioskManutencaoToggleField && el.kioskManutencaoCheckbox) {
    kioskManutencaoToggleField.addEventListener("click", (e) => {
      if (e.target !== el.kioskManutencaoCheckbox && !el.kioskManutencaoCheckbox.contains(e.target)) {
        el.kioskManutencaoCheckbox.checked = !el.kioskManutencaoCheckbox.checked;
        el.kioskManutencaoCheckbox.dispatchEvent(new Event("change"));
      }
    });
  }

  // Eventos dos Modais de Manutenção
  const modalParada = document.getElementById("modalManutencaoParada");
  const modalLiberacao = document.getElementById("modalManutencaoLiberacao");

  document.getElementById("mParadaCancelBtn")?.addEventListener("click", () => {
    modalParada?.classList.remove("modal-visible");
  });
  modalParada?.addEventListener("click", (e) => {
    if (e.target === modalParada) {
      modalParada.classList.remove("modal-visible");
    }
  });

  document.getElementById("mParadaConfirmBtn")?.addEventListener("click", () => {
    if (!pendingManutencaoSelection) return;
    const motivo = document.getElementById("mParadaMotivo")?.value?.trim();
    const acao = document.getElementById("mParadaAcao")?.value?.trim();
    if (!motivo) {
      alert("Por favor, preencha o motivo da parada.");
      document.getElementById("mParadaMotivo")?.focus();
      return;
    }
    if (!acao) {
      alert("Por favor, preencha o que precisa ser feito para arrumar.");
      document.getElementById("mParadaAcao")?.focus();
      return;
    }
    salvarFormaParadaManutencao(pendingManutencaoSelection.setor, pendingManutencaoSelection.formaNumero, motivo, acao);
    modalParada?.classList.remove("modal-visible");
    renderLiberacaoDual();
    renderizarRelatorioManutencao();
    setSyncStatus("ok", `Forma ${pendingManutencaoSelection.formaNumero} inativada por manutenção.`);
  });

  document.getElementById("mLiberacaoCancelBtn")?.addEventListener("click", () => {
    modalLiberacao?.classList.remove("modal-visible");
  });
  modalLiberacao?.addEventListener("click", (e) => {
    if (e.target === modalLiberacao) {
      modalLiberacao.classList.remove("modal-visible");
    }
  });

  document.getElementById("mLiberacaoConfirmBtn")?.addEventListener("click", () => {
    if (!pendingManutencaoSelection) return;
    const obs = document.getElementById("mLiberacaoObs")?.value?.trim();
    if (!obs) {
      alert("Por favor, informe a observação/serviço realizado na liberação.");
      document.getElementById("mLiberacaoObs")?.focus();
      return;
    }
    liberarFormaManutencao(pendingManutencaoSelection.setor, pendingManutencaoSelection.formaNumero, obs);
    modalLiberacao?.classList.remove("modal-visible");
    renderLiberacaoDual();
    setSyncStatus("ok", `Forma ${pendingManutencaoSelection.formaNumero} liberada da manutenção.`);
  });

  ["rmFiltroStatus", "rmFiltroDataInicio", "rmFiltroDataFim"].forEach((id) => {
    document.getElementById(id)?.addEventListener("input", renderizarRelatorioManutencao);
  });
  document.getElementById("rmBtnLimparFiltros")?.addEventListener("click", () => {
    const status = document.getElementById("rmFiltroStatus");
    const dataInicio = document.getElementById("rmFiltroDataInicio");
    const dataFim = document.getElementById("rmFiltroDataFim");
    if (status) status.value = "TODOS";
    if (dataInicio) dataInicio.value = "";
    if (dataFim) dataFim.value = "";
    renderizarRelatorioManutencao();
  });

  document.getElementById("rmBtnImprimirPDF")?.addEventListener("click", () => {
    document.body.classList.add("print-relatorio-manutencao");
    window.print();
    document.body.classList.remove("print-relatorio-manutencao");
  });

  // Controle de Tela Cheia no Quiosque
  if (el.btnKioskFullscreen) {
    el.btnKioskFullscreen.addEventListener("click", () => {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(err => {
          console.error(`Erro ao ativar Tela Cheia: ${err.message}`);
        });
        el.btnKioskFullscreen.textContent = " Sair Tela Cheia";
      } else {
        document.exitFullscreen().catch(() => {});
        el.btnKioskFullscreen.textContent = " Tela Cheia";
      }
    });
  }
  document.addEventListener("fullscreenchange", () => {
    if (el.btnKioskFullscreen) {
      if (document.fullscreenElement) {
        el.btnKioskFullscreen.textContent = " Sair Tela Cheia";
      } else {
        el.btnKioskFullscreen.textContent = " Tela Cheia";
      }
    }
  });

  // Botão Sair Quiosque
  if (el.btnKioskBack) {
    el.btnKioskBack.addEventListener("click", () => {
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(() => {});
      }
      if (el.kioskLibCheckbox && el.kioskLibCheckbox.checked) {
        el.kioskLibCheckbox.checked = false;
        el.kioskLibCheckbox.dispatchEvent(new Event("change"));
      }
      if (el.kioskOdinCheckbox && el.kioskOdinCheckbox.checked) {
        el.kioskOdinCheckbox.checked = false;
        el.kioskOdinCheckbox.dispatchEvent(new Event("change"));
      }
      if (el.kioskManutencaoCheckbox && el.kioskManutencaoCheckbox.checked) {
        el.kioskManutencaoCheckbox.checked = false;
        el.kioskManutencaoCheckbox.dispatchEvent(new Event("change"));
      }
      document.body.classList.remove("kiosk-active", "liberation-active", "odin-active", "manutencao-active");
      setMode("HUB");
    });
  }

  if (el.btnKioskSync) {
    el.btnKioskSync.addEventListener("click", async () => {
      const btn = el.btnKioskSync;
      const oldText = btn.textContent;
      btn.textContent = "Sincronizando...";
      btn.disabled = true;
      try {
        await loadProgrammedFormas();
        await loadClickedFormsFromSupabase();
        renderLiberacaoDual();
        showLibFeedback("Sincronização concluída com sucesso!", "ok");
      } catch (err) {
        showLibFeedback("Erro ao sincronizar.", "error");
      } finally {
        btn.textContent = oldText;
        btn.disabled = false;
      }
    });
  }
  if (el.btnLimparFormas) {
    el.btnLimparFormas.addEventListener("click", () => {
      if (!confirm("Limpar todas as formas concretadas? (não apaga da planilha)")) return;
      localStorage.removeItem(CLICKED_FORMS_KEY);
      renderLiberacaoDual();
    });
  }

  el.insFiltroData.addEventListener("change", renderInspecaoLiberados);
  el.insModoCarga.addEventListener("change", renderInspecaoLiberados);
  if (el.insStatusFiltro) {
    el.insStatusFiltro.addEventListener("change", renderInspecaoLiberados);
  }
  if (el.insSetorGroup) {
    el.insSetorGroup.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      const btn = target.closest(".sector-filter-btn");
      if (!btn) return;
      el.insSetorGroup.querySelectorAll(".sector-filter-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      state.activeInsSector = btn.dataset.sectorVal || "";
      clearSubmitLock("inspecao");
      renderInspecaoLiberados();
    });
  }
  if (el.insCarregarLiberados) {
    el.insCarregarLiberados.addEventListener("click", renderInspecaoLiberados);
    el.insCarregarLiberados.addEventListener("click", () => clearSubmitLock("inspecao"));
  }
  if (el.insFiltroData) {
    el.insFiltroData.addEventListener("change", () => clearSubmitLock("inspecao"));
  }
  if (el.insColaborador) {
    el.insColaborador.addEventListener("input", () => clearSubmitLock("inspecao"));
  }
  if (el.insFormaFiltro) {
    el.insFormaFiltro.addEventListener("input", filtrarFormasTabela);
  }

  if (el.insLiberadosBody) {
    el.insLiberadosBody.addEventListener("click", async (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;

      const tr = target.closest("tr[data-record-id]");
      if (!tr) return;

      const recordId = tr.dataset.recordId;
      const dataFabricacao = tr.dataset.dataFabricacao;
      const setor = tr.dataset.setor;
      const formaNumero = tr.dataset.formaNumero;
      const modelo = tr.dataset.modelo;
      const codigoPoste = tr.dataset.codigoPoste;
      const descricaoPoste = tr.dataset.descricaoPoste;
      const codigoProduto = tr.dataset.codigoProduto;

      const posteBase = {
        recordId,
        dataFabricacao,
        setor,
        formaNumero,
        modelo,
        codigoPoste,
        descricaoPoste,
        codigoProduto
      };

      if (target.closest(".ins-def-select-btn")) {
        window.insDefeitosSelecionarPoste?.(posteBase);
        return;
      }
      if (target.closest(".ins-open-btn")) {
        await openInspecaoPosteDetalhe(posteBase);
      } else if (target.closest(".ins-ver-checklist-btn") || tr.dataset.inspecaoRaw) {
        const rawJson = tr.dataset.inspecaoRaw;
        if (rawJson) {
          try {
            const rawRow = JSON.parse(rawJson);
            if (String(rawRow.status_montagem || "").toUpperCase() === "R"
                && !rawRow.checklists?.__segunda_inspecao) {
              abrirEscolhaPosteReprovado(rawRow, posteBase);
            } else {
              await window.abrirVisualizacaoChecklist(rawRow);
            }
          } catch (e) {
            console.error("Erro ao analisar inspecaoRaw:", e);
          }
        }
      }
    });
  }

  if (el.insChecklistSections) {
    el.insChecklistSections.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.matches("img.mp-item-photo-thumbnail")) {
        window.abrirFotoVisualizacao(target.src);
        return;
      }
      const btn = target.closest("button[data-ins-section][data-ins-item][data-ins-value]");
      if (!btn) return;
      const sectionId = btn.dataset.insSection || "";
      const itemId = btn.dataset.insItem || "";
      const value = btn.dataset.insValue || "";
      setInspecaoChecklistAnswer(sectionId, itemId, value);
    });

    el.insChecklistSections.addEventListener("change", async (event) => {
      const target = event.target;
      if (!(target instanceof HTMLInputElement)) return;
      if (!target.classList.contains("ins-item-photo-input")) return;

      const file = target.files?.[0];
      if (!file) return;

      const sectionId = target.dataset.insSection || "";
      const itemId = target.dataset.insItem || "";

      target.disabled = true;
      setSyncStatus("warn", "Processando foto da inspeção...");
      try {
        const dataUrl = await fileToDataUrl(file);
        const base64 = await compressImage(dataUrl, 1024, 0.7);
        const sync = await setInspecaoChecklistPhoto(sectionId, itemId, base64);
        if (sync?.synced) setSyncStatus("ok", "Foto salva e vinculada à inspeção.");
      } catch (err) {
        console.error("Erro ao salvar foto da inspeção:", err);
        showMsgBox(`Foto não salva: ${err.message || "Tente novamente."}`, "error");
      } finally {
        target.disabled = false;
        target.value = "";
      }
    });
  }

  if (el.insStatusButtons) {
    el.insStatusButtons.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      const btn = target.closest("button[data-ins-status]");
      if (!btn || state.inspecaoPostesAtual?.finalizadoEm) return;
      const status = btn.dataset.insStatus || "";
      if (!status) return;
      setInspecaoStatus(status);
    });
  }

  if (el.insObservacoes) {
    el.insObservacoes.addEventListener("input", () => {
      if (!state.inspecaoPostesAtual) return;
      state.inspecaoPostesAtual.observacoesMontagem = el.insObservacoes.value;
      upsertMontagemPoste(state.inspecaoPostesAtual);
    });
  }

  if (el.insFinalizarPoste) {
    el.insFinalizarPoste.addEventListener("click", finalizarInspecaoPosteAtual);
  }

  if (el.mpFiltroData) el.mpFiltroData.addEventListener("change", renderMontagemPostesLiberados);
  if (el.mpModoCarga) el.mpModoCarga.addEventListener("change", renderMontagemPostesLiberados);
  if (el.mpSetor) el.mpSetor.addEventListener("change", renderMontagemPostesLiberados);
  if (el.mpStatusFiltro) el.mpStatusFiltro.addEventListener("change", renderMontagemPostesLiberados);
  if (el.mpCarregarLiberados) el.mpCarregarLiberados.addEventListener("click", renderMontagemPostesLiberados);
  if (el.mpFormaFiltro) el.mpFormaFiltro.addEventListener("input", filtrarMontagemTabela);

  if (el.mpLiberadosBody) {
    el.mpLiberadosBody.addEventListener("click", async (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;

      const verChecklistBtn = target.closest(".mp-ver-checklist-btn");
      const finalizadoRow = target.closest("tr[data-forma-numero]");
      if (verChecklistBtn || (finalizadoRow?.dataset.montagemRaw && !target.closest(".mp-open-btn"))) {
        const tr = finalizadoRow;
        if (tr && tr.dataset.montagemRaw) {
          try {
            const montRecord = JSON.parse(tr.dataset.montagemRaw);
            if (String(montRecord.status_montagem || "").toUpperCase() === "R"
                && !montRecord.checklists?.__segunda_inspecao
                && isModeAllowed("MONTAGEM_POSTES")) {
              abrirEscolhaPosteReprovado(montRecord, {
                recordId: tr.dataset.recordId || "",
                dataFabricacao: tr.dataset.dataFabricacao || "",
                setor: tr.dataset.setor || "",
                formaNumero: tr.dataset.formaNumero || "",
                modelo: tr.dataset.modelo || "",
                codigoPoste: tr.dataset.codigoPoste || "",
                descricaoPoste: tr.dataset.descricaoPoste || "",
                codigoProduto: tr.dataset.codigoProduto || ""
              }, "MONTAGEM_POSTES");
            } else {
              window.abrirVisualizacaoChecklist(montRecord);
            }
          } catch (e) {
            console.error("Erro ao abrir visualização do checklist:", e);
          }
        }
        return;
      }

      const btn = target.closest(".mp-open-btn");
      if (!btn) return;
      const tr = btn.closest("tr[data-forma-numero]");
      if (!tr) return;

      await openMontagemPosteDetalhe({
        recordId: tr.dataset.recordId || "",
        dataFabricacao: tr.dataset.dataFabricacao || "",
        setor: tr.dataset.setor || "",
        formaNumero: tr.dataset.formaNumero || "",
        modelo: tr.dataset.modelo || "",
        codigoPoste: tr.dataset.codigoPoste || "",
        descricaoPoste: tr.dataset.descricaoPoste || "",
        codigoProduto: tr.dataset.codigoProduto || ""
      });
    });
  }

  if (el.mpChecklistSections) {
    el.mpChecklistSections.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.matches("img.mp-item-photo-thumbnail")) {
        window.abrirFotoVisualizacao(target.src);
        return;
      }
      const btn = target.closest("button[data-mp-section][data-mp-item][data-mp-value]");
      if (!btn) return;
      const sectionId = btn.dataset.mpSection || "";
      const itemId = btn.dataset.mpItem || "";
      const value = btn.dataset.mpValue || "";
      setMontagemChecklistAnswer(sectionId, itemId, value);
    });

    el.mpChecklistSections.addEventListener("change", async (event) => {
      const target = event.target;
      if (!(target instanceof HTMLInputElement)) return;
      if (!target.classList.contains("mp-item-photo-input")) return;

      const file = target.files?.[0];
      if (!file) return;

      const sectionId = target.dataset.mpSection || "";
      const itemId = target.dataset.mpItem || "";

      target.disabled = true;
      setSyncStatus("warn", "Processando foto da montagem...");
      try {
        const dataUrl = await fileToDataUrl(file);
        const base64 = await compressImage(dataUrl, 1024, 0.7);
        const sync = await setMontagemChecklistPhoto(sectionId, itemId, base64);
        if (sync?.synced) setSyncStatus("ok", "Foto salva e vinculada ao checklist.");
      } catch (err) {
        console.error("Erro ao salvar foto da montagem:", err);
        showMsgBox(`Foto não salva: ${err.message || "Tente novamente."}`, "error");
      } finally {
        target.disabled = false;
        target.value = "";
      }
    });
  }

  if (el.mpStatusButtons) {
    el.mpStatusButtons.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      const btn = target.closest("button[data-mp-status]");
      if (!btn || state.montagemPostesAtual?.finalizadoEm) return;
      const status = btn.dataset.mpStatus || "";
      if (!status) return;
      setMontagemStatus(status);
    });
  }

  if (el.mpMotivoSelect) {
    el.mpMotivoSelect.addEventListener("change", () => {
      if (state.montagemPostesAtual?.finalizadoEm) return;
      setMontagemMotivoRecusa(el.mpMotivoSelect.value || "");
    });
  }

  if (el.mpObservacoes) {
    el.mpObservacoes.addEventListener("input", () => {
      if (!state.montagemPostesAtual || state.montagemPostesAtual.finalizadoEm) return;
      const current = { ...state.montagemPostesAtual };
      current.observacoesMontagem = (el.mpObservacoes.value || "").trim();
      state.montagemPostesAtual = current;
      upsertMontagemPoste(current);
      syncMontagemPosteToApi(current, "CHECKLIST", { silent: true }).catch(() => {});
    });
  }

  if (el.mpFinalizarPoste) el.mpFinalizarPoste.addEventListener("click", () => {
    finalizarMontagemPosteAtual();
  });

  if (el.atualizarDashboard) el.atualizarDashboard.addEventListener("click", carregarDashboardConcretagem);
  if (el.dashData) el.dashData.addEventListener("change", carregarDashboardConcretagem);
  if (el.filtrarHistorico) el.filtrarHistorico.addEventListener("click", () => renderHistorico());
  el.histTipo?.addEventListener("change", () => renderHistorico());
  if (el.gerarRelatorioSetor) el.gerarRelatorioSetor.addEventListener("click", gerarRelatorioSetor);
  if (el.relBtnImprimir) el.relBtnImprimir.addEventListener("click", imprimirRelatorioSetor);
  if (el.relBtnWhatsapp) el.relBtnWhatsapp.addEventListener("click", enviarRelatorioWhatsapp);
  if (el.acmpCarregar) el.acmpCarregar.addEventListener("click", renderAcmpConcretagem);
  if (el.acmpData) el.acmpData.addEventListener("change", renderAcmpConcretagem);
  if (el.acmpModoCarga) el.acmpModoCarga.addEventListener("change", renderAcmpConcretagem);
  if (el.acmpSetor) el.acmpSetor.addEventListener("change", renderAcmpConcretagem);
  if (el.acmpSalvar) el.acmpSalvar.addEventListener("click", salvarAcmp);
  if (el.acmpImprimir) el.acmpImprimir.addEventListener("click", imprimirAcmp);

  if (el.insFotos) el.insFotos.addEventListener("change", async (event) => {
    clearSubmitLock("inspecao");
    const files = Array.from(event.target.files || []);
    state.insPhotosRawFiles = (state.insPhotosRawFiles || []).concat(files);
    const photos = await filesToCompressedDataUrls(event.target.files);
    state.insPhotos = state.insPhotos.concat(photos);
    renderPhotoPreview(el.insFotosPreview, state.insPhotos);
  });

  // Sidebar toggle
  const appSidebar = document.getElementById("appSidebar");
  const appShell   = document.querySelector(".app-shell");
  const sidebarOverlay = document.getElementById("sidebarOverlay");
  const sidebarToggle  = document.getElementById("sidebarToggle");

  // Restaura estado colapsado no desktop
  if (localStorage.getItem("sidebarCollapsed") === "1") {
    document.body.classList.add("sidebar-hidden");
  }

  function closeMobileSidebar() {
    appSidebar?.classList.remove("sidebar-open");
    sidebarOverlay?.classList.remove("visible");
  }

  if (!state.essentialNavigationBound && sidebarToggle && appSidebar) {
    sidebarToggle.addEventListener("click", () => {
      if (window.innerWidth <= 1024) {
        // Mobile: drawer com overlay
        appSidebar.classList.toggle("sidebar-open");
        sidebarOverlay?.classList.toggle("visible");
      } else {
        // Desktop/tablet: colapsa sem overlay
        const hidden = document.body.classList.toggle("sidebar-hidden");
        localStorage.setItem("sidebarCollapsed", hidden ? "1" : "0");
      }
    });
  }
  if (!state.essentialNavigationBound && sidebarOverlay && appSidebar) {
    sidebarOverlay.addEventListener("click", closeMobileSidebar);
  }
  if (!state.essentialNavigationBound) {
    document.querySelectorAll(".nav-item").forEach((btn) => {
      btn.addEventListener("click", () => {
        if (window.innerWidth <= 1024) closeMobileSidebar();
      });
    });
  }
  const navInicio = document.getElementById("navInicio");
  if (navInicio) navInicio.addEventListener("click", () => setMode("HUB"));
  const navDashboard = document.getElementById("navDashboard");
  if (navDashboard) navDashboard.addEventListener("click", () => setMode("DASHBOARD"));
  const navProdAnalise = document.getElementById("navProdAnalise");
  if (navProdAnalise) navProdAnalise.addEventListener("click", () => setMode("PROD_ANALISE"));

  const hubMandrilCircular = document.getElementById("hubMandrilCircular");
  if (hubMandrilCircular) hubMandrilCircular.addEventListener("click", () => setMode("MANDRIL_CIRCULAR"));
  document.getElementById("hubRelatorio")?.addEventListener("click", () => handleHubModeNavigation("RELATORIO"));
  document.getElementById("hubHistorico")?.addEventListener("click", () => handleHubModeNavigation("HISTORICO"));

  if (el.mcFiltroData) el.mcFiltroData.addEventListener("change", carregarMandrilCircular);

  // Productivity filters & actions
  document.getElementById("paBtnToggleFiltros")?.addEventListener("click", () => setProdutividadeDrawerOpen(true));
  document.getElementById("paBtnFecharFiltros")?.addEventListener("click", () => setProdutividadeDrawerOpen(false));
  document.getElementById("paFiltrosDrawer")?.addEventListener("click", (ev) => {
    if (ev.target?.id === "paFiltrosDrawer") setProdutividadeDrawerOpen(false);
  });
  document.getElementById("paBtnAtualizar")?.addEventListener("click", carregarProdutividadeConcretagem);
  const paBtnFiltrar = document.getElementById("paBtnFiltrar");
  if (paBtnFiltrar) paBtnFiltrar.addEventListener("click", () => {
    setProdutividadeDrawerOpen(false);
    carregarProdutividadeConcretagem();
  });
  document.getElementById("paBtnLimparFiltros")?.addEventListener("click", () => {
    clearSavedDashboardFilter("pa");
    document.getElementById("paDataInicio").value = todayYmd();
    document.getElementById("paDataFim").value = todayYmd();
    document.getElementById("paFiltroSetor").value = "";
    document.getElementById("paMetaCiclo").value = "15";
    syncDashboardFilterChips("pa");
    setProdutividadeDrawerOpen(false);
    carregarProdutividadeConcretagem();
  });
  const paBtnExportarCSV = document.getElementById("paBtnExportarCSV");
  if (paBtnExportarCSV) paBtnExportarCSV.addEventListener("click", exportarPaCSV);
  const paBtnExportarDadosCSV = document.getElementById("paBtnExportarDadosCSV");
  if (paBtnExportarDadosCSV) paBtnExportarDadosCSV.addEventListener("click", exportarPaDadosCSV);
  const paBtnExportarExcel = document.getElementById("paBtnExportarExcel");
  if (paBtnExportarExcel) paBtnExportarExcel.addEventListener("click", exportarPaExcel);
  const paBtnExportarPDF = document.getElementById("paBtnExportarPDF");
  if (paBtnExportarPDF) paBtnExportarPDF.addEventListener("click", exportarPaPDF);
  document.querySelectorAll("[data-pa-tab]").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const targetTab = e.currentTarget.dataset.paTab;
      document.querySelectorAll("[data-pa-tab]").forEach(b => b.classList.remove("active"));
      e.currentTarget.classList.add("active");
      document.querySelectorAll(".pa-tab-section").forEach(section => section.classList.remove("active"));
      const sectionId = "paSecao" + targetTab.charAt(0).toUpperCase() + targetTab.slice(1);
      document.getElementById(sectionId)?.classList.add("active");
      Object.values(chartInstances).forEach(chart => chart?.resize?.());
    });
  });

  // Dashboard charts filter
  const dbData = document.getElementById("dbData");
  if (dbData) dbData.addEventListener("change", carregarDadosGlobaisDashboard);
  const dbBtnHoje = document.getElementById("dbBtnHoje");
  if (dbBtnHoje) dbBtnHoje.addEventListener("click", () => {
    if (dbData) dbData.value = todayYmd();
    carregarDadosGlobaisDashboard();
  });
  const dbBtnAtualizar = document.getElementById("dbBtnAtualizar");
  if (dbBtnAtualizar) dbBtnAtualizar.addEventListener("click", carregarDadosGlobaisDashboard);

  document.querySelectorAll("[data-hub-mode]").forEach((btn) => {
    if (btn.dataset.hubNavBound === "1") return;
    btn.addEventListener("click", () => {
      handleHubModeNavigation(btn.dataset.hubMode || "");
    });
  });

  // Sequencia Setor 3 bindings
  el.seqS3Data?.addEventListener("change", () => {
    renderSequenciaS3();
  });
  el.seqS3Search?.addEventListener("input", () => {
    filterSequenciaS3();
  });
  el.seqS3BtnSalvar?.addEventListener("click", () => {
    saveSequenciaS3();
  });
}

async function syncOfflineData() {
  if (!supabaseClient) return;

  let syncedCount = 0;

  // 1. Sincronizar montagem_poste (Etapa MONTAGEM / INSPECAO)
  try {
    const mpDb = readMontagemPostesDb();
    const pendingKeys = Object.keys(mpDb.postes || {}).filter(key => mpDb.postes[key].pendingSync === true);
    for (const key of pendingKeys) {
      const entry = mpDb.postes[key];
      // Tenta re-enviar para o Supabase
      const payload = buildMontagemPostePayload(entry, entry.etapa || "FINALIZACAO");
      const apiResult = await postToMontagemApiWithTimeout("salvar_montagem_poste", payload);
      if (apiResult.ok) {
        mpDb.postes[key].pendingSync = false;
        syncedCount++;
      }
    }
    if (pendingKeys.length > 0) {
      writeMontagemPostesDb(mpDb);
    }
  } catch (err) {
    console.error("[syncOfflineData] Erro ao sincronizar montagem:", err);
  }

  // 2. Sincronizar apontamentos de concretagem e inspeções locais (LIBERACAO / INSPECAO)
  try {
    const db = readDb();
    let dbChanged = false;

    // Sincronizar eventos pendentes
    for (let ev of db.events || []) {
      if (ev.pendingSync === true) {
        if (ev.etapa === "LIBERACAO") {
          const payload = {
            dia: new Date(ev.timestamp).toLocaleDateString("pt-BR"),
            hora: new Date(ev.timestamp).toLocaleTimeString("pt-BR"),
            setor: ev.setor,
            forma: ev.formaNumero,
            dataFabricacao: ev.dataFabricacao,
            colaborador: ev.colaborador,
            modelo: ev.modelo || "",
            tipo_concreto: ev.tipoConcreto || "Padrão",
            vibrado: ev.vibrado ?? null,
            codigo_poste: ev.codigoPoste || null,
            descricao_poste: ev.descricaoPoste || null,
            codigo_produto: ev.codigoProduto || null,
            status: ev.status || "LIBERADO"
          };
          const apiResult = await postToApi("salvar_forma_click", payload);
          if (apiResult.ok) {
            ev.pendingSync = false;
            dbChanged = true;
            syncedCount++;
          }
        } else if (ev.etapa === "INSPECAO") {
          const record = db.records.find(r => r.id === ev.recordId);
          const inspecaoLoc = record?.inspecoes?.find(ins => ins.pendingSync === true);

          if (record && inspecaoLoc) {
            // Sincronizar registro montagem_poste individual
            const composedKey = [record.id, record.dataFabricacao, record.setor, record.formaNumero, 'INSPECAO'].join("||");
            const payload = {
              key: composedKey,
              recordId: record.id,
              dataFabricacao: record.dataFabricacao,
              setor: record.setor,
              formaNumero: record.formaNumero,
              modelo: record.modelo || "",
              codigoPoste: record.codigoPoste || "",
              descricaoPoste: record.descricaoPoste || "",
              codigoProduto: record.codigoProduto || "",
              statusMontagem: inspecaoLoc.status,
              motivoRecusa: inspecaoLoc.codigos?.[0] || "",
              etapa: "INSPECAO",
              inicioInspecaoMontagem: ev.timestamp,
              finalizadoEm: ev.timestamp,
              checklists: {},
              observacoesMontagem: inspecaoLoc.observacoes || "",
              montadorNome: inspecaoLoc.colaborador
            };
            const apiResult = await postToMontagemApi("salvar_montagem_poste", payload);
            if (apiResult.ok) {
              ev.pendingSync = false;
              inspecaoLoc.pendingSync = false;
              dbChanged = true;
              syncedCount++;
            }
          }
        }
      }
    }

    if (dbChanged) {
      writeDb(db);
    }
  } catch (err) {
    console.error("[syncOfflineData] Erro ao sincronizar apontamentos:", err);
  }

  // 3. Sincronizar prog_s3_s4 (Sequencia Setor 3)
  try {
    const progDb = readProgS3S4Db();
    let progChanged = false;
    const pendingKeys = Object.keys(progDb.programacoes || {}).filter(key => progDb.programacoes[key].pendingSync === true);
    for (const key of pendingKeys) {
      const entry = progDb.programacoes[key];
      const { error } = await supabaseClient
        .from("prog_s3_s4")
        .upsert({
          data: entry.data,
          forma: entry.forma,
          setor: entry.setor,
          modelo: entry.modelo
        }, { onConflict: "data,forma,setor" });

      if (!error) {
        progDb.programacoes[key].pendingSync = false;
        progChanged = true;
        syncedCount++;
      }
    }
    if (progChanged) {
      writeProgS3S4Db(progDb);
    }
  } catch (err) {
    console.error("[syncOfflineData] Erro ao sincronizar prog_s3_s4:", err);
  }

  if (syncedCount > 0) {
    setSyncStatus("ok", `Sincronização offline automática concluída! ${syncedCount} item(ns) enviado(s).`);
    try {
      await loadClickedFormsFromSupabase();
      await sincronizarManutencaoLocalPendente();
      renderLiberacaoDual();
      renderizarRelatorioManutencao();
    } catch (e) {
      console.error("Erro ao recarregar dados pós sincronização:", e);
    }
  }
}

// Sincronização offline automática ao restabelecer sinal de rede
window.addEventListener("online", () => {
  setSyncStatus("pending", "Conexão restabelecida. Sincronizando dados offline...");
  syncOfflineData();
});

// Sweeper de sincronização rodando periodicamente a cada 30 segundos
setInterval(() => {
  if (navigator.onLine) {
    syncOfflineData();
  }
}, 30000);

// Sincronização automática de dados a cada 3 minutos (pull de novas programações e concretagens)
setInterval(async () => {
  if (navigator.onLine) {
    try {
      console.log("[Auto-Sync] Iniciando sincronização automática periódica (3 minutos)...");
      await loadProgrammedFormas();
      await loadClickedFormsFromSupabase();
      renderLiberacaoDual();
      console.log("[Auto-Sync] Sincronização automática periódica concluída com sucesso.");
    } catch (err) {
      console.error("[Auto-Sync] Erro na sincronização automática periódica:", err);
    }
  }
}, 180000);

function subscribeToRealtimeUpdates() {
  if (!supabaseClient) return;
  const channel = supabaseClient.channel('custom-producao-channel')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'producao' },
      async (payload) => {
        console.log("Realtime event on producao:", payload);
        const dataAtual = el.libData?.value || todayYmd();
        // If the change is for the currently viewed date
        if (payload.new && payload.new.data_fabricacao === dataAtual) {
          // Re-fetch everything silently and re-render
          await loadClickedFormsFromSupabase();
          // Atualiza as interfaces que estão abertas
          if (["LIBERACAO", "LIBERACAO_S1", "LIBERACAO_S2", "LIBERACAO_S3", "LIBERACAO_S4"].includes(state.activeLiberacaoSector)) {
            renderLiberacaoDual();
          }
        }
      }
    )
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: MANUTENCAO_FORMAS_TABLE },
      async () => {
        await carregarFormasManutencaoSupabase();
        renderLiberacaoDual();
        renderizarRelatorioManutencao();
      }
    )
    .subscribe((status) => {
      if (status === 'SUBSCRIBED') {
        console.log('Realtime subscribed to producao changes');
      }
    });
}

const VOLUME_PRODUTO_M3 = {
  "935": 0.18,
  "938": 0.18,
  "941": 0.22,
  "943": 0.22,
  "936": 0.30,
  "939": 0.30,
  "13580": 0.25,
  "DEFAULT": 0.20,
  "SETOR_4": 0.08
};

function getFormVolume(codigo, modelo, setor = "") {
  const code = String(codigo || "").trim();
  if (VOLUME_PRODUTO_M3[code]) return VOLUME_PRODUTO_M3[code];
  if (setor === "Setor 4") return VOLUME_PRODUTO_M3.SETOR_4;

  const m = String(modelo || "").toUpperCase();
  if (m.includes("1 CX")) return 0.18;
  if (m.includes("2 CX") || m.includes("2CX")) return 0.22;
  if (m.includes("3 CX") || m.includes("3CX")) return 0.26;
  if (m.includes("4 CX") || m.includes("4CX")) return 0.30;
  if (m.includes("600")) return 0.30;
  if (m.includes("300")) return 0.22;
  if (m.includes("SUB.") || m.includes("SUBTERRANEO")) return 0.20;
  if (m.includes("DTB") || m.includes("DTD")) return 0.25;
  if (m.includes("CEMIG")) return 0.18;
  if (m.includes("6,0 X 90") || m.includes("7,5 X 90")) return 0.08;
  if (m.includes("7,0 X 150") || m.includes("7,5 X 200")) return 0.12;

  return VOLUME_PRODUTO_M3.DEFAULT;
}

function isConcretePadrao(row) {
  const raw = row?.tipo_concreto || row?.tipoConcreto || row?.concretoTipo || "";
  if (!raw) return true;
  const normalized = String(raw).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase();
  if (normalized === "INSPECIONADO") return true;
  const isDefect = normalized.includes("SECO") || normalized.includes("SEGREGAD") || normalized.includes("EXSUDAD");
  return !isDefect;
}

function buildProductiveHourBuckets(rows, valueGetter) {
  const buckets = {};
  rows.forEach(row => {
    const ts = row.data_hora || row.updated_at || row.timestamp;
    if (!ts) return;
    const date = new Date(ts);
    if (isNaN(date.getTime())) return;
    const label = String(date.getHours()).padStart(2, '0') + 'h';
    buckets[label] = (buckets[label] || 0) + valueGetter(row);
  });

  const labels = Object.keys(buckets).sort();
  return { labels, values: labels.map(label => buckets[label]) };
}

function deduplicarLinhasProducao(rows) {
  if (!rows || rows.length === 0) return [];
  const groups = {};
  rows.forEach(r => {
    const key = `${r.data_fabricacao}||${r.forma || r.forma_numero || ""}`;
    if (!groups[key]) groups[key] = [];
    groups[key].push(r);
  });

  const uniqueRows = [];
  Object.keys(groups).forEach(key => {
    const list = groups[key];
    let selected = list.find(r => r.status === 'LIBERADO');
    if (!selected) {
      selected = list.find(r => r.tipo_concreto !== 'INSPECIONADO');
    }
    if (!selected) {
      selected = list[0];
    }
    uniqueRows.push(selected);
  });
  return uniqueRows;
}

function getLocalRowsForPeriod(dStart, dEnd) {
  const db = readDb();
  return db.events
    .filter(ev => ev.isFromApi === true && ev.etapa === "LIBERACAO" && ev.dataFabricacao >= dStart && ev.dataFabricacao <= dEnd)
    .map(ev => ({
      id: ev.id || uuid(),
      data_fabricacao: ev.dataFabricacao,
      data_hora: ev.timestamp,
      setor: ev.setor,
      forma: ev.formaNumero,
      modelo: ev.modelo,
      codigo_produto: ev.codigoProduto || null,
      colaborador: ev.colaborador,
      status: "LIBERADO"
    }))
    .sort((a, b) => new Date(a.data_hora).getTime() - new Date(b.data_hora).getTime());
}

function calcularMetricasProdutividade(filteredRows, allRows, dStart, dEnd, meta) {
  const totalFormas = filteredRows.length;
  let totalVolume = 0;
  filteredRows.forEach(r => {
    totalVolume += getFormVolume(r.codigo_produto, r.modelo, r.setor);
  });

  const groups = {};
  filteredRows.forEach(r => {
    const key = `${r.data_fabricacao}||${r.setor}`;
    if (!groups[key]) groups[key] = [];
    groups[key].push(r);
  });

  const validCycles = [];
  const cyclesBySector = {};
  const allIntervals = [];
  const paradasList = [];
  let tempoPerdidoTotal = 0;

  Object.keys(groups).forEach(key => {
    const [dia, setor] = key.split("||");
    const list = groups[key].sort((a, b) => new Date(a.data_hora).getTime() - new Date(b.data_hora).getTime());

    if (!cyclesBySector[setor]) {
      cyclesBySector[setor] = [];
    }

    for (let i = 1; i < list.length; i++) {
      const tPrev = new Date(list[i - 1].data_hora).getTime();
      const tCurr = new Date(list[i].data_hora).getTime();
      const diffMin = (tCurr - tPrev) / 60000;

      if (diffMin <= 0) continue;

      allIntervals.push(diffMin);

      if (diffMin > 20) {
        let classif = "VERDE";
        if (diffMin > 20 && diffMin <= 30) classif = "AMARELO";
        if (diffMin > 30) classif = "VERMELHO";

        paradasList.push({
          inicio: new Date(tPrev).toLocaleTimeString("pt-BR", {hour: '2-digit', minute:'2-digit'}),
          fim: new Date(tCurr).toLocaleTimeString("pt-BR", {hour: '2-digit', minute:'2-digit'}),
          duracao: Math.round(diffMin),
          setor: list[i].setor,
          produto: list[i].modelo || "N/A",
          classificacao: classif,
          data: dia
        });
      }

      if (diffMin <= 60) {
        validCycles.push(diffMin);
        cyclesBySector[setor].push(diffMin);
        if (diffMin > meta) {
          tempoPerdidoTotal += (diffMin - meta);
        }
      }
    }
  });

  let cicloMedio = 0;
  let cicloMediana = 0;
  let cicloMin = 0;
  let cicloMax = 0;
  let cicloDesvioPadrao = 0;

  if (validCycles.length > 0) {
    validCycles.sort((a, b) => a - b);
    const sum = validCycles.reduce((s, v) => s + v, 0);
    cicloMedio = sum / validCycles.length;

    const mid = Math.floor(validCycles.length / 2);
    cicloMediana = validCycles.length % 2 !== 0 ? validCycles[mid] : (validCycles[mid - 1] + validCycles[mid]) / 2;

    cicloMin = validCycles[0];
    cicloMax = validCycles[validCycles.length - 1];

    const avg = cicloMedio;
    const sqDiffs = validCycles.map(v => Math.pow(v - avg, 2));
    const avgSqDiff = sqDiffs.reduce((s, v) => s + v, 0) / validCycles.length;
    cicloDesvioPadrao = Math.sqrt(avgSqDiff);
  }

  const numeroParadas = paradasList.filter(p => p.classificacao === "AMARELO" || p.classificacao === "VERMELHO").length;
  paradasList.sort((a, b) => b.duracao - a.duracao);

  let tempoDisponivelMin = validCycles.reduce((s, v) => s + v, 0);
  if (tempoDisponivelMin === 0) tempoDisponivelMin = 480;

  const producaoTeorica = tempoDisponivelMin / meta;
  const eficienciaOperacional = producaoTeorica > 0 ? (totalFormas / producaoTeorica) * 100 : 0;

  const jornadaDiaria = [];
  const diasUnicos = Array.from(new Set(filteredRows.map(r => r.data_fabricacao))).sort();
  diasUnicos.forEach(dia => {
    const list = filteredRows.filter(r => r.data_fabricacao === dia).sort((a, b) => new Date(a.data_hora).getTime() - new Date(b.data_hora).getTime());
    if (list.length > 0) {
      const tIni = new Date(list[0].data_hora);
      const tFim = new Date(list[list.length - 1].data_hora);
      jornadaDiaria.push({
        data: dia.split("-").reverse().join("/"),
        inicio: tIni.toLocaleTimeString("pt-BR", {hour:'2-digit', minute:'2-digit'}),
        fim: tFim.toLocaleTimeString("pt-BR", {hour:'2-digit', minute:'2-digit'}),
        formas: list.length,
        metaDiaria: Math.round(480 / meta)
      });
    }
  });
  jornadaDiaria.reverse();

  const productiveFormsBuckets = buildProductiveHourBuckets(filteredRows, () => 1);
  const productiveVolumeBuckets = buildProductiveHourBuckets(filteredRows, r => getFormVolume(r.codigo_produto, r.modelo, r.setor));
  const heatmapFaixas = {};
  productiveFormsBuckets.labels.forEach((label, index) => {
    heatmapFaixas[label] = productiveFormsBuckets.values[index];
  });

  let melhorCicloHistorico = 15;
  const historicalGroups = {};
  allRows.forEach(r => {
    const key = `${r.data_fabricacao}||${r.setor}`;
    if (!historicalGroups[key]) historicalGroups[key] = [];
    historicalGroups[key].push(r);
  });
  const histCycles = [];
  Object.keys(historicalGroups).forEach(k => {
    const list = historicalGroups[k].sort((a, b) => new Date(a.data_hora).getTime() - new Date(b.data_hora).getTime());
    for (let i = 1; i < list.length; i++) {
      const diff = (new Date(list[i].data_hora).getTime() - new Date(list[i-1].data_hora).getTime()) / 60000;
      if (diff >= 1 && diff <= 60) histCycles.push(diff);
    }
  });
  if (histCycles.length > 0) {
    histCycles.sort((a, b) => a - b);
    melhorCicloHistorico = histCycles[0];
  }

  const capMaxFormsDia = Math.round(480 / melhorCicloHistorico);
  const capMaxM3Dia = capMaxFormsDia * (totalVolume / Math.max(totalFormas, 1));

  const capMedFormsDia = cicloMedio > 0 ? Math.round(480 / cicloMedio) : 0;
  const capMedM3Dia = capMedFormsDia * (totalVolume / Math.max(totalFormas, 1));

  const numDias = Math.max(diasUnicos.length, 1);
  const capAtuFormsDia = Math.round(totalFormas / numDias);
  const capAtuM3Dia = totalVolume / numDias;

  let totalFormasPorHora = 0;
  Object.keys(cyclesBySector).forEach(setor => {
    const sectorCycles = cyclesBySector[setor];
    if (sectorCycles.length > 0) {
      const sectorSum = sectorCycles.reduce((s, v) => s + v, 0);
      const sectorAvg = sectorSum / sectorCycles.length;
      if (sectorAvg > 0) {
        totalFormasPorHora += 60 / sectorAvg;
      }
    }
  });

  const avgVol = totalVolume / Math.max(totalFormas, 1);
  const m3PorHora = totalFormasPorHora * avgVol;

  return {
    filteredRows,
    totalFormas,
    totalVolume,
    cicloMedio,
    cicloMediana,
    cicloMin,
    cicloMax,
    cicloDesvioPadrao,
    numeroParadas,
    tempoPerdidoTotal,
    eficienciaOperacional,
    formasPorHora: totalFormasPorHora,
    m3PorHora: m3PorHora,
    paradasAmarelas: paradasList.filter(p => p.classificacao === "AMARELO").length,
    paradasVermelhas: paradasList.filter(p => p.classificacao === "VERMELHO").length,
    paradasList,
    jornadaDiaria,
    heatmapFaixas,
    productiveVolumeBuckets,
    capMaxFormsDia,
    capMaxM3Dia,
    capMedFormsDia,
    capMedM3Dia,
    capAtuFormsDia,
    capAtuM3Dia,
    filteredRows
  };
}

function renderizarAlertasOperacionais(metricas, meta) {
  const panel = document.getElementById("paAlertsPanel");
  if (!panel) return;
  panel.innerHTML = "";

  const alerts = [];
  if (metricas.cicloMedio > meta) {
    alerts.push({
      type: "warning",
      text: ` Ciclo Médio (${Math.round(metricas.cicloMedio)} min) está acima do ciclo meta configurado (${meta} min).`
    });
  }
  if (metricas.eficienciaOperacional > 0 && metricas.eficienciaOperacional < 80) {
    alerts.push({
      type: "danger",
      text: ` Eficiência Operacional (${Math.round(metricas.eficienciaOperacional)}%) está abaixo da meta aceitável de 80%.`
    });
  }
  const vermelhasHoje = metricas.paradasList.filter(p => p.classificacao === "VERMELHO" && p.data === todayYmd()).length;
  if (vermelhasHoje >= 3) {
    alerts.push({
      type: "danger",
      text: ` Alerta crítico: Mais de 3 paradas vermelhas (>30 min) identificadas na data de hoje.`
    });
  }
  if (metricas.tempoPerdidoTotal > 60) {
    alerts.push({
      type: "warning",
      text: ` Tempo Perdido Acumulado (${Math.round(metricas.tempoPerdidoTotal)} min) excede o limite aceitável de 60 minutos.`
    });
  }

  if (alerts.length > 0) {
    alerts.forEach(a => {
      const div = document.createElement("div");
      div.className = `pa-alert pa-alert-${a.type}`;
      div.textContent = a.text;
      panel.appendChild(div);
    });
    panel.classList.remove("hidden");
  } else {
    panel.classList.add("hidden");
  }
}

function renderizarTabelaParadas(list) {
  const tbody = document.getElementById("paTbodyParadas");
  if (!tbody) return;
  if (list.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" data-visual-print="35c7163d3ca6" style="text-align:center;color:var(--c-ink-2);">Nenhuma parada registrada.</td></tr>';
    return;
  }
  tbody.innerHTML = list.slice(0, 10).map(p => {
    let badge = "badge-verde";
    if (p.classificacao === "AMARELO") badge = "badge-amarelo";
    if (p.classificacao === "VERMELHO") badge = "badge-vermelho";
    return `<tr>
      <td>${p.data.split("-").reverse().join("/")} ${p.inicio}</td>
      <td>${p.data.split("-").reverse().join("/")} ${p.fim}</td>
      <td style="font-weight: bold;">${p.duracao} min</td>
      <td>${p.setor}</td>
      <td>${p.produto}</td>
      <td><span class="badge-parada ${badge}">${p.classificacao}</span></td>
    </tr>`;
  }).join("");
}

function renderizarTabelaDadosConcretagem(filteredRows) {
  const tbody = document.getElementById("paDadosTbody");
  if (!tbody) return;
  if (!filteredRows || filteredRows.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" data-visual-print="35c7163d3ca6" style="text-align:center;color:var(--c-ink-2);">Nenhum dado encontrado no período.</td></tr>';
    return;
  }

  // Ordenar por horário (mais recente primeiro)
  const rows = [...filteredRows].sort((a, b) => new Date(b.data_hora || b.updated_at) - new Date(a.data_hora || a.updated_at));

  tbody.innerHTML = rows.map(r => {
    let time = "N/A";
    const tsStr = r.data_hora || r.updated_at;
    if (tsStr) {
      const d = new Date(tsStr);
      if (!isNaN(d.getTime())) {
        time = d.toLocaleTimeString("pt-BR", { hour: '2-digit', minute: '2-digit' });
      }
    }
    const tipo = r.tipo_concreto || r.tipoConcreto || r.concretoTipo || "Padrão";
    return `
      <tr>
        <td style="font-weight: 600;">${r.forma_numero || r.forma || ""}</td>
        <td>${r.setor || ""}</td>
        <td>${tipo}</td>
        <td style="text-align: center;">${time}</td>
        <td>${r.colaborador || ""}</td>
      </tr>
    `;
  }).join("");
}

function exportarPaDadosCSV() {
  const rows = state.paLastRows;
  if (!rows || rows.length === 0) {
    showMsgBox("Gere um filtro antes de exportar.", "error");
    return;
  }

  let csvContent = "data:text/csv;charset=utf-8,";
  csvContent += "Forma;Setor;Tipo de Concreto;Data;Horario;Operador\n";

  const sortedRows = [...rows].sort((a, b) => new Date(a.data_hora || a.updated_at) - new Date(b.data_hora || b.updated_at));

  sortedRows.forEach(r => {
    let dateStr = "";
    let timeStr = "";
    const tsStr = r.data_hora || r.updated_at;
    if (tsStr) {
      const d = new Date(tsStr);
      if (!isNaN(d.getTime())) {
        dateStr = d.toLocaleDateString("pt-BR");
        timeStr = d.toLocaleTimeString("pt-BR", { hour: '2-digit', minute: '2-digit' });
      }
    }
    const tipo = r.tipo_concreto || r.tipoConcreto || r.concretoTipo || "Padrão";

    const fields = [
      r.forma_numero || r.forma || "",
      r.setor || "",
      tipo,
      dateStr,
      timeStr,
      r.colaborador || ""
    ];

    csvContent += fields.map(f => '"' + String(f).replace(/"/g, '""') + '"').join(";") + "\n";
  });

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `dados_concretagem_${new Date().getTime()}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function renderizarTabelaJornada(list) {
  const container = document.getElementById("paJornadaCards");
  if (!container) return;
  if (!list || list.length === 0) {
    container.innerHTML = '<div class="muted" style="padding:12px;text-align:center;">Sem dados para o periodo.</div>';
    return;
  }
  container.innerHTML = list.slice(0, 10).map(j => `
    <article class="pa-journey-card">
      <div class="pa-journey-card-head">
        <strong>${j.data}</strong>
        <span>${j.formas} formas</span>
      </div>
      <div class="pa-journey-card-grid">
        <div><span>Inicio</span><strong>${j.inicio}</strong></div>
        <div><span>Termino</span><strong>${j.fim}</strong></div>
        <div><span>Meta diaria</span><strong>${j.metaDiaria}</strong></div>
      </div>
    </article>
  `).join("");
}


function renderizarVolumeTipoPorSetor(rows) {
  const container = document.getElementById("paVolumeTipoSetor");
  if (!container) return;
  const setores = ["Setor 1", "Setor 2", "Setor 3", "Setor 4"];
  const data = setores.map(setor => {
    const acc = { setor, padrao: 0, fora: 0 };
    rows.filter(r => r.setor === setor).forEach(r => {
      const vol = getFormVolume(r.codigo_produto, r.modelo, r.setor);
      if (isConcretePadrao(r)) acc.padrao += vol;
      else acc.fora += vol;
    });
    return acc;
  });
  const maxTotal = Math.max(...data.map(d => d.padrao + d.fora), 1);
  container.innerHTML = data.map(item => {
    const total = item.padrao + item.fora;
    const padraoPct = total > 0 ? (item.padrao / total) * 100 : 0;
    const foraPct = total > 0 ? (item.fora / total) * 100 : 0;
    const width = Math.max((total / maxTotal) * 100, total > 0 ? 8 : 0);
    return `
      <div class="pa-volume-sector-row">
        <div class="pa-volume-sector-head">
          <strong>${item.setor}</strong>
          <span>${total.toFixed(2)} m3</span>
        </div>
        <div class="pa-volume-sector-track" style="width:${width}%">
          <div class="pa-volume-padrao" style="width:${padraoPct}%"></div>
          <div class="pa-volume-fora" style="width:${foraPct}%"></div>
        </div>
        <div class="pa-volume-sector-legend">
          <span>Padrao: ${item.padrao.toFixed(2)} m3</span>
          <span>Fora: ${item.fora.toFixed(2)} m3</span>
        </div>
      </div>
    `;
  }).join("");
}

function renderizarGraficosSetorProdutividade(rows) {
  const setores = ["Setor 1", "Setor 2", "Setor 3", "Setor 4"];
  const formas = setores.map(setor => rows.filter(r => r.setor === setor).length);
  const volumes = setores.map(setor => rows
    .filter(r => r.setor === setor)
    .reduce((sum, r) => sum + getFormVolume(r.codigo_produto, r.modelo, r.setor), 0));

  destroyChart("chartPaFormasSetor");
  const ctxFormas = document.getElementById("chartPaFormasSetor");
  if (ctxFormas && typeof Chart !== "undefined") {
    chartInstances["chartPaFormasSetor"] = new Chart(ctxFormas, {
      type: "bar",
      data: {
        labels: setores,
        datasets: [{ label: "Formas", data: formas, backgroundColor: "#2563eb", borderRadius: 6 }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          datalabels: {
            display: true,
            color: '#ffffff',
            anchor: 'center',
            align: 'center',
            font: { weight: 'bold', size: 10 }
          }
        },
        scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
      },
      plugins: [typeof ChartDataLabels !== 'undefined' ? ChartDataLabels : {}]
    });
  }

  destroyChart("chartPaVolumeSetor");
  const ctxVolume = document.getElementById("chartPaVolumeSetor");
  if (ctxVolume && typeof Chart !== "undefined") {
    chartInstances["chartPaVolumeSetor"] = new Chart(ctxVolume, {
      type: "bar",
      data: {
        labels: setores,
        datasets: [{ label: "Volume (m3)", data: volumes, backgroundColor: "#e8762a", borderRadius: 6 }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          datalabels: {
            display: true,
            color: '#ffffff',
            anchor: 'center',
            align: 'center',
            font: { weight: 'bold', size: 10 },
            formatter: (v) => v.toFixed(1)
          }
        },
        scales: { y: { beginAtZero: true } }
      },
      plugins: [typeof ChartDataLabels !== 'undefined' ? ChartDataLabels : {}]
    });
  }
}

function renderizarProducaoSetoresUltimos7(rows, selectedDate) {
  const baseDate = selectedDate ? new Date(selectedDate + "T12:00:00") : new Date();
  const dates = [];
  const d = new Date(baseDate);
  while (dates.length < 7) {
    const dow = d.getDay();
    if (dow !== 0 && dow !== 6) dates.push(d.toISOString().split("T")[0]);
    d.setDate(d.getDate() - 1);
  }
  const labels = dates.map(date => date.split("-").reverse().join("/"));
  const bySetor = {
    "Setor 1": {},
    "Setor 2": {},
    "Setor 3": {},
    "Setor 4": {}
  };
  rows.forEach(r => {
    const setor = r.setor || "";
    const dia = r.data_fabricacao || "";
    if (bySetor[setor] && dates.includes(dia)) bySetor[setor][dia] = (bySetor[setor][dia] || 0) + 1;
  });

  destroyChart("chartProdSetores");
  const ctx = document.getElementById("chartProdSetores");
  if (ctx && typeof Chart !== "undefined") {
    chartInstances["chartProdSetores"] = new Chart(ctx, {
      type: "bar",
      data: {
        labels,
        datasets: [
          { label: "Setor 1", data: dates.map(date => bySetor["Setor 1"][date] || 0), backgroundColor: "rgba(59, 130, 246, 0.85)", borderRadius: 4 },
          { label: "Setor 2", data: dates.map(date => bySetor["Setor 2"][date] || 0), backgroundColor: "rgba(16, 185, 129, 0.85)", borderRadius: 4 },
          { label: "Setor 3", data: dates.map(date => bySetor["Setor 3"][date] || 0), backgroundColor: "rgba(139, 92, 246, 0.85)", borderRadius: 4 },
          { label: "Setor 4", data: dates.map(date => bySetor["Setor 4"][date] || 0), backgroundColor: "rgba(249, 115, 22, 0.85)", borderRadius: 4 }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: "bottom", labels: { usePointStyle: true, boxWidth: 8 } },
          datalabels: {
            display: function(context) { return context.dataset.data[context.dataIndex] > 0; },
            color: '#ffffff',
            anchor: 'center',
            align: 'center',
            font: { weight: 'bold', size: 10 },
            formatter: Math.round
          }
        },
        scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true, ticks: { precision: 0 } } }
      },
      plugins: [typeof ChartDataLabels !== 'undefined' ? ChartDataLabels : {}]
    });
  }

  const histEl = document.getElementById("dbHistory");
  if (histEl) {
    const totalByDate = {};
    rows.forEach(r => {
      const dia = r.data_fabricacao || "";
      if (dates.includes(dia)) totalByDate[dia] = (totalByDate[dia] || 0) + 1;
    });
    const max = Math.max(...dates.map(date => totalByDate[date] || 0), 1);
    histEl.innerHTML = dates.map(date => {
      const total = totalByDate[date] || 0;
      const pct = Math.round((total / max) * 100);
      return `<div class="ins-dash-hist-row">
        <span class="ins-dash-hist-date">${date.split("-").reverse().join("/")}</span>
        <div class="ins-dash-hist-bar-track"><div class="ins-dash-hist-bar" style="width:${pct}%"></div></div>
        <span class="ins-dash-hist-count">${total}</span>
      </div>`;
    }).join("");
  }
}

function renderizarGraficosProdutividade(metricas, dStart, dEnd) {
  const diasUnicos = Array.from(new Set(metricas.filteredRows.map(r => r.data_fabricacao))).sort().reverse();

  const volumes = metricas.filteredRows.reduce((total, row) => {
    const volume = getFormVolume(row.codigo_produto, row.modelo, row.setor);
    if (isConcretePadrao(row)) total.padrao += volume;
    else total.fora += volume;
    return total;
  }, { padrao: 0, fora: 0 });
  const volumeTotal = volumes.padrao + volumes.fora;
  const volumeCenter = document.getElementById("paVolumeTotalRosca");
  if (volumeCenter) volumeCenter.textContent = volumeTotal.toLocaleString("pt-BR", { maximumFractionDigits: 1 });

  destroyChart("chartPaVolDiaStacked");
  const ctxVolDiaStacked = document.getElementById("chartPaVolDiaStacked");
  if (ctxVolDiaStacked && typeof Chart !== "undefined") {
    chartInstances["chartPaVolDiaStacked"] = new Chart(ctxVolDiaStacked, {
      type: "doughnut",
      data: {
        labels: ["Concreto bom", "Fora do padrão"],
        datasets: [{
          data: [volumes.padrao, volumes.fora],
          backgroundColor: ["#15966c", "#dc5454"],
          borderColor: "#fff",
          borderWidth: 3,
          hoverOffset: 5
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: "70%",
        plugins: {
          legend: { position: "bottom", labels: { usePointStyle: true, boxWidth: 9, padding: 14 } },
          tooltip: { callbacks: { label: context => `${context.label}: ${Number(context.parsed).toLocaleString("pt-BR", { maximumFractionDigits: 2 })} m³` } },
          datalabels: { display: false }
        }
      },
      plugins: [typeof ChartDataLabels !== "undefined" ? ChartDataLabels : {}]
    });
  }

  // Ciclo médio diário no período filtrado, sem intervalos de pausa acima de 60 minutos.
  destroyChart("chartPaCicloDia");
    const mapCicloDia = {};
    diasUnicos.forEach(d => { mapCicloDia[d] = []; });

    // Agrupar por dia
    const groups = {};
    metricas.filteredRows.forEach(r => {
      const key = `${r.data_fabricacao}||${r.setor}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(r);
    });

    Object.keys(groups).forEach(key => {
      const [dia, setor] = key.split("||");
      const list = groups[key].sort((a, b) => new Date(a.data_hora).getTime() - new Date(b.data_hora).getTime());
      for (let i = 1; i < list.length; i++) {
        const diff = (new Date(list[i].data_hora).getTime() - new Date(list[i-1].data_hora).getTime()) / 60000;
        if (diff > 0 && diff <= 60) {
          if (mapCicloDia[dia]) mapCicloDia[dia].push(diff);
        }
      }
    });

    const dataCicloDia = diasUnicos.map(d => {
      const list = mapCicloDia[d] || [];
      if (list.length === 0) return 0;
      return list.reduce((s, v) => s + v, 0) / list.length;
    });

    const validDays = dataCicloDia.filter(value => value > 0);
    const cycleValue = document.getElementById("paCicloDiaValor");
    const cycleDetail = document.getElementById("paCicloDiaDetalhe");
    if (cycleValue) cycleValue.textContent = validDays.length
      ? `${Math.round(validDays.reduce((sum, value) => sum + value, 0) / validDays.length)} min` : "—";
    if (cycleDetail) cycleDetail.textContent = validDays.length
      ? `Média de ${validDays.length} dia(s) com ciclos válidos` : "Sem ciclos válidos no período";

  // 2. Histograma de Tempos de Ciclo
  destroyChart("chartPaHistograma");
  const ctxHist = document.getElementById("chartPaHistograma");
  if (ctxHist && typeof Chart !== "undefined") {
    const buckets = { "<5 min": 0, "5-10 min": 0, "10-15 min": 0, "15-20 min": 0, "20-30 min": 0, ">30 min": 0 };

    const groups = {};
    metricas.filteredRows.forEach(r => {
      const key = `${r.data_fabricacao}||${r.setor}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(r);
    });

    Object.keys(groups).forEach(key => {
      const list = groups[key].sort((a, b) => new Date(a.data_hora).getTime() - new Date(b.data_hora).getTime());
      for (let i = 1; i < list.length; i++) {
        const diff = (new Date(list[i].data_hora).getTime() - new Date(list[i-1].data_hora).getTime()) / 60000;
        if (diff <= 0) continue;
        if (diff < 5) buckets["<5 min"]++;
        else if (diff >= 5 && diff < 10) buckets["5-10 min"]++;
        else if (diff >= 10 && diff < 15) buckets["10-15 min"]++;
        else if (diff >= 15 && diff < 20) buckets["15-20 min"]++;
        else if (diff >= 20 && diff < 30) buckets["20-30 min"]++;
        else buckets[">30 min"]++;
      }
    });

    chartInstances["chartPaHistograma"] = new Chart(ctxHist, {
      type: 'bar',
      data: {
        labels: Object.keys(buckets),
        datasets: [{
          label: 'Frequência de Ciclos',
          data: Object.values(buckets),
          backgroundColor: '#8b5cf6',
          borderRadius: 6
        }]
      },
      options: { responsive: true, maintainAspectRatio: false }
    });
  }

  destroyChart("chartPaCurvaAcumulada");
  destroyChart("chartPaPareto");

  // 5. Heatmap de Produção
  destroyChart("chartPaHeatmap");
  const ctxHeat = document.getElementById("chartPaHeatmap");
  if (ctxHeat && typeof Chart !== "undefined") {
    const labelsHeat = Object.keys(metricas.heatmapFaixas);
    const dataHeat = Object.values(metricas.heatmapFaixas);

    chartInstances["chartPaHeatmap"] = new Chart(ctxHeat, {
      type: 'bar',
      data: {
        labels: labelsHeat,
        datasets: [{
          label: 'Formas Concretadas',
          data: dataHeat,
          backgroundColor: 'rgba(14, 116, 144, 0.85)',
          borderRadius: 3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: { x: { ticks: { maxTicksLimit: 12 } } }
      }
    });
  }

  destroyChart("chartPaEficienciaSetor");

  // 7. Volume por hora produtiva
  destroyChart("chartPaM3Hora");
  const ctxM3Hora = document.getElementById("chartPaM3Hora");
  if (ctxM3Hora && typeof Chart !== "undefined") {
    const faixasHoras = metricas.productiveVolumeBuckets?.labels || [];
    const volumesHoras = metricas.productiveVolumeBuckets?.values || [];

    chartInstances["chartPaM3Hora"] = new Chart(ctxM3Hora, {
      type: 'bar',
      data: {
        labels: faixasHoras,
        datasets: [{
          label: 'Volume concretado (m3)',
          data: volumesHoras,
          backgroundColor: 'rgba(232, 118, 42, 0.9)',
          borderRadius: 6
        }]
      },
      options: { responsive: true, maintainAspectRatio: false }
    });
  }

}

async function carregarProdutividadeConcretagem() {
  const requestId = ++dashboardRequestSeq.produtividade;
  const dStart = document.getElementById("paDataInicio")?.value || todayYmd();
  const dEnd = document.getElementById("paDataFim")?.value || todayYmd();
  const meta = parseFloat(document.getElementById("paMetaCiclo")?.value || "15");
  const filterSetor = document.getElementById("paFiltroSetor")?.value || "";
  const scope = getDashboardScopeFromSetor(filterSetor);
  atualizarResumoFiltrosProdutividade();

  setSyncStatus("pending", "Carregando dados de produtividade...");
  const produtividadeRpcPromise = chamarDashboardRpcComCache("rpc_dashboard_produtividade_resumo_v1", {
    p_data_inicio: dStart,
    p_data_fim: dEnd,
    p_scope: scope
  }, `rpc:produtividade:resumo:${dStart}:${dEnd}:${scope}`).catch((err) => {
    console.warn("RPC de produtividade indisponivel; mantendo calculo local:", err);
    return null;
  });

  let allRows = [];
  if (hasApiConfigured()) {
    try {
      const result = await carregarLinhasSupabaseComCache({
        cacheKey: `produtividade:periodo:${dStart}:${dEnd}`,
        table: "producao",
        select: DASHBOARD_PRODUCAO_SELECT,
        orderBy: "data_hora",
        orderOptions: { ascending: true },
        applyFilters: query => query
          .gte('data_fabricacao', dStart)
          .lte('data_fabricacao', dEnd)
          .in('status', ['LIBERADO', 'INSPECIONADO'])
      });
      allRows = result.rows;
    } catch (err) {
      console.warn("Erro do servidor em produtividade, buscando local:", err);
      allRows = getLocalRowsForPeriod(dStart, dEnd);
    }
  } else {
    allRows = getLocalRowsForPeriod(dStart, dEnd);
  }

  allRows = deduplicarLinhasProducao(allRows);
  allRows.sort((a, b) => new Date(a.data_hora || a.updated_at || 0).getTime() - new Date(b.data_hora || b.updated_at || 0).getTime());

  const baseDate7 = new Date(dEnd + "T12:00:00");
  const dates7 = [];
  const d7 = new Date(baseDate7);
  while (dates7.length < 7) {
    const dow = d7.getDay();
    if (dow !== 0 && dow !== 6) dates7.push(d7.toISOString().split("T")[0]);
    d7.setDate(d7.getDate() - 1);
  }
  const start7 = dates7[dates7.length - 1];
  let rowsUltimos7 = [];
  if (hasApiConfigured()) {
    try {
      const result = await carregarLinhasSupabaseComCache({
        cacheKey: `produtividade:ultimos7:${start7}:${dEnd}`,
        table: "producao",
        select: DASHBOARD_PRODUCAO_SELECT,
        orderBy: "data_hora",
        orderOptions: { ascending: true },
        applyFilters: query => query
          .gte('data_fabricacao', start7)
          .lte('data_fabricacao', dEnd)
          .in('status', ['LIBERADO', 'INSPECIONADO'])
      });
      rowsUltimos7 = result.rows;
    } catch (err) {
      console.warn("Erro ao buscar últimos 7 dias de produção:", err);
      rowsUltimos7 = getLocalRowsForPeriod(start7, dEnd);
    }
  } else {
    rowsUltimos7 = getLocalRowsForPeriod(start7, dEnd);
  }

  rowsUltimos7 = deduplicarLinhasProducao(rowsUltimos7);
  rowsUltimos7.sort((a, b) => new Date(a.data_hora || a.updated_at || 0).getTime() - new Date(b.data_hora || b.updated_at || 0).getTime());

  const produtividadeRpc = await produtividadeRpcPromise;
  if (requestId !== dashboardRequestSeq.produtividade) return;

  let filteredRows = allRows.filter(r => {
    if (filterSetor) {
      if (filterSetor === "Setores 1 e 2") {
        if (r.setor !== "Setor 1" && r.setor !== "Setor 2") return false;
      } else {
        if (r.setor !== filterSetor) return false;
      }
    }
    return true;
  });

  const metricas = calcularMetricasProdutividade(filteredRows, allRows, dStart, dEnd, meta);

  document.getElementById("paKpiFormas").textContent = produtividadeRpc?.payload?.kpis?.total_formas ?? metricas.totalFormas;
  document.getElementById("paKpiVolume").textContent = metricas.totalVolume.toFixed(2) + " m³";
  document.getElementById("paKpiCicloMedio").textContent = metricas.cicloMedio > 0 ? Math.round(metricas.cicloMedio) + " min" : "N/A";
  document.getElementById("paKpiCicloDetalhes").innerHTML = `
    Mediana: ${metricas.cicloMediana > 0 ? Math.round(metricas.cicloMediana) + "m" : "N/A"} |
    DP: ${metricas.cicloDesvioPadrao > 0 ? Math.round(metricas.cicloDesvioPadrao) + "m" : "N/A"}<br>
    Min: ${metricas.cicloMin > 0 ? Math.round(metricas.cicloMin) + "m" : "—"} |
    Max: ${metricas.cicloMax > 0 ? Math.round(metricas.cicloMax) + "m" : "—"}
  `;
  document.getElementById("paKpiEficiencia").textContent = metricas.eficienciaOperacional > 0 ? Math.round(metricas.eficienciaOperacional) + "%" : "N/A";
  const paKpiParadas = document.getElementById("paKpiParadas");
  if (paKpiParadas) paKpiParadas.textContent = metricas.numeroParadas;

  // As linhas seguintes foram removidas porque os respectivos cards HTML foram deletados:
  // document.getElementById("paKpiTempoPerdido").textContent = ...
  // document.getElementById("paKpiParadas").textContent = ...


  // Novos KPIs de Volume de Concreto e Fora do Padrão
  const mesStart = dEnd.substring(0, 8) + '01';
  let allRowsMes = [];
  if (hasApiConfigured()) {
    try {
      const result = await carregarLinhasSupabaseComCache({
        cacheKey: `produtividade:mes:${mesStart}:${dEnd}`,
        table: "producao",
        select: "data_fabricacao, codigo_produto, modelo, setor, tipo_concreto, forma, status, data_hora",
        applyFilters: query => query
          .gte('data_fabricacao', mesStart)
          .lte('data_fabricacao', dEnd)
          .in('status', ['LIBERADO', 'INSPECIONADO'])
      });
      allRowsMes = result.rows;
    } catch (err) {
      console.warn("Erro ao buscar dados mensais", err);
      allRowsMes = getLocalRowsForPeriod(mesStart, dEnd);
    }
  } else {
    allRowsMes = getLocalRowsForPeriod(mesStart, dEnd);
  }

  allRowsMes = deduplicarLinhasProducao(allRowsMes);
  allRowsMes.sort((a, b) => new Date(a.data_hora || a.updated_at || 0).getTime() - new Date(b.data_hora || b.updated_at || 0).getTime());

  if (filterSetor) {
    allRowsMes = allRowsMes.filter(r => r.setor === filterSetor);
  }

  const rowsDia = filteredRows;

  let volConcretoDia = 0;
  let volForaPadraoDia = 0;
  rowsDia.forEach(r => {
    const vol = getFormVolume(r.codigo_produto, r.modelo, r.setor);
    volConcretoDia += vol;
    const isPadrao = isConcretePadrao(r);
    if (!isPadrao) volForaPadraoDia += vol;
  });

  let volConcretoMes = 0;
  let volForaPadraoMes = 0;
  allRowsMes.forEach(r => {
    const vol = getFormVolume(r.codigo_produto, r.modelo, r.setor);
    volConcretoMes += vol;
    const isPadrao = isConcretePadrao(r);
    if (!isPadrao) volForaPadraoMes += vol;
  });

  const volBomDia = volConcretoDia - volForaPadraoDia;
  const pctBomDia = volConcretoDia > 0 ? (volBomDia / volConcretoDia) * 100 : 0;
  const pctForaDia = volConcretoDia > 0 ? (volForaPadraoDia / volConcretoDia) * 100 : 0;

  const volBomMes = volConcretoMes - volForaPadraoMes;
  const pctBomMes = volConcretoMes > 0 ? (volBomMes / volConcretoMes) * 100 : 0;
  const pctForaMes = volConcretoMes > 0 ? (volForaPadraoMes / volConcretoMes) * 100 : 0;

  const paKpiVolumeMes = document.getElementById("paKpiVolumeMes");
  if (paKpiVolumeMes) paKpiVolumeMes.textContent = `Mês: ${volConcretoMes.toFixed(2)} m³`;

  const paKpiVolBomDia = document.getElementById("paKpiVolBomDia");
  if (paKpiVolBomDia) paKpiVolBomDia.textContent = `${volBomDia.toFixed(2)} m³ (${pctBomDia.toFixed(0)}%)`;

  const paKpiVolBomMes = document.getElementById("paKpiVolBomMes");
  if (paKpiVolBomMes) paKpiVolBomMes.textContent = `Mês: ${volBomMes.toFixed(2)} m³ (${pctBomMes.toFixed(0)}%)`;

  const paKpiVolForaDia = document.getElementById("paKpiVolForaDia");
  if (paKpiVolForaDia) paKpiVolForaDia.textContent = `${volForaPadraoDia.toFixed(2)} m³ (${pctForaDia.toFixed(0)}%)`;

  const paKpiVolForaMes = document.getElementById("paKpiVolForaMes");
  if (paKpiVolForaMes) paKpiVolForaMes.textContent = `Mês: ${volForaPadraoMes.toFixed(2)} m³ (${pctForaMes.toFixed(0)}%)`;

  const setKpi = (id, value) => {
    const node = document.getElementById(id);
    if (node) node.textContent = value;
  };
  setKpi("paKpiCicloMin", metricas.cicloMin > 0 ? Math.round(metricas.cicloMin) + " min" : "N/A");
  setKpi("paKpiCicloMax", metricas.cicloMax > 0 ? Math.round(metricas.cicloMax) + " min" : "N/A");
  setKpi("paKpiDesvioPadrao", metricas.cicloDesvioPadrao > 0 ? metricas.cicloDesvioPadrao.toFixed(1) + " min" : "N/A");
  setKpi("paKpiFormasHora", metricas.formasPorHora > 0 ? metricas.formasPorHora.toFixed(1) : "N/A");
  setKpi("paKpiM3Hora", metricas.m3PorHora > 0 ? metricas.m3PorHora.toFixed(2) + " m³/h" : "N/A");
  setKpi("paKpiParadasAV", `${metricas.paradasAmarelas} / ${metricas.paradasVermelhas}`);

  const elPaKpiJornada = document.getElementById("paKpiJornada");
  if (elPaKpiJornada) {
    if (metricas.jornadaDiaria && metricas.jornadaDiaria.length > 0) {
      const list = metricas.jornadaDiaria;
      if (list.length === 1) {
        elPaKpiJornada.textContent = `${list[0].inicio} - ${list[0].fim}`;
      } else {
        elPaKpiJornada.textContent = `${list[list.length - 1].inicio} - ${list[0].fim}`;
      }
    } else {
      elPaKpiJornada.textContent = "Sem registro";
    }
  }

  renderizarAlertasOperacionais(metricas, meta);
  renderizarVolumeTipoPorSetor(filteredRows);
  renderizarGraficosSetorProdutividade(filteredRows);
  renderizarProducaoSetoresUltimos7(rowsUltimos7, dEnd);
  renderizarGraficosProdutividade(metricas, dStart, dEnd);
  renderizarTabelaParadas(metricas.paradasList);
  renderizarTabelaJornada(metricas.jornadaDiaria);
  renderizarTabelaDadosConcretagem(filteredRows);

  state.paLastMetricas = metricas;
  state.paLastRows = filteredRows;

  setSyncStatus("ok", "Análise de produtividade atualizada.");
}

function exportarPaCSV() {
  const metricas = state.paLastMetricas;
  if (!metricas || !metricas.paradasList) {
    showMsgBox("Gere um filtro antes de exportar.", "error");
    return;
  }

  let csvContent = "data:text/csv;charset=utf-8,";
  csvContent += "Data;Horario Inicio;Horario Fim;Duracao (min);Setor;Produto;Classificacao\n";

  metricas.paradasList.forEach(p => {
    csvContent += `${p.data};${p.inicio};${p.fim};${p.duracao};${p.setor};${p.produto};${p.classificacao}\n`;
  });

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `paradas_concretagem_${todayYmd()}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function exportarPaExcel() {
  const metricas = state.paLastMetricas;
  if (!metricas || !metricas.paradasList) {
    showMsgBox("Gere um filtro antes de exportar.", "error");
    return;
  }

  let tableHtml = "<table border='1'><tr><th>Data</th><th>Horario Inicio</th><th>Horario Fim</th><th>Duracao (min)</th><th>Setor</th><th>Produto</th><th>Classificacao</th></tr>";
  metricas.paradasList.forEach(p => {
    tableHtml += `<tr><td>${p.data}</td><td>${p.inicio}</td><td>${p.fim}</td><td>${p.duracao}</td><td>${p.setor}</td><td>${p.produto}</td><td>${p.classificacao}</td></tr>`;
  });
  tableHtml += "</table>";

  const blob = new Blob([tableHtml], { type: "application/vnd.ms-excel" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", `produtividade_concretagem_${todayYmd()}.xls`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function exportarPaPDF() {
  window.print();
}

function init() {
  setMode("HUB");
  updateSwVersionBadge();
  setSyncStatus("pending", "Verificando conexão com a planilha...");
  renderInspecaoCodigosChecklist();
  bindEvents();
  subscribeToRealtimeUpdates();
  atualizarIndicadoresManutencaoHub();
  carregarFormasManutencaoSupabase().then(() => {
    atualizarIndicadoresManutencaoHub();
    renderLiberacaoDual();
  });

  const now = todayYmd();
  if (el.libData) el.libData.value = now;
  if (el.insFiltroData) el.insFiltroData.value = now;
  if (el.insModoCarga) el.insModoCarga.value = "data";
  if (el.mpFiltroData) el.mpFiltroData.value = now;
  if (el.mpModoCarga) el.mpModoCarga.value = "data";
  if (el.mpSetor) el.mpSetor.value = "";
  if (el.histTipo) el.histTipo.value = "";
  if (el.dashData) el.dashData.value = now;
  if (el.relData) el.relData.value = now;
  if (el.relSetor) el.relSetor.value = "Setor 2";
  if (el.acmpData) el.acmpData.value = now;
  if (el.acmpSetor) el.acmpSetor.value = "";
  const dbDataEl = document.getElementById("dbData");
  if (dbDataEl) dbDataEl.value = now;
  const paDataInicio = document.getElementById("paDataInicio");
  const paDataFim = document.getElementById("paDataFim");
  if (paDataInicio) paDataInicio.value = now;
  if (paDataFim) paDataFim.value = now;

  if ("serviceWorker" in navigator) {
    let refreshing = false;
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (!refreshing) {
        refreshing = true;
        window.location.reload();
      }
    });

    navigator.serviceWorker.register("./sw.js?v=20261105-dt-width", { updateViaCache: "none" }).then((reg) => {
      reg.update().catch(() => {});
    }).catch(() => {});
  }

  const session = readAuthSession();
  if (session) {
    state.authUser = session;
    if (el.insColaborador && session.name) {
      el.insColaborador.value = session.name;
    }
    setAccessByRole(session.role);
    unlockAppAfterLogin();
    applyRoleVisibility();
    applyAutoResponsibleFields();
    ensurePostLoginBootstrap();
    setMode("HUB");
  } else {
    lockAppForLogin();
    applyRoleVisibility();
    if (el.loginNome) el.loginNome.focus();
  }
}

init();

// ==========================================
// ABA: MONTAGEM INDICADORES
// ==========================================
let chartMiPorDiaInstance = null;
let chartMiPorSetorInstance = null;
let chartMiPorMontadorInstance = null;

let miRawMontagemData = [];
let miRawProducaoData = [];
let miFilteredMontagemData = [];
let miPaginaAtual = 1;
const miLinhasPorPagina = 15;
let miOrdenacaoColuna = "finalizado_em";
let miOrdenacaoAsc = false;
let miAbaAtiva = "resumo";
let miUltimosGraficos = null;
let miDefeitosExportData = null;
let dfPresentationData = null;
let dfPresentationSlideIndex = 0;
let dfPresentationReturnFocus = null;
const DF_PRESENTATION_SLIDE_TOTAL = 4;

function formatarDuracao(ms) {
  if (ms === null || ms === undefined || isNaN(ms) || ms < 0) return "-";
  const totalSecs = Math.floor(ms / 1000);
  const mins = Math.floor(totalSecs / 60);
  const secs = totalSecs % 60;
  if (mins === 0) return `${secs}s`;
  return `${mins}m ${secs}s`;
}

function formatarDataHoraMontagemXlsx(value) {
  if (!value) return "";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}

function getMiDataReferencia(row) {
  const raw = row?.finalizado_em || row?.finalizadoEm || row?.inicio_inspecao_montagem || row?.inicioInspecaoMontagem || row?.data_fabricacao || row?.dataFabricacao || "";
  return String(raw).split("T")[0];
}

function isLinhaMontagemDashboard(row) {
  const etapa = String(row?.etapa || "").trim().toUpperCase();
  if (etapa === "INSPECAO" || etapa === "REINSPECAO" || isHistoricoReprovacao(row)) return false;
  return Boolean(row?.status_montagem || row?.finalizado_em);
}

function isLinhaAvaliacaoDefeitosDashboard(row) {
  if (isHistoricoReprovacao(row)) return true;
  const setor = String(row?.setor || "").trim();
  if (setor === "Setor 3" || setor === "Setor 4") {
    return Boolean(row?.status_montagem || row?.finalizado_em);
  }
  return isLinhaMontagemDashboard(row);
}

function isLinhaDefeitoDashboard(row) {
  return obterDefeitosRegistradosLinha(row).length > 0;
}

function removerReprovacoesDuplicadasDashboard(rows) {
  const historicos = new Set(rows.filter(isHistoricoReprovacao).map(row => String(row.id || row.key || "")));
  const candidatos = rows.filter(row => isHistoricoReprovacao(row)
    || !historicos.has(getHistoricoReprovacaoKey(row.id || row.key, row.finalizado_em || row.finalizadoEm)));
  const eventos = new Map();
  for (const row of candidatos) {
    const defeitos = obterDefeitosRegistradosLinha(row);
    const inicio = Date.parse(row.inicio_inspecao_montagem || row.inicioInspecaoMontagem || "");
    const fim = Date.parse(row.finalizado_em || row.finalizadoEm || "");
    const peca = row.record_id || String(row.id || row.key || "").split(`||${ETAPA_HISTORICO_REPROVACAO}||`)[0];
    // Missing timestamps cannot identify an inspection safely; retain the row.
    if (!defeitos.length || !peca || !Number.isFinite(inicio) || !Number.isFinite(fim)) {
      eventos.set(Symbol(), row);
      continue;
    }
    const chave = JSON.stringify([peca, row.setor || "", inicio, fim,
      [...defeitos].sort()]);
    const anterior = eventos.get(chave);
    if (!anterior || (isHistoricoReprovacao(row) && !isHistoricoReprovacao(anterior))) {
      eventos.set(chave, row);
    }
  }
  return [...eventos.values()];
}

function isMontagemRetrabalhoStatus(status) {
  const s = String(status || "").trim().toUpperCase();
  const codigosRetrabalho = new Set(["RR", "RETRABALHO"]);
  return codigosRetrabalho.has(s);
}

function normalizarTexto(valor) {
  return String(valor || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

function atualizarResumoFiltrosMontagem() {
  const dStart = document.getElementById("miDataInicio")?.value || todayYmd();
  const dEnd = document.getElementById("miDataFim")?.value || todayYmd();
  const setor = document.getElementById("miFiltroSetor")?.value || "Todos os setores";
  const status = document.getElementById("miFiltroStatus")?.value || "Todos os status";
  const resumo = document.getElementById("miFiltroResumo");
  if (!resumo) return;
  const fmt = (d) => d ? d.split("-").reverse().join("/") : "-";
  const periodo = dStart === dEnd ? fmt(dStart) : `${fmt(dStart)} a ${fmt(dEnd)}`;
  resumo.textContent = `${periodo} - ${setor} - ${status}`;
}

function setMontagemDrawerOpen(open) {
  const drawer = document.getElementById("miFiltrosDrawer");
  if (!drawer) return;
  drawer.classList.toggle("hidden", !open);
  drawer.setAttribute("aria-hidden", open ? "false" : "true");
}

function getMiStatusMeta(status) {
  if (status === "A") return { label: "Aprovado", className: "mi-status-a" };
  if (status === "RR") return { label: "Retrabalhado e aprovado", className: "mi-status-rr" };
  if (status === "R") return { label: "Reprovado", className: "mi-status-r" };
  return { label: "Em andamento", className: "mi-status-open" };
}

function miStatusButton(row) {
  const meta = getMiStatusMeta(row.status_montagem);
  const id = escapeHtml(row.id);
  return `<button type="button" class="mi-status-pill ${meta.className}" onclick="abrirVisualizacaoChecklist('${id}')">${meta.label}</button>`;
}

function obterChecklistSectionsLinha(row) {
  const isInspecao = row.setor === "Setor 3" || row.setor === "Setor 4";
  return isInspecao
    ? getInspecaoChecklistSections(row.modelo || "")
    : getMontagemChecklistSections(row.modelo || "");
}

function isSecaoInspecaoVisual(section) {
  const id = normalizarTexto(section?.id || "");
  const titulo = normalizarTexto(section?.titulo || "");
  return id.includes("visual") || titulo.includes("inspecao visual");
}

function obterChecklistVisualSectionsLinha(row) {
  return obterChecklistSectionsLinha(row).filter(isSecaoInspecaoVisual);
}

function contarDefeitosPossiveisLinha(row) {
  return obterChecklistSectionsLinha(row).reduce((total, sec) => {
    return total + (Array.isArray(sec.itens) ? sec.itens.length : 0);
  }, 0);
}

function obterDefeitosPossiveisLinha(row) {
  const itens = [];
  obterChecklistSectionsLinha(row).forEach(sec => {
    if (!Array.isArray(sec.itens)) return;
    sec.itens.forEach(item => {
      const label = typeof item === "string"
        ? item
        : (item.label || item.texto || item.descricao || item.nome || item.codigoFalha || "");
      const clean = String(label || "").trim();
      if (clean) itens.push(clean);
    });
  });
  return itens;
}

function calcularIndicadoresDefeitosMontagem(rows, producaoRows = []) {
  const resumo = {
    postes: 0,
    producao: producaoRows.length,
    totalPossivel: 0,
    totalErros: 0,
    postesComDefeito: 0,
    postesReprovados: 0,
    retrabalho: 0,
    listaDefeitos: {},
    ocorrenciasPorTipo: {},
    porForma: {},
    porTipo: {},
    porSetor: {},
    matriz: {},
    fissuras: {
      total: 0,
      circulares: 0,
      outros: 0
    }
  };

  producaoRows.forEach(row => {
    const setor = row.setor || "Sem setor";
    if (!resumo.porSetor[setor]) resumo.porSetor[setor] = { setor, erros: 0, producao: 0 };
    resumo.porSetor[setor].producao++;
  });

  const postesVistos = new Set();
  const postesComDefeitoVistos = new Set();
  const postesReprovadosVistos = new Set();
  const postesRetrabalhadosVistos = new Set();

  rows.forEach(row => {
    const forma = row.forma_numero || row.formaNumero || "Sem forma";
    const setor = row.setor || "Sem setor";
    const key = `${setor}||${forma}`;
    const idOriginal = String(row.id || row.key || "").split(`||${ETAPA_HISTORICO_REPROVACAO}||`)[0];
    const posteKey = String(row.record_id || idOriginal || `${row.data_fabricacao || ""}||${key}||${row.modelo || ""}`);
    const defeitosPossiveis = obterDefeitosPossiveisLinha(row);
    const possiveis = defeitosPossiveis.length;
    const rejeitados = obterDefeitosRegistradosLinha(row);
    const statusMontagem = String(row.status_montagem || "").trim().toUpperCase();
    const isPosteComDefeito = rejeitados.length > 0;
    const isReprovado = ["R", "RR", "REPROVADO", "RETRABALHO"].includes(statusMontagem);
    const isRetrabalho = isMontagemRetrabalhoStatus(statusMontagem);

    if (!resumo.porForma[key]) {
      resumo.porForma[key] = {
        forma,
        setor,
        modelo: row.modelo || "",
        postes: 0,
        postesReprovados: 0,
        listaDefeitos: {},
        possiveis: 0,
        potencial: 0,
        erros: 0,
        retrabalho: 0
      };
    }

    resumo.totalPossivel += possiveis;
    resumo.totalErros += rejeitados.length;
    if (!postesVistos.has(posteKey)) {
      postesVistos.add(posteKey);
      resumo.postes++;
      resumo.porForma[key].postes++;
    }
    resumo.porForma[key].potencial += possiveis;
    resumo.porForma[key].erros += rejeitados.length;
    if (isPosteComDefeito && !postesComDefeitoVistos.has(posteKey)) {
      postesComDefeitoVistos.add(posteKey);
      resumo.postesComDefeito++;
      resumo.porForma[key].postesReprovados++;
    }
    if (isReprovado && !postesReprovadosVistos.has(posteKey)) {
      postesReprovadosVistos.add(posteKey);
      resumo.postesReprovados++;
    }
    if (isRetrabalho && !postesRetrabalhadosVistos.has(posteKey)) {
      postesRetrabalhadosVistos.add(posteKey);
      resumo.retrabalho++;
      resumo.porForma[key].retrabalho++;
    }

    defeitosPossiveis.forEach(item => {
      const norm = normalizarTexto(item);
      if (!norm) return;
      resumo.listaDefeitos[norm] = item;
      resumo.porForma[key].listaDefeitos[norm] = item;
    });

    if (!resumo.porSetor[setor]) resumo.porSetor[setor] = { setor, erros: 0, producao: 0 };
    resumo.porSetor[setor].erros += rejeitados.length;

    rejeitados.forEach(item => {
      resumo.porTipo[item] = (resumo.porTipo[item] || 0) + 1;
      if (!resumo.ocorrenciasPorTipo[item]) resumo.ocorrenciasPorTipo[item] = [];
      resumo.ocorrenciasPorTipo[item].push(row);
      if (!resumo.matriz[item]) resumo.matriz[item] = {};
      resumo.matriz[item][setor] = (resumo.matriz[item][setor] || 0) + 1;
      if (normalizarTexto(item).includes("fissura")) {
        resumo.fissuras.total++;
        const modelo = normalizarTexto(row.modelo || "");
        if (modelo.includes("circular") || modelo.includes("circ")) resumo.fissuras.circulares++;
        else resumo.fissuras.outros++;
      }
    });
  });

  Object.values(resumo.porForma).forEach(item => {
    item.possiveis = Object.keys(item.listaDefeitos).length;
  });

  return resumo;
}

function formatPct(value) {
  if (!isFinite(value)) return "0,0%";
  return `${value.toFixed(1).replace(".", ",")}%`;
}

const DASHBOARD_DEFEITOS_COLORS_BY_TYPE = Object.freeze({
  "bolhas em excesso": "#2563eb",
  "falhas de preenchimento": "#dc2626",
  "pequenas avarias": "#16a34a",
  "buchas de fixacao": "#d97706",
  "bolhas fora do padrao": "#7c3aed",
  "falha na concretagem / armacao aparente": "#0891b2",
  "fissuras": "#be123c",
  "prisioneiros (lacre / aterramento)": "#4f46e5",
  "rebarbas": "#65a30d",
  "reprovacao sem defeito detalhado": "#0f766e",
  "homogeneidade do concreto": "#c2410c",
  "concreto segregado": "#9333ea",
  "grandes avarias": "#0e7490",
  "facao obstruido": "#b91c1c",
  "furacao obstruida (pinos)": "#15803d",
  "armacao aparente": "#a21caf",
  "trincas": "#b45309",
  "tubulacao entupida": "#0369a1",
  "carimbo de identificacao": "#db2777",
  "manchas excessivas": "#6d28d9",
  "acabamento face exposta": "#047857",
  "acabamento abas": "#9a3412",
  "montagem do poste": "#4338ca",
  "liberacao qualidade": "#7e22ce",
  "codificacao poste": "#0d9488",
  "limpeza aterramento": "#a16207",
  "limpeza lacre": "#475569"
});

function getDashboardDefectColor(tipo) {
  const key = normalizarTexto(tipo);
  if (DASHBOARD_DEFEITOS_COLORS_BY_TYPE[key]) return DASHBOARD_DEFEITOS_COLORS_BY_TYPE[key];
  let hash = 2166136261;
  for (const char of key) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619);
  const value = hash >>> 0;
  return `hsl(${value % 360} ${58 + ((value >>> 9) % 20)}% ${35 + ((value >>> 17) % 15)}%)`;
}

function criarRankingParticipacaoDefeitos(porTipo = {}, totalErros = 0) {
  const itens = Object.entries(porTipo || {})
    .map(([tipo, total]) => [String(tipo || "Defeito nao identificado"), Number(total || 0)])
    .filter(([, total]) => Number.isFinite(total) && total > 0)
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], "pt-BR"));
  const totalCalculado = itens.reduce((soma, [, total]) => soma + total, 0);
  const totalInformado = Number(totalErros || 0);
  const totalBase = Number.isFinite(totalInformado) && totalInformado > 0 ? totalInformado : totalCalculado;
  const maiorTotal = itens.reduce((maior, [, total]) => Math.max(maior, total), 0);

  return itens.map(([tipo, total]) => ({
    tipo,
    total,
    percentual: totalBase > 0 ? (total / totalBase) * 100 : 0,
    larguraRelativa: maiorTotal > 0 ? (total / maiorTotal) * 100 : 0,
    cor: getDashboardDefectColor(tipo),
    totalBase
  }));
}

function criarParticipacaoDefeitosPorSetor(matriz = {}, numeroSetor) {
  const porTipo = {};
  let total = 0;
  Object.entries(matriz || {}).forEach(([tipo, setores]) => {
    const quantidade = Object.entries(setores || {}).reduce((soma, [setor, valor]) => {
      const codigo = String(setor).trim().toLowerCase().replace(/\s+/g, "");
      const numero = Number(valor);
      return (codigo === `s${numeroSetor}` || codigo === `setor${numeroSetor}`) && Number.isFinite(numero) && numero > 0
        ? soma + numero
        : soma;
    }, 0);
    if (quantidade > 0) {
      porTipo[tipo] = quantidade;
      total += quantidade;
    }
  });
  return { porTipo, total };
}

function renderParticipacaoDefeitos(containerId, badgeId, porTipo, totalErros, numeroSetor = null) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const rankingDefeitos = criarRankingParticipacaoDefeitos(porTipo, totalErros);
  const totalBase = rankingDefeitos[0]?.totalBase || Number(totalErros || 0);
  const badge = document.getElementById(badgeId);
  if (badge) badge.textContent = `${totalBase} ocorrencia${totalBase === 1 ? "" : "s"}`;
  if (rankingDefeitos.length === 0) {
    container.innerHTML = '<div class="muted">Sem defeitos no periodo e filtros selecionados.</div>';
    return;
  }
  const referencia = numeroSetor ? `do Setor ${numeroSetor}` : "do total";
  container.innerHTML = `
    <div class="df-defect-share-caption">
      <strong>${totalBase} ocorrencia${totalBase === 1 ? "" : "s"} ${numeroSetor ? `no Setor ${numeroSetor}` : "no total"}</strong>
      <span>A barra compara o volume; o percentual usa o total de defeitos ${numeroSetor ? `do Setor ${numeroSetor}` : "do periodo"}.</span>
    </div>
    <div class="df-defect-share-list">
      ${rankingDefeitos.map(item => `
        <div class="df-defect-share-row" title="${escapeHtml(item.tipo)}: ${item.total} (${formatPct(item.percentual)} ${referencia})">
          <div class="df-defect-share-label">
            <i style="--df-defect-color: ${item.cor}" aria-hidden="true"></i>
            <span>${escapeHtml(item.tipo)}</span>
          </div>
          <div class="df-defect-share-track" role="meter" aria-label="${escapeHtml(item.tipo)}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${item.percentual.toFixed(1)}">
            <div class="df-defect-share-fill" style="--df-defect-color: ${item.cor}; --df-defect-width: ${item.larguraRelativa.toFixed(2)}%">
              <strong>${item.total}</strong>
            </div>
            <span class="df-defect-share-percent">${formatPct(item.percentual)}</span>
          </div>
        </div>
      `).join("")}
    </div>
  `;
}

function criarModeloApresentacaoDefeitos(indicadores = {}) {
  const numero = value => {
    const parsed = Number(value || 0);
    return Number.isFinite(parsed) ? parsed : 0;
  };
  const totalErros = numero(indicadores.totalErros);
  const totalPossivel = numero(indicadores.totalPossivel);
  const postes = numero(indicadores.postes);
  const producao = numero(indicadores.producao);
  const postesComDefeito = numero(indicadores.postesComDefeito);
  const postesReprovados = numero(indicadores.postesReprovados);
  const retrabalho = numero(indicadores.retrabalho);
  const setores = Object.values(indicadores.porSetor || {})
    .map(item => {
      const erros = numero(item?.erros);
      const producaoSetor = numero(item?.producao);
      return {
        setor: String(item?.setor || "Setor nao identificado"),
        erros,
        producao: producaoSetor,
        taxa: producaoSetor > 0 ? (erros / producaoSetor) * 100 : 0
      };
    })
    .sort((a, b) => a.setor.localeCompare(b.setor, "pt-BR", { numeric: true }));

  return {
    totalErros,
    totalPossivel,
    postes,
    producao,
    postesComDefeito,
    postesReprovados,
    retrabalho,
    taxaDefeitos: totalPossivel > 0 ? (totalErros / totalPossivel) * 100 : 0,
    indiceReprovacao: postes > 0 ? (postesComDefeito / postes) * 100 : 0,
    taxaPostesReprovados: producao > 0 ? (postesReprovados / producao) * 100 : 0,
    taxaRetrabalho: postes > 0 ? (retrabalho / postes) * 100 : 0,
    ranking: criarRankingParticipacaoDefeitos(indicadores.porTipo || {}, totalErros),
    setores,
    matriz: indicadores.matriz || {}
  };
}

function criarLinhasDetalheDefeito(ocorrencias = [], producaoRows = []) {
  const concretagemPorForma = new Map();
  producaoRows.forEach(row => {
    const status = normalizeUpper(row.status);
    if (status !== "LIBERADO" && status !== "CONCRETADO") return;
    const key = `${String(row.data_fabricacao || "").slice(0, 10)}||${normalizeUpper(row.setor)}||${normalizeForma(row.forma || "")}`;
    const previous = concretagemPorForma.get(key);
    if (!previous || String(row.data_hora || "") > String(previous.data_hora || "")) {
      concretagemPorForma.set(key, row);
    }
  });

  return ocorrencias.map(row => {
    const dataProducao = String(row.data_fabricacao || row.dataFabricacao || "").slice(0, 10);
    const setor = row.setor || "";
    const forma = row.forma_numero || row.formaNumero || row.forma || "";
    const key = `${dataProducao}||${normalizeUpper(setor)}||${normalizeForma(forma)}`;
    const concretagem = concretagemPorForma.get(key);
    return {
      posteKey: String(row.record_id || row.id || key).split(`||${ETAPA_HISTORICO_REPROVACAO}||`)[0],
      modelo: row.modelo || concretagem?.modelo || "-",
      forma: forma || "-",
      dataProducao: dataProducao || concretagem?.data_fabricacao || "",
      dataInspecao: row.finalizado_em || row.finalizadoEm || row.inicio_inspecao_montagem || row.inicioInspecaoMontagem || "",
      tipoConcreto: concretagem?.tipo_concreto || "-",
      setor: setor || "-",
      horaConcretagem: concretagem?.data_hora || ""
    };
  }).sort((a, b) =>
    String(b.dataProducao || "").localeCompare(String(a.dataProducao || ""))
    || String(b.dataInspecao || "").localeCompare(String(a.dataInspecao || ""))
    || String(a.forma || "").localeCompare(String(b.forma || ""), "pt-BR", { numeric: true })
  );
}

function formatarDataDetalheDefeito(value) {
  const raw = String(value || "");
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw.split("-").reverse().join("/");
  const date = new Date(raw);
  return Number.isNaN(date.getTime()) ? "-" : date.toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" });
}

function formatarDataHoraDetalheDefeito(value) {
  const date = new Date(value || "");
  return !value || Number.isNaN(date.getTime()) ? "-" : date.toLocaleString("pt-BR", {
    timeZone: "America/Sao_Paulo", day: "2-digit", month: "2-digit", year: "numeric",
    hour: "2-digit", minute: "2-digit"
  });
}

function formatarHoraDetalheDefeito(value) {
  const date = new Date(value || "");
  return !value || Number.isNaN(date.getTime()) ? "-" : date.toLocaleTimeString("pt-BR", {
    timeZone: "America/Sao_Paulo", hour: "2-digit", minute: "2-digit"
  });
}

function renderHtmlDetalheDefeito(tipo, ocorrencias, producaoRows) {
  const linhas = criarLinhasDetalheDefeito(ocorrencias, producaoRows);
  const postes = new Set(linhas.map(row => row.posteKey)).size;
  return `
    <div class="df-defect-detail-head">
      <strong>${escapeHtml(tipo)}</strong>
      <span>${linhas.length} ocorrência${linhas.length === 1 ? "" : "s"} em ${postes} poste${postes === 1 ? "" : "s"}</span>
    </div>
    <div class="df-defect-detail-scroll">
      <table class="df-defect-detail-table">
        <thead><tr><th>Poste / modelo</th><th>Forma</th><th>Produção</th><th>Inspeção</th><th>Tipo de concreto</th><th>Setor</th><th>Hora concretagem</th></tr></thead>
        <tbody>${linhas.map(row => `
          <tr>
            <td data-label="Poste / modelo">${escapeHtml(row.modelo)}</td>
            <td data-label="Forma">${escapeHtml(row.forma)}</td>
            <td data-label="Produção">${escapeHtml(formatarDataDetalheDefeito(row.dataProducao))}</td>
            <td data-label="Inspeção">${escapeHtml(formatarDataHoraDetalheDefeito(row.dataInspecao))}</td>
            <td data-label="Tipo de concreto">${escapeHtml(row.tipoConcreto)}</td>
            <td data-label="Setor">${escapeHtml(row.setor)}</td>
            <td data-label="Hora concretagem">${escapeHtml(formatarHoraDetalheDefeito(row.horaConcretagem))}</td>
          </tr>
        `).join("")}</tbody>
      </table>
    </div>
  `;
}

let dfDefectDetails = { ocorrenciasPorTipo: {}, producaoRows: [], tiposOrdenados: [], queriedKeys: new Set() };

async function carregarConcretagensDetalheDefeito(ocorrencias, detailData) {
  const conhecidas = new Set(detailData.producaoRows
    .filter(row => ["LIBERADO", "CONCRETADO"].includes(normalizeUpper(row.status)))
    .map(row => `${String(row.data_fabricacao || "").slice(0, 10)}||${normalizeUpper(row.setor)}||${normalizeForma(row.forma || "")}`));
  const pendentes = new Map();
  ocorrencias.forEach(row => {
    const data = String(row.data_fabricacao || row.dataFabricacao || "").slice(0, 10);
    const setor = row.setor || "";
    const forma = row.forma_numero || row.formaNumero || row.forma || "";
    const key = `${data}||${normalizeUpper(setor)}||${normalizeForma(forma)}`;
    if (/^\d{4}-\d{2}-\d{2}$/.test(data) && setor && forma && !conhecidas.has(key) && !detailData.queriedKeys.has(key)) {
      pendentes.set(key, { data, setor, forma });
    }
  });
  if (!pendentes.size || !hasApiConfigured() || !navigator.onLine) return;

  const dates = [...new Set([...pendentes.values()].map(item => item.data))];
  const sectors = [...new Set([...pendentes.values()].map(item => item.setor))];
  const forms = new Set();
  pendentes.forEach(item => {
    forms.add(item.forma);
    const formaNormalizada = normalizeForma(item.forma);
    forms.add(formaNormalizada);
    const numerada = formaNormalizada.match(/^([A-Z]*)(\d+)$/);
    if (numerada) {
      forms.add(`${numerada[1]}${numerada[2].padStart(2, "0")}`);
      forms.add(`${numerada[1]}${numerada[2].padStart(3, "0")}`);
    }
  });
  pendentes.forEach((_, key) => detailData.queriedKeys.add(key));
  try {
    const result = await carregarLinhasSupabaseComCache({
      table: "producao",
      select: DASHBOARD_DEFEITOS_PRODUCAO_SELECT,
      pageSize: 1000,
      maxPages: 10,
      pageConcurrency: 2,
      requireComplete: true,
      timeoutMs: 30000,
      orderBy: "id",
      orderOptions: { ascending: true },
      applyFilters: query => query
        .in("data_fabricacao", dates)
        .in("setor", sectors)
        .in("forma", [...forms])
        .in("status", ["LIBERADO", "CONCRETADO"])
    });
    detailData.producaoRows.push(...result.rows);
  } catch (error) {
    pendentes.forEach((_, key) => detailData.queriedKeys.delete(key));
    console.warn("Concretagem indisponível para parte do detalhe de defeitos:", error);
  }
}

async function alternarDetalheDefeito(button) {
  const container = document.getElementById("miDefeitosPorTipo");
  const index = Number(button?.dataset?.dfDefectIndex);
  const detailData = dfDefectDetails;
  const [tipo] = detailData.tiposOrdenados[index] || [];
  const panel = button && document.getElementById(button.getAttribute("aria-controls"));
  if (!container || !tipo || !panel) return;
  const abrir = panel.hidden;
  container.querySelectorAll(".df-defect-toggle").forEach(item => item.setAttribute("aria-expanded", "false"));
  container.querySelectorAll(".df-defect-detail").forEach(item => { item.hidden = true; });
  if (!abrir) return;
  panel.hidden = false;
  button.setAttribute("aria-expanded", "true");
  panel.innerHTML = '<div class="muted">Carregando postes e dados da concretagem...</div>';
  const ocorrencias = detailData.ocorrenciasPorTipo[tipo] || [];
  await carregarConcretagensDetalheDefeito(ocorrencias, detailData);
  if (detailData !== dfDefectDetails || button.getAttribute("aria-expanded") !== "true") return;
  panel.innerHTML = renderHtmlDetalheDefeito(tipo, ocorrencias, detailData.producaoRows);
}

function renderIndicadoresDefeitosMontagem(indicadores, producaoRows = []) {
  const taxaNc = indicadores.totalPossivel > 0 ? (indicadores.totalErros / indicadores.totalPossivel) * 100 : 0;
  const indiceReprovacao = indicadores.postes > 0 ? (indicadores.postesComDefeito / indicadores.postes) * 100 : 0;
  const taxaPostesReprovados = indicadores.producao > 0 ? (indicadores.postesReprovados / indicadores.producao) * 100 : 0;
  const taxaRetrabalho = indicadores.postes > 0 ? (indicadores.retrabalho / indicadores.postes) * 100 : 0;
  dfPresentationData = criarModeloApresentacaoDefeitos(indicadores);
  const setText = (id, value) => {
    const node = document.getElementById(id);
    if (node) node.textContent = value;
  };

  setText("miDefTotalErros", indicadores.totalErros);
  setText("miDefOcorrenciasMirror", indicadores.totalErros);
  setText("miDefTotalPossivel", indicadores.totalPossivel);
  setText("miDefTaxa", formatPct(taxaNc));
  setText("miDefPostes", indicadores.postes);
  setText("miDefTaxaProducao", formatPct(indiceReprovacao));
  setText("miDefTaxaPostesReprovados", formatPct(taxaPostesReprovados));
  setText("miDefPostesReprovadosResumo", `${indicadores.postesReprovados} / ${formatPct(taxaPostesReprovados)}`);
  setText("miDefTaxaRetrabalho", formatPct(taxaRetrabalho));
  setText("miDefProducaoPeriodo", indicadores.producao);
  setText("miDefPostesReprovados", indicadores.postesReprovados);
  setText("miDefFissuras", indicadores.fissuras.total);
  setText("miDefFissurasCirculares", indicadores.fissuras.circulares);

  const porTipoEl = document.getElementById("miDefeitosPorTipo");
  const tiposOrdenados = Object.entries(indicadores.porTipo).sort((a, b) => b[1] - a[1]);
  dfDefectDetails = { ocorrenciasPorTipo: indicadores.ocorrenciasPorTipo || {}, producaoRows: [...producaoRows], tiposOrdenados, queriedKeys: new Set() };
  if (porTipoEl) {
    if (tiposOrdenados.length === 0) {
      porTipoEl.innerHTML = '<div class="muted">Nenhum erro encontrado no periodo.</div>';
    } else {
      porTipoEl.innerHTML = tiposOrdenados.map(([tipo, total], index) => `
        <div class="df-defect-entry">
          <button type="button" class="mi-defeito-tipo-row df-defect-toggle" data-df-defect-index="${index}" aria-expanded="false" aria-controls="dfDefectDetail${index}">
            <span>${escapeHtml(tipo)}</span>
            <span class="df-defect-row-end"><strong>${total}</strong><i aria-hidden="true">⌄</i></span>
          </button>
          <div id="dfDefectDetail${index}" class="df-defect-detail" hidden></div>
        </div>
      `).join("");
    }
  }

  const paretoEl = document.getElementById("miDefPareto");
  setText("miDefParetoBadge", `${indicadores.totalErros} total`);
  let acumulado = 0;
  const pareto = tiposOrdenados.map(([tipo, total]) => {
    const pct = indicadores.totalErros > 0 ? (total / indicadores.totalErros) * 100 : 0;
    acumulado += pct;
    return { tipo, total, pct, acumulado };
  });
  const vitais = pareto.filter(item => item.acumulado <= 80);
  const tiposVitais = vitais.length || (pareto.length ? 1 : 0);
  setText("miDefTiposVitais", tiposVitais);
  if (paretoEl) {
    if (pareto.length === 0) {
      paretoEl.innerHTML = '<div class="muted">Sem dados para Pareto no periodo.</div>';
    } else {
      paretoEl.innerHTML = pareto.slice(0, 10).map(item => `
        <div class="mi-def-pareto-row ${item.acumulado <= 80 ? "vital" : ""}">
          <div>
            <strong>${escapeHtml(item.tipo)}</strong>
            <span>${formatPct(item.pct)} do total | ${formatPct(item.acumulado)} acumulado</span>
          </div>
          <em>${item.total}</em>
        </div>
      `).join("");
    }
  }

  const setoresEl = document.getElementById("miDefSetores");
  if (setoresEl) {
    const setores = Object.values(indicadores.porSetor).sort((a, b) => b.erros - a.erros);
    if (setores.length === 0) {
      setoresEl.innerHTML = '<div class="muted">Sem setores no periodo.</div>';
    } else {
      setoresEl.innerHTML = setores.map(item => {
        const setorTaxa = item.producao > 0 ? (item.erros / item.producao) * 100 : 0;
        return `
          <div class="mi-defeitos-row">
            <div class="mi-defeitos-row-main">
              <strong>${escapeHtml(item.setor)}</strong>
              <span>${item.producao} produzido(s)</span>
            </div>
            <div class="mi-defeitos-row-metrics">
              <span><strong>${item.erros}</strong> erros</span>
              <span><strong>${formatPct(setorTaxa)}</strong> taxa/producao</span>
            </div>
          </div>
        `;
      }).join("");
    }
  }

  renderParticipacaoDefeitos("miDefMatriz", "miDefMatrizTotal", indicadores.porTipo, indicadores.totalErros);
  [1, 2].forEach(numeroSetor => {
    const { porTipo, total } = criarParticipacaoDefeitosPorSetor(indicadores.matriz, numeroSetor);
    renderParticipacaoDefeitos(`miDefMatrizS${numeroSetor}`, `miDefMatrizS${numeroSetor}Total`, porTipo, total, numeroSetor);
  });

  const planoEl = document.getElementById("miDefPlanoAcao");
  if (planoEl) {
    if (pareto.length === 0) {
      planoEl.innerHTML = '<div class="muted">Sem defeitos para sugerir plano.</div>';
    } else {
      planoEl.innerHTML = pareto.slice(0, 2).map(item => {
        const prioridade = item.pct > 20 ? "Critica" : item.pct > 10 ? "Alta" : item.pct > 5 ? "Media" : "Baixa";
        const meta = Math.max(1, Math.floor(item.total * 0.5));
        return `
          <div class="mi-def-action">
            <strong>${escapeHtml(item.tipo)}</strong>
            <span>Prioridade ${prioridade} | ${item.total} ocorrencia(s) | meta 90 dias: ${meta}</span>
            <p>Estratificar por setor, forma e montador; revisar causa raiz no ponto de maior incidencia e acompanhar semanalmente.</p>
          </div>
        `;
      }).join("");
    }
  }

  const presentationOverlay = document.getElementById("dfPresentationOverlay");
  if (presentationOverlay && !presentationOverlay.classList.contains("hidden")) {
    renderizarApresentacaoDefeitos();
  }
}

function formatarDataApresentacaoDefeitos(ymd) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(ymd || ""))) return "-";
  return new Date(`${ymd}T12:00:00`).toLocaleDateString("pt-BR");
}

function obterContextoApresentacaoDefeitos() {
  const inicio = document.getElementById("dfDataInicio")?.value || todayYmd();
  const fim = document.getElementById("dfDataFim")?.value || todayYmd();
  const setorSelect = document.getElementById("dfFiltroSetor");
  const statusSelect = document.getElementById("dfFiltroStatus");
  const setor = setorSelect?.selectedOptions?.[0]?.textContent?.trim() || "Todos os Setores";
  const status = statusSelect?.selectedOptions?.[0]?.textContent?.trim() || "Todos os Status";
  const periodo = inicio === fim
    ? formatarDataApresentacaoDefeitos(inicio)
    : `${formatarDataApresentacaoDefeitos(inicio)} a ${formatarDataApresentacaoDefeitos(fim)}`;
  return { inicio, fim, periodo, setor, status };
}

function criarCabecalhoSlideDefeitos(titulo, contexto) {
  const escopo = contexto.status && !normalizarTexto(contexto.status).startsWith("todos")
    ? `${contexto.setor} | ${contexto.status}`
    : contexto.setor;
  return `
    <header class="df-slide-head">
      <div class="df-slide-brand">
        <div class="df-slide-brand-mark">CT</div>
        <div><span>ConcreTrack | Qualidade</span><strong>${escapeHtml(titulo)}</strong></div>
      </div>
      <div class="df-slide-context"><span>${escapeHtml(contexto.periodo)}</span><strong>${escapeHtml(escopo)}</strong></div>
    </header>
  `;
}

function criarRodapeSlideDefeitos(numero) {
  return `
    <footer class="df-slide-foot">
      <span><strong>Fonte:</strong> montagem_poste + producao | dados do periodo e escopo selecionados</span>
      <span>${String(numero).padStart(2, "0")} / ${String(DF_PRESENTATION_SLIDE_TOTAL).padStart(2, "0")}</span>
    </footer>
  `;
}

function criarSlideDefeitos(numero, titulo, contexto, corpo, classe = "") {
  return `
    <section class="df-presentation-slide ${classe}" data-df-presentation-slide="${numero - 1}" aria-label="Slide ${numero}: ${escapeHtml(titulo)}">
      ${criarCabecalhoSlideDefeitos(titulo, contexto)}
      <div class="df-slide-body">${corpo}</div>
      ${criarRodapeSlideDefeitos(numero)}
    </section>
  `;
}

function renderizarApresentacaoDefeitos() {
  const deck = document.getElementById("dfPresentationDeck");
  if (!deck || !dfPresentationData) return;
  const dados = dfPresentationData;
  const contexto = obterContextoApresentacaoDefeitos();
  const numero = value => Number(value || 0).toLocaleString("pt-BR");
  const principal = dados.ranking[0];
  const rankingSlide = dados.ranking.slice(0, 8);
  const top3 = dados.ranking.slice(0, 3);
  const insightPrincipal = principal
    ? `O defeito de maior incidencia foi <strong>${escapeHtml(principal.tipo)}</strong>, com ${numero(principal.total)} ocorrencia(s), equivalente a ${formatPct(principal.percentual)} do total.`
    : "Nao foram identificadas ocorrencias de defeito no periodo selecionado.";

  const slideResumo = criarSlideDefeitos(1, "Visao executiva", contexto, `
    <div class="df-slide-overview-grid">
      <div class="df-slide-overview-copy">
        <span class="df-slide-kicker">Fechamento da qualidade</span>
        <h1 class="df-slide-title">Dashboard de Defeitos</h1>
        <p>Panorama consolidado das inspecoes de montagem, ocorrencias de nao conformidade e impacto sobre a producao.</p>
      </div>
      <div class="df-slide-rate-hero">
        <span>Taxa de defeitos</span>
        <strong>${formatPct(dados.taxaDefeitos)}</strong>
        <small>${numero(dados.totalErros)} ocorrencias em ${numero(dados.totalPossivel)} oportunidades avaliadas</small>
      </div>
    </div>
    <div class="df-slide-kpi-grid">
      <article class="df-slide-kpi" data-visual-print="2d58793bd3ca" style="--df-kpi-color:var(--c-ink-2);"><span>Ocorrencias de NC</span><strong>${numero(dados.totalErros)}</strong><small>Total registrado no checklist</small></article>
      <article class="df-slide-kpi" data-visual-print="37c901c9cb29" style="--df-kpi-color:var(--c-ink-3);"><span>Postes avaliados</span><strong>${numero(dados.postes)}</strong><small>Inspecoes validas no periodo</small></article>
      <article class="df-slide-kpi" data-visual-print="a6e9973aea6d" style="--df-kpi-color:var(--c-crit);"><span>Postes reprovados</span><strong>${numero(dados.postesReprovados)}</strong><small>${formatPct(dados.taxaPostesReprovados)} sobre a producao</small></article>
      <article class="df-slide-kpi" data-visual-print="37f4ebc36cde" style="--df-kpi-color:var(--c-orange);"><span>Retrabalho</span><strong>${numero(dados.retrabalho)}</strong><small>${formatPct(dados.taxaRetrabalho)} dos postes avaliados</small></article>
    </div>
    <div class="df-slide-insight"><strong>Leitura executiva</strong><span>${insightPrincipal}</span></div>
  `, "df-slide-overview");

  const rankingHtml = rankingSlide.length
    ? `<div class="df-slide-ranking">${rankingSlide.map(item => `
        <div class="df-slide-ranking-row">
          <div class="df-slide-ranking-label"><i style="--df-defect-color:${item.cor}"></i><span title="${escapeHtml(item.tipo)}">${escapeHtml(item.tipo)}</span></div>
          <div class="df-slide-ranking-track"><div class="df-slide-ranking-fill" style="--df-defect-color:${item.cor};--df-defect-width:${item.larguraRelativa.toFixed(2)}%">${numero(item.total)}</div></div>
          <div class="df-slide-ranking-pct">${formatPct(item.percentual)}</div>
        </div>`).join("")}</div>`
    : '<div class="df-slide-empty">Sem defeitos no periodo selecionado.</div>';
  const top3Html = top3.length
    ? `<div class="df-slide-top3">${top3.map((item, index) => `<article><strong>${index + 1}o | ${escapeHtml(item.tipo)}</strong>${numero(item.total)} ocorrencia(s) | ${formatPct(item.percentual)} do total</article>`).join("")}</div>`
    : "";
  const slideRanking = criarSlideDefeitos(2, "Participacao dos defeitos", contexto, `
    <div class="df-slide-section-head">
      <div><span class="df-slide-kicker">Distribuicao das ocorrencias</span><h1 class="df-slide-title">Defeitos por participacao</h1></div>
      <p>Ranking dos ${Math.min(8, dados.ranking.length)} principais tipos. A barra compara o volume e o percentual considera ${numero(dados.totalErros)} ocorrencias.</p>
    </div>
    ${rankingHtml}
    ${top3Html}
  `, "df-slide-ranking-view");

  const maiorTaxaSetor = dados.setores.reduce((maior, item) => Math.max(maior, item.taxa), 0);
  const setoresHtml = dados.setores.length
    ? `<div class="df-slide-sector-grid" style="--df-sector-card-count:${Math.min(4, dados.setores.length)}">${dados.setores.slice(0, 4).map(item => `
        <article class="df-slide-sector-card">
          <header><strong>${escapeHtml(item.setor)}</strong><span>${formatPct(item.taxa)}</span></header>
          <p>${numero(item.erros)} erro(s) | ${numero(item.producao)} produzido(s)</p>
          <div class="df-slide-sector-track"><i style="--df-sector-width:${maiorTaxaSetor > 0 ? Math.min(100, (item.taxa / maiorTaxaSetor) * 100).toFixed(2) : 0}%"></i></div>
        </article>`).join("")}</div>`
    : '<div class="df-slide-empty">Sem dados setoriais no periodo selecionado.</div>';
  const setoresMatriz = dados.setores.slice(0, 4).map(item => item.setor);
  const tiposMatriz = dados.ranking.slice(0, 6);
  const maiorCelula = tiposMatriz.reduce((maior, item) => setoresMatriz.reduce((maxSetor, setor) => Math.max(maxSetor, Number(dados.matriz?.[item.tipo]?.[setor] || 0)), maior), 0);
  const matrizHtml = setoresMatriz.length && tiposMatriz.length
    ? `<div class="df-slide-matrix-card">
        <div class="df-slide-matrix-title"><strong>Matriz dos principais defeitos por setor</strong><span>Cor mais intensa = maior recorrencia</span></div>
        <div class="df-slide-matrix" style="--df-sector-count:${setoresMatriz.length}">
          <div class="df-slide-matrix-row head"><strong>Defeito</strong>${setoresMatriz.map(setor => `<span class="df-slide-matrix-cell">${escapeHtml(setor.replace("Setor ", "S"))}</span>`).join("")}</div>
          ${tiposMatriz.map(item => `<div class="df-slide-matrix-row"><strong title="${escapeHtml(item.tipo)}">${escapeHtml(item.tipo)}</strong>${setoresMatriz.map(setor => {
            const total = Number(dados.matriz?.[item.tipo]?.[setor] || 0);
            const intensidade = maiorCelula > 0 ? total / maiorCelula : 0;
            const bg = total > 0 ? `rgba(37,99,235,${(0.16 + intensidade * 0.78).toFixed(2)})` : "#edf2f7";
            const textColor = intensidade > 0.45 ? "#fff" : "#173653";
            return `<span class="df-slide-matrix-cell" style="--df-matrix-bg:${bg};--df-matrix-text:${textColor}">${total}</span>`;
          }).join("")}</div>`).join("")}
        </div>
      </div>`
    : "";
  const slideSetores = criarSlideDefeitos(3, "Desempenho por setor", contexto, `
    <div class="df-slide-section-head">
      <div><span class="df-slide-kicker">Onde estao as ocorrencias</span><h1 class="df-slide-title">Comparativo setorial</h1></div>
      <p>Taxa setorial = quantidade de erros do setor dividida pela producao do mesmo setor.</p>
    </div>
    ${setoresHtml}
    ${matrizHtml}
  `, "df-slide-sector-view");

  const orientacoes = [
    "Abrir analise de causa no setor e na forma com maior incidencia; definir responsavel e prazo.",
    "Estratificar por modelo e montador, revisar o padrao operacional e registrar a contramedida.",
    "Acompanhar semanalmente a recorrencia e validar a eficacia da acao no proximo fechamento."
  ];
  const acoesHtml = top3.length
    ? `<div class="df-slide-action-grid" style="--df-action-count:${top3.length}">${top3.map((item, index) => `
        <article class="df-slide-action-card" style="--df-defect-color:${item.cor}">
          <span>Prioridade ${index + 1}</span><strong>${escapeHtml(item.tipo)}</strong><em>${numero(item.total)} | ${formatPct(item.percentual)}</em><p>${orientacoes[index]}</p>
        </article>`).join("")}</div>`
    : '<div class="df-slide-empty">Sem ocorrencias para priorizar neste periodo.</div>';
  const slideAcoes = criarSlideDefeitos(4, "Prioridades e memoria de calculo", contexto, `
    <div class="df-slide-section-head">
      <div><span class="df-slide-kicker">Fechamento e proximo passo</span><h1 class="df-slide-title">Plano de acao</h1></div>
      <p>Prioridades ordenadas por participacao no total de ocorrencias registradas.</p>
    </div>
    ${acoesHtml}
    <div class="df-slide-method-grid">
      <article class="df-slide-method-card"><span>Indicador principal</span><strong>Taxa de defeitos</strong><p>${numero(dados.totalErros)} ocorrencias ÷ ${numero(dados.totalPossivel)} oportunidades × 100 = <b>${formatPct(dados.taxaDefeitos)}</b>.</p></article>
      <article class="df-slide-method-card"><span>Indicador secundario</span><strong>Indice de reprovacao</strong><p>${numero(dados.postesComDefeito)} postes com defeito ÷ ${numero(dados.postes)} avaliados × 100 = <b>${formatPct(dados.indiceReprovacao)}</b>.</p></article>
      <article class="df-slide-method-card"><span>Indicador terciario</span><strong>Taxa de retrabalho</strong><p>${numero(dados.retrabalho)} retrabalhos ÷ ${numero(dados.postes)} avaliados × 100 = <b>${formatPct(dados.taxaRetrabalho)}</b>.</p></article>
    </div>
  `, "df-slide-action-view");

  deck.innerHTML = slideResumo + slideRanking + slideSetores + slideAcoes;
  exibirSlideApresentacaoDefeitos(dfPresentationSlideIndex);
}

function ajustarEscalaApresentacaoDefeitos() {
  const overlay = document.getElementById("dfPresentationOverlay");
  const viewport = document.getElementById("dfPresentationViewport");
  const frame = document.getElementById("dfPresentationFrame");
  const deck = document.getElementById("dfPresentationDeck");
  if (!overlay || overlay.classList.contains("hidden") || !viewport || !frame || !deck) return;
  const larguraDisponivel = Math.max(240, viewport.clientWidth - 36);
  const alturaDisponivel = Math.max(180, viewport.clientHeight - 36);
  const escala = Math.min(1, larguraDisponivel / 1024, alturaDisponivel / 768);
  frame.style.width = `${Math.round(1024 * escala)}px`;
  frame.style.height = `${Math.round(768 * escala)}px`;
  deck.style.transform = `scale(${escala})`;
}

function exibirSlideApresentacaoDefeitos(index) {
  const slides = Array.from(document.querySelectorAll("[data-df-presentation-slide]"));
  if (!slides.length) return;
  dfPresentationSlideIndex = Math.max(0, Math.min(slides.length - 1, Number(index || 0)));
  slides.forEach((slide, slideIndex) => {
    const ativo = slideIndex === dfPresentationSlideIndex;
    slide.classList.toggle("is-active", ativo);
    slide.setAttribute("aria-hidden", ativo ? "false" : "true");
  });
  const counter = document.getElementById("dfPresentationCounter");
  if (counter) counter.textContent = `${dfPresentationSlideIndex + 1} / ${slides.length}`;
  const prev = document.getElementById("dfPresentationPrev");
  const next = document.getElementById("dfPresentationNext");
  if (prev) prev.disabled = dfPresentationSlideIndex === 0;
  if (next) next.disabled = dfPresentationSlideIndex === slides.length - 1;
}

function abrirApresentacaoDefeitos() {
  if (!dfPresentationData) {
    showMsgBox("Atualize o Dashboard Defeitos antes de abrir a apresentacao.", "error");
    return;
  }
  const overlay = document.getElementById("dfPresentationOverlay");
  if (!overlay) return;
  dfPresentationReturnFocus = document.activeElement;
  dfPresentationSlideIndex = 0;
  renderizarApresentacaoDefeitos();
  overlay.classList.remove("hidden");
  document.body.classList.add("df-presentation-open");
  exibirSlideApresentacaoDefeitos(0);
  requestAnimationFrame(() => {
    ajustarEscalaApresentacaoDefeitos();
    document.getElementById("dfPresentationNext")?.focus();
  });
}

function fecharApresentacaoDefeitos() {
  const overlay = document.getElementById("dfPresentationOverlay");
  if (!overlay || overlay.classList.contains("hidden")) return;
  overlay.classList.add("hidden");
  document.body.classList.remove("df-presentation-open", "df-presentation-print");
  if (document.fullscreenElement === overlay && document.exitFullscreen) {
    document.exitFullscreen().catch(() => {});
  }
  if (dfPresentationReturnFocus?.focus) dfPresentationReturnFocus.focus();
}

async function alternarTelaCheiaApresentacaoDefeitos() {
  const overlay = document.getElementById("dfPresentationOverlay");
  if (!overlay) return;
  try {
    if (document.fullscreenElement === overlay) await document.exitFullscreen();
    else if (overlay.requestFullscreen) await overlay.requestFullscreen();
  } catch (error) {
    console.warn("Nao foi possivel alternar a tela cheia da apresentacao:", error);
  }
}

function imprimirApresentacaoDefeitos() {
  const overlay = document.getElementById("dfPresentationOverlay");
  if (!overlay || overlay.classList.contains("hidden")) return;
  document.getElementById("dfPresentationPageStyle")?.remove();
  const pageStyle = document.createElement("style");
  pageStyle.id = "dfPresentationPageStyle";
  pageStyle.textContent = "@page { size: 10.6667in 8in; margin: 0; }";
  document.head.appendChild(pageStyle);
  document.body.classList.add("df-presentation-print");
  requestAnimationFrame(() => {
    window.print();
    setTimeout(finalizarImpressaoApresentacaoDefeitos, 0);
  });
}

function finalizarImpressaoApresentacaoDefeitos() {
  document.body.classList.remove("df-presentation-print");
  document.getElementById("dfPresentationPageStyle")?.remove();
}

function renderIndicadoresDefeitosContrato(contract, productionRows = []) {
  const kpis = contract?.kpis || {};
  const bySectorContract = contract?.by_sector || {};
  const byDefect = contract?.by_defect || {};
  const defectMatrix = contract?.defect_matrix || {};
  const setText = (id, value) => {
    const node = document.getElementById(id);
    if (node) node.textContent = value;
  };

  const sectorCode = value => {
    const normalized = normalizarTexto(String(value || "")).replace(/\s+/g, " ").trim();
    const match = normalized.match(/^(?:setor\s*)?(\d+)$/);
    return match ? `S${match[1]}` : String(value || "").trim();
  };
  const scopeSectors = {
    S1: ["S1"],
    S2: ["S2"],
    S3: ["S3"],
    S4: ["S4"],
    S1_S2: ["S1", "S2"],
    TOTAL: ["S1", "S2", "S3", "S4"]
  };
  const includedSectors = Array.isArray(contract?.included_sectors) && contract.included_sectors.length
    ? contract.included_sectors.map(sectorCode)
    : (scopeSectors[contract?.scope] || scopeSectors.TOTAL);
  setText("miDefSetoresBadge", `${includedSectors.join("+")} recalculado`);
  const productionBySector = {};
  (productionRows || []).forEach(row => {
    const status = String(row?.status || "").toUpperCase();
    const code = sectorCode(row?.setor);
    if (!includedSectors.includes(code) || !["LIBERADO", "INSPECIONADO", "CONCRETADO"].includes(status)) return;
    productionBySector[code] = (productionBySector[code] || 0) + 1;
  });
  const bySector = {};
  includedSectors.forEach(code => {
    const item = bySectorContract[code] || {};
    bySector[code] = {
      ...item,
      producao: productionRows.length ? Number(productionBySector[code] || 0) : Number(item?.producao || 0),
      erros: Number(item?.erros || 0)
    };
  });

  const indicadores = {
    postes: Number(kpis.postes || 0),
    producao: Number(kpis.producao || 0),
    totalPossivel: Number(kpis.total_possivel || 0),
    totalErros: Number(kpis.total_erros || 0),
    postesComDefeito: Number(kpis.postes_com_defeito || 0),
    postesReprovados: Number(kpis.postes_reprovados || 0),
    retrabalho: Number(kpis.retrabalho || 0),
    porTipo: Object.fromEntries(Object.entries(byDefect).map(([key, value]) => [key, Number(value || 0)])),
    porSetor: {},
    matriz: {},
    fissuras: {
      total: Number(kpis.fissuras || 0),
      circulares: Number(kpis.fissuras_circulares || 0),
      outros: Math.max(0, Number(kpis.fissuras || 0) - Number(kpis.fissuras_circulares || 0))
    }
  };

  Object.entries(bySector).forEach(([scope, item]) => {
    indicadores.porSetor[scope] = {
      setor: scope,
      erros: Number(item?.erros || 0),
      producao: Number(item?.producao || 0)
    };
  });

  Object.entries(defectMatrix).forEach(([tipo, setores]) => {
    indicadores.matriz[tipo] = {};
    Object.entries(setores || {}).forEach(([scope, total]) => {
      indicadores.matriz[tipo][scope] = Number(total || 0);
    });
  });

  miDefeitosExportData = {
    scope: contract?.scope || "TOTAL",
    includedSectors,
    kpis,
    bySector,
    byDefect,
    defectMatrix
  };

  renderIndicadoresDefeitosMontagem(indicadores);

  const setoresEl = document.getElementById("miDefSetores");
  if (setoresEl) {
    const setores = Object.entries(bySector).sort((a, b) => String(a[0]).localeCompare(String(b[0]), "pt-BR", { numeric: true }));
    if (!setores.length) {
      setoresEl.innerHTML = '<div class="muted">Sem setores no periodo.</div>';
    } else {
      setoresEl.innerHTML = setores.map(([scope, item]) => {
        const producao = Number(item?.producao || 0);
        const erros = Number(item?.erros || 0);
        const setorTaxa = producao > 0 ? (erros / producao) * 100 : 0;
        return `
          <div class="mi-defeitos-row">
            <div class="mi-defeitos-row-main">
              <strong>${escapeHtml(scope)}</strong>
              <span>${producao} produzido(s)</span>
            </div>
            <div class="mi-defeitos-row-metrics">
              <span><strong>${erros}</strong> erros</span>
              <span><strong>${formatPct(setorTaxa)}</strong> taxa/producao</span>
            </div>
          </div>
        `;
      }).join("");
    }
  }
}

function exportarDashboardDefeitosCsv() {
  const dados = miDefeitosExportData;
  if (!dados?.includedSectors?.length) {
    showMsgBox("Atualize o dashboard antes de exportar.", "error");
    return;
  }

  const dStart = document.getElementById("dfDataInicio")?.value || todayYmd();
  const dEnd = document.getElementById("dfDataFim")?.value || todayYmd();
  const kpis = dados.kpis || {};
  const linhas = [
    ["Dashboard de Defeitos"],
    ["Periodo", dStart, dEnd],
    ["Escopo", dados.scope],
    [],
    ["Indicador", "Valor"],
    ["Producao", Number(kpis.producao || 0)],
    ["Postes avaliados", Number(kpis.postes || 0)],
    ["Ocorrencias de NC", Number(kpis.total_erros || 0)],
    ["Oportunidades avaliadas", Number(kpis.total_possivel || 0)],
    ["Postes reprovados", Number(kpis.postes_reprovados || 0)],
    ["Retrabalho", Number(kpis.retrabalho || 0)],
    [],
    ["Taxa de defeitos por setor"],
    ["Setor", "Produzidos", "Erros", "Taxa/producao"]
  ];

  dados.includedSectors.forEach(setor => {
    const item = dados.bySector?.[setor] || {};
    const producao = Number(item.producao || 0);
    const erros = Number(item.erros || 0);
    linhas.push([setor, producao, erros, formatPct(producao > 0 ? (erros / producao) * 100 : 0)]);
  });

  linhas.push([], ["Matriz defeito x setor"], ["Defeito", ...dados.includedSectors, "Total"]);
  Object.entries(dados.byDefect || {})
    .sort((a, b) => Number(b[1] || 0) - Number(a[1] || 0))
    .forEach(([tipo, total]) => {
      const matrizSetores = dados.defectMatrix?.[tipo] || {};
      linhas.push([tipo, ...dados.includedSectors.map(setor => Number(matrizSetores[setor] || 0)), Number(total || 0)]);
    });

  const escopoArquivo = String(dados.scope || "TOTAL").toLowerCase().replace(/[^a-z0-9]+/g, "-");
  baixarArquivoBlob(
    criarCsv(linhas),
    `dashboard_defeitos_${dStart}_a_${dEnd}_${escopoArquivo}.csv`,
    "text/csv;charset=utf-8",
    true
  );
  showMsgBox("Dashboard de defeitos exportado em CSV.", "success");
}

function atualizarResumoFiltrosProdutividade() {
  const dStart = document.getElementById("paDataInicio")?.value || todayYmd();
  const dEnd = document.getElementById("paDataFim")?.value || todayYmd();
  const setor = document.getElementById("paFiltroSetor")?.value || "Todos os setores";
  const meta = document.getElementById("paMetaCiclo")?.value || "15";
  const resumo = document.getElementById("paFiltroResumo");
  if (!resumo) return;
  const fmt = (d) => d ? d.split("-").reverse().join("/") : "-";
  const periodo = dStart === dEnd ? fmt(dStart) : `${fmt(dStart)} a ${fmt(dEnd)}`;
  resumo.textContent = `${periodo} - ${setor} - Meta ${meta} min`;
}

function atualizarResumoFiltrosDefeitos() {
  const dStart = document.getElementById("dfDataInicio")?.value || todayYmd();
  const dEnd = document.getElementById("dfDataFim")?.value || todayYmd();
  const setor = document.getElementById("dfFiltroSetor")?.value || "Todos os setores";
  const resumo = document.getElementById("dfFiltroResumo");
  const caption = document.getElementById("dfScopeCaption");
  if (!resumo) return;
  const fmt = (d) => d ? d.split("-").reverse().join("/") : "-";
  const periodo = dStart === dEnd ? fmt(dStart) : `${fmt(dStart)} a ${fmt(dEnd)}`;
  resumo.textContent = `${periodo} - ${setor}`;
  if (caption) {
    const label = !setor || normalizarTexto(setor).startsWith("todos")
      ? "Total geral"
      : setor === "Setores 1 e 2"
        ? "Consolidado S1+S2"
        : setor;
    caption.textContent = `Escopo ativo: ${label}`;
  }
}

function sincronizarDfScopeTabs() {
  const value = document.getElementById("dfFiltroSetor")?.value || "";
  document.querySelectorAll("[data-df-scope]").forEach(btn => {
    btn.classList.toggle("active", (btn.dataset.dfScope || "") === value);
  });
  atualizarResumoFiltrosDefeitos();
}

function setProdutividadeDrawerOpen(open) {
  const drawer = document.getElementById("paFiltrosDrawer");
  if (!drawer) return;
  if (drawer.classList.contains("pa-filters-inline")) return;
  drawer.classList.toggle("hidden", !open);
  drawer.setAttribute("aria-hidden", open ? "false" : "true");
}

function ativarAbaMontagem(tab) {
  miAbaAtiva = tab || "resumo";
  document.querySelectorAll(".mi-tab-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.tab === miAbaAtiva);
  });
  document.querySelectorAll(".mi-tab-section").forEach(section => {
    section.classList.remove("active");
  });
  const sectionId = "miSecao" + miAbaAtiva.charAt(0).toUpperCase() + miAbaAtiva.slice(1);
  document.getElementById(sectionId)?.classList.add("active");
  if (miUltimosGraficos) {
    renderGraficosMontagem(
      miUltimosGraficos.byDay,
      miUltimosGraficos.bySector,
      miUltimosGraficos.byMontador,
      miUltimosGraficos.prodByDay
    );
  }
}

function aplicarLayoutDashboardDefeitos() {
  const defeitosSection = document.getElementById("miSecaoDefeitos");
  const target = document.getElementById("dfContent");
  if (defeitosSection && target && defeitosSection.parentElement !== target) {
    target.appendChild(defeitosSection);
  }
  if (defeitosSection) {
    defeitosSection.classList.add("active");
    defeitosSection.style.display = "block";
  }
}

function limparLayoutDashboardDefeitos() {
  const defeitosSection = document.getElementById("miSecaoDefeitos");
  const target = document.getElementById("miSecaoProdutividade");
  if (defeitosSection && target?.parentElement && defeitosSection.parentElement?.id === "dfContent") {
    target.parentElement.insertBefore(defeitosSection, target);
  }
  if (defeitosSection) defeitosSection.style.display = "";
}

async function carregarMontagemIndicadores() {
  if (!supabaseClient) return;
  const dashboardKind = "montagem";
  const requestId = ++dashboardRequestSeq[dashboardKind];
  const dStart = getDashboardFilterValue("DataInicio", todayYmd());
  const dEnd = getDashboardFilterValue("DataFim", todayYmd());
  const montagemStartIso = new Date(`${dStart}T00:00:00-03:00`).toISOString();
  const montagemEndIso = new Date(`${dEnd}T23:59:59.999-03:00`).toISOString();

  setSyncStatus("pending", "Carregando indicadores de montagem...");
  try {
    // O resumo e calculado localmente com a mesma base exibida. O antigo RPC de
    // montagem era redundante e podia estourar o statement_timeout ao abrir a tela.
    const [montagemRes, producaoRes] = await Promise.all([
      carregarLinhasSupabaseComCache({
        cacheKey: `${dashboardKind}:montagem_poste:screen-v2:${dStart}:${dEnd}`,
        table: "montagem_poste",
        select: DASHBOARD_MONTAGEM_SCREEN_SELECT,
        pageSize: 500,
        maxPages: 100,
        timeoutMs: 60000,
        orderBy: "id",
        orderOptions: { ascending: true },
        applyFilters: query => query
          .or(`and(finalizado_em.gte.${montagemStartIso},finalizado_em.lte.${montagemEndIso}),and(inicio_inspecao_montagem.gte.${montagemStartIso},inicio_inspecao_montagem.lte.${montagemEndIso}),and(data_fabricacao.gte.${dStart},data_fabricacao.lte.${dEnd})`)
      }),
      carregarLinhasSupabaseComCache({
        cacheKey: `${dashboardKind}:producao:${dStart}:${dEnd}`,
        table: "producao",
        select: DASHBOARD_PRODUCAO_SELECT,
        pageSize: 500,
        maxPages: 100,
        timeoutMs: 60000,
        orderBy: "id",
        orderOptions: { ascending: true },
        applyFilters: query => query
          .gte("data_fabricacao", dStart)
          .lte("data_fabricacao", dEnd)
      })
    ]);

    if (requestId !== dashboardRequestSeq[dashboardKind]) return;

    miRawMontagemData = montagemRes.rows || [];
    miRawProducaoData = producaoRes.rows || [];

    miPaginaAtual = 1;
    aplicarFiltrosEExibirMontagem();
    const fromCache = montagemRes.state === "OFFLINE_CACHE" || producaoRes.state === "OFFLINE_CACHE";
    if (fromCache) setSyncStatus("warn", "Indicadores carregados do cache local.");
    else setSyncStatus("ok", "Indicadores de montagem atualizados.");

  } catch(err) {
    console.error("Erro carregarMontagemIndicadores:", err);
    setSyncStatus("error", "Erro ao carregar indicadores.");
  }
}

let dashboardDefeitosBaseCache = null;
let dashboardDefeitosBaseRequest = null;

async function obterBaseDashboardDefeitos(dStart, dEnd, forceRefresh = false) {
  const key = `${dStart}:${dEnd}`;
  if (!forceRefresh && dashboardDefeitosBaseRequest?.key === key) return dashboardDefeitosBaseRequest.promise;
  if (dashboardDefeitosBaseRequest) dashboardDefeitosBaseRequest.controller?.abort();
  if (!forceRefresh && dashboardDefeitosBaseCache?.key === key) return dashboardDefeitosBaseCache.value;

  const montagemStartIso = new Date(`${dStart}T00:00:00-03:00`).toISOString();
  const montagemEndIso = new Date(`${dEnd}T23:59:59.999-03:00`).toISOString();
  const request = {
    key,
    promise: null,
    controller: typeof AbortController !== "undefined" ? new AbortController() : null
  };
  dashboardDefeitosBaseRequest = request;
  request.promise = Promise.all([
    carregarLinhasSupabaseComCache({
      cacheKey: `defeitos:montagem_poste:historico-v2:${dStart}:${dEnd}`,
      table: "montagem_poste",
      select: DASHBOARD_DEFEITOS_MONTAGEM_SELECT,
      pageSize: 1000,
      maxPages: 50,
      pageConcurrency: 2,
      requireComplete: true,
      timeoutMs: 60000,
      signal: request.controller?.signal,
      orderBy: "id",
      orderOptions: { ascending: true },
      applyFilters: query => query
        .or(`and(finalizado_em.gte.${montagemStartIso},finalizado_em.lte.${montagemEndIso}),and(inicio_inspecao_montagem.gte.${montagemStartIso},inicio_inspecao_montagem.lte.${montagemEndIso}),and(data_fabricacao.gte.${dStart},data_fabricacao.lte.${dEnd})`)
    }),
    carregarLinhasSupabaseComCache({
      cacheKey: `defeitos:producao:v3:${dStart}:${dEnd}`,
      table: "producao",
      select: DASHBOARD_DEFEITOS_PRODUCAO_SELECT,
      pageSize: 1000,
      maxPages: 50,
      pageConcurrency: 2,
      requireComplete: true,
      timeoutMs: 60000,
      signal: request.controller?.signal,
      orderBy: "id",
      orderOptions: { ascending: true },
      applyFilters: query => query
        .gte("data_fabricacao", dStart)
        .lte("data_fabricacao", dEnd)
    })
  ]).then(([montagemRes, producaoRes]) => {
    const value = { montagemRes, producaoRes };
    if (dashboardDefeitosBaseRequest === request
        && montagemRes.state !== "OFFLINE_CACHE" && producaoRes.state !== "OFFLINE_CACHE") {
      dashboardDefeitosBaseCache = { key, value };
    }
    return value;
  }).finally(() => {
    if (dashboardDefeitosBaseRequest === request) dashboardDefeitosBaseRequest = null;
  });
  return request.promise;
}

async function carregarDashboardDefeitos(forceRefresh = false) {
  aplicarLayoutDashboardDefeitos();
  if (!supabaseClient) return;
  const dashboardKind = "defeitos";
  const requestId = ++dashboardRequestSeq[dashboardKind];
  const dStart = getDashboardFilterValue("DataInicio", todayYmd());
  const dEnd = getDashboardFilterValue("DataFim", todayYmd());
  const setorFiltro = getDashboardFilterValue("FiltroSetor", "");
  const statusFiltro = getDashboardFilterValue("FiltroStatus", "");
  const pesquisa = getDashboardFilterValue("FiltroPesquisa", "").trim().toLowerCase();
  const scope = getDashboardScopeFromSetor(setorFiltro);

  atualizarResumoFiltrosDefeitos();
  setSyncStatus("pending", "Carregando dashboard de defeitos...");
  try {
    // O contrato RPC anterior excedia o statement_timeout em periodos extensos.
    // A tela agora calcula tudo a partir das bases paginadas e mantem o mesmo
    // conjunto de dados usado no detalhamento e na exportacao.
    const { montagemRes, producaoRes } = await obterBaseDashboardDefeitos(dStart, dEnd, forceRefresh);

    if (requestId !== dashboardRequestSeq[dashboardKind]) return;
    const pertenceAoSetor = row => {
      if (!setorFiltro || normalizarTexto(setorFiltro).startsWith("todos")) return true;
      if (setorFiltro === "Setores 1 e 2") return row.setor === "Setor 1" || row.setor === "Setor 2";
      return row.setor === setorFiltro;
    };
    const pertenceAoStatus = row => {
      if (!statusFiltro || normalizarTexto(statusFiltro).startsWith("todos")) return true;
      if (statusFiltro === "A") return String(row.status_montagem || "").toUpperCase() === "A" && !isLinhaDefeitoDashboard(row);
      if (statusFiltro === "R") return isLinhaDefeitoDashboard(row);
      return String(row.status_montagem || "").toUpperCase() === statusFiltro.toUpperCase();
    };
    const correspondePesquisa = row => !pesquisa || [
      row.forma_numero, row.forma, row.modelo, row.montador_nome
    ].some(value => String(value || "").toLowerCase().includes(pesquisa));
    const chaveForma = row => `${row.data_fabricacao || ""}|${row.setor || ""}|${normalizeForma(row.forma_numero || row.forma || "")}`;
    const montagemRows = removerReprovacoesDuplicadasDashboard(montagemRes.rows || []).filter(row => {
      const day = getMiDataReferencia(row);
      return isLinhaAvaliacaoDefeitosDashboard(row)
        && day >= dStart
        && day <= dEnd
        && pertenceAoSetor(row)
        && pertenceAoStatus(row)
        && correspondePesquisa(row);
    });
    const formasEncontradas = new Set(montagemRows.map(chaveForma));
    const producaoRows = (producaoRes.rows || []).filter(row =>
      pertenceAoSetor(row) && (!pesquisa || correspondePesquisa(row) || formasEncontradas.has(chaveForma(row)))
    );
    const indicadores = calcularIndicadoresDefeitosMontagem(montagemRows, producaoRows);
    renderIndicadoresDefeitosMontagem(indicadores, producaoRows);

    const includedSectorsByScope = {
      S1: ["Setor 1"],
      S2: ["Setor 2"],
      S3: ["Setor 3"],
      S4: ["Setor 4"],
      S1_S2: ["Setor 1", "Setor 2"],
      TOTAL: ["Setor 1", "Setor 2", "Setor 3", "Setor 4"]
    };
    const includedSectors = includedSectorsByScope[scope] || includedSectorsByScope.TOTAL;
    const badge = document.getElementById("miDefSetoresBadge");
    if (badge) badge.textContent = `${includedSectors.map(item => item.replace("Setor ", "S")).join("+")} recalculado`;
    miDefeitosExportData = {
      scope,
      includedSectors,
      kpis: {
        producao: indicadores.producao,
        postes: indicadores.postes,
        total_erros: indicadores.totalErros,
        total_possivel: indicadores.totalPossivel,
        postes_reprovados: indicadores.postesReprovados,
        retrabalho: indicadores.retrabalho
      },
      bySector: indicadores.porSetor,
      byDefect: indicadores.porTipo,
      defectMatrix: indicadores.matriz
    };
    const updated = document.getElementById("dfAtualizadoLabel");
    if (updated) updated.textContent = `Atualizado ${new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`;
    setSyncStatus(
      montagemRes.state === "OFFLINE_CACHE" || producaoRes.state === "OFFLINE_CACHE" ? "warn" : "ok",
      montagemRes.state === "OFFLINE_CACHE" || producaoRes.state === "OFFLINE_CACHE" ? "Dashboard Defeitos carregado do cache local." : "Dashboard Defeitos atualizado."
    );
  } catch (err) {
    if (requestId !== dashboardRequestSeq[dashboardKind]) return;
    console.error("Erro carregarDashboardDefeitos:", err);
    setSyncStatus("error", "Erro ao carregar dashboard de defeitos.");
  }
}

function aplicarFiltrosEExibirMontagem() {
  const dStart = getDashboardFilterValue("DataInicio", todayYmd());
  const dEnd = getDashboardFilterValue("DataFim", todayYmd());
  let fSetor = getDashboardFilterValue("FiltroSetor", "");
  let fStatus = getDashboardFilterValue("FiltroStatus", "");
  const fPesquisa = getDashboardFilterValue("FiltroPesquisa", "").trim().toLowerCase();
  if (normalizarTexto(fSetor).startsWith("todos")) fSetor = "";
  if (normalizarTexto(fStatus).startsWith("todos")) fStatus = "";
  atualizarResumoFiltrosMontagem();

  // 1. Filtrar dados de Montagem em memória
  miFilteredMontagemData = miRawMontagemData.filter(row => {
    // Considerar apenas montagens finalizadas
    if (!isLinhaMontagemDashboard(row)) return false;

    // Filtro por Data
    const day = getMiDataReferencia(row);
    if (!day || day < dStart || day > dEnd) return false;

    // Filtro por Setor
    if (fSetor) {
      if (fSetor === "Setores 1 e 2") {
        if (row.setor !== "Setor 1" && row.setor !== "Setor 2") return false;
      } else {
        if (row.setor !== fSetor) return false;
      }
    }

    // Filtro por Status
    if (fStatus) {
      const possuiDefeito = isLinhaDefeitoDashboard(row);
      if (fStatus === "R") {
        if (!possuiDefeito) return false;
      } else if (fStatus === "A") {
        if (possuiDefeito || row.status_montagem !== "A") return false;
      } else if (row.status_montagem !== fStatus) {
        return false;
      }
    }

    // Filtro por Pesquisa de Texto
    if (fPesquisa) {
      const forma = (row.forma_numero || "").toLowerCase();
      const modelo = (row.modelo || "").toLowerCase();
      const montador = (row.montador_nome || "").toLowerCase();
      if (!forma.includes(fPesquisa) && !modelo.includes(fPesquisa) && !montador.includes(fPesquisa)) {
        return false;
      }
    }

    return true;
  });

  window.renderTaxaMontagem?.(miFilteredMontagemData);

  // 2. Filtrar dados de Produção
  const miFilteredDefeitosData = miFilteredMontagemData.filter(isLinhaDefeitoDashboard);

  const filteredProducao = miRawProducaoData.filter(row => {
    const day = row.data_fabricacao;
    if (!day || day < dStart || day > dEnd) return false;
    if (fSetor) {
      if (fSetor === "Setores 1 e 2") {
        if (row.setor !== "Setor 1" && row.setor !== "Setor 2") return false;
      } else {
        if (row.setor !== fSetor) return false;
      }
    }
    return true;
  });

  // 3. Processar Indicadores para Gráficos e KPIs
  let totalInspecionado = miFilteredMontagemData.length;
  let totalAprovados = 0;
  let totalRecusados = 0;

  const byDay = {};
  const bySector = {};
  const byMontador = {};

  const temposPorModelo = {}; // { modelo: { totalMs: 0, count: 0 } }
  const temposPorMontador = {}; // { montador: { totalMs: 0, count: 0 } }

  miFilteredMontagemData.forEach(row => {
    const day = getMiDataReferencia(row);
    const possuiDefeito = isLinhaDefeitoDashboard(row);
    if (row.status_montagem === "A") totalAprovados++;
    if (possuiDefeito) totalRecusados++;

    if (!byDay[day]) byDay[day] = { total: 0, aprovados: 0, recusados: 0 };
    byDay[day].total++;
    if (possuiDefeito) byDay[day].recusados++;
    else byDay[day].aprovados++;

    const sec = row.setor || "Desconhecido";
    bySector[sec] = (bySector[sec] || 0) + 1;

    const mon = row.montador_nome || "Desconhecido";
    byMontador[mon] = (byMontador[mon] || 0) + 1;

    // Tempo de inspeção/montagem
    if (row.finalizado_em && row.inicio_inspecao_montagem) {
      const start = new Date(row.inicio_inspecao_montagem).getTime();
      const end = new Date(row.finalizado_em).getTime();
      const diff = end - start;
      if (diff >= 0) {
        // Por Modelo
        const mod = row.modelo || "Desconhecido";
        if (!temposPorModelo[mod]) temposPorModelo[mod] = { totalMs: 0, count: 0 };
        temposPorModelo[mod].totalMs += diff;
        temposPorModelo[mod].count++;

        // Por Montador
        if (!temposPorMontador[mon]) temposPorMontador[mon] = { totalMs: 0, count: 0 };
        temposPorMontador[mon].totalMs += diff;
        temposPorMontador[mon].count++;
      }
    }
  });

  renderIndicadoresDefeitosMontagem(calcularIndicadoresDefeitosMontagem(miFilteredDefeitosData, filteredProducao), filteredProducao);


  // Renderizar tempos médios
  const elTotalAprovados = document.getElementById("miTotalAprovados");
  if (elTotalAprovados) elTotalAprovados.textContent = totalAprovados;
  const elTotalRecusados = document.getElementById("miTotalRecusados");
  if (elTotalRecusados) elTotalRecusados.textContent = totalRecusados;

  const elTempoModelo = document.getElementById("miTempoMedioModelo");
  if (elTempoModelo) {
    const listModelos = Object.keys(temposPorModelo).map(key => {
      const avg = temposPorModelo[key].totalMs / temposPorModelo[key].count;
      return { key, avg, count: temposPorModelo[key].count };
    }).sort((a, b) => b.avg - a.avg);

    if (listModelos.length === 0) {
      elTempoModelo.innerHTML = '<div class="muted" style="padding: 10px; text-align: center;">Nenhum dado de tempo disponível</div>';
    } else {
      elTempoModelo.innerHTML = `
        <div style="display: flex; flex-direction: column; gap: 8px;">
          ${listModelos.map(item => `
            <div data-visual-print="a77f0a96207d" style="display:flex;justify-content:space-between;align-items:center;background:var(--c-bg);padding:8px 12px;border-radius:var(--r);border:1px solid var(--c-bg);font-size:0.85rem;">
              <span data-visual-print="93a01a9d61fe" style="font-weight:600;color:var(--c-navy);">${item.key}</span>
              <div style="display: flex; align-items: center; gap: 8px;">
                <span data-visual-print="cb5b5466d69a" style="font-size:0.75rem;color:var(--c-ink-2);">(${item.count} itens)</span>
                <span data-visual-print="55fbe0135f04" style="font-weight:bold;color:var(--c-ink-2);background:var(--c-bg);padding:2px 8px;border-radius:var(--r);">${formatarDuracao(item.avg)}</span>
              </div>
            </div>
          `).join("")}
        </div>
      `;
    }
  }

  const elTempoMontador = document.getElementById("miTempoMontador");
  if (elTempoMontador) {
    const listMontadores = Object.keys(temposPorMontador).map(key => {
      const avg = temposPorMontador[key].totalMs / temposPorMontador[key].count;
      return { key, avg, count: temposPorMontador[key].count };
    }).sort((a, b) => b.avg - a.avg);

    if (listMontadores.length === 0) {
      elTempoMontador.innerHTML = '<div class="muted" style="padding: 10px; text-align: center;">Nenhum dado de tempo disponível</div>';
    } else {
      elTempoMontador.innerHTML = `
        <div style="display: flex; flex-direction: column; gap: 8px;">
          ${listMontadores.map(item => `
            <div data-visual-print="a77f0a96207d" style="display:flex;justify-content:space-between;align-items:center;background:var(--c-bg);padding:8px 12px;border-radius:var(--r);border:1px solid var(--c-bg);font-size:0.85rem;">
              <span data-visual-print="93a01a9d61fe" style="font-weight:600;color:var(--c-navy);">${item.key}</span>
              <div style="display: flex; align-items: center; gap: 8px;">
                <span data-visual-print="cb5b5466d69a" style="font-size:0.75rem;color:var(--c-ink-2);">(${item.count} itens)</span>
                <span data-visual-print="1a7b70b29b99" style="font-weight:bold;color:var(--c-ok);background:var(--c-bg);padding:2px 8px;border-radius:var(--r);">${formatarDuracao(item.avg)}</span>
              </div>
            </div>
          `).join("")}
        </div>
      `;
    }
  }

  // Processar Comparativos (Produzidos vs Montados)
  const prodBySector = { "Setor 1": 0, "Setor 2": 0, "Setor 3": 0, "Setor 4": 0 };
  let prodGeral = 0;
  const prodByDay = {};

  filteredProducao.forEach(row => {
    prodGeral++;
    const sec = row.setor || "Outros";
    if (sec in prodBySector) {
      prodBySector[sec]++;
    }
    const day = row.data_fabricacao;
    if (day) {
      prodByDay[day] = (prodByDay[day] || 0) + 1;
    }
  });

  document.getElementById("miProdGeral").textContent = prodGeral;
  const elTotalProduzido = document.getElementById("miTotalProduzido");
  if (elTotalProduzido) elTotalProduzido.textContent = prodGeral;

  document.getElementById("miMontGeral").textContent = totalInspecionado;
  const elTotalInspecionado = document.getElementById("miTotalInspecionado");
  if (elTotalInspecionado) elTotalInspecionado.textContent = totalInspecionado;

  const pctGeral = prodGeral > 0 ? Math.round((totalInspecionado / prodGeral) * 100) : 0;
  document.getElementById("miPctGeral").textContent = pctGeral + "%";
  const elAtingimentoPct = document.getElementById("miAtingimentoPct");
  if (elAtingimentoPct) elAtingimentoPct.textContent = pctGeral + "%";

  const barGeral = document.getElementById("miBarGeral");
  if (barGeral) barGeral.style.width = Math.min(pctGeral, 100) + "%";

  const elProducaoDia = document.getElementById("miProducaoDia");
  const todayStr = todayYmd();
  const prodDia = miRawProducaoData.filter(row => {
    if (row.data_fabricacao !== todayStr) return false;
    if (fSetor) {
      if (fSetor === "Setores 1 e 2") {
        if (row.setor !== "Setor 1" && row.setor !== "Setor 2") return false;
      } else {
        if (row.setor !== fSetor) return false;
      }
    }
    return true;
  }).length;
  if (elProducaoDia) elProducaoDia.textContent = prodDia;

  // Detalhamento por Setor
  const sectors = ["Setor 1", "Setor 2", "Setor 3", "Setor 4"];
  const sectorsContainer = document.getElementById("miSetoresContainer");
  if (sectorsContainer) {
    sectorsContainer.innerHTML = sectors.map(s => {
      if (fSetor) {
        if (fSetor === "Setores 1 e 2") {
          if (s !== "Setor 1" && s !== "Setor 2") return "";
        } else {
          if (s !== fSetor) return "";
        }
      }
      const prod = prodBySector[s] || 0;
      const mont = bySector[s] || 0;
      const pct = prod > 0 ? Math.round((mont / prod) * 100) : 0;
      return `
        <div>
          <div style="display: flex; justify-content: space-between; font-size: 0.85rem; margin-bottom: 4px;">
            <span data-visual-print="f1ee70a69375" style="font-weight:600;color:var(--c-ink-2);">${s}</span>
            <span data-visual-print="52ffd4ac77f5" style="color:var(--c-ink-2);">Produzidos: <strong>${prod}</strong> | Montados: <strong>${mont}</strong> <span data-visual-print="a76fad1b7211" style="font-weight:bold;color:var(--c-ok);margin-left:8px;">${pct}%</span></span>
          </div>
          <div data-visual-print="5c16de0c12bc" style="background:var(--c-line);height:8px;border-radius:var(--r-sm);overflow:hidden;">
            <div data-visual-print="ac8bd312aa72" style="background:var(--c-ok);height:100%;transition:width 0.5s ease-in-out;"></div>
          </div>
        </div>
      `;
    }).join("");
  }

  renderGraficosMontagem(byDay, bySector, byMontador, prodByDay);
  renderizarTabelaMontagemPaginada();
  setSyncStatus("idle", "Indicadores atualizados.");
}

function somarDiasYmd(value, dias) {
  const date = new Date(`${value}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + dias);
  return date.toISOString().slice(0, 10);
}

function diferencaDiasYmd(inicio, fim) {
  const start = new Date(`${inicio}T12:00:00Z`).getTime();
  const end = new Date(`${fim}T12:00:00Z`).getTime();
  return Math.floor((end - start) / 86400000);
}

function dividirPeriodoYmd(inicio, fim, diasPorLote = 7) {
  if (!inicio || !fim || inicio > fim) throw new Error("Periodo selecionado invalido.");
  const lotes = [];
  let cursor = inicio;
  while (cursor <= fim) {
    const candidatoFim = somarDiasYmd(cursor, Math.max(1, diasPorLote) - 1);
    const loteFim = candidatoFim < fim ? candidatoFim : fim;
    lotes.push([cursor, loteFim]);
    cursor = somarDiasYmd(loteFim, 1);
  }
  return lotes;
}

const EXPORTACAO_MONTAGEM_PAGE_SIZE = 500;
const EXPORTACAO_MONTAGEM_MAX_PAGES = 100;
const EXPORTACAO_MONTAGEM_TIMEOUT_MS = 120000;
const EXPORTACAO_PRODUCAO_LOOKUP_SIZE = 300;

function isErroExportacaoTransitorio(error) {
  const mensagem = String(error?.message || error || "").toLowerCase();
  return error?.name === "AbortError"
    || mensagem.includes("statement timeout")
    || mensagem.includes("canceling statement")
    || mensagem.includes("57014")
    || mensagem.includes("failed to fetch")
    || mensagem.includes("network")
    || mensagem.includes("timeout")
    || /\b(429|502|503|504)\b/.test(mensagem);
}

async function executarConsultaExportacaoComTimeout(criarConsulta, timeoutMs = EXPORTACAO_MONTAGEM_TIMEOUT_MS) {
  const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
  let timer = null;
  const timeoutPromise = new Promise((resolve, reject) => {
    timer = window.setTimeout(() => {
      if (controller) controller.abort();
      const timeoutError = new Error(`Timeout do cliente apos ${Math.round(timeoutMs / 1000)} segundos.`);
      timeoutError.name = "AbortError";
      reject(timeoutError);
    }, timeoutMs);
  });

  try {
    const queryPromise = Promise.resolve(criarConsulta(controller?.signal));
    return await Promise.race([queryPromise, timeoutPromise]);
  } finally {
    if (timer) window.clearTimeout(timer);
  }
}

function criarErroLoteDiario(loteInicio, ultimoErro) {
  const error = new Error(`Lote [${loteInicio}] não pôde ser carregado`);
  error.cause = ultimoErro;
  return error;
}

async function carregarBaseExportacaoPorPeriodo({ table, select, inicio, fim, onProgress }) {
  if (!supabaseClient) throw new Error("Servidor indisponível para consultar a base de montagem.");
  if (table !== "montagem_poste") throw new Error("A exportacao por periodo aceita somente a tabela montagem_poste.");

  const lotes = dividirPeriodoYmd(inicio, fim, 7);
  let totalPaginas = 0;
  let totalLotesConsolidados = 0;
  const resultados = [];
  if (typeof onProgress === "function") onProgress(0, lotes.length);

  const carregarIntervaloUmaVez = async (loteInicio, loteFim, loteNumero, totalLotes) => {
    const rows = [];
    let paginas = 0;

    for (let pagina = 0; pagina < EXPORTACAO_MONTAGEM_MAX_PAGES; pagina++) {
      const from = pagina * EXPORTACAO_MONTAGEM_PAGE_SIZE;
      const to = pagina * EXPORTACAO_MONTAGEM_PAGE_SIZE + 499;
      const { data, error } = await executarConsultaExportacaoComTimeout(signal => {
        let query = supabaseClient
          .from(table)
          .select(select)
          .gte("data_fabricacao", loteInicio)
          .lte("data_fabricacao", loteFim)
          .order("id", { ascending: true })
          .range(from, to);
        if (signal && typeof query.abortSignal === "function") query = query.abortSignal(signal);
        return query;
      });
      if (error) throw error;

      const paginaRows = Array.isArray(data) ? data : [];
      rows.push(...paginaRows);
      paginas++;
      console.log(`[export] montagem lote ${loteNumero}/${totalLotes} [${loteInicio}→${loteFim}] página ${pagina + 1}/? — ${paginaRows.length} linhas OK`);

      if (paginaRows.length < EXPORTACAO_MONTAGEM_PAGE_SIZE) return { rows, paginas, lotesConsolidados: 1 };
      if (pagina === EXPORTACAO_MONTAGEM_MAX_PAGES - 1) {
        const limiteError = new Error(`Intervalo [${loteInicio} a ${loteFim}] excedeu 50.000 linhas, subdivida o período`);
        limiteError.code = "EXPORT_INTERVAL_LIMIT";
        throw limiteError;
      }
    }

    throw new Error(`Intervalo [${loteInicio} a ${loteFim}] excedeu 50.000 linhas, subdivida o período`);
  };

  const carregarIntervalo = async (loteInicio, loteFim, loteNumero, totalLotes) => {
    let ultimoErro = null;
    for (let tentativa = 1; tentativa <= 3; tentativa++) {
      try {
        return await carregarIntervaloUmaVez(loteInicio, loteFim, loteNumero, totalLotes);
      } catch (error) {
        ultimoErro = error;
        if (error?.code === "EXPORT_INTERVAL_LIMIT") throw error;
        if (!isErroExportacaoTransitorio(error)) throw error;
        console.warn(`[export] montagem lote ${loteNumero}/${totalLotes} [${loteInicio}→${loteFim}] tentativa ${tentativa}/3 falhou:`, error);
        if (tentativa < 3) {
          await new Promise(resolve => window.setTimeout(resolve, 750 * tentativa));
        }
      }
    }

    const totalDias = diferencaDiasYmd(loteInicio, loteFim);
    if (totalDias <= 0) throw criarErroLoteDiario(loteInicio, ultimoErro);

    const meio = somarDiasYmd(loteInicio, Math.floor(totalDias / 2));
    console.warn(`[export] montagem lote ${loteNumero}/${totalLotes} [${loteInicio}→${loteFim}] subdividido após 3 tentativas.`);
    const esquerda = await carregarIntervalo(loteInicio, meio, loteNumero, totalLotes);
    const direita = await carregarIntervalo(somarDiasYmd(meio, 1), loteFim, loteNumero, totalLotes);
    return {
      rows: esquerda.rows.concat(direita.rows),
      paginas: esquerda.paginas + direita.paginas,
      lotesConsolidados: esquerda.lotesConsolidados + direita.lotesConsolidados
    };
  };

  // Um unico worker sequencial evita concorrencia entre lotes e torna qualquer
  // falha imediatamente fatal para a exportacao inteira.
  for (let index = 0; index < lotes.length; index++) {
    const [loteInicio, loteFim] = lotes[index];
    const resultado = await carregarIntervalo(loteInicio, loteFim, index + 1, lotes.length);
    resultados.push(...resultado.rows);
    totalPaginas += resultado.paginas;
    totalLotesConsolidados += resultado.lotesConsolidados;
    console.log(`[export] montagem lote ${index + 1}/${lotes.length} total consolidado: ${resultado.rows.length} linhas`);
    if (typeof onProgress === "function") onProgress(index + 1, lotes.length);
  }

  const rowsComId = [];
  let totalIdsNulos = 0;
  resultados.forEach(row => {
    if (row?.id === null || row?.id === undefined) {
      totalIdsNulos++;
      return;
    }
    rowsComId.push(row);
  });
  if (totalIdsNulos > 0) {
    console.warn(`[export] montagem: ${totalIdsNulos} linha(s) com id nulo foram descartadas antes da deduplicação.`);
  }

  const unicos = new Map();
  rowsComId.forEach(row => unicos.set(String(row.id), row));
  const rows = [...unicos.values()].sort((a, b) => {
    const dataA = `${a.data_fabricacao || ""}|${a.id || ""}`;
    const dataB = `${b.data_fabricacao || ""}|${b.id || ""}`;
    return dataA.localeCompare(dataB, "pt-BR", { numeric: true });
  });

  console.log(`[export] montagem TOTAL: ${rows.length} linhas em ${totalLotesConsolidados} lotes / ${totalPaginas} páginas`);
  return rows;
}

async function carregarLookupProducaoPorRecordIds(montagemRows) {
  const idsDistintos = new Map();
  montagemRows.forEach(row => {
    const recordId = row?.record_id;
    if (recordId === null || recordId === undefined || String(recordId).trim() === "") return;
    idsDistintos.set(String(recordId), recordId);
  });

  const recordIds = [...idsDistintos.values()];
  const lotes = [];
  for (let index = 0; index < recordIds.length; index += EXPORTACAO_PRODUCAO_LOOKUP_SIZE) {
    lotes.push(recordIds.slice(index, index + EXPORTACAO_PRODUCAO_LOOKUP_SIZE));
  }
  console.log(`[export] lookup producao: ${recordIds.length} record_ids distintos em ${lotes.length} lotes`);

  const producaoPorId = new Map();
  for (let index = 0; index < lotes.length; index++) {
    const lote = lotes[index];
    let resposta = null;
    let ultimoErro = null;

    for (let tentativa = 1; tentativa <= 3; tentativa++) {
      try {
        resposta = await executarConsultaExportacaoComTimeout(signal => {
          let query = supabaseClient
            .from("producao")
            .select("id,codigo_poste,descricao_poste,codigo_produto")
            .in("id", lote);
          if (signal && typeof query.abortSignal === "function") query = query.abortSignal(signal);
          return query;
        });
        if (resposta.error) throw resposta.error;
        ultimoErro = null;
        break;
      } catch (error) {
        ultimoErro = error;
        console.warn(`[export] lookup producao lote ${index + 1}/${lotes.length} tentativa ${tentativa}/3 falhou:`, error);
        if (tentativa < 3) await new Promise(resolve => window.setTimeout(resolve, 750 * tentativa));
      }
    }

    if (ultimoErro || !resposta) {
      const error = new Error(`Lookup de producao lote ${index + 1}/${lotes.length} não pôde ser carregado`);
      error.cause = ultimoErro;
      throw error;
    }

    const encontrados = Array.isArray(resposta.data) ? resposta.data : [];
    encontrados.forEach(row => {
      if (row?.id !== null && row?.id !== undefined) producaoPorId.set(String(row.id), row);
    });
    console.log(`[export] lookup producao lote ${index + 1}/${lotes.length} — ${lote.length} IDs, ${encontrados.length} encontrados`);
  }

  idsDistintos.forEach((recordId, chave) => {
    if (!producaoPorId.has(chave)) {
      console.warn(`[export] lookup producao: record_id ${recordId} sem correspondente em producao.`);
    }
  });
  return producaoPorId;
}

const XLSX_MAX_CELL_TEXT_LENGTH = 32000;

function dividirTextoCelulaXlsx(value, limite = XLSX_MAX_CELL_TEXT_LENGTH) {
  if (typeof value !== "string" || value.length <= limite) return [value];
  const partes = [];
  let inicio = 0;
  while (inicio < value.length) {
    let fim = Math.min(inicio + limite, value.length);
    // Nao separar um par substituto UTF-16, usado por emojis e outros simbolos.
    if (fim < value.length) {
      const anterior = value.charCodeAt(fim - 1);
      const proximo = value.charCodeAt(fim);
      if (anterior >= 0xD800 && anterior <= 0xDBFF && proximo >= 0xDC00 && proximo <= 0xDFFF) fim--;
    }
    partes.push(value.slice(inicio, fim));
    inicio = fim;
  }
  return partes;
}

function normalizarLinhasParaLimiteCelulaXlsx(linhas, limite = XLSX_MAX_CELL_TEXT_LENGTH) {
  const colunasOriginais = [];
  const colunasVistas = new Set();
  const maxPartesPorColuna = new Map();
  let totalCelulasDivididas = 0;

  (linhas || []).forEach(linha => {
    Object.keys(linha || {}).forEach(coluna => {
      if (!colunasVistas.has(coluna)) {
        colunasVistas.add(coluna);
        colunasOriginais.push(coluna);
      }
      const partes = dividirTextoCelulaXlsx(linha[coluna], limite);
      if (partes.length > 1) totalCelulasDivididas++;
      maxPartesPorColuna.set(coluna, Math.max(maxPartesPorColuna.get(coluna) || 1, partes.length));
    });
  });

  const colunas = [];
  colunasOriginais.forEach(coluna => {
    const totalPartes = maxPartesPorColuna.get(coluna) || 1;
    for (let parte = 1; parte <= totalPartes; parte++) {
      colunas.push(parte === 1 ? coluna : `${coluna} - parte ${parte}`);
    }
  });

  const linhasNormalizadas = (linhas || []).map(linha => {
    const normalizada = {};
    colunasOriginais.forEach(coluna => {
      const partes = dividirTextoCelulaXlsx(linha?.[coluna], limite);
      const totalPartes = maxPartesPorColuna.get(coluna) || 1;
      for (let parte = 1; parte <= totalPartes; parte++) {
        const nomeColuna = parte === 1 ? coluna : `${coluna} - parte ${parte}`;
        normalizada[nomeColuna] = partes[parte - 1] ?? "";
      }
    });
    return normalizada;
  });

  return {
    linhas: linhasNormalizadas,
    colunas,
    totalCelulasDivididas,
    maximoPartes: Math.max(1, ...maxPartesPorColuna.values())
  };
}

async function salvarWorkbookXlsx(workbook, nomeArquivo) {
  const bytes = window.XLSX.write(workbook, {
    bookType: "xlsx",
    type: "array",
    compression: true
  });
  if (!bytes || !bytes.byteLength) throw new Error("A planilha foi gerada sem conteudo.");

  const mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  const blob = new Blob([bytes], { type: mime });
  baixarArquivoBlob(blob, nomeArquivo, mime);
  return blob.size;
}

function criarResumoExportacaoMontagem(montagemRows, dStart, dEnd) {
  const realizadas = montagemRows.filter(isLinhaMontagemDashboard);
  const aprovadas = realizadas.filter(row => String(row.status_montagem || "").trim().toUpperCase() === "A").length;
  const naoConformes = realizadas.filter(isLinhaDefeitoDashboard).length;
  const retrabalhos = realizadas.filter(row => isMontagemRetrabalhoStatus(row.status_montagem)).length;
  const atingimento = montagemRows.length > 0 ? (realizadas.length / montagemRows.length) * 100 : 0;
  const aprovacao = realizadas.length > 0 ? (aprovadas / realizadas.length) * 100 : 0;
  const percentual = valor => `${valor.toLocaleString("pt-BR", { minimumFractionDigits: 1, maximumFractionDigits: 1 })}%`;

  return [
    ["RELATORIO COMPLETO - DASHBOARD MONTAGEM"],
    ["Periodo", `${fmtDate(dStart)} a ${fmtDate(dEnd)}`],
    ["Gerado em", new Date().toLocaleString("pt-BR")],
    [],
    ["INDICADORES PRINCIPAIS", "VALOR", "MEMORIA DE CALCULO"],
    ["Programado", montagemRows.length, "Quantidade total de montagens no periodo"],
    ["Realizado", realizadas.length, "Quantidade de montagens concluidas"],
    ["Atingimento", percentual(atingimento), "Realizado / Programado x 100"],
    [],
    ["INDICADORES SECUNDARIOS", "VALOR", "MEMORIA DE CALCULO"],
    ["Aprovados", aprovadas, "Montagens concluidas com status Aprovado"],
    ["Taxa de aprovacao", percentual(aprovacao), "Aprovados / Realizado x 100"],
    ["Nao conformes", naoConformes, "Status de reprovacao, retrabalho ou checklist com item nao conforme"],
    ["Retrabalhos", retrabalhos, "Montagens com status de retrabalho"],
    [],
    ["BASES EXPORTADAS", "REGISTROS"],
    ["Base Montagem", montagemRows.length]
  ];
}

async function exportarMontagemIndicadoresXlsx() {
  if (!window.XLSX?.utils) {
    showMsgBox("Biblioteca XLSX indisponivel. Verifique a conexao e tente novamente.", "error");
    return;
  }

  const dStart = document.getElementById("miDataInicio")?.value || todayYmd();
  const dEnd = document.getElementById("miDataFim")?.value || todayYmd();
  if (dStart > dEnd) {
    showMsgBox("O inicio do periodo nao pode ser posterior ao fim.", "error");
    return;
  }

  const nomeArquivo = `base_montagem_${dStart}_a_${dEnd}.xlsx`;

  const button = document.getElementById("miBtnExportarXlsx");
  const label = button?.textContent || "Exportar XLSX";
  if (button) {
    button.disabled = true;
    button.textContent = "Exportando base...";
  }
  try {
    const montagemRows = (await carregarBaseExportacaoPorPeriodo({
      table: "montagem_poste",
      select: DASHBOARD_MONTAGEM_SELECT,
      inicio: dStart,
      fim: dEnd,
      onProgress: (concluidos, total) => {
        if (button && total > 0) button.textContent = `Carregando montagem ${concluidos}/${total}...`;
      }
    })).filter(row => !isHistoricoReprovacao(row));

    if (!montagemRows.length) throw new Error("Nenhum registro de montagem encontrado no periodo selecionado.");
    if (button) button.textContent = "Consultando produtos...";
    const producaoPorId = await carregarLookupProducaoPorRecordIds(montagemRows);
    const linhasMontagem = montagemRows.map(row => {
      const producao = producaoPorId.get(String(row.record_id || "")) || {};
      const inicio = row.inicio_inspecao_montagem || "";
      const fim = row.finalizado_em || "";
      const durMs = inicio && fim ? (new Date(fim) - new Date(inicio)) : null;
      const checklist = typeof row.checklists === "string" ? row.checklists : JSON.stringify(row.checklists || {});
      return {
        "ID montagem": row.id || "",
        "ID producao": row.record_id || "",
        "Data da producao": fmtDate(row.data_fabricacao || ""),
        "Inicio da montagem": formatarDataHoraMontagemXlsx(inicio),
        "Fim da montagem": formatarDataHoraMontagemXlsx(fim),
        "Tempo de montagem": formatarDuracao(durMs),
        "Setor": row.setor || "",
        "Forma": row.forma_numero || "",
        "Modelo": row.modelo || producao.modelo || "",
        "Codigo do poste": producao.codigo_poste || "",
        "Descricao do poste": producao.descricao_poste || "",
        "Codigo do produto": producao.codigo_produto || "",
        "Status montagem": row.status_montagem || "",
        "Descricao status": getMiStatusMeta(row.status_montagem || "").label,
        "Motivo da recusa": row.motivo_recusa || "",
        "Etapa": row.etapa || "",
        "Banco": row.banco || "",
        "Montador": row.montador_nome || "",
        "Observacoes": row.observacoes_montagem || "",
        "Checklist JSON": checklist,
        "Criado em": formatarDataHoraMontagemXlsx(row.created_at || ""),
        "Atualizado em": formatarDataHoraMontagemXlsx(row.updated_at || "")
      };
    });
    console.log(`[export] TOTAL final: ${linhasMontagem.length} linhas prontas para o workbook`);
    const baseMontagemXlsx = normalizarLinhasParaLimiteCelulaXlsx(linhasMontagem);
    if (baseMontagemXlsx.totalCelulasDivididas > 0) {
      console.warn(`[export] XLSX: ${baseMontagemXlsx.totalCelulasDivididas} célula(s) longa(s) divididas em até ${baseMontagemXlsx.maximoPartes} partes, sem truncamento.`);
    }

    const xlsx = window.XLSX;
    const wb = xlsx.utils.book_new();
    const wsResumo = xlsx.utils.aoa_to_sheet(criarResumoExportacaoMontagem(montagemRows, dStart, dEnd));
    wsResumo["!cols"] = [{ wch: 30 }, { wch: 22 }, { wch: 62 }];
    xlsx.utils.book_append_sheet(wb, wsResumo, "Resumo");
    const wsMontagem = xlsx.utils.json_to_sheet(baseMontagemXlsx.linhas);
    wsMontagem["!cols"] = baseMontagemXlsx.colunas.map(key => ({ wch: Math.min(55, Math.max(14, key.length + 3)) }));
    if (wsMontagem["!ref"]) wsMontagem["!autofilter"] = { ref: wsMontagem["!ref"] };
    xlsx.utils.book_append_sheet(wb, wsMontagem, "Base Montagem");
    await salvarWorkbookXlsx(wb, nomeArquivo);
    showMsgBox(`${montagemRows.length} registro(s) de montagem exportados.`, "success");
  } catch (err) {
    const mensagem = String(err?.message || err || "erro desconhecido");
    console.error("[export] Erro ao exportar base de montagem:", err?.stack || err, err);
    showMsgBox(`Nao foi possivel exportar a base: ${escapeHtml(mensagem)}`, "error");
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = label;
    }
  }
}

function obterOcorrenciasDefeitosLinha(row, options = {}) {
  const checklists = row.checklists || {};
  let parsed = checklists;
  if (typeof checklists === "string") {
    try {
      parsed = JSON.parse(checklists);
    } catch (e) {
      parsed = {};
    }
  }

  const sections = options.visualOnly ? obterChecklistVisualSectionsLinha(row) : obterChecklistSectionsLinha(row);

  const rejeitados = [];
  sections.forEach(sec => {
    const secRes = parsed[sec.id];
    if (secRes && typeof secRes === "object") {
      sec.itens.forEach(item => {
        if (secRes[item.id] === "nao") {
          rejeitados.push({ codigo: item.codigoFalha || "", descricao: item.texto, secao_id: sec.id, item_id: item.id });
        }
      });
    }
  });
  return rejeitados;
}

function obterItensRejeitadosLinha(row, options = {}) {
  return obterOcorrenciasDefeitosLinha(row, options).map(item => item.descricao);
}

function obterOcorrenciasDefeitosRegistradosLinha(row) {
  const rejeitados = obterOcorrenciasDefeitosLinha(row);
  if (rejeitados.length) return rejeitados;
  const status = String(row?.status_montagem || "").trim().toUpperCase();
  if (!["R", "RR", "REPROVADO", "RETRABALHO"].includes(status)) return [];
  const motivo = String(row?.motivo_recusa || "").trim();
  if (!motivo) return [{ codigo: "", descricao: "Reprovação sem defeito detalhado" }];
  return motivo.split(",").map(value => {
    const codigo = value.trim();
    const descricao = getDefeitoInfo(codigo).descricao;
    return { codigo, descricao: descricao === "Não especificado" ? codigo : descricao };
  }).filter(item => item.descricao);
}

function obterDefeitosRegistradosLinha(row) {
  return obterOcorrenciasDefeitosRegistradosLinha(row).map(item => item.descricao);
}

function renderizarTabelaMontagemPaginada() {
  const tbody = document.getElementById("miTabelaBody");
  if (!tbody) return;

  const totalRegistros = miFilteredMontagemData.length;
  document.getElementById("miTabelaTotal").textContent = totalRegistros;
  document.getElementById("miPaginacaoTotal").textContent = totalRegistros;

  if (totalRegistros === 0) {
    tbody.innerHTML = '<tr><td colspan="9" data-visual-print="d8a6f4e8acd6" style="text-align:center;color:var(--c-ink-2);padding:25px;">Nenhum registro encontrado para os filtros selecionados.</td></tr>';
    const cardsContainer = document.getElementById("miCardsContainer");
    if (cardsContainer) cardsContainer.innerHTML = '<div data-visual-print="d8a6f4e8acd6" style="text-align:center;color:var(--c-ink-2);padding:25px;">Nenhum registro encontrado para os filtros selecionados.</div>';
    document.getElementById("miPaginacaoDe").textContent = "0";
    document.getElementById("miPaginacaoA").textContent = "0";
    document.getElementById("miPaginacaoBotoes").innerHTML = "";
    return;
  }

  // Ordenação
  const col = miOrdenacaoColuna;
  const asc = miOrdenacaoAsc;

  const sortedData = [...miFilteredMontagemData].sort((a, b) => {
    let valA = a[col] || "";
    let valB = b[col] || "";

    if (col === "finalizado_em" || col === "inicio_inspecao_montagem" || col === "data_fabricacao") {
      valA = valA ? new Date(valA).getTime() : 0;
      valB = valB ? new Date(valB).getTime() : 0;
    } else if (col === "tempo_inspecao") {
      valA = a.finalizado_em && a.inicio_inspecao_montagem ? (new Date(a.finalizado_em) - new Date(a.inicio_inspecao_montagem)) : 0;
      valB = b.finalizado_em && b.inicio_inspecao_montagem ? (new Date(b.finalizado_em) - new Date(b.inicio_inspecao_montagem)) : 0;
    } else {
      valA = String(valA).toLowerCase();
      valB = String(valB).toLowerCase();
    }

    if (valA < valB) return asc ? -1 : 1;
    if (valA > valB) return asc ? 1 : -1;
    return 0;
  });

  // Paginação
  const totalPaginas = Math.ceil(totalRegistros / miLinhasPorPagina);
  if (miPaginaAtual > totalPaginas) miPaginaAtual = totalPaginas || 1;
  if (miPaginaAtual < 1) miPaginaAtual = 1;

  const inicioIdx = (miPaginaAtual - 1) * miLinhasPorPagina;
  const fimIdx = Math.min(inicioIdx + miLinhasPorPagina, totalRegistros);
  const paginaDados = sortedData.slice(inicioIdx, fimIdx);

  document.getElementById("miPaginacaoDe").textContent = inicioIdx + 1;
  document.getElementById("miPaginacaoA").textContent = fimIdx;

  // Renderizar Linhas (Tabela - Desktop)
  tbody.innerHTML = paginaDados.map(row => {
    const dataFab = row.data_fabricacao ? row.data_fabricacao.split("T")[0].split("-").reverse().join("/") : "N/A";

    const formatTimeShort = (isoStr) => {
      if (!isoStr) return "N/A";
      const d = new Date(isoStr);
      if (isNaN(d.getTime())) return isoStr;
      return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    };

    const inicio = formatTimeShort(row.inicio_inspecao_montagem);
    const fim = formatTimeShort(row.finalizado_em);

    const durMs = row.finalizado_em && row.inicio_inspecao_montagem ? (new Date(row.finalizado_em) - new Date(row.inicio_inspecao_montagem)) : null;
    const tempoText = formatarDuracao(durMs);

    let statusHtml = '<span data-visual-print="d346b5f71fb8" style="color:var(--c-ink-2);font-weight:bold;">Em Andamento</span>';
    if (row.status_montagem === "A") {
      statusHtml = `<span onclick="abrirVisualizacaoChecklist('${row.id}')" data-visual-print="ccc60c1c8285" style="color:var(--c-ok);font-weight:bold;background:var(--c-line);padding:4px 8px;border-radius:var(--r);font-size:0.8rem;cursor:pointer;text-decoration:underline;">Aprovado</span>`;
    } else if (row.status_montagem === "RR") {
      statusHtml = `<span onclick="abrirVisualizacaoChecklist('${row.id}')" data-visual-print="6cbe829f0e61" style="color:var(--c-orange);font-weight:bold;background:var(--c-line-2);padding:4px 8px;border-radius:var(--r);font-size:0.8rem;cursor:pointer;text-decoration:underline;">Aprovado e Retrabalhado</span>`;
    } else if (row.status_montagem === "R") {
      statusHtml = `<span onclick="abrirVisualizacaoChecklist('${row.id}')" data-visual-print="5cbe74869750" style="color:var(--c-crit);font-weight:bold;background:var(--c-line-2);padding:4px 8px;border-radius:var(--r);font-size:0.8rem;cursor:pointer;text-decoration:underline;">Reprovado</span>`;
    }

    const rejeitados = obterItensRejeitadosLinha(row);
    let rejeitadosHtml = "";
    if (rejeitados.length > 0) {
      rejeitadosHtml = `
        <div style="display: inline-flex; align-items: center; gap: 8px; justify-content: center; text-align: left;">
          <span data-visual-print="20bbd063b2fd" style="display:inline-block;width:10px;height:10px;border-radius:50%;background-color:var(--c-orange);box-shadow:none;flex-shrink:0;" title="Possui itens rejeitados"></span>
          <span data-visual-print="335717d31425" style="font-size:0.78rem;color:var(--c-crit);background:var(--c-line-2);padding:2px 6px;border-radius:var(--r-sm);max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${rejeitados.join(', ')}">${rejeitados.join(', ')}</span>
        </div>
      `;
    } else {
      rejeitadosHtml = `
        <div style="display: inline-flex; align-items: center; gap: 8px; justify-content: center;">
          <span data-visual-print="64ecd559eded" style="display:inline-block;width:10px;height:10px;border-radius:50%;background-color:var(--c-ok);box-shadow:none;flex-shrink:0;" title="Todos os itens aprovados"></span>
          <span data-visual-print="1989786dc062" style="font-size:0.78rem;color:var(--c-ink-2);">Tudo OK</span>
        </div>
      `;
    }

    return `
      <tr data-visual-print="049a05aa5533" style="border-bottom:1px solid var(--c-bg);">
        <td style="padding: 10px; text-align: center; max-width: 90px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${dataFab}</td>
        <td style="padding: 10px; text-align: center;">${row.setor || ""}</td>
        <td style="padding: 10px; text-align: center; max-width: 70px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><strong>${row.forma_numero || ""}</strong></td>
        <td style="padding: 10px; text-align: center;">${row.modelo || ""}</td>
        <td data-visual-print="6c77ef02d775" style="padding:10px;text-align:center;font-size:0.8rem;color:var(--c-ink-2);">${inicio}</td>
        <td data-visual-print="6c77ef02d775" style="padding:10px;text-align:center;font-size:0.8rem;color:var(--c-ink-2);">${fim}</td>
        <td style="padding: 10px; text-align: center; font-size: 0.85rem; font-weight: 600;">${tempoText}</td>
        <td style="padding: 10px; text-align: center;">${statusHtml}</td>
        <td style="padding: 10px; text-align: center; font-size: 0.85rem;">${row.montador_nome || ""}</td>
      </tr>
    `;
  }).join("");

  // Renderizar Cards (Mobile)
  const cardsContainer = document.getElementById("miCardsContainer");
  if (cardsContainer) {
    cardsContainer.innerHTML = paginaDados.map(row => {
      const dataFab = row.data_fabricacao ? row.data_fabricacao.split("T")[0].split("-").reverse().join("/") : "N/A";

      const formatTimeShort = (isoStr) => {
        if (!isoStr) return "N/A";
        const d = new Date(isoStr);
        if (isNaN(d.getTime())) return isoStr;
        return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
      };

      const inicio = formatTimeShort(row.inicio_inspecao_montagem);
      const fim = formatTimeShort(row.finalizado_em);

      const durMs = row.finalizado_em && row.inicio_inspecao_montagem ? (new Date(row.finalizado_em) - new Date(row.inicio_inspecao_montagem)) : null;
      const tempoText = formatarDuracao(durMs);

      let statusHtml = '<span data-visual-print="d346b5f71fb8" style="color:var(--c-ink-2);font-weight:bold;">Em Andamento</span>';
      if (row.status_montagem === "A") {
        statusHtml = `<span onclick="abrirVisualizacaoChecklist('${row.id}')" data-visual-print="ccc60c1c8285" style="color:var(--c-ok);font-weight:bold;background:var(--c-line);padding:4px 8px;border-radius:var(--r);font-size:0.8rem;cursor:pointer;text-decoration:underline;">Aprovado</span>`;
      } else if (row.status_montagem === "RR") {
        statusHtml = `<span onclick="abrirVisualizacaoChecklist('${row.id}')" data-visual-print="6cbe829f0e61" style="color:var(--c-orange);font-weight:bold;background:var(--c-line-2);padding:4px 8px;border-radius:var(--r);font-size:0.8rem;cursor:pointer;text-decoration:underline;">Aprovado e Retrabalhado</span>`;
      } else if (row.status_montagem === "R") {
        statusHtml = `<span onclick="abrirVisualizacaoChecklist('${row.id}')" data-visual-print="5cbe74869750" style="color:var(--c-crit);font-weight:bold;background:var(--c-line-2);padding:4px 8px;border-radius:var(--r);font-size:0.8rem;cursor:pointer;text-decoration:underline;">Reprovado</span>`;
      }

      const rejeitados = obterItensRejeitadosLinha(row);
      let rejeitadosHtml = "";
      if (rejeitados.length > 0) {
        rejeitadosHtml = `
          <div style="display: inline-flex; align-items: center; gap: 8px; text-align: left; vertical-align: middle;">
            <span data-visual-print="20bbd063b2fd" style="display:inline-block;width:10px;height:10px;border-radius:50%;background-color:var(--c-orange);box-shadow:none;flex-shrink:0;" title="Possui itens rejeitados"></span>
            <span data-visual-print="335717d31425" style="font-size:0.78rem;color:var(--c-crit);background:var(--c-line-2);padding:2px 6px;border-radius:var(--r-sm);max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${rejeitados.join(', ')}">${rejeitados.join(', ')}</span>
          </div>
        `;
      } else {
        rejeitadosHtml = `
          <div style="display: inline-flex; align-items: center; gap: 8px; vertical-align: middle;">
            <span data-visual-print="64ecd559eded" style="display:inline-block;width:10px;height:10px;border-radius:50%;background-color:var(--c-ok);box-shadow:none;flex-shrink:0;" title="Todos os itens aprovados"></span>
            <span data-visual-print="1989786dc062" style="font-size:0.78rem;color:var(--c-ink-2);">Tudo OK</span>
          </div>
        `;
      }

      return `
        <div class="mi-mobile-card">
          <div class="mi-mobile-card-header">
            <div><strong>Forma ${row.forma_numero || ""}</strong> (${row.setor || ""}) - <span data-visual-print="bc143bb9068c" style="color:var(--c-ink-2);font-weight:600;">${row.modelo || ""}</span></div>
            <div>${statusHtml}</div>
          </div>
          <div class="mi-mobile-card-body">
            <div><strong>Data Prod:</strong> ${dataFab}</div>
            <div><strong>Duração:</strong> ${tempoText}</div>
            <div><strong>Período:</strong> ${inicio} - ${fim}</div>
            <div><strong>Montador:</strong> ${row.montador_nome || ""}</div>
          </div>
        </div>
      `;
    }).join("");
  }

  // Atualizar Ícones de Ordenação
  const colunas = ["data_fabricacao", "setor", "forma_numero", "modelo", "inicio_inspecao_montagem", "finalizado_em", "tempo_inspecao", "status_montagem", "montador_nome"];
  colunas.forEach(c => {
    const elIcon = document.getElementById("sort_icon_" + c);
    if (elIcon) {
      if (miOrdenacaoColuna === c) {
        elIcon.textContent = miOrdenacaoAsc ? " ▲" : " ▼";
        elIcon.style.color = "var(--c-ink-2)";
      } else {
        elIcon.textContent = "";
      }
    }
  });

  // Renderizar Botões de Paginação
  const pagContainer = document.getElementById("miPaginacaoBotoes");
  if (!pagContainer) return;

  let buttonsHtml = "";
  buttonsHtml += `
    <button class="btn" style="padding: 5px 10px; font-size: 0.8rem;" ${miPaginaAtual === 1 ? "disabled" : ""} onclick="mudarMiPagina(${miPaginaAtual - 1})">
      Anterior
    </button>
  `;

  const maxButtons = 5;
  let startPage = Math.max(1, miPaginaAtual - Math.floor(maxButtons / 2));
  let endPage = Math.min(totalPaginas, startPage + maxButtons - 1);
  if (endPage - startPage + 1 < maxButtons) {
    startPage = Math.max(1, endPage - maxButtons + 1);
  }

  for (let p = startPage; p <= endPage; p++) {
    buttonsHtml += `
      <button class="btn ${miPaginaAtual === p ? "primary" : ""}" style="padding: 5px 10px; font-size: 0.8rem; min-width: 30px;" onclick="mudarMiPagina(${p})">
        ${p}
      </button>
    `;
  }

  buttonsHtml += `
    <button class="btn" style="padding: 5px 10px; font-size: 0.8rem;" ${miPaginaAtual === totalPaginas ? "disabled" : ""} onclick="mudarMiPagina(${miPaginaAtual + 1})">
      Próximo
    </button>
  `;

  pagContainer.innerHTML = buttonsHtml;
}

window.mudarMiPagina = function(p) {
  miPaginaAtual = p;
  renderizarTabelaMontagemPaginada();
};

window.ordenarMiTabela = function(coluna) {
  if (miOrdenacaoColuna === coluna) {
    miOrdenacaoAsc = !miOrdenacaoAsc;
  } else {
    miOrdenacaoColuna = coluna;
    miOrdenacaoAsc = true;
  }
  miPaginaAtual = 1;
  renderizarTabelaMontagemPaginada();
};

function renderGraficosMontagem(byDay, bySector, byMontador, prodByDay = {}) {
  miUltimosGraficos = { byDay, bySector, byMontador, prodByDay };
  const continuousMontagem = document.body.classList.contains("mode-montagem-indicadores");
  const shouldRenderProducao = continuousMontagem || miAbaAtiva === "producao" || window.innerWidth >= 768;
  const shouldRenderQualidade = continuousMontagem || miAbaAtiva === "qualidade" || window.innerWidth >= 768;
  if (!shouldRenderProducao && chartMiPorDiaInstance) {
    chartMiPorDiaInstance.destroy();
    chartMiPorDiaInstance = null;
  }
  if (!shouldRenderQualidade && chartMiPorSetorInstance) {
    chartMiPorSetorInstance.destroy();
    chartMiPorSetorInstance = null;
  }
  if (!shouldRenderQualidade && chartMiPorMontadorInstance) {
    chartMiPorMontadorInstance.destroy();
    chartMiPorMontadorInstance = null;
  }

  const isMobile = window.innerWidth < 768;
  const labelFontSize = isMobile ? 12 : 16;
  const legendBoxWidth = isMobile ? 10 : 15;

  // Por Dia
  const unionSet = new Set([
    ...Object.keys(byDay),
    ...Object.keys(prodByDay)
  ]);
  unionSet.delete("Desconhecido");
  unionSet.delete("");
  const dias = Array.from(unionSet).sort();

  const dataDiaProduzidos = dias.map(d => prodByDay[d] || 0);
  const dataDiaAprovados = dias.map(d => byDay[d]?.aprovados || 0);
  const dataDiaRecusados = dias.map(d => byDay[d]?.recusados || 0);
  const diasFormatados = dias.map(d => d.split("-").reverse().join("/"));

  const ctxDia = document.getElementById("chartMiPorDia")?.getContext("2d");
  if (ctxDia && shouldRenderProducao) {
    if (chartMiPorDiaInstance) chartMiPorDiaInstance.destroy();
    chartMiPorDiaInstance = new Chart(ctxDia, {
      type: "bar",
      data: {
        labels: diasFormatados,
        datasets: [
          { label: "Produzidos", data: dataDiaProduzidos, backgroundColor: "#3b82f6", stack: "Stack 0" },
          { label: "Aprovados", data: dataDiaAprovados, backgroundColor: "#10b981", stack: "Stack 1" },
          { label: "Recusados", data: dataDiaRecusados, backgroundColor: "#ef4444", stack: "Stack 1" }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          intersect: false,
          mode: 'index'
        },
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: legendBoxWidth,
              font: { size: labelFontSize }
            }
          }
        },
        scales: {
          x: {
            stacked: true,
            ticks: {
              font: { size: labelFontSize },
              maxRotation: 0,
              autoSkip: true,
              maxTicksLimit: isMobile ? 4 : 10
            }
          },
          y: {
            stacked: true,
            beginAtZero: true,
            ticks: { font: { size: labelFontSize } }
          }
        }
      }
    });
  }

  // Por Setor
  const setores = Object.keys(bySector).sort();
  const dataSetor = setores.map(s => bySector[s]);
  const ctxSetor = document.getElementById("chartMiPorSetor")?.getContext("2d");
  if (ctxSetor && shouldRenderQualidade) {
    if (chartMiPorSetorInstance) chartMiPorSetorInstance.destroy();
    chartMiPorSetorInstance = new Chart(ctxSetor, {
      type: "doughnut",
      data: {
        labels: setores,
        datasets: [{ data: dataSetor, backgroundColor: ["#3b82f6", "#10b981", "#f59e0b", "#8b5cf6", "#64748b"] }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: legendBoxWidth,
              font: { size: labelFontSize }
            }
          }
        }
      }
    });
  }

  // Por Montador
  const montadores = Object.keys(byMontador).sort((a,b) => byMontador[b] - byMontador[a]);
  const dataMontador = montadores.map(m => byMontador[m]);
  const ctxMontador = document.getElementById("chartMiPorMontador")?.getContext("2d");
  if (ctxMontador && shouldRenderQualidade) {
    if (chartMiPorMontadorInstance) chartMiPorMontadorInstance.destroy();
    chartMiPorMontadorInstance = new Chart(ctxMontador, {
      type: "bar",
      data: {
        labels: montadores,
        datasets: [{ label: "Postes Inspecionados", data: dataMontador, backgroundColor: "#6366f1" }]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          intersect: false,
          mode: 'nearest'
        },
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: { ticks: { font: { size: labelFontSize } } },
          y: { ticks: { font: { size: labelFontSize } } }
        }
      }
    });
  }
}

window.abrirFotoVisualizacao = function(src) {
  if (!src) return;
  document.querySelector(".vc-photo-lightbox")?.remove();
  const overlay = document.createElement("div");
  overlay.className = "vc-photo-lightbox";
  const img = document.createElement("img");
  img.src = src;
  img.alt = "Foto da inspeção ampliada";
  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "Fechar ×";
  overlay.append(img, close);
  overlay.addEventListener("click", (event) => { if (event.target !== img) overlay.remove(); });
  document.body.appendChild(overlay);
};

window.abrirVisualizacaoChecklist = async function(idOrRow) {
  let row;
  if (typeof idOrRow === "object" && idOrRow !== null) {
    row = idOrRow;
  } else {
    row = (typeof miRawMontagemData !== "undefined" && Array.isArray(miRawMontagemData))
      ? miRawMontagemData.find(r => String(r.id) === String(idOrRow))
      : null;
  }
  if (!row) return;

  // A tela usa uma consulta leve. Os campos grandes do checklist sao buscados
  // apenas quando o usuario abre um registro, preservando o detalhe completo.
  if (!Object.prototype.hasOwnProperty.call(row, "checklists") && supabaseClient && row.id) {
    try {
      const { data, error } = await supabaseClient
        .from("montagem_poste")
        .select(DASHBOARD_MONTAGEM_SELECT)
        .eq("id", row.id)
        .maybeSingle();
      if (error) throw error;
      if (data) row = data;
    } catch (err) {
      console.warn("Nao foi possivel carregar os detalhes do checklist:", err);
      showMsgBox("Nao foi possivel abrir os detalhes completos deste checklist.", "error");
      return;
    }
  }

  // Normalizar propriedades para suportar tanto snake_case do Supabase quanto camelCase do frontend local
  const normRow = {
    id: row.id || row.key || "",
    forma_numero: row.forma_numero || row.formaNumero || "",
    modelo: row.modelo || "",
    montador_nome: row.montador_nome || row.montadorNome || "",
    data_fabricacao: row.data_fabricacao || row.dataFabricacao || "",
    inicio_inspecao_montagem: row.inicio_inspecao_montagem || row.inicioInspecaoMontagem || "",
    finalizado_em: row.finalizado_em || row.finalizadoEm || "",
    status_montagem: row.status_montagem || row.statusMontagem || "",
    checklists: row.checklists || {},
    observacoes_montagem: row.observacoes_montagem || row.observacoesMontagem || "",
    motivo_recusa: row.motivo_recusa || row.motivoRecusa || "",
    etapa: row.etapa || ""
  };

  const findProducaoConcretagem = () => {
    if (!Array.isArray(miRawProducaoData)) return null;
    const dataFab = String(normRow.data_fabricacao || "").split("T")[0];
    const setor = String(row.setor || "").trim();
    const forma = normalizeForma(normRow.forma_numero || row.forma || row.forma_numero || row.formaNumero || "");
    return miRawProducaoData.find((prod) => {
      const prodData = String(prod.data_fabricacao || prod.dataFabricacao || "").split("T")[0];
      const prodSetor = String(prod.setor || "").trim();
      const prodForma = normalizeForma(prod.forma || prod.forma_numero || prod.formaNumero || "");
      return prodData === dataFab && prodSetor === setor && prodForma === forma;
    }) || null;
  };

  const producaoConcretagem = findProducaoConcretagem();
  const dataHoraConcretagem = producaoConcretagem?.data_hora || producaoConcretagem?.dataHora || producaoConcretagem?.created_at || "";
  const tipoConcreto = producaoConcretagem?.tipo_concreto || producaoConcretagem?.tipoConcreto || producaoConcretagem?.concretoTipo || "";

  const modal = document.getElementById("visualizarChecklistModal");
  if (!modal) return;

  document.getElementById("vcMetaForma").textContent = normRow.forma_numero || "-";
  document.getElementById("vcMetaModelo").textContent = normRow.modelo || "-";
  document.getElementById("vcMetaMontador").textContent = normRow.montador_nome || "-";
  document.getElementById("vcMetaData").textContent = normRow.data_fabricacao ? String(normRow.data_fabricacao).split("T")[0].split("-").reverse().join("/") : "-";
  document.getElementById("vcMetaConcretagem").textContent = dataHoraConcretagem ? formatDateTime(dataHoraConcretagem) : "-";
  document.getElementById("vcMetaTipoConcreto").textContent = tipoConcreto || "-";

  const formatTimeShort = (isoStr) => {
    if (!isoStr) return "N/A";
    const d = new Date(isoStr);
    if (isNaN(d.getTime())) return isoStr;
    return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  };

  document.getElementById("vcMetaInicio").textContent = formatTimeShort(normRow.inicio_inspecao_montagem);
  document.getElementById("vcMetaFim").textContent = formatTimeShort(normRow.finalizado_em);

  const fallbackDia = normRow.finalizado_em ? String(normRow.finalizado_em).split("T")[0].split("-").reverse().join("/") : "-";
  const fallbackHora = normRow.finalizado_em ? formatTimeShort(normRow.finalizado_em) : "-";

  let checklists = normRow.checklists || {};
  if (typeof checklists === "string") {
    try {
      checklists = JSON.parse(checklists);
    } catch (e) {
      checklists = {};
    }
  }

  const diaInspecao = checklists.dia_inspecao || fallbackDia;
  const horaDispositivo = checklists.horario_dispositivo || fallbackHora;

  document.getElementById("vcMetaDiaInspecao").textContent = diaInspecao;
  document.getElementById("vcMetaHoraDispositivo").textContent = horaDispositivo;

  let geoText = "Não informada";
  const geo = checklists.geolocation;
  if (geo) {
    if (geo.error) {
      geoText = `<span data-visual-print="55a1ddb51f47" style="color:var(--c-orange);font-weight:500;">Indisponível (${geo.error})</span>`;
    } else if (geo.latitude !== undefined && geo.longitude !== undefined) {
      const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${geo.latitude},${geo.longitude}`;
      const accuracyStr = geo.accuracy ? ` (±${geo.accuracy.toFixed(1)}m)` : "";
      geoText = `<a href="${mapsUrl}" target="_blank" data-visual-print="c56a160edea3" style="color:var(--c-ink-2);text-decoration:underline;font-weight:700;display:inline-flex;align-items:center;gap:4px;"> Ver no Mapa (Lat: ${geo.latitude.toFixed(6)}, Lng: ${geo.longitude.toFixed(6)})${accuracyStr}</a>`;
    }
  }
  document.getElementById("vcMetaGeolocalizacao").innerHTML = geoText;

  let statusText = "Em Andamento";
  let statusColor = "#64748b";
  if (normRow.status_montagem === "A") {
    statusText = "Aprovado";
    statusColor = "#16a34a";
  } else if (normRow.status_montagem === "RR") {
    statusText = "Retrabalhado e aprovado";
    statusColor = "#d97706";
  } else if (normRow.status_montagem === "R") {
    statusText = normRow.checklists?.__segunda_inspecao?.resultado === "SEGREGADO" ? "Perda do poste" : "Reprovado · 2ª inspeção pendente";
    statusColor = "#dc2626";
  }
  const elStatus = document.getElementById("vcMetaStatus");
  elStatus.textContent = statusText;
  elStatus.style.color = statusColor;
  modal.querySelector("#unificado-report-second")?.remove();
  const secondMode = normRow.etapa === "INSPECAO" ? "INSPECAO" : "MONTAGEM_POSTES";
  if (normRow.status_montagem === "R" && normRow.finalizado_em
      && !normRow.checklists?.__segunda_inspecao
      && normRow.etapa !== ETAPA_HISTORICO_REPROVACAO
      && row.record_id && row.setor && isModeAllowed(secondMode)) {
    const button = document.createElement("button");
    button.id = "unificado-report-second";
    button.type = "button";
    button.textContent = "Iniciar segunda inspeção (retrabalho)";
    button.addEventListener("click", async () => {
      button.disabled = true;
      const posteBase = {
        recordId: row.record_id,
        dataFabricacao: normRow.data_fabricacao,
        setor: row.setor,
        formaNumero: normRow.forma_numero,
        modelo: normRow.modelo,
        codigoPoste: row.codigo_poste || producaoConcretagem?.codigo_poste || "",
        descricaoPoste: row.descricao_poste || producaoConcretagem?.descricao_poste || "",
        codigoProduto: row.codigo_produto || producaoConcretagem?.codigo_produto || "",
        segundaInspecao: true
      };
      modal.classList.remove("modal-visible");
      try {
        if (secondMode === "INSPECAO") await openInspecaoPosteDetalhe(posteBase);
        else await openMontagemPosteDetalhe(posteBase);
      } catch (error) {
        modal.classList.add("modal-visible");
        button.disabled = false;
        showMsgBox("Não foi possível abrir a segunda inspeção. Tente novamente.", "error");
      }
    });
    elStatus.parentElement.appendChild(button);
  }

  // Render content
  const container = document.getElementById("vcChecklistContent");
  container.innerHTML = "";

  const sections = normRow.etapa === "INSPECAO" ? getInspecaoChecklistSections(normRow.modelo || "") : getMontagemChecklistSections(normRow.modelo || "");

  sections.forEach(section => {
    const secDiv = document.createElement("div");
    secDiv.style.marginBottom = "20px";
    secDiv.innerHTML = `
      <div data-visual-print="b8dbf4c0e87e" style="font-weight:bold;background:var(--c-line);padding:6px 10px;border-radius:var(--r);margin-bottom:8px;color:var(--c-navy);">
        ${section.titulo}
      </div>
    `;

    const listDiv = document.createElement("div");
    listDiv.style.display = "flex";
    listDiv.style.flexDirection = "column";
    listDiv.style.gap = "8px";

    section.itens.forEach(item => {
      const resp = checklists[section.id]?.[item.id] || "";
      const photoBase64 = checklists[section.id]?.[item.id + "_photo"] || "";

      let badge = '<span data-visual-print="dc66206352a6" style="color:var(--c-ink-2);font-weight:bold;background:var(--c-line);padding:2px 6px;border-radius:var(--r-sm);font-size:0.75rem;">N/A</span>';
      if (resp === "sim") {
        badge = '<span data-visual-print="b9c51af1ae53" style="color:var(--c-ok);font-weight:bold;background:var(--c-line);padding:2px 6px;border-radius:var(--r-sm);font-size:0.75rem;">Aprovado</span>';
      } else if (resp === "nao") {
        badge = '<span data-visual-print="f8173f00c953" style="color:var(--c-crit);font-weight:bold;background:var(--c-line-2);padding:2px 6px;border-radius:var(--r-sm);font-size:0.75rem;">Reprovado</span>';
      }

      let imgHtml = "";
      if (photoBase64) {
        imgHtml = `
          <div style="margin-top: 8px; display: flex; align-items: center; gap: 10px;">
            <img src="${photoBase64}" data-visual-print="35e3dd02e712" style="max-width:150px;max-height:150px;border-radius:var(--r);border:1px solid var(--c-line);cursor:pointer;" onclick="abrirFotoVisualizacao('${photoBase64}')" title="Clique para ampliar" />
            <a href="${photoBase64}" download="foto_falha_${item.id || 'falha'}.png" class="btn" data-visual-print="c97e7c9f627d" style="padding:6px 12px;font-size:0.8rem;text-decoration:none;display:inline-flex;align-items:center;gap:4px;background:var(--c-ink-2);color:white;border:none;border-radius:var(--r);cursor:pointer;font-weight:bold;">
               Baixar Foto
            </a>
          </div>
        `;
      }

      const itemDiv = document.createElement("div");
      itemDiv.style.display = "flex";
      itemDiv.style.flexDirection = "column";
      itemDiv.style.padding = "8px";
      itemDiv.style.background = "var(--c-bg)";
      itemDiv.style.borderRadius = "8px";
      itemDiv.style.border = "1px solid #f1f5f9";
      itemDiv.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span style="font-weight: 500; font-size: 0.85rem;">
            ${item.critico ? '<span data-visual-print="d41855f5c646" style="color:var(--c-orange);margin-right:4px;">●</span>' : ''}
            ${item.texto}
          </span>
          ${badge}
        </div>
        ${imgHtml}
      `;
      listDiv.appendChild(itemDiv);
    });

    secDiv.appendChild(listDiv);
    container.appendChild(secDiv);
  });

  // Segunda inspeção: o código R permanece para segregação, RR para aprovação após retrabalho.
  const second = checklists.__segunda_inspecao || null;
  if ((normRow.status_montagem === "R" || second) && normRow.finalizado_em) {
    const secondPanel = document.createElement("section");
    secondPanel.className = "vc-second-inspection";
    const resultLabel = second?.resultado === "SEGREGADO" ? "Segregado" :
      second?.resultado === "APROVADO_RETRABALHADO" ? "Retrabalhado e aprovado" : "Pendente";
    secondPanel.innerHTML = `<h3>Segunda inspeção</h3><div>Resultado: <strong>${resultLabel}</strong></div>`;
    if (second?.em) {
      const meta = document.createElement("div");
      meta.textContent = `${formatDateTime(second.em)} · ${second.por || ""}`;
      secondPanel.appendChild(meta);
    }
    if (normRow.status_montagem === "R" && isModeAllowed(normRow.etapa === "INSPECAO" ? "INSPECAO" : "MONTAGEM_POSTES")) {
      const actions = document.createElement("div");
      actions.className = "vc-second-inspection-actions";
      [["SEGREGADO", "Segregado"], ["APROVADO_RETRABALHADO", "Retrabalhado e aprovado"]].forEach(([result, label]) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "btn";
        button.textContent = label;
        button.addEventListener("click", async () => {
          actions.querySelectorAll("button").forEach((item) => item.disabled = true);
          const nextChecklists = {
            ...checklists,
            __segunda_inspecao: {
              primeira_inspecao: "R",
              resultado: result,
              em: nowIso(),
              por: state.authUser?.name || ""
            }
          };
          const nextStatus = result === "SEGREGADO" ? "R" : "RR";
          try {
            if (!supabaseClient || !normRow.id) throw new Error("Banco de inspeções indisponível.");
            const { data: savedRow, error } = await supabaseClient.from("montagem_poste")
              .update({ status_montagem: nextStatus, checklists: nextChecklists })
              .eq("id", normRow.id)
              .eq("status_montagem", "R")
              .select("id,status_montagem,checklists")
              .maybeSingle();
            if (error) throw error;
            if (!savedRow) throw new Error("O registro foi alterado por outra sessão; atualize e tente novamente.");
            const localDb = readMontagemPostesDb();
            if (localDb.postes[normRow.id]) {
              localDb.postes[normRow.id].statusMontagem = nextStatus;
              localDb.postes[normRow.id].checklists = nextChecklists;
              localDb.postes[normRow.id].pendingSync = false;
              writeMontagemPostesDb(localDb);
            }
            Object.keys(localStorage).filter((key) => key.startsWith(`${MAPA_REPORT_CACHE_PREFIX}:`) && key.includes("montagem_poste"))
              .forEach((key) => localStorage.removeItem(key));
            modal.classList.remove("modal-visible");
            showMsgBox(`Segunda inspeção salva: ${label}.`, "success");
            if (normRow.etapa === "INSPECAO") await renderInspecaoLiberados();
            else await renderMontagemPostesLiberados();
          } catch (error) {
            console.error("Erro na segunda inspeção:", error);
            showMsgBox(`Não foi possível salvar a segunda inspeção: ${error.message || error}`, "error");
            actions.querySelectorAll("button").forEach((item) => item.disabled = false);
          }
        });
        actions.appendChild(button);
      });
      secondPanel.appendChild(actions);
    }
    container.appendChild(secondPanel);
  }

  // Render global photos (fotos de recusa da VPS Storage)
  const photosContainer = document.createElement("div");
  photosContainer.id = "vcVpsPhotosContainer";
  container.appendChild(photosContainer);

  const backendUrl = getBackendUrl();
  fetch(`${backendUrl}/inspecoes/${encodeURIComponent(normRow.id)}/fotos`)
    .then(res => res.json())
    .then(resData => {
      if (resData.success && resData.data && resData.data.length > 0) {
        resData.data = resData.data.map((photo) => ({
          ...photo,
          url: new URL(photo.url, backendUrl).href
        }));
        const globalDiv = document.createElement("div");
        globalDiv.style.marginTop = "20px";
        globalDiv.style.marginBottom = "20px";
        globalDiv.innerHTML = `
          <div data-visual-print="e75870a7f29d" style="font-weight:bold;background:var(--c-line-2);padding:6px 10px;border-radius:var(--r);margin-bottom:8px;color:var(--c-crit);">
            Fotos da Inspeção / Recusa (VPS Storage)
          </div>
          <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px;">
            ${resData.data.map((photo, index) => `
              <div data-visual-print="229d879aa57d" style="display:flex;flex-direction:column;gap:8px;padding:8px;background:var(--c-bg);border:1px solid var(--c-line);border-radius:var(--r);align-items:center;" id="photo-card-${photo.id}">
                <img src="${photo.url}" style="max-width: 100%; max-height: 150px; border-radius: 6px; cursor: pointer; object-fit: cover;" onclick="abrirFotoVisualizacao('${photo.url}')" title="Clique para ampliar" />
                <div style="display: flex; gap: 6px; width: 100%;">
                  <a href="${photo.url}?download=1" download="${photo.arquivo_nome}" class="btn" data-visual-print="d7a93c0b5228" style="padding:6px 10px;font-size:0.75rem;text-decoration:none;display:inline-flex;align-items:center;gap:4px;background:var(--c-ink-2);color:white;border:none;border-radius:var(--r);cursor:pointer;font-weight:bold;flex:1;justify-content:center;box-sizing:border-box;">
                     Baixar
                  </a>
                  <button onclick="excluirFotoVps('${photo.id}')" class="btn" data-visual-print="f674b7b01160" style="padding:6px 10px;font-size:0.75rem;background:var(--c-crit);color:white;border:none;border-radius:var(--r);cursor:pointer;font-weight:bold;flex:1;display:inline-flex;align-items:center;justify-content:center;gap:4px;">
                     Excluir
                  </button>
                </div>
              </div>
            `).join("")}
          </div>
        `;
        photosContainer.appendChild(globalDiv);
      }
    })
    .catch(err => {
      console.error("Erro ao carregar fotos do Storage VPS:", err);
    });

  // Obs
  const obsContainer = document.getElementById("vcObsContainer");
  const elObs = document.getElementById("vcObservacoes");
  const obsVal = normRow.observacoes_montagem || normRow.motivo_recusa || "";
  if (obsVal) {
    elObs.textContent = obsVal;
    obsContainer.style.display = "block";
  } else {
    obsContainer.style.display = "none";
  }

  modal.classList.add("modal-visible");
};

window.excluirFotoVps = async function(photoId) {
  if (!confirm("Tem certeza que deseja excluir esta foto da VPS e do banco de dados?")) return;
  const backendUrl = getBackendUrl();
  const user = state.authUser?.name || "sistema";
  try {
    const res = await fetch(`${backendUrl}/fotos/${photoId}?usuario=${encodeURIComponent(user)}`, {
      method: "DELETE"
    });
    const data = await res.json();
    if (data.success) {
      showMsgBox("Foto excluída com sucesso.", "success");
      const card = document.getElementById(`photo-card-${photoId}`);
      if (card) card.remove();
    } else {
      showMsgBox("Erro ao excluir foto: " + data.error, "error");
    }
  } catch (err) {
    showMsgBox("Falha de rede ao conectar à API de Storage.", "error");
  }
};

/* Sequencia Setor 3 (PWA Offline-First Feature) */

window.readProgS3S4Db = function() {
  try {
    const raw = localStorage.getItem("pwa_prog_s3_s4_v1");
    return raw ? JSON.parse(raw) : { programacoes: {} };
  } catch (err) {
    return { programacoes: {} };
  }
};

window.writeProgS3S4Db = function(db) {
  localStorage.setItem("pwa_prog_s3_s4_v1", JSON.stringify(db));
};

window.getModelosForFormaS3 = function(forma) {
  return ["", ...getProductionModelOptions(forma, "Setor 3")];
};

window.renderSequenciaS3 = async function() {
  const listContainer = el.seqS3List;
  if (!listContainer) return;

  const selectedDate = el.seqS3Data?.value || todayYmd();
  listContainer.innerHTML = '<div class="muted text-center" style="padding: 20px; width: 100%;">Carregando programações...</div>';

  let localDb = readProgS3S4Db();
  let savedModels = {};

  // Tenta buscar no Supabase se online
  if (supabaseClient && navigator.onLine) {
    try {
      const { data, error } = await supabaseClient
        .from("prog_s3_s4")
        .select("forma, modelo")
        .eq("data", selectedDate)
        .eq("setor", "Setor 3");

      if (!error && data) {
        data.forEach(item => {
          savedModels[item.forma] = item.modelo || "";

          const cacheKey = `${selectedDate}||${item.forma}||Setor 3`;
          localDb.programacoes[cacheKey] = {
            data: selectedDate,
            forma: item.forma,
            setor: "Setor 3",
            modelo: item.modelo || "",
            pendingSync: false
          };
        });
        writeProgS3S4Db(localDb);
      }
    } catch (err) {
      console.error("Erro ao carregar do servidor:", err);
    }
  }

  // Preenche a partir do cache local se offline
  const prefix = `${selectedDate}||`;
  Object.keys(localDb.programacoes || {}).forEach(key => {
    if (key.startsWith(prefix) && key.endsWith("||Setor 3")) {
      const entry = localDb.programacoes[key];
      if (savedModels[entry.forma] === undefined) {
        savedModels[entry.forma] = entry.modelo || "";
      }
    }
  });

  // Renderiza formas SC01 a SC52
  listContainer.innerHTML = "";
  const shapesCount = 52;

  for (let i = 1; i <= shapesCount; i++) {
    const formaName = "SC" + String(i).padStart(2, "0");
    const selectedModel = savedModels[formaName] || "";
    const options = getModelosForFormaS3(formaName);

    let selectHtml = `<select class="seq-s3-select" data-forma="${formaName}">`;
    options.forEach(opt => {
      const label = opt === "" ? "Sem Produção (Vazio)" : opt;
      const isSelected = selectedModel === opt ? "selected" : "";
      selectHtml += `<option value="${opt}" ${isSelected}>${label}</option>`;
    });
    selectHtml += `</select>`;

    const div = document.createElement("div");
    div.className = "seq-s3-item seq-s3-row";
    div.dataset.forma = formaName;
    div.innerHTML = `
      <div class="seq-s3-forma-badge">${formaName}</div>
      <div class="seq-s3-select-wrapper">
        ${selectHtml}
        <span class="seq-s3-arrow">▼</span>
      </div>
    `;
    listContainer.appendChild(div);
  }

  updateSeqS3TotalCount();
};

window.updateSeqS3TotalCount = function() {
  const rows = document.querySelectorAll(".seq-s3-row");
  let activeCount = 0;
  rows.forEach(row => {
    if (row.style.display !== "none") {
      activeCount++;
    }
  });
  const elTotal = document.getElementById("seqS3TotalCount");
  if (elTotal) elTotal.textContent = activeCount;
};

window.filterSequenciaS3 = function() {
  const query = el.seqS3Search?.value?.trim().toUpperCase() || "";
  const rows = document.querySelectorAll(".seq-s3-row");

  rows.forEach(row => {
    const forma = row.dataset.forma || "";
    if (forma.toUpperCase().includes(query)) {
      row.style.display = "";
    } else {
      row.style.display = "none";
    }
  });

  updateSeqS3TotalCount();
};

window.saveSequenciaS3 = async function() {
  const selectedDate = el.seqS3Data?.value;
  if (!selectedDate) {
    showMsgBox("Selecione a data da programação.", "error");
    return;
  }

  const selects = document.querySelectorAll(".seq-s3-select");
  const localDb = readProgS3S4Db();
  let syncPromises = [];
  let isNetworkFailure = false;
  let savedCount = 0;

  // Mostra modal de carregamento
  const loadingModal = document.getElementById("loadingModal");
  if (loadingModal) {
    loadingModal.querySelector(".loading-msg").textContent = "Salvando programação, aguarde...";
    loadingModal.classList.add("modal-visible");
  }

  for (const select of selects) {
    const forma = select.dataset.forma;
    const modelo = select.value;
    const cacheKey = `${selectedDate}||${forma}||Setor 3`;

    // Atualiza cache local
    localDb.programacoes[cacheKey] = {
      data: selectedDate,
      forma: forma,
      setor: "Setor 3",
      modelo: modelo,
      pendingSync: false
    };

    if (supabaseClient && navigator.onLine) {
      const p = supabaseClient
        .from("prog_s3_s4")
        .upsert({
          data: selectedDate,
          forma: forma,
          setor: "Setor 3",
          modelo: modelo
        }, { onConflict: "data,forma,setor" })
        .then(({ error }) => {
          if (error) {
            console.error(`Erro ao salvar fôrma ${forma}:`, error.message);
            localDb.programacoes[cacheKey].pendingSync = true;
          } else {
            savedCount++;
          }
        })
        .catch(err => {
          console.error(err);
          isNetworkFailure = true;
          localDb.programacoes[cacheKey].pendingSync = true;
        });
      syncPromises.push(p);
    } else {
      localDb.programacoes[cacheKey].pendingSync = true;
    }
  }

  if (syncPromises.length > 0) {
    await Promise.all(syncPromises);
  }

  writeProgS3S4Db(localDb);

  if (loadingModal) {
    loadingModal.classList.remove("modal-visible");
  }

  if (isNetworkFailure || !navigator.onLine) {
    setSyncStatus("warn", "Programação salva localmente (sem sinal de rede). Sincronizando em background.");
    showMsgBox("Programação salva localmente devido à falta de sinal. O sistema sincronizará assim que retornar online.", "success");
  } else {
    setSyncStatus("ok", "Programação Setor 3 salva e sincronizada com sucesso!");
    showMsgBox("Programação do Setor 3 salva com sucesso no banco de dados!", "success");
  }

  setMode("HUB");
};


// =========================================================
// MODO ODIN - FUNÇÕES AUXILIARES DE CANCELAMENTO
// =========================================================
async function cancelarOuDesprogramarOdin(forma, setor, card) {
  await cancelarConcretagemOdin(forma, setor, card);
}

// =========================================================
// DINAMIC SW VERSION BADGE LOADER
// =========================================================
async function updateSwVersionBadge() {
  const badge = document.getElementById("swVersionBadge");
  if (!badge) return;

  // Add click to force reload/update
  badge.title = "Clique para forçar atualização do app";
  badge.style.cursor = "pointer";
  if (!badge.dataset.listenerBound) {
    badge.dataset.listenerBound = "true";
    badge.addEventListener("click", async () => {
      if (confirm("Deseja forçar a atualização deste aplicativo para a versão mais recente?")) {
        badge.textContent = "Atualizando...";
        if (navigator.serviceWorker) {
          try {
            const registrations = await navigator.serviceWorker.getRegistrations();
            for (let reg of registrations) {
              await reg.unregister();
            }
          } catch(e) {}
        }
        if ("caches" in window) {
          try {
            const keys = await caches.keys();
            await Promise.all(
              keys
                .filter((key) => key.includes("mapa-concretagem"))
                .map((key) => caches.delete(key))
            );
          } catch(e) {}
        }
        window.location.replace(`./index.html?cache-reset=v5.31&ts=${Date.now()}`);
      }
    });
  }

  try {
    const response = await fetch("sw.js?v=" + Date.now(), { cache: "no-store" });
    if (response.ok) {
      const text = await response.text();
      const match = text.match(/CACHE_NAME\s*=\s*["']mapa-concretagem(?:-teste)?-v([^"']+)["']/);
      if (match && match[1]) {
        badge.textContent = `v${match[1]}`;
        badge.style.display = "inline-block";
        return;
      }
    }
  } catch (e) {
    console.warn("Erro ao buscar versão do SW:", e);
  }
  // Fallback
  badge.textContent = "v5.31";
  badge.style.display = "inline-block";
}
